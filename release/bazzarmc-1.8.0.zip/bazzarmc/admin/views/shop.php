<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_cat_options   = BMC_Catalog::category_options();
$bmc_sort_options  = BMC_Settings::sort_options();
$bmc_icon_options  = BMC_Catalog::icon_options();
$bmc_cat_selected  = array_map( 'absint', (array) $settings['shop_categories'] );
$bmc_sort_selected = array_map( 'sanitize_key', (array) $settings['filter_sort_options'] );

BMC_Admin::form_open( 'shop' );

BMC_Admin::section_open(
	'ویترین محصولات',
	'فهرست محصولات ووکامرس با نوار فیلتر دسته‌بندی، کارت محصول و پنجرهٔ مشاهدهٔ سریع. این بخش با شورت‌کد <code>[bazzarmc_shop]</code> یا ویجت «ویترین محصولات» در المنتور روی هر صفحه‌ای قرار می‌گیرد.'
);

BMC_Admin::row( 'فعال‌سازی ویترین', BMC_Admin::toggle( 'shop_enabled', $settings['shop_enabled'], 'ویترین و کارت محصول BazzarMc فعال باشد' ), 'اگر خاموش شود، شورت‌کدها و ویجت‌های ویترین پیام غیرفعال‌بودن نمایش می‌دهند.' );

BMC_Admin::row(
	'منبع محصولات',
	BMC_Admin::select(
		'shop_source',
		$settings['shop_source'],
		array(
			'all'   => 'همهٔ محصولات منتشرشده',
			'ranks' => 'فقط محصولات دارای رنک (ماینکرافت یا دستی)',
			'mc'    => 'فقط رنک‌های همگام‌شده از سرور ماینکرافت',
			'tag'   => 'فقط محصولات با برچسب مشخص',
		)
	),
	'محصولات پنهان (catalog visibility) و رنک‌های پایین‌تر از رنک کاربر همیشه از فهرست حذف می‌شوند.'
);

BMC_Admin::row( 'برچسب منبع', BMC_Admin::input( 'shop_source_tag', $settings['shop_source_tag'], array( 'dir' => 'ltr', 'placeholder' => 'rank-vip' ) ), 'نامک (slug) برچسب محصول؛ فقط وقتی «منبع محصولات» روی برچسب باشد.' );

BMC_Admin::row( 'صفحهٔ فروشگاه', BMC_Admin::page_select( 'page_shop', $settings['page_shop'] ), 'برای بازگشت از صفحهٔ تکی محصول و دکمه‌های «فروشگاه» استفاده می‌شود؛ اگر خالی باشد، صفحهٔ فروشگاه ووکامرس به‌کار می‌رود.' );

if ( $bmc_cat_options ) {
	echo '<div class="bmc-row"><div class="bmc-row__label"><label>دسته‌بندی‌های نوار فیلتر</label><span class="bmc-row__hint">خالی = همهٔ دسته‌بندی‌های سطح اول.</span></div><div class="bmc-row__field"><div class="bmc-checkbox-grid bmc-checkbox-grid--scroll">';

	foreach ( $bmc_cat_options as $bmc_term_id => $bmc_term_label ) {
		printf(
			'<label class="bmc-check"><input type="checkbox" name="shop_categories[]" value="%1$d" %2$s /> <span>%3$s</span></label>',
			(int) $bmc_term_id,
			checked( in_array( (int) $bmc_term_id, $bmc_cat_selected, true ), true, false ),
			esc_html( $bmc_term_label )
		);
	}

	echo '</div></div></div>';
} else {
	echo '<div class="bmc-note">' . bmc_get_icon( 'info', array( 'size' => 16 ) ) . ' هنوز دسته‌بندی محصولی ساخته نشده است؛ نوار فیلتر فقط گزینهٔ «همه» را نشان می‌دهد.</div>';
}

BMC_Admin::row( 'عمق دسته‌بندی‌ها', '<input type="number" class="bmc-input bmc-input--sm" name="shop_category_depth" min="1" max="4" value="' . esc_attr( (int) $settings['shop_category_depth'] ) . '" />', '۱ = فقط خود دسته‌ها، ۲ = همراه با زیردسته‌ها.' );
BMC_Admin::row( 'پنهان‌کردن دستهٔ خالی', BMC_Admin::toggle( 'shop_hide_empty_cats', $settings['shop_hide_empty_cats'], 'دسته‌های بدون محصول در فیلتر نشان داده نشوند' ) );

BMC_Admin::row( 'شامل‌کردن محصولات (شناسه)', BMC_Admin::input( 'shop_include', $settings['shop_include'], array( 'dir' => 'ltr', 'placeholder' => '12,18,44' ) ), 'خالی = بدون محدودیت. شناسه‌ها با کاما جدا شوند.' );
BMC_Admin::row( 'حذف محصولات (شناسه)', BMC_Admin::input( 'shop_exclude', $settings['shop_exclude'], array( 'dir' => 'ltr', 'placeholder' => '7,9' ) ), 'این شناسه‌ها همیشه از ویترین حذف می‌شوند.' );

BMC_Admin::row( 'تعداد در هر صفحه', '<input type="number" class="bmc-input bmc-input--sm" name="shop_per_page" min="1" max="96" value="' . esc_attr( (int) $settings['shop_per_page'] ) . '" />' );

BMC_Admin::row(
	'ستون‌ها (دسکتاپ / تبلت / موبایل)',
	'<div class="bmc-inline">'
		. '<input type="number" class="bmc-input bmc-input--sm" name="shop_columns" min="1" max="6" value="' . esc_attr( (int) $settings['shop_columns'] ) . '" />'
		. '<input type="number" class="bmc-input bmc-input--sm" name="shop_columns_tablet" min="1" max="5" value="' . esc_attr( (int) $settings['shop_columns_tablet'] ) . '" />'
		. '<input type="number" class="bmc-input bmc-input--sm" name="shop_columns_mobile" min="1" max="3" value="' . esc_attr( (int) $settings['shop_columns_mobile'] ) . '" />'
		. '</div>',
	'هر ویجت المنتور می‌تواند این مقدارها را برای خودش تغییر دهد.'
);

BMC_Admin::row( 'فاصلهٔ بین کارت‌ها (پیکسل)', '<input type="number" class="bmc-input bmc-input--sm" name="shop_gap" min="0" max="80" value="' . esc_attr( (int) $settings['shop_gap'] ) . '" />' );

BMC_Admin::row(
	'صفحه‌بندی',
	BMC_Admin::select(
		'shop_pagination',
		$settings['shop_pagination'],
		array(
			'numbers'   => 'شمارهٔ صفحه',
			'load_more' => 'دکمهٔ «نمایش بیشتر»',
			'none'      => 'بدون صفحه‌بندی',
		)
	)
);

BMC_Admin::row( 'متن دکمهٔ نمایش بیشتر', BMC_Admin::input( 'shop_load_more_text', $settings['shop_load_more_text'] ) );
BMC_Admin::row( 'عنوان ویترین', BMC_Admin::input( 'shop_heading', $settings['shop_heading'], array( 'placeholder' => 'فروشگاه سرور' ) ), 'خالی = بدون عنوان.' );
BMC_Admin::row( 'آیکون عنوان', BMC_Admin::select( 'shop_heading_icon', $settings['shop_heading_icon'], $bmc_icon_options ) );

BMC_Admin::row( 'شمارندهٔ نتایج', BMC_Admin::toggle( 'shop_show_count', $settings['shop_show_count'], 'تعداد محصولات نمایش‌داده‌شده بالای فهرست نوشته شود' ) );
BMC_Admin::row( 'متن شمارنده', BMC_Admin::input( 'shop_count_text', $settings['shop_count_text'] ), 'متغیرها: <code>{shown}</code> <code>{total}</code>' );
BMC_Admin::row( 'متن حالت خالی', BMC_Admin::textarea( 'shop_empty_text', (string) $settings['shop_empty_text'], 2 ) );
BMC_Admin::row( 'فیلتر زنده (AJAX)', BMC_Admin::toggle( 'shop_ajax', $settings['shop_ajax'], 'بدون رفرش صفحه، نتایج بلافاصله به‌روز شوند' ), 'اگر خاموش باشد، فیلترها با پیوند و فرم GET کار می‌کنند.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'نوار فیلتر دسته‌بندی', 'نوار فیلتر از دسته‌بندی‌های محصول ووکامرس ساخته می‌شود و جدا از کارت محصول است؛ می‌توانید آن را با ویجت «نوار فیلتر محصولات» در المنتور جای دیگری بگذارید.' );

BMC_Admin::row( 'نمایش نوار فیلتر', BMC_Admin::toggle( 'filter_enabled', $settings['filter_enabled'], 'نوار فیلتر بالای ویترین نمایش داده شود' ) );

BMC_Admin::row(
	'سبک فیلتر',
	BMC_Admin::select(
		'filter_style',
		$settings['filter_style'],
		array(
			'pills'  => 'دکمه‌های گرد (پیشنهادی)',
			'tabs'   => 'زبانه‌ای',
			'chips'  => 'چیپس فشرده',
			'select' => 'فهرست کشویی',
		)
	)
);

BMC_Admin::row(
	'جای نوار فیلتر',
	BMC_Admin::select(
		'filter_position',
		$settings['filter_position'],
		array(
			'top'  => 'بالای محصولات (تمام‌پهنا)',
			'side' => 'کنار محصولات (ستون کناری چسبان)',
		)
	)
);

BMC_Admin::row( 'عنوان نوار فیلتر', BMC_Admin::input( 'filter_title', $settings['filter_title'], array( 'placeholder' => 'دسته‌بندی‌ها' ) ), 'خالی = بدون عنوان.' );
BMC_Admin::row( 'آیکون نوار فیلتر', BMC_Admin::select( 'filter_icon', $settings['filter_icon'], $bmc_icon_options ) );
BMC_Admin::row( 'گزینهٔ «همه»', BMC_Admin::toggle( 'filter_show_all', $settings['filter_show_all'], 'اولین گزینه همهٔ محصولات باشد' ) );
BMC_Admin::row( 'متن گزینهٔ «همه»', BMC_Admin::input( 'filter_all_label', $settings['filter_all_label'] ) );
BMC_Admin::row( 'شمارش محصولات دسته', BMC_Admin::toggle( 'filter_show_counts', $settings['filter_show_counts'], 'تعداد محصولات هر دسته کنار نام آن نمایش داده شود' ) );
BMC_Admin::row( 'تصویر دسته', BMC_Admin::toggle( 'filter_show_thumb', $settings['filter_show_thumb'], 'تصویر بندانگشتی دسته کنار نام آن نمایش داده شود' ) );
BMC_Admin::row( 'چسبان در اسکرول', BMC_Admin::toggle( 'filter_sticky', $settings['filter_sticky'], 'نوار فیلتر هنگام اسکرول در جای خود بماند' ) );

BMC_Admin::row( 'مرتب‌سازی', BMC_Admin::toggle( 'filter_show_sort', $settings['filter_show_sort'], 'فهرست مرتب‌سازی در نوار فیلتر باشد' ) );
BMC_Admin::row( 'برچسب مرتب‌سازی', BMC_Admin::input( 'filter_sort_label', $settings['filter_sort_label'] ) );

echo '<div class="bmc-row"><div class="bmc-row__label"><label>گزینه‌های مرتب‌سازی</label><span class="bmc-row__hint">فقط گزینه‌های انتخاب‌شده در فهرست کشویی نشان داده می‌شوند.</span></div><div class="bmc-row__field"><div class="bmc-checkbox-grid">';

foreach ( $bmc_sort_options as $bmc_sort_key => $bmc_sort_label ) {
	printf(
		'<label class="bmc-check"><input type="checkbox" name="filter_sort_options[]" value="%1$s" %2$s /> <span>%3$s</span></label>',
		esc_attr( $bmc_sort_key ),
		checked( in_array( (string) $bmc_sort_key, $bmc_sort_selected, true ), true, false ),
		esc_html( $bmc_sort_label )
	);
}

echo '</div></div></div>';

BMC_Admin::row( 'مرتب‌سازی پیش‌فرض', BMC_Admin::select( 'filter_default_sort', $settings['filter_default_sort'], $bmc_sort_options ) );

BMC_Admin::row( 'جست‌وجو', BMC_Admin::toggle( 'filter_show_search', $settings['filter_show_search'], 'جعبهٔ جست‌وجوی محصول در نوار فیلتر باشد' ) );
BMC_Admin::row( 'placeholder جست‌وجو', BMC_Admin::input( 'filter_search_placeholder', $settings['filter_search_placeholder'] ) );
BMC_Admin::row( 'حداقل نویسهٔ جست‌وجوی زنده', '<input type="number" class="bmc-input bmc-input--sm" name="filter_search_min" min="1" max="8" value="' . esc_attr( (int) $settings['filter_search_min'] ) . '" />', 'تا رسیدن به این تعداد نویسه، جست‌وجوی خودکار انجام نمی‌شود.' );

BMC_Admin::row( 'دکمهٔ پاک‌کردن', BMC_Admin::toggle( 'filter_show_reset', $settings['filter_show_reset'], 'دکمهٔ بازنشانی فیلترها نمایش داده شود' ) );
BMC_Admin::row( 'متن دکمهٔ پاک‌کردن', BMC_Admin::input( 'filter_reset_text', $settings['filter_reset_text'] ) );

BMC_Admin::section_close();

BMC_Admin::section_open( 'کارت محصول', 'کارت محصول بخشی جدا از نوار فیلتر است؛ با ویجت «کارت محصول» در المنتور یا شورت‌کد <code>[bazzarmc_product_card id="123"]</code> تک‌کارت هم می‌توان ساخت.' );

BMC_Admin::row( 'تصویر محصول', BMC_Admin::toggle( 'card_show_image', $settings['card_show_image'], 'تصویر محصول در کارت نمایش داده شود' ) );

BMC_Admin::row(
	'نسبت تصویر',
	BMC_Admin::select(
		'card_image_ratio',
		$settings['card_image_ratio'],
		array(
			'auto' => 'خودکار (اندازهٔ اصلی تصویر)',
			'1:1'  => 'مربع ۱:۱',
			'4:3'  => 'افقی ۴:۳',
			'3:4'  => 'عمودی ۳:۴',
			'16:9' => 'پهن ۱۶:۹',
		)
	)
);

BMC_Admin::row( 'دسته‌بندی در کارت', BMC_Admin::toggle( 'card_show_category', $settings['card_show_category'], 'نام دسته بالای عنوان نمایش داده شود' ) );
BMC_Admin::row( 'قیمت', BMC_Admin::toggle( 'card_show_price', $settings['card_show_price'], 'قیمت محصول در کارت نمایش داده شود' ) );
BMC_Admin::row( 'چکیده', BMC_Admin::toggle( 'card_show_excerpt', $settings['card_show_excerpt'], 'توضیح کوتاه (یا ابتدای توضیحات) نمایش داده شود' ) );
BMC_Admin::row( 'تعداد واژهٔ چکیده', '<input type="number" class="bmc-input bmc-input--sm" name="card_excerpt_words" min="0" max="80" value="' . esc_attr( (int) $settings['card_excerpt_words'] ) . '" />', 'صفر = چکیده حذف شود.' );
BMC_Admin::row( 'امتیاز کاربران', BMC_Admin::toggle( 'card_show_rating', $settings['card_show_rating'], 'ستارهٔ امتیاز و تعداد رای نمایش داده شود' ) );
BMC_Admin::row( 'برچسب تخفیف', BMC_Admin::toggle( 'card_show_sale_badge', $settings['card_show_sale_badge'], 'برچسب تخفیف با درصد روی تصویر باشد' ) );
BMC_Admin::row( 'متن برچسب تخفیف', BMC_Admin::input( 'card_sale_badge_text', $settings['card_sale_badge_text'] ) );
BMC_Admin::row( 'برچسب رنک', BMC_Admin::toggle( 'card_show_rank_badge', $settings['card_show_rank_badge'], 'نام رنک ماینکرافت روی تصویر محصول باشد' ) );
BMC_Admin::row( 'وضعیت موجودی', BMC_Admin::toggle( 'card_show_stock', $settings['card_show_stock'], 'موجودی انبار در کارت نوشته شود' ) );
BMC_Admin::row( 'اعتبار رنک', BMC_Admin::toggle( 'card_show_meta', $settings['card_show_meta'], 'مدت اعتبار رنک (روز) در کارت نمایش داده شود' ) );

BMC_Admin::row( 'متن دکمهٔ خرید', BMC_Admin::input( 'card_button_text', $settings['card_button_text'] ) );
BMC_Admin::row( 'متن دکمهٔ محصول متغیر', BMC_Admin::input( 'card_button_text_variable', $settings['card_button_text_variable'] ), 'برای محصولاتی که variation دارند.' );
BMC_Admin::row( 'متن دکمهٔ ناموجود', BMC_Admin::input( 'card_button_text_soldout', $settings['card_button_text_soldout'] ) );
BMC_Admin::row( 'آیکون دکمهٔ خرید', BMC_Admin::select( 'card_button_icon', $settings['card_button_icon'], $bmc_icon_options ) );
BMC_Admin::row( 'دکمهٔ خرید مستقیم', BMC_Admin::toggle( 'card_buy_now', $settings['card_buy_now'], 'دکمهٔ دوم: افزودن به سبد و رفتن مستقیم به صفحهٔ پرداخت' ) );
BMC_Admin::row( 'متن خرید مستقیم', BMC_Admin::input( 'card_buy_now_text', $settings['card_buy_now_text'] ) );

BMC_Admin::row(
	'چینش متن کارت',
	BMC_Admin::select(
		'card_align',
		$settings['card_align'],
		array(
			'right'  => 'راست‌چین',
			'center' => 'وسط‌چین',
		)
	)
);

BMC_Admin::row(
	'افکت هاور',
	BMC_Admin::select(
		'card_hover',
		$settings['card_hover'],
		array(
			'lift' => 'بلندشدن کارت',
			'glow' => 'درخشش حاشیه',
			'none' => 'بدون افکت',
		)
	)
);

BMC_Admin::row( 'گردی گوشهٔ کارت (پیکسل)', '<input type="number" class="bmc-input bmc-input--sm" name="card_radius" min="0" max="48" value="' . esc_attr( (int) $settings['card_radius'] ) . '" />' );

BMC_Admin::row(
	'کلیک روی کارت',
	BMC_Admin::select(
		'card_click',
		$settings['card_click'],
		array(
			'quickview' => 'بازشدن پنجرهٔ مشاهدهٔ سریع (پیشنهادی)',
			'single'    => 'رفتن به صفحهٔ تکی محصول',
			'none'      => 'بدون عمل (فقط دکمهٔ خرید)',
		)
	),
	'کلیک روی <strong>هر نقطهٔ کارت به‌جز دکمهٔ خرید</strong> این کار را انجام می‌دهد.'
);

BMC_Admin::row( 'راهنمای مشاهدهٔ سریع', BMC_Admin::toggle( 'card_qv_hint', $settings['card_qv_hint'], 'برچسب «مشاهدهٔ سریع» هنگام هاور روی تصویر ظاهر شود' ) );

BMC_Admin::section_close();

BMC_Admin::section_open( 'پنجرهٔ مشاهدهٔ سریع (Quick View)', 'با کلیک روی کارت (به‌جز دکمهٔ خرید) پنجره‌ای باز می‌شود که توضیحات، ویژگی‌ها و دکمهٔ افزودن به سبد خرید را نشان می‌دهد.' );

BMC_Admin::row( 'فعال‌سازی پنجره', BMC_Admin::toggle( 'qv_enabled', $settings['qv_enabled'], 'پنجرهٔ مشاهدهٔ سریع فعال باشد' ), 'اگر خاموش شود، کلیک روی کارت طبق «کلیک روی کارت» به صفحهٔ تکی می‌رود.' );
BMC_Admin::row( 'پهنای پنجره (پیکسل)', '<input type="number" class="bmc-input bmc-input--sm" name="qv_width" min="360" max="1400" value="' . esc_attr( (int) $settings['qv_width'] ) . '" />', 'در موبایل پنجره تمام‌صفحه می‌شود.' );
BMC_Admin::row( 'عنوان پنجره', BMC_Admin::input( 'qv_title_text', $settings['qv_title_text'] ), 'هنگام بارگذاری محصول، نام محصول جای آن می‌نشیند.' );
BMC_Admin::row( 'تصویر بزرگ', BMC_Admin::toggle( 'qv_show_image', $settings['qv_show_image'], 'تصویر بزرگ محصول نمایش داده شود' ) );
BMC_Admin::row( 'قیمت', BMC_Admin::toggle( 'qv_show_price', $settings['qv_show_price'], 'قیمت در پنجره نمایش داده شود' ) );
BMC_Admin::row( 'جدول اطلاعات', BMC_Admin::toggle( 'qv_show_meta', $settings['qv_show_meta'], 'دسته‌بندی‌ها، شناسهٔ محصول و وضعیت موجودی نمایش داده شود' ) );
BMC_Admin::row( 'توضیح کوتاه', BMC_Admin::toggle( 'qv_show_excerpt', $settings['qv_show_excerpt'], 'توضیح کوتاه محصول نمایش داده شود' ) );
BMC_Admin::row( 'توضیحات کامل', BMC_Admin::toggle( 'qv_show_description', $settings['qv_show_description'], 'توضیحات کامل محصول در پایین پنجره نمایش داده شود' ) );
BMC_Admin::row( 'ویژگی‌ها (Attributes)', BMC_Admin::toggle( 'qv_show_attributes', $settings['qv_show_attributes'], 'جدول ویژگی‌های محصول نمایش داده شود' ) );
BMC_Admin::row( 'اطلاعات رنک', BMC_Admin::toggle( 'qv_show_rank', $settings['qv_show_rank'], 'نام رنک و مدت اعتبار آن در پنجره نوشته شود' ) );
BMC_Admin::row( 'دکمهٔ افزودن به سبد', BMC_Admin::toggle( 'qv_show_add_to_cart', $settings['qv_show_add_to_cart'], 'فرم افزودن به سبد خرید (با انتخاب variation) داخل پنجره باشد' ) );
BMC_Admin::row( 'پیوند صفحهٔ تکی', BMC_Admin::toggle( 'qv_show_single_link', $settings['qv_show_single_link'], 'پیوند «دیدن صفحهٔ کامل محصول» در پایین پنجره باشد' ) );
BMC_Admin::row( 'متن پیوند صفحهٔ تکی', BMC_Admin::input( 'qv_single_link_text', $settings['qv_single_link_text'] ) );
BMC_Admin::row( 'متن دکمهٔ بستن', BMC_Admin::input( 'qv_close_text', $settings['qv_close_text'] ) );
BMC_Admin::row( 'متن بارگذاری', BMC_Admin::input( 'qv_loading_text', $settings['qv_loading_text'] ) );
BMC_Admin::row( 'متن خطا', BMC_Admin::input( 'qv_error_text', $settings['qv_error_text'] ) );

BMC_Admin::section_close();

BMC_Admin::section_open( 'صفحهٔ تکی محصول', 'می‌توانید صفحهٔ تکی محصول ووکامرس را خاموش کنید تا کارت‌ها و پنجرهٔ مشاهدهٔ سریع جای آن را بگیرند.' );

$bmc_mode = (string) $settings['single_product_mode'];

BMC_Admin::row(
	'وضعیت صفحهٔ تکی',
	BMC_Admin::select(
		'single_product_mode',
		$bmc_mode,
		array(
			'enabled'  => 'فعال (پیش‌فرض ووکامرس)',
			'disabled' => 'غیرفعال — صفحه با خطای ۴۰۴ بسته می‌شود',
			'redirect' => 'غیرفعال با انتقال — کاربر به مقصد دیگری می‌رود',
		)
	),
	'وقتی صفحهٔ تکی بسته باشد، کلیک روی کارت به‌جای صفحهٔ محصول، پنجرهٔ مشاهدهٔ سریع را باز می‌کند و پیوند «دیدن صفحهٔ کامل» از پنجره حذف می‌شود.'
);

BMC_Admin::row(
	'مقصد انتقال',
	BMC_Admin::select(
		'single_redirect_target',
		$settings['single_redirect_target'],
		array(
			'shop' => 'صفحهٔ فروشگاه',
			'home' => 'صفحهٔ نخست',
			'page' => 'صفحهٔ دلخواه',
		)
	)
);

BMC_Admin::row( 'صفحهٔ دلخواه مقصد', BMC_Admin::page_select( 'single_redirect_page', $settings['single_redirect_page'] ) );

if ( 'enabled' !== $bmc_mode ) {
	echo '<div class="bmc-note bmc-note--warn">' . bmc_get_icon( 'warning', array( 'size' => 16 ) ) . ' صفحهٔ تکی محصول اکنون بسته است. پیوندهای قدیمی محصولات در گوگل با خطای ۴۰۴ یا انتقال مواجه می‌شوند.</div>';
}

BMC_Admin::section_close();

BMC_Admin::section_open( 'راه‌های نمایش', 'ویترین، کارت محصول و نوار فیلتر هر سه هم با شورت‌کد و هم با ویجت المنتور در دسترس هستند.' );

echo '<div class="bmc-note">' . bmc_get_icon( 'info', array( 'size' => 16 ) ) . ' شورت‌کدها: <code>[bazzarmc_shop]</code> <code>[bazzarmc_products]</code> <code>[bazzarmc_product_card id="123"]</code> <code>[bazzarmc_product_filter]</code></div>';

echo '<div class="bmc-table-wrap"><table class="bmc-table"><thead><tr><th>ویجت المنتور</th><th>کاربرد</th></tr></thead><tbody>'
	. '<tr><td>ویترین محصولات</td><td>شبکهٔ محصولات با نوار فیلتر، صفحه‌بندی و پنجرهٔ مشاهدهٔ سریع</td></tr>'
	. '<tr><td>کارت محصول</td><td>یک کارت تکی برای محصول دلخواه (تصویر، نام، قیمت، دکمهٔ خرید)</td></tr>'
	. '<tr><td>نوار فیلتر محصولات</td><td>فیلتر دسته‌بندی/جست‌وجو/مرتب‌سازی به‌صورت جدا از ویترین</td></tr>'
	. '</tbody></table></div>';

BMC_Admin::section_close();

BMC_Admin::form_close();
