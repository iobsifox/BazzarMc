<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! is_user_logged_in() || ! function_exists( 'wc_get_account_menu_items' ) ) {
	return;
}

$bmc_nav_layout = 'vertical';

do_action( 'woocommerce_before_account_navigation' );

echo '<div class="bmc-acct-nav-wrap">';

echo BMC_Public::render_account_nav(
	array(
		'layout'     => $bmc_nav_layout,
		'icons'      => true,
		'counts'     => true,
		'title'      => 'حساب کاربری',
		'title_icon' => 'manage_accounts',
	)
);

echo '</div>';

do_action( 'woocommerce_after_account_navigation' );
