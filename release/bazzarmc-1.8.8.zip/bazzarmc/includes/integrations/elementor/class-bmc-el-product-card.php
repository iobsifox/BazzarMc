<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;

class BMC_EL_Product_Card extends BMC_EL_Base {

	public function get_name() {
		return 'bmc-product-card';
	}

	public function get_title() {
		return 'کارت محصول';
	}

	public function get_icon() {
		return 'eicon-product-add-to-cart';
	}

	protected function bmc_slug() {
		return 'product-card';
	}

	protected function extra_keywords() {
		return array( 'product', 'card', 'quickview', 'add to cart', 'کارت', 'محصول', 'خرید', 'مشاهده سریع' );
	}

	protected function extra_scripts() {
		return array( 'bmc-catalog' );
	}

	private function yesno_options() {
		return array(
			''    => 'پیش‌فرض (از تنظیمات افزونه)',
			'no'  => 'خیر',
			'yes' => 'بله',
		);
	}

	protected function content_controls() {
		$this->start_controls_section(
			'bmc_sec_content',
			array(
				'label' => 'کارت محصول',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'bmc_notice',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => 'یک کارت محصول جدا از ویترین: تصویر، نام، قیمت و دکمهٔ خرید. کلیک روی هر نقطهٔ کارت به‌جز دکمهٔ خرید، پنجرهٔ مشاهدهٔ سریع (توضیحات محصول) را باز می‌کند.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_control(
			'product_id',
			array(
				'label'       => 'محصول',
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'options'     => $this->product_options(),
				'description' => 'اگر محصول در فهرست نیست، شناسهٔ آن را در کادر بعدی بنویسید.',
			)
		);

		$this->add_control(
			'product_id_manual',
			array(
				'label'   => 'شناسهٔ دستی محصول',
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'default' => '',
			)
		);

		$this->add_control(
			'card_show_image',
			array(
				'label'   => 'تصویر محصول',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_image_ratio',
			array(
				'label'   => 'نسبت تصویر',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''     => 'پیش‌فرض',
					'auto' => 'خودکار',
					'1:1'  => 'مربع ۱:۱',
					'4:3'  => 'افقی ۴:۳',
					'3:4'  => 'عمودی ۳:۴',
					'16:9' => 'پهن ۱۶:۹',
				),
			)
		);

		$this->add_control(
			'card_show_category',
			array(
				'label'   => 'دسته‌بندی',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_show_price',
			array(
				'label'   => 'قیمت',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_show_excerpt',
			array(
				'label'   => 'چکیدهٔ توضیحات',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_excerpt_words',
			array(
				'label'   => 'تعداد واژهٔ چکیده',
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 80,
				'default' => '',
			)
		);

		$this->add_control(
			'card_show_rating',
			array(
				'label'   => 'امتیاز کاربران',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_show_sale_badge',
			array(
				'label'   => 'برچسب تخفیف',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_show_rank_badge',
			array(
				'label'   => 'برچسب رنک ماینکرافت',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_show_stock',
			array(
				'label'   => 'وضعیت موجودی',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_show_meta',
			array(
				'label'   => 'مدت اعتبار رنک',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_button_text',
			array(
				'label'   => 'متن دکمهٔ خرید',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'card_button_text_variable',
			array(
				'label'   => 'متن دکمهٔ محصول متغیر',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'card_button_text_soldout',
			array(
				'label'   => 'متن دکمهٔ ناموجود',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'card_button_icon',
			array(
				'label'   => 'آیکون دکمهٔ خرید',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'card_buy_now',
			array(
				'label'   => 'دکمهٔ خرید مستقیم',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_buy_now_text',
			array(
				'label'   => 'متن خرید مستقیم',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'card_align',
			array(
				'label'   => 'چینش متن کارت',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''       => 'پیش‌فرض',
					'right'  => 'راست‌چین',
					'center' => 'وسط‌چین',
				),
			)
		);

		$this->add_control(
			'card_hover',
			array(
				'label'   => 'افکت هاور',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''     => 'پیش‌فرض',
					'lift' => 'بلندشدن کارت',
					'glow' => 'درخشش حاشیه',
					'none' => 'بدون افکت',
				),
			)
		);

		$this->add_control(
			'card_radius',
			array(
				'label'   => 'گردی گوشهٔ کارت',
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 48,
				'default' => '',
			)
		);

		$this->add_control(
			'card_click',
			array(
				'label'       => 'کلیک روی کارت',
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'options'     => array(
					''          => 'پیش‌فرض',
					'quickview' => 'پنجرهٔ مشاهدهٔ سریع',
					'single'    => 'صفحهٔ تکی محصول',
					'none'      => 'بدون عمل',
				),
				'description' => 'کلیک روی هر نقطهٔ کارت به‌جز دکمهٔ خرید.',
			)
		);

		$this->add_control(
			'card_qv_hint',
			array(
				'label'   => 'راهنمای «مشاهدهٔ سریع»',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'qv_enabled',
			array(
				'label'   => 'پنجرهٔ مشاهدهٔ سریع',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'qv_width',
			array(
				'label'   => 'پهنای پنجره (پیکسل)',
				'type'    => Controls_Manager::NUMBER,
				'min'     => 360,
				'max'     => 1400,
				'default' => '',
			)
		);

		$this->add_control(
			'qv_show_description',
			array(
				'label'   => 'توضیحات کامل در پنجره',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'qv_show_attributes',
			array(
				'label'   => 'جدول ویژگی‌ها در پنجره',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'qv_show_add_to_cart',
			array(
				'label'   => 'فرم افزودن به سبد در پنجره',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'qv_show_single_link',
			array(
				'label'   => 'پیوند صفحهٔ تکی در پنجره',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'qv_single_link_text',
			array(
				'label'   => 'متن پیوند صفحهٔ تکی',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->end_controls_section();
	}

	protected function style_controls() {
		$this->start_controls_section(
			'bmc_sec_card_style',
			array(
				'label' => 'ظاهر کارت',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'card_bg',
			array(
				'label'     => 'پس‌زمینهٔ کارت',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-pcard' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'card_border_color',
			array(
				'label'     => 'رنگ حاشیهٔ کارت',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-pcard' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'card_shadow',
				'label'    => 'سایهٔ کارت',
				'selector' => '{{WRAPPER}} .bmc-pcard',
			)
		);

		$this->add_responsive_control(
			'card_body_padding',
			array(
				'label'      => 'فاصلهٔ داخلی متن کارت',
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-pcard__body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'card_max_width',
			array(
				'label'      => 'بیشترین پهنای کارت',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array(
						'min' => 180,
						'max' => 900,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-shop--single .bmc-shop__grid' => 'grid-template-columns: minmax(0, {{SIZE}}{{UNIT}});',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'card_title_typography',
				'label'    => 'تایپوگرافی نام محصول',
				'selector' => '{{WRAPPER}} .bmc-pcard__title',
			)
		);

		$this->add_control(
			'card_title_color',
			array(
				'label'     => 'رنگ نام محصول',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-pcard__title, {{WRAPPER}} .bmc-pcard__title a' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'card_price_typography',
				'label'    => 'تایپوگرافی قیمت',
				'selector' => '{{WRAPPER}} .bmc-pcard__price',
			)
		);

		$this->add_control(
			'card_price_color',
			array(
				'label'     => 'رنگ قیمت',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-pcard__price, {{WRAPPER}} .bmc-pcard__price .woocommerce-Price-amount' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'card_excerpt_typography',
				'label'    => 'تایپوگرافی چکیده',
				'selector' => '{{WRAPPER}} .bmc-pcard__excerpt',
			)
		);

		$this->add_control(
			'card_excerpt_color',
			array(
				'label'     => 'رنگ چکیده',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-pcard__excerpt' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		$this->button_style_controls( 'دکمهٔ خرید' );
	}

	private function product_options() {
		$options = array( '' => '— محصولِ صفحهٔ جاری —' );

		if ( ! class_exists( 'BMC_Catalog' ) ) {
			return $options;
		}

		foreach ( BMC_Catalog::product_options( 300 ) as $id => $label ) {
			$options[ (string) $id ] = $label;
		}

		return $options;
	}

	private function overrides( $settings ) {
		$keys = array(
			'card_show_image', 'card_image_ratio', 'card_show_category', 'card_show_price', 'card_show_excerpt',
			'card_excerpt_words', 'card_show_rating', 'card_show_sale_badge', 'card_show_rank_badge',
			'card_show_stock', 'card_show_meta', 'card_button_text', 'card_button_text_variable',
			'card_button_text_soldout', 'card_button_icon', 'card_buy_now', 'card_buy_now_text', 'card_align',
			'card_hover', 'card_radius', 'card_click', 'card_qv_hint', 'qv_enabled', 'qv_width',
			'qv_show_description', 'qv_show_attributes', 'qv_show_add_to_cart', 'qv_show_single_link',
			'qv_single_link_text',
		);

		$out = array();

		foreach ( $keys as $key ) {
			if ( ! isset( $settings[ $key ] ) || '' === $settings[ $key ] || null === $settings[ $key ] ) {
				continue;
			}

			$out[ $key ] = $settings[ $key ];
		}

		return $out;
	}

	protected function render_inner( $settings ) {
		if ( $this->woocommerce_missing() ) {
			return $this->notice( 'برای نمایش کارت محصول، ووکامرس باید فعال باشد.' );
		}

		if ( ! class_exists( 'BMC_Catalog' ) ) {
			return $this->notice( 'ماژول ویترین BazzarMc در دسترس نیست.' );
		}

		$product_id = 0;

		if ( ! empty( $settings['product_id_manual'] ) ) {
			$product_id = absint( $settings['product_id_manual'] );
		} elseif ( ! empty( $settings['product_id'] ) ) {
			$product_id = absint( $settings['product_id'] );
		}

		if ( ! $product_id ) {
			$product_id = (int) get_the_ID();
		}

		if ( ! $product_id || ! function_exists( 'wc_get_product' ) || ! wc_get_product( $product_id ) ) {
			return $this->editor_placeholder( 'محصولی برای این کارت انتخاب نشده یا محصول وجود ندارد.' );
		}

		return (string) BMC_Catalog::render_single_card( $product_id, $this->overrides( $settings ) );
	}
}
