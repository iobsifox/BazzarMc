<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Group_Control_Box_Shadow;

class BMC_EL_Shop extends BMC_EL_Base {

	public function get_name() {
		return 'bmc-shop';
	}

	public function get_title() {
		return 'ویترین محصولات';
	}

	public function get_icon() {
		return 'eicon-products';
	}

	protected function bmc_slug() {
		return 'shop';
	}

	protected function extra_keywords() {
		return array( 'shop', 'catalog', 'products', 'grid', 'quickview', 'ویترین', 'فروشگاه', 'محصول', 'کارت', 'فیلتر' );
	}

	protected function extra_scripts() {
		return array( 'bmc-catalog' );
	}

	private function yesno_options() {
		return array(
			''    => 'پیش‌فرض (از تنظیمات افزونه)',
			'no'  => 'خیر',
			'yes' => 'بله',
		);
	}

	protected function content_controls() {
		$this->start_controls_section(
			'bmc_sec_content',
			array(
				'label' => 'ویترین',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'bmc_notice',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => 'شبکهٔ محصولات ووکامرس با نوار فیلتر دسته‌بندی، کارت محصول و پنجرهٔ مشاهدهٔ سریع. کلیک روی هر نقطهٔ کارت (به‌جز دکمهٔ خرید) پنجرهٔ توضیحات محصول را باز می‌کند.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_control(
			'shop_source',
			array(
				'label'   => 'منبع محصولات',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''      => 'پیش‌فرض (از تنظیمات افزونه)',
					'all'   => 'همهٔ محصولات',
					'ranks' => 'فقط محصولات دارای رنک',
					'mc'    => 'فقط رنک‌های سرور ماینکرافت',
					'tag'   => 'فقط محصولات یک برچسب',
				),
			)
		);

		$this->add_control(
			'shop_source_tag',
			array(
				'label'     => 'برچسب (نامک)',
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'condition' => array( 'shop_source' => 'tag' ),
			)
		);

		$this->add_control(
			'shop_categories',
			array(
				'label'       => 'دسته‌بندی‌های نمایشی',
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'default'     => array(),
				'options'     => $this->category_options(),
				'description' => 'خالی = همهٔ دسته‌بندی‌های سطح اول.',
			)
		);

		$this->add_control(
			'shop_category_depth',
			array(
				'label'   => 'عمق دسته‌بندی‌ها',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''  => 'پیش‌فرض',
					'1' => '۱ — فقط خود دسته‌ها',
					'2' => '۲ — با زیردسته‌ها',
					'3' => '۳ — سه سطح',
					'4' => '۴ — چهار سطح',
				),
			)
		);

		$this->add_control(
			'shop_include',
			array(
				'label'       => 'فقط این محصولات (شناسه)',
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'description' => 'با کاما جدا کنید: ۱۲,۱۸',
			)
		);

		$this->add_control(
			'shop_exclude',
			array(
				'label'   => 'حذف این محصولات (شناسه)',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'shop_per_page',
			array(
				'label'   => 'تعداد در هر صفحه',
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 96,
				'default' => '',
			)
		);

		$this->add_responsive_control(
			'shop_columns',
			array(
				'label'   => 'تعداد ستون‌ها',
				'type'    => Controls_Manager::NUMBER,
				'min'     => 1,
				'max'     => 6,
				'default' => '',
			)
		);

		$this->add_control(
			'shop_gap',
			array(
				'label'      => 'فاصلهٔ بین کارت‌ها',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 60,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-shop__grid' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'shop_pagination',
			array(
				'label'   => 'صفحه‌بندی',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''          => 'پیش‌فرض',
					'numbers'   => 'شمارهٔ صفحه',
					'load_more' => 'دکمهٔ نمایش بیشتر',
					'none'      => 'بدون صفحه‌بندی',
				),
			)
		);

		$this->add_control(
			'shop_heading',
			array(
				'label'   => 'عنوان ویترین',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'shop_heading_icon',
			array(
				'label'     => 'آیکون عنوان',
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'condition' => array( 'shop_heading!' => '' ),
			)
		);

		$this->add_control(
			'shop_show_count',
			array(
				'label'   => 'شمارندهٔ نتایج',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'shop_count_text',
			array(
				'label'     => 'متن شمارنده',
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'condition' => array( 'shop_show_count!' => 'no' ),
			)
		);

		$this->add_control(
			'shop_empty_text',
			array(
				'label'   => 'متن حالت خالی',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'shop_load_more_text',
			array(
				'label'     => 'متن دکمهٔ نمایش بیشتر',
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'condition' => array( 'shop_pagination' => 'load_more' ),
			)
		);

		$this->add_control(
			'shop_ajax',
			array(
				'label'       => 'فیلتر زنده (AJAX)',
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'options'     => $this->yesno_options(),
				'description' => 'خیر = فیلترها با پیوند و فرم GET انجام می‌شوند.',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'bmc_sec_filter',
			array(
				'label' => 'نوار فیلتر',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'filter_enabled',
			array(
				'label'   => 'نمایش نوار فیلتر',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'filter_style',
			array(
				'label'   => 'سبک فیلتر',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''       => 'پیش‌فرض',
					'pills'  => 'دکمه‌های گرد',
					'tabs'   => 'زبانه‌ای',
					'chips'  => 'چیپس فشرده',
					'select' => 'فهرست کشویی',
				),
			)
		);

		$this->add_control(
			'filter_position',
			array(
				'label'   => 'جای نوار فیلتر',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''    => 'پیش‌فرض',
					'top' => 'بالای محصولات',
					'side' => 'ستون کناری',
				),
			)
		);

		$this->add_control(
			'filter_title',
			array(
				'label'   => 'عنوان نوار فیلتر',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'filter_icon',
			array(
				'label'   => 'آیکون نوار فیلتر',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'filter_show_all',
			array(
				'label'   => 'گزینهٔ «همه»',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'filter_all_label',
			array(
				'label'   => 'متن گزینهٔ «همه»',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'filter_show_counts',
			array(
				'label'   => 'شمارش محصولات دسته',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'filter_show_thumb',
			array(
				'label'   => 'تصویر دسته',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'filter_sticky',
			array(
				'label'   => 'چسبان در اسکرول',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'filter_show_sort',
			array(
				'label'   => 'فهرست مرتب‌سازی',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'filter_sort_label',
			array(
				'label'   => 'برچسب مرتب‌سازی',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'filter_sort_options',
			array(
				'label'    => 'گزینه‌های مرتب‌سازی',
				'type'     => Controls_Manager::SELECT2,
				'multiple' => true,
				'default'  => array(),
				'options'  => BMC_Settings::sort_options(),
			)
		);

		$this->add_control(
			'filter_default_sort',
			array(
				'label'   => 'مرتب‌سازی پیش‌فرض',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array_merge( array( '' => 'پیش‌فرض' ), BMC_Settings::sort_options() ),
			)
		);

		$this->add_control(
			'filter_show_search',
			array(
				'label'   => 'جعبهٔ جست‌وجو',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'filter_search_placeholder',
			array(
				'label'   => 'placeholder جست‌وجو',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'filter_show_reset',
			array(
				'label'   => 'دکمهٔ پاک‌کردن فیلتر',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'filter_reset_text',
			array(
				'label'   => 'متن دکمهٔ پاک‌کردن',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'bmc_sec_card',
			array(
				'label' => 'کارت محصول',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'card_show_image',
			array(
				'label'   => 'تصویر محصول',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_image_ratio',
			array(
				'label'   => 'نسبت تصویر',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''     => 'پیش‌فرض',
					'auto' => 'خودکار',
					'1:1'  => 'مربع ۱:۱',
					'4:3'  => 'افقی ۴:۳',
					'3:4'  => 'عمودی ۳:۴',
					'16:9' => 'پهن ۱۶:۹',
				),
			)
		);

		$this->add_control(
			'card_show_category',
			array(
				'label'   => 'دسته‌بندی',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_show_price',
			array(
				'label'   => 'قیمت',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_show_excerpt',
			array(
				'label'   => 'چکیدهٔ توضیحات',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_excerpt_words',
			array(
				'label'   => 'تعداد واژهٔ چکیده',
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 80,
				'default' => '',
			)
		);

		$this->add_control(
			'card_show_rating',
			array(
				'label'   => 'امتیاز کاربران',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_show_sale_badge',
			array(
				'label'   => 'برچسب تخفیف',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_sale_badge_text',
			array(
				'label'   => 'متن برچسب تخفیف',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'card_show_rank_badge',
			array(
				'label'   => 'برچسب رنک ماینکرافت',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_show_stock',
			array(
				'label'   => 'وضعیت موجودی',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_show_meta',
			array(
				'label'   => 'مدت اعتبار رنک',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_button_text',
			array(
				'label'   => 'متن دکمهٔ خرید',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'card_button_text_variable',
			array(
				'label'   => 'متن دکمهٔ محصول متغیر',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'card_button_text_soldout',
			array(
				'label'   => 'متن دکمهٔ ناموجود',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'card_button_icon',
			array(
				'label'   => 'آیکون دکمهٔ خرید',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'card_buy_now',
			array(
				'label'   => 'دکمهٔ خرید مستقیم',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_buy_now_text',
			array(
				'label'   => 'متن خرید مستقیم',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'card_align',
			array(
				'label'   => 'چینش متن کارت',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''       => 'پیش‌فرض',
					'right'  => 'راست‌چین',
					'center' => 'وسط‌چین',
				),
			)
		);

		$this->add_control(
			'card_hover',
			array(
				'label'   => 'افکت هاور',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''     => 'پیش‌فرض',
					'lift' => 'بلندشدن کارت',
					'glow' => 'درخشش حاشیه',
					'none' => 'بدون افکت',
				),
			)
		);

		$this->add_control(
			'card_click',
			array(
				'label'       => 'کلیک روی کارت',
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'options'     => array(
					''          => 'پیش‌فرض',
					'quickview' => 'پنجرهٔ مشاهدهٔ سریع',
					'single'    => 'صفحهٔ تکی محصول',
					'none'      => 'بدون عمل',
				),
				'description' => 'کلیک روی هر نقطهٔ کارت به‌جز دکمهٔ خرید.',
			)
		);

		$this->add_control(
			'card_qv_hint',
			array(
				'label'   => 'راهنمای «مشاهدهٔ سریع» روی تصویر',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'card_radius',
			array(
				'label'   => 'گردی گوشهٔ کارت',
				'type'    => Controls_Manager::NUMBER,
				'min'     => 0,
				'max'     => 48,
				'default' => '',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'bmc_sec_qv',
			array(
				'label' => 'مشاهدهٔ سریع',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'qv_enabled',
			array(
				'label'   => 'پنجرهٔ مشاهدهٔ سریع',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'qv_width',
			array(
				'label'   => 'پهنای پنجره (پیکسل)',
				'type'    => Controls_Manager::NUMBER,
				'min'     => 360,
				'max'     => 1400,
				'default' => '',
			)
		);

		$this->add_control(
			'qv_title_text',
			array(
				'label'   => 'عنوان پنجره',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'qv_show_image',
			array(
				'label'   => 'تصویر بزرگ',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'qv_show_price',
			array(
				'label'   => 'قیمت',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'qv_show_meta',
			array(
				'label'   => 'جدول اطلاعات',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'qv_show_excerpt',
			array(
				'label'   => 'توضیح کوتاه',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'qv_show_description',
			array(
				'label'   => 'توضیحات کامل',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'qv_show_attributes',
			array(
				'label'   => 'جدول ویژگی‌ها',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'qv_show_rank',
			array(
				'label'   => 'اطلاعات رنک',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'qv_show_add_to_cart',
			array(
				'label'   => 'فرم افزودن به سبد خرید',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'qv_show_single_link',
			array(
				'label'   => 'پیوند صفحهٔ تکی',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'qv_single_link_text',
			array(
				'label'   => 'متن پیوند صفحهٔ تکی',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->end_controls_section();
	}

	protected function style_controls() {
		$this->start_controls_section(
			'bmc_sec_card_style',
			array(
				'label' => 'کارت محصول',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'card_bg',
			array(
				'label'     => 'پس‌زمینهٔ کارت',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-pcard' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'card_border_color',
			array(
				'label'     => 'رنگ حاشیهٔ کارت',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-pcard' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Box_Shadow::get_type(),
			array(
				'name'     => 'card_shadow',
				'label'    => 'سایهٔ کارت',
				'selector' => '{{WRAPPER}} .bmc-pcard',
			)
		);

		$this->add_responsive_control(
			'card_padding',
			array(
				'label'      => 'فاصلهٔ داخلی متن کارت',
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-pcard__body' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'card_title_typography',
				'label'    => 'تایپوگرافی نام محصول',
				'selector' => '{{WRAPPER}} .bmc-pcard__title',
			)
		);

		$this->add_control(
			'card_title_color',
			array(
				'label'     => 'رنگ نام محصول',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-pcard__title, {{WRAPPER}} .bmc-pcard__title a' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'card_title_hover_color',
			array(
				'label'     => 'رنگ نام محصول در هاور',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-pcard__title a:hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'card_excerpt_typography',
				'label'    => 'تایپوگرافی چکیده',
				'selector' => '{{WRAPPER}} .bmc-pcard__excerpt',
			)
		);

		$this->add_control(
			'card_excerpt_color',
			array(
				'label'     => 'رنگ چکیده',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-pcard__excerpt' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'card_price_typography',
				'label'    => 'تایپوگرافی قیمت',
				'selector' => '{{WRAPPER}} .bmc-pcard__price',
			)
		);

		$this->add_control(
			'card_price_color',
			array(
				'label'     => 'رنگ قیمت',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-pcard__price, {{WRAPPER}} .bmc-pcard__price .woocommerce-Price-amount' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'card_cat_color',
			array(
				'label'     => 'رنگ دسته‌بندی',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-pcard__cat' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'card_badge_bg',
			array(
				'label'     => 'پس‌زمینهٔ برچسب تخفیف',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-pcard__badge--sale' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'card_rank_badge_color',
			array(
				'label'     => 'رنگ برچسب رنک',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-pcard__badge--rank' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'bmc_sec_filter_style',
			array(
				'label' => 'نوار فیلتر',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'filter_bg',
			array(
				'label'     => 'پس‌زمینهٔ نوار فیلتر',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-filter' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'filter_border_color',
			array(
				'label'     => 'رنگ حاشیهٔ نوار فیلتر',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-filter' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'filter_padding',
			array(
				'label'      => 'فاصلهٔ داخلی نوار فیلتر',
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-filter' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'filter_typography',
				'label'    => 'تایپوگرافی گزینه‌ها',
				'selector' => '{{WRAPPER}} .bmc-filter__item',
			)
		);

		$this->add_control(
			'filter_item_bg',
			array(
				'label'     => 'پس‌زمینهٔ گزینه',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-filter__item' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'filter_item_color',
			array(
				'label'     => 'رنگ گزینه',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-filter__item' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'filter_item_active_bg',
			array(
				'label'     => 'پس‌زمینهٔ گزینهٔ فعال',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-filter__item.is-active' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'filter_item_active_color',
			array(
				'label'     => 'رنگ گزینهٔ فعال',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-filter__item.is-active' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'filter_count_color',
			array(
				'label'     => 'رنگ شمارش دسته',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-filter__count' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'bmc_sec_qv_style',
			array(
				'label' => 'پنجرهٔ مشاهدهٔ سریع',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'qv_note',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => 'پنجرهٔ مشاهدهٔ سریع در انتهای صفحه (بیرون از قاب ویجت) ساخته می‌شود تا روی همه‌چیز قرار بگیرد؛ به همین دلیل رنگ‌هایش از پوستهٔ رنگی افزونه (تیره/روشن)، رنگ تأکیدی و قلم انتخاب‌شده در همین ویجت پیروی می‌کند. پهنای پنجره از بخش «مشاهدهٔ سریع» در همین ویجت یا از تنظیمات افزونه تغییر می‌کند.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->end_controls_section();

		$this->button_style_controls( 'دکمهٔ خرید کارت' );
	}

	private function category_options() {
		$options = array();

		if ( ! class_exists( 'BMC_Catalog' ) ) {
			return $options;
		}

		foreach ( BMC_Catalog::category_options() as $id => $label ) {
			$options[ (string) $id ] = $label;
		}

		return $options;
	}

	private function overrides( $settings ) {
		$map = array(
			'shop_source'                 => 'shop_source',
			'shop_source_tag'             => 'shop_source_tag',
			'shop_category_depth'         => 'shop_category_depth',
			'shop_include'                => 'shop_include',
			'shop_exclude'                => 'shop_exclude',
			'shop_per_page'               => 'shop_per_page',
			'shop_gap'                    => 'shop_gap',
			'shop_pagination'             => 'shop_pagination',
			'shop_heading'                => 'shop_heading',
			'shop_heading_icon'           => 'shop_heading_icon',
			'shop_show_count'             => 'shop_show_count',
			'shop_count_text'             => 'shop_count_text',
			'shop_empty_text'             => 'shop_empty_text',
			'shop_load_more_text'         => 'shop_load_more_text',
			'shop_ajax'                   => 'shop_ajax',
			'filter_enabled'              => 'filter_enabled',
			'filter_style'                => 'filter_style',
			'filter_position'             => 'filter_position',
			'filter_title'                => 'filter_title',
			'filter_icon'                 => 'filter_icon',
			'filter_show_all'             => 'filter_show_all',
			'filter_all_label'            => 'filter_all_label',
			'filter_show_counts'          => 'filter_show_counts',
			'filter_show_thumb'           => 'filter_show_thumb',
			'filter_sticky'               => 'filter_sticky',
			'filter_show_sort'            => 'filter_show_sort',
			'filter_sort_label'           => 'filter_sort_label',
			'filter_default_sort'         => 'filter_default_sort',
			'filter_show_search'          => 'filter_show_search',
			'filter_search_placeholder'   => 'filter_search_placeholder',
			'filter_show_reset'           => 'filter_show_reset',
			'filter_reset_text'           => 'filter_reset_text',
			'card_show_image'             => 'card_show_image',
			'card_image_ratio'            => 'card_image_ratio',
			'card_show_category'          => 'card_show_category',
			'card_show_price'             => 'card_show_price',
			'card_show_excerpt'           => 'card_show_excerpt',
			'card_excerpt_words'          => 'card_excerpt_words',
			'card_show_rating'            => 'card_show_rating',
			'card_show_sale_badge'        => 'card_show_sale_badge',
			'card_sale_badge_text'        => 'card_sale_badge_text',
			'card_show_rank_badge'        => 'card_show_rank_badge',
			'card_show_stock'             => 'card_show_stock',
			'card_show_meta'              => 'card_show_meta',
			'card_button_text'            => 'card_button_text',
			'card_button_text_variable'   => 'card_button_text_variable',
			'card_button_text_soldout'    => 'card_button_text_soldout',
			'card_button_icon'            => 'card_button_icon',
			'card_buy_now'                => 'card_buy_now',
			'card_buy_now_text'           => 'card_buy_now_text',
			'card_align'                  => 'card_align',
			'card_hover'                  => 'card_hover',
			'card_click'                  => 'card_click',
			'card_qv_hint'                => 'card_qv_hint',
			'card_radius'                 => 'card_radius',
			'qv_enabled'                  => 'qv_enabled',
			'qv_width'                    => 'qv_width',
			'qv_title_text'               => 'qv_title_text',
			'qv_show_image'               => 'qv_show_image',
			'qv_show_price'               => 'qv_show_price',
			'qv_show_meta'                => 'qv_show_meta',
			'qv_show_excerpt'             => 'qv_show_excerpt',
			'qv_show_description'         => 'qv_show_description',
			'qv_show_attributes'          => 'qv_show_attributes',
			'qv_show_rank'                => 'qv_show_rank',
			'qv_show_add_to_cart'         => 'qv_show_add_to_cart',
			'qv_show_single_link'         => 'qv_show_single_link',
			'qv_single_link_text'         => 'qv_single_link_text',
		);

		$out = array();

		foreach ( $map as $control => $key ) {
			if ( ! isset( $settings[ $control ] ) ) {
				continue;
			}

			$value = $settings[ $control ];

			if ( '' === $value || null === $value ) {
				continue;
			}

			if ( 'shop_gap' === $control && is_array( $value ) ) {
				$value = isset( $value['size'] ) ? (int) $value['size'] : '';
			}

			if ( '' === $value || null === $value ) {
				continue;
			}

			$out[ $key ] = $value;
		}

		if ( ! empty( $settings['shop_categories'] ) && is_array( $settings['shop_categories'] ) ) {
			$out['shop_categories'] = array_map( 'absint', $settings['shop_categories'] );
		}

		if ( ! empty( $settings['filter_sort_options'] ) && is_array( $settings['filter_sort_options'] ) ) {
			$out['filter_sort_options'] = array_map( 'sanitize_key', $settings['filter_sort_options'] );
		}

		if ( isset( $settings['shop_columns'] ) ) {
			$out['shop_columns']        = (int) $settings['shop_columns'];
			$out['shop_columns_tablet'] = isset( $settings['shop_columns_tablet'] ) && '' !== $settings['shop_columns_tablet'] ? (int) $settings['shop_columns_tablet'] : '';
			$out['shop_columns_mobile'] = isset( $settings['shop_columns_mobile'] ) && '' !== $settings['shop_columns_mobile'] ? (int) $settings['shop_columns_mobile'] : '';
		}

		return $out;
	}

	protected function render_inner( $settings ) {
		if ( $this->woocommerce_missing() ) {
			return $this->notice( 'برای نمایش ویترین محصولات، ووکامرس باید فعال باشد.' );
		}

		if ( ! class_exists( 'BMC_Catalog' ) ) {
			return $this->notice( 'ماژول ویترین BazzarMc در دسترس نیست.' );
		}

		$html = (string) BMC_Catalog::render_shop( $this->overrides( $settings ) );

		return '' !== trim( $html ) ? $html : $this->editor_placeholder( 'محصولی برای نمایش در ویترین پیدا نشد.' );
	}
}
