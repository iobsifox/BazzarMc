<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Elementor {

	const CATEGORY    = 'bazzarmc';
	const MIN_VERSION = '3.1.0';

	private static $booted       = false;
	private static $registered   = false;
	private static $files_loaded = false;

	private static $widgets = array(
		'class-bmc-el-account-card.php'    => 'BMC_EL_Account_Card',
		'class-bmc-el-link-box.php'        => 'BMC_EL_Link_Box',
		'class-bmc-el-status.php'          => 'BMC_EL_Status',
		'class-bmc-el-account-nav.php'     => 'BMC_EL_Account_Nav',
		'class-bmc-el-account-content.php' => 'BMC_EL_Account_Content',
		'class-bmc-el-cart.php'            => 'BMC_EL_Cart',
		'class-bmc-el-checkout.php'        => 'BMC_EL_Checkout',
		'class-bmc-el-tickets.php'         => 'BMC_EL_Tickets',
		'class-bmc-el-ticket.php'          => 'BMC_EL_Ticket',
		'class-bmc-el-deliveries.php'      => 'BMC_EL_Deliveries',
		'class-bmc-el-ranks.php'           => 'BMC_EL_Ranks',
		'class-bmc-el-form.php'            => 'BMC_EL_Form',
		'class-bmc-el-shop.php'            => 'BMC_EL_Shop',
		'class-bmc-el-product-card.php'    => 'BMC_EL_Product_Card',
		'class-bmc-el-product-filter.php'  => 'BMC_EL_Product_Filter',
	);

	public static function init() {
		add_action( 'plugins_loaded', array( __CLASS__, 'boot' ), 20 );
		add_action( 'init', array( __CLASS__, 'boot' ), 20 );
	}

	public static function version() {
		return defined( 'ELEMENTOR_VERSION' ) ? (string) ELEMENTOR_VERSION : '';
	}

	public static function is_active() {
		return did_action( 'elementor/loaded' ) && class_exists( '\Elementor\Plugin' );
	}

	public static function is_supported() {
		return self::is_active() && version_compare( self::version(), self::MIN_VERSION, '>=' );
	}

	public static function can_load_widgets() {
		return self::is_supported() && class_exists( '\Elementor\Widget_Base' );
	}

	public static function files_loaded() {
		return self::$files_loaded;
	}

	public static function widget_names() {
		return array_values( self::$widgets );
	}

	public static function booted() {
		return self::$booted;
	}

	public static function enabled() {
		if ( class_exists( 'BMC_Safe' ) && BMC_Safe::safe_mode() ) {
			return false;
		}

		return BMC_Settings::bool( 'elementor_enabled', true );
	}

	public static function boot() {
		if ( self::$booted || ! self::is_supported() || ! self::enabled() ) {
			return;
		}

		self::$booted = true;

		self::load_files();

		add_action( 'elementor/elements/categories_registered', array( __CLASS__, 'register_category' ) );
		add_action( 'elementor/widgets/register', array( __CLASS__, 'register_widgets' ) );
		add_action( 'elementor/widgets/widgets_registered', array( __CLASS__, 'register_widgets' ) );

		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ), 5 );
		add_action( 'elementor/editor/before_enqueue_scripts', array( __CLASS__, 'register_assets' ), 5 );
		add_action( 'elementor/preview/enqueue_styles', array( __CLASS__, 'preview_assets' ) );

		if ( did_action( 'elementor/widgets/register' ) || did_action( 'elementor/widgets/widgets_registered' ) ) {
			self::register_widgets( self::widgets_manager() );
		}
	}

	public static function widgets_manager() {
		if ( ! class_exists( '\Elementor\Plugin' ) || empty( \Elementor\Plugin::$instance ) ) {
			return null;
		}

		$plugin = \Elementor\Plugin::$instance;

		if ( ! empty( $plugin->widgets_manager ) ) {
			return $plugin->widgets_manager;
		}

		if ( method_exists( $plugin, 'get_widgets_manager' ) ) {
			return $plugin->get_widgets_manager();
		}

		return null;
	}

	private static function load_files() {
		if ( self::$files_loaded ) {
			return true;
		}

		$dir = BMC_PATH . 'includes/integrations/elementor/';

		if ( ! is_dir( $dir ) ) {
			return false;
		}

		if ( ! self::can_load_widgets() ) {
			return false;
		}

		try {
			require_once $dir . 'class-bmc-el-base.php';

			foreach ( array_keys( self::$widgets ) as $file ) {
				if ( file_exists( $dir . $file ) ) {
					require_once $dir . $file;
				}
			}
		} catch ( Throwable $bmc_error ) {
			if ( class_exists( 'BMC_Safe' ) ) {
				BMC_Safe::collect( 'elementor:load', $bmc_error );
			}

			error_log( 'BazzarMc Elementor: ' . $bmc_error->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log

			return false;
		}

		self::$files_loaded = true;

		return true;
	}

	public static function register_category( $elements_manager ) {
		if ( ! $elements_manager || ! method_exists( $elements_manager, 'add_category' ) ) {
			return;
		}

		$elements_manager->add_category(
			self::CATEGORY,
			array(
				'title' => 'BazzarMc — فروشگاه ماینکرافت',
				'icon'  => 'eicon-woocommerce',
			)
		);
	}

	public static function register_widgets( $widgets_manager = null ) {
		if ( self::$registered ) {
			return;
		}

		if ( ! self::enabled() || ! self::is_supported() ) {
			return;
		}

		if ( ! self::load_files() ) {
			return;
		}

		self::$registered = true;

		if ( ! $widgets_manager ) {
			$widgets_manager = self::widgets_manager();
		}

		if ( ! $widgets_manager ) {
			return;
		}

		foreach ( self::$widgets as $class ) {
			if ( ! class_exists( $class ) ) {
				continue;
			}

			try {
				$instance = new $class();

				if ( method_exists( $widgets_manager, 'register' ) ) {
					$widgets_manager->register( $instance );
				} elseif ( method_exists( $widgets_manager, 'register_widget_type' ) ) {
					$widgets_manager->register_widget_type( $instance );
				}
			} catch ( Throwable $bmc_error ) {
				if ( class_exists( 'BMC_Safe' ) ) {
					BMC_Safe::collect( 'elementor:register:' . $class, $bmc_error );
				}

				error_log( 'BazzarMc Elementor register ' . $class . ': ' . $bmc_error->getMessage() ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log
			}
		}
	}

	public static function register_assets() {
		$css = BMC_URL . 'assets/css/';
		$js  = BMC_URL . 'assets/js/';

		if ( ! wp_style_is( 'bmc-public', 'registered' ) && ! wp_style_is( 'bmc-public', 'done' ) ) {
			wp_register_style( 'bmc-public', $css . 'bmc-public.css', array(), BMC_VERSION );
		}

		wp_register_style( 'bmc-elementor', $css . 'bmc-elementor.css', array( 'bmc-public' ), BMC_VERSION );
		wp_register_script( 'bmc-icons', $js . 'bmc-icons.js', array(), BMC_VERSION, true );
		wp_register_script( 'bmc-link', $js . 'bmc-link.js', array( 'jquery', 'bmc-icons' ), BMC_VERSION, true );
		wp_register_script( 'bmc-checkout', $js . 'bmc-checkout.js', array( 'jquery', 'bmc-icons' ), BMC_VERSION, true );

		if ( BMC_Settings::bool( 'font_cdn', true ) && ! wp_style_is( 'bmc-vazir', 'registered' ) ) {
			wp_register_style( 'bmc-vazir', 'https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css', array(), '33.003' );
		}
	}

	public static function preview_assets() {
		self::register_assets();

		wp_enqueue_style( 'bmc-public' );
		wp_enqueue_style( 'bmc-elementor' );
		wp_enqueue_script( 'bmc-icons' );

		if ( BMC_Settings::bool( 'font_cdn', true ) ) {
			wp_enqueue_style( 'bmc-vazir' );
		}
	}

	public static function style_depends() {
		$styles = array( 'bmc-public', 'bmc-elementor' );

		if ( BMC_Settings::bool( 'font_cdn', true ) ) {
			$styles[] = 'bmc-vazir';
		}

		return $styles;
	}
}
