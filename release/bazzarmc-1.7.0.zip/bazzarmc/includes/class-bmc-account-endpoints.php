<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Account_Endpoints {

	const FLUSH_OPTION  = 'bmc_flush_permalinks';
	const FLUSH_NOTICE  = 'bmc_flush_notice';

	private static $snapshot = null;

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_endpoints' ) );
		add_filter( 'query_vars', array( __CLASS__, 'query_vars' ) );
		add_filter( 'woocommerce_account_menu_items', array( __CLASS__, 'menu_items' ), 40 );

		add_action( 'woocommerce_account_' . self::slug( 'connect' ) . '_endpoint', array( 'BMC_Public', 'my_account_content' ) );
		add_action( 'woocommerce_account_' . self::slug( 'tickets' ) . '_endpoint', array( 'BMC_Tickets', 'render_list_endpoint' ) );
		add_action( 'woocommerce_account_' . BMC_Tickets::ENDPOINT_VIEW . '_endpoint', array( 'BMC_Tickets', 'render_view_endpoint' ) );

		add_action( 'admin_init', array( __CLASS__, 'maybe_flush' ) );
		add_action( 'admin_notices', array( __CLASS__, 'flush_notice' ) );
	}

	public static function keys() {
		return array( 'connect', 'tickets' );
	}

	public static function default_slug( $key ) {
		return 'tickets' === $key ? BMC_Tickets::ENDPOINT_LIST : BMC_Public::ENDPOINT;
	}

	public static function default_title( $key ) {
		return 'tickets' === $key ? 'تیکت پشتیبانی' : 'اتصال ماینکرافت';
	}

	public static function setting_prefix( $key ) {
		return 'tickets' === $key ? 'ma_tickets_' : 'ma_connect_';
	}

	public static function slug( $key ) {
		$prefix  = self::setting_prefix( $key );
		$default = self::default_slug( $key );
		$value   = sanitize_title( (string) BMC_Settings::get( $prefix . 'slug', $default ) );

		if ( '' === $value ) {
			$value = $default;
		}

		if ( in_array( $value, self::reserved(), true ) ) {
			$value = $default;
		}

		foreach ( self::keys() as $other ) {
			if ( $other === $key ) {
				continue;
			}

			if ( $value === sanitize_title( (string) BMC_Settings::get( self::setting_prefix( $other ) . 'slug', self::default_slug( $other ) ) ) ) {
				$value = $default;
			}
		}

		return $value;
	}

	public static function slugs() {
		$out = array();

		foreach ( self::keys() as $key ) {
			$out[ $key ] = self::slug( $key );
		}

		return $out;
	}

	public static function reserved() {
		return array(
			'dashboard',
			'orders',
			'view-order',
			'downloads',
			'edit-address',
			'payment-methods',
			'edit-account',
			'customer-logout',
			'lost-password',
			'add-payment-method',
			'delete-payment-method',
			'set-default-payment-method',
			BMC_Tickets::ENDPOINT_VIEW,
		);
	}

	public static function title( $key ) {
		$title = trim( (string) BMC_Settings::get( self::setting_prefix( $key ) . 'title', self::default_title( $key ) ) );

		return '' === $title ? self::default_title( $key ) : $title;
	}

	public static function icon( $key ) {
		$prefix = self::setting_prefix( $key );
		$icon   = sanitize_text_field( (string) BMC_Settings::get( $prefix . 'icon', '' ) );

		if ( '' === $icon || ! class_exists( 'BMC_Icons' ) || ! BMC_Icons::has( $icon ) ) {
			$icon = 'tickets' === $key ? 'support_agent' : 'sports_esports';
		}

		return $icon;
	}

	public static function position( $key ) {
		$allowed = array_keys( BMC_Settings::endpoint_positions() );
		$value   = sanitize_key( (string) BMC_Settings::get( self::setting_prefix( $key ) . 'position', '' ) );

		if ( ! in_array( $value, $allowed, true ) ) {
			$value = 'tickets' === $key ? 'before_logout' : 'after_orders';
		}

		return $value;
	}

	public static function in_menu( $key ) {
		if ( 'tickets' === $key ) {
			return BMC_Tickets::enabled() && BMC_Settings::bool( 'ma_tickets_enabled', true );
		}

		return BMC_Settings::bool( 'ma_connect_enabled', true );
	}

	public static function show_badge( $key ) {
		if ( 'tickets' === $key ) {
			return BMC_Settings::bool( 'ma_tickets_badge', true );
		}

		return BMC_Settings::bool( 'ma_connect_badge', true );
	}

	public static function definition( $key ) {
		return array(
			'key'      => $key,
			'slug'     => self::slug( $key ),
			'default'  => self::default_slug( $key ),
			'title'    => self::title( $key ),
			'icon'     => self::icon( $key ),
			'position' => self::position( $key ),
			'in_menu'  => self::in_menu( $key ),
			'badge'    => self::show_badge( $key ),
			'url'      => self::url( $key ),
		);
	}

	public static function definitions() {
		$out = array();

		foreach ( self::keys() as $key ) {
			$out[ $key ] = self::definition( $key );
		}

		return $out;
	}

	public static function url( $key ) {
		if ( function_exists( 'wc_get_account_endpoint_url' ) ) {
			$url = (string) wc_get_account_endpoint_url( self::slug( $key ) );

			if ( '' !== $url && false === strpos( $url, 'wc_get_account_endpoint_url' ) ) {
				return $url;
			}
		}

		return function_exists( 'wc_get_page_permalink' ) ? (string) wc_get_page_permalink( 'myaccount' ) : home_url( '/' );
	}

	public static function view_url( $ticket_id = 0 ) {
		if ( ! function_exists( 'wc_get_account_endpoint_url' ) ) {
			return self::url( 'tickets' );
		}

		if ( $ticket_id ) {
			return (string) wc_get_account_endpoint_url( BMC_Tickets::ENDPOINT_VIEW ) . absint( $ticket_id ) . '/';
		}

		return self::url( 'tickets' );
	}

	public static function is_current( $key ) {
		if ( ! function_exists( 'is_wc_endpoint_url' ) ) {
			return false;
		}

		return (bool) is_wc_endpoint_url( self::slug( $key ) );
	}

	public static function register_endpoints() {
		foreach ( self::keys() as $key ) {
			if ( 'tickets' === $key && ! BMC_Tickets::enabled() ) {
				continue;
			}

			add_rewrite_endpoint( self::slug( $key ), EP_ROOT | EP_PAGES );
		}

		if ( BMC_Tickets::enabled() ) {
			add_rewrite_endpoint( BMC_Tickets::ENDPOINT_VIEW, EP_ROOT | EP_PAGES );
		}
	}

	public static function query_vars( $vars ) {
		foreach ( self::keys() as $key ) {
			$vars[] = self::slug( $key );
		}

		$vars[] = BMC_Tickets::ENDPOINT_VIEW;

		return array_values( array_unique( $vars ) );
	}

	public static function menu_items( $items ) {
		if ( ! is_array( $items ) ) {
			return $items;
		}

		$defs = self::definitions();

		foreach ( $defs as $def ) {
			unset( $items[ $def['slug'] ], $items[ $def['default'] ] );
		}

		unset( $items[ BMC_Tickets::ENDPOINT_VIEW ] );

		foreach ( $defs as $key => $def ) {
			if ( ! $def['in_menu'] ) {
				continue;
			}

			$items = self::insert( $items, $def['slug'], $def['title'], $def['position'] );
		}

		return $items;
	}

	public static function insert( array $items, $slug, $title, $position ) {
		$out = array();

		switch ( $position ) {
			case 'first':
				$out[ $slug ] = $title;
				foreach ( $items as $key => $label ) {
					$out[ $key ] = $label;
				}
				return $out;

			case 'last':
				foreach ( $items as $key => $label ) {
					$out[ $key ] = $label;
				}
				$out[ $slug ] = $title;
				return $out;

			case 'after_dashboard':
				return self::insert_after( $items, $slug, $title, 'dashboard' );

			case 'before_logout':
				return self::insert_before( $items, $slug, $title, 'customer-logout' );

			case 'after_orders':
			default:
				return self::insert_after( $items, $slug, $title, 'orders' );
		}
	}

	private static function insert_after( array $items, $slug, $title, $anchor ) {
		$out    = array();
		$placed = false;

		foreach ( $items as $key => $label ) {
			$out[ $key ] = $label;

			if ( $key === $anchor ) {
				$out[ $slug ] = $title;
				$placed       = true;
			}
		}

		if ( ! $placed ) {
			$out[ $slug ] = $title;
		}

		return $out;
	}

	private static function insert_before( array $items, $slug, $title, $anchor ) {
		$out    = array();
		$placed = false;

		foreach ( $items as $key => $label ) {
			if ( $key === $anchor && ! $placed ) {
				$out[ $slug ] = $title;
				$placed       = true;
			}

			$out[ $key ] = $label;
		}

		if ( ! $placed ) {
			$out[ $slug ] = $title;
		}

		return $out;
	}

	public static function nav_icon( $endpoint ) {
		foreach ( self::keys() as $key ) {
			$def = self::definition( $key );

			if ( $def['slug'] === $endpoint || $def['default'] === $endpoint ) {
				return $def['icon'];
			}
		}

		return '';
	}

	public static function nav_meta( $endpoint ) {
		$meta = array(
			'count' => 0,
			'dot'   => false,
			'note'  => '',
		);

		if ( ! is_user_logged_in() ) {
			return $meta;
		}

		foreach ( self::keys() as $key ) {
			$def = self::definition( $key );

			if ( $def['slug'] !== $endpoint && $def['default'] !== $endpoint ) {
				continue;
			}

			if ( ! $def['badge'] ) {
				return $meta;
			}

			if ( 'tickets' === $key ) {
				$meta['count'] = (int) BMC_Tickets::open_tickets_note( get_current_user_id() );
				$meta['dot']   = BMC_Settings::bool( 'ma_tickets_dot', true ) && (int) BMC_Tickets::unread_for_user( get_current_user_id() ) > 0;

				return $meta;
			}

			$linked = class_exists( 'BMC_Link' ) && BMC_Link::is_linked( get_current_user_id() );

			$meta['dot']  = ! $linked;
			$meta['note'] = $linked ? 'متصل' : 'نیاز به اتصال';

			return $meta;
		}

		return $meta;
	}

	public static function nav_url( $endpoint ) {
		foreach ( self::keys() as $key ) {
			$def = self::definition( $key );

			if ( $def['slug'] === $endpoint ) {
				return (string) $def['url'];
			}
		}

		return '';
	}

	public static function snapshot() {
		if ( null === self::$snapshot ) {
			self::$snapshot = self::slugs();
		}

		return self::$snapshot;
	}

	public static function queue_flush_if_changed() {
		$before = (array) get_option( self::FLUSH_OPTION . '_slugs', array() );
		$now    = self::slugs();

		if ( ! $before ) {
			update_option( self::FLUSH_OPTION . '_slugs', $now, false );

			return false;
		}

		if ( $before === $now ) {
			return false;
		}

		update_option( self::FLUSH_OPTION . '_slugs', $now, false );
		self::queue_flush();

		return true;
	}

	public static function queue_flush() {
		update_option( self::FLUSH_OPTION, 1, false );
	}

	public static function maybe_flush() {
		if ( ! get_option( self::FLUSH_OPTION, 0 ) ) {
			return;
		}

		delete_option( self::FLUSH_OPTION );

		flush_rewrite_rules();

		set_transient( self::FLUSH_NOTICE, 1, 60 );
	}

	public static function flush_notice() {
		if ( ! get_transient( self::FLUSH_NOTICE ) ) {
			return;
		}

		delete_transient( self::FLUSH_NOTICE );

		echo '<div class="notice notice-success is-dismissible"><p><strong>BazzarMc:</strong> پیوندهای یکتا بازسازی شد تا آدرس تازهٔ بخش‌های حساب کاربری فعال شود.</p></div>';
	}

	public static function status_rows() {
		$rows = array();

		foreach ( self::keys() as $key ) {
			$def    = self::definition( $key );
			$meta   = self::nav_meta( $def['slug'] );
			$rows[] = array(
				'key'      => $key,
				'label'    => 'tickets' === $key ? 'تیکت‌ها' : 'اتصال حساب ماینکرافت',
				'title'    => $def['title'],
				'slug'     => $def['slug'],
				'url'      => $def['url'],
				'in_menu'  => $def['in_menu'],
				'icon'     => $def['icon'],
				'position' => $def['position'],
				'count'    => $meta['count'],
				'note'     => $meta['note'],
			);
		}

		return $rows;
	}
}
