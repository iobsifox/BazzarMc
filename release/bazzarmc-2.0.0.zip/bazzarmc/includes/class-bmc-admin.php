<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Admin {

	const SLUG = 'bazzarmc';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_init', array( __CLASS__, 'handle_post' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_export_csv' ) );

		add_action( 'wp_ajax_bmc_admin_action', array( __CLASS__, 'ajax_action' ) );

		add_filter( 'admin_body_class', array( __CLASS__, 'body_class' ) );
	}

	public static function body_class( $classes ) {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && false !== strpos( $screen->id, self::SLUG ) ) {
			$classes .= ' bmc-admin-page';
		}
		return $classes;
	}

	public static function register_menu() {
		add_menu_page(
			'BazzarMc',
			'BazzarMc',
			'manage_woocommerce',
			self::SLUG,
			array( __CLASS__, 'render_page' ),
			BMC_Icons::admin_menu_icon(),
			56
		);
	}

	public static function enqueue_assets( $hook ) {
		if ( false === strpos( (string) $hook, self::SLUG ) ) {
			return;
		}

		wp_enqueue_style( 'bmc-admin', BMC_URL . 'assets/css/bmc-admin.css', array(), BMC_VERSION );
		wp_enqueue_script( 'bmc-icons', BMC_URL . 'assets/js/bmc-icons.js', array(), BMC_VERSION, true );

		if ( BMC_Settings::bool( 'font_cdn', true ) ) {
			wp_enqueue_style( 'bmc-vazir-admin', 'https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css', array(), '33.003' );
		}

		wp_enqueue_script( 'bmc-admin', BMC_URL . 'assets/js/bmc-admin.js', array( 'jquery', 'bmc-icons' ), BMC_VERSION, true );

		wp_localize_script(
			'bmc-admin',
			'bmcAdmin',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'bmc_admin' ),
				'i18n'    => array(
					'copied'     => 'کپی شد!',
					'confirm'    => 'آیا مطمئن هستید؟',
					'working'    => 'در حال انجام…',
					'done'       => 'انجام شد',
					'error'      => 'خطا رخ داد',
				),
			)
		);

		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );
	}

	public static function tabs() {
		return array(
			'dashboard'  => array( 'label' => 'داشبورد', 'icon' => 'monitoring' ),
			'server'     => array( 'label' => 'اتصال سرور', 'icon' => 'power' ),
			'products'   => array( 'label' => 'محصولات و رنک‌ها', 'icon' => 'inventory_2' ),
			'deliveries' => array( 'label' => 'تحویل‌ها', 'icon' => 'local_shipping' ),
			'login'      => array( 'label' => 'تأیید و حساب کاربری', 'icon' => 'badge' ),
			'messages'   => array( 'label' => 'متن‌ها و قالب‌ها', 'icon' => 'mail' ),
			'tools'      => array( 'label' => 'ابزارها و امنیت', 'icon' => 'build' ),
		);
	}

	public static function current_tab() {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard';

		if ( 'setup' === $tab ) {
			$tab = 'server';
		}

		return array_key_exists( $tab, self::tabs() ) ? $tab : 'dashboard';
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}

		$tab      = self::current_tab();
		$settings = BMC_Settings::all();
		$view     = BMC_PATH . 'admin/views/' . $tab . '.php';

		self::render_notices();

		echo '<div class="bmc-admin" dir="rtl">';

		self::render_header();

		echo '<div class="bmc-admin__body">';

		self::render_nav( $tab );

		echo '<div class="bmc-admin__content">';

		if ( file_exists( $view ) ) {
			include $view;
		} else {
			echo '<div class="bmc-box">قالب این بخش یافت نشد.</div>';
		}

		echo '</div></div></div>';
	}

	private static function render_header() {
		$stats   = BMC_Deliveries::stats();
		$token   = BMC_Settings::api_token();
		$api_url = BMC_Settings::api_base_url();
		?>
		<header class="bmc-admin__header">
			<div class="bmc-admin__title">
				<span class="bmc-admin__logo"><?php bmc_icon( 'sports_esports', array( 'size' => 26 ) ); ?></span>
				<div>
					<h1>BazzarMc</h1>
					<p>اتصال فروشگاه ووکامرس به سرور ماینکرافت — نسخهٔ <?php echo esc_html( BMC_VERSION ); ?></p>
				</div>
			</div>

			<div class="bmc-admin__chips">
				<div class="bmc-mode-switch" role="radiogroup" aria-label="حالت تنظیمات">
					<button type="button" class="bmc-mode-btn is-active" data-mode="simple" title="فقط گزینه‌های اصلی و ضروری">
						<?php bmc_icon( 'tune', array( 'size' => 15 ) ); ?>
						<span>حالت ساده</span>
					</button>
					<button type="button" class="bmc-mode-btn" data-mode="advanced" title="نمایش تمام تنظیمات و جزئیات">
						<?php bmc_icon( 'settings', array( 'size' => 15 ) ); ?>
						<span>حالت پیشرفته</span>
					</button>
				</div>
				<span class="bmc-chip <?php echo $stats['pending'] ? 'is-warn' : 'is-ok'; ?>">
					<?php echo esc_html( BMC_Helpers::to_persian_digits( $stats['pending'] ) ); ?> تحویل در انتظار
				</span>
				<span class="bmc-chip is-info">
					<?php echo esc_html( BMC_Helpers::to_persian_digits( $stats['linked_users'] ) ); ?> کاربر متصل
				</span>
			</div>

			<div class="bmc-admin__token">
				<div class="bmc-admin__token-row">
					<label>توکن اتصال سرور</label>
					<button type="button" class="button bmc-copy" data-copy="<?php echo esc_attr( $token ); ?>">کپی</button>
				</div>
				<code class="bmc-token" id="bmcTokenValue"><?php echo esc_html( $token ); ?></code>
				<div class="bmc-admin__token-row">
					<label>آدرس API</label>
					<button type="button" class="button bmc-copy" data-copy="<?php echo esc_attr( $api_url ); ?>">کپی</button>
				</div>
				<code class="bmc-token bmc-token--sm"><?php echo esc_html( $api_url ); ?></code>
			</div>
		</header>
		<?php
	}

	private static function render_nav( $current ) {
		echo '<nav class="bmc-admin__nav"><ul>';

		foreach ( self::tabs() as $key => $tab ) {
			$url   = admin_url( 'admin.php?page=' . self::SLUG . '&tab=' . $key );
			$class = $key === $current ? 'is-active' : '';

			printf(
				'<li><a class="%1$s" href="%2$s"><span class="bmc-admin__nav-icon">%3$s</span>%4$s</a></li>',
				esc_attr( $class ),
				esc_url( $url ),
				bmc_get_icon( $tab['icon'], array( 'size' => 17 ) ),
				esc_html( $tab['label'] )
			);
		}

		echo '</ul>';

		$report = BMC_Migrate::migration_report();
		if ( $report['legacy_plugin'] || $report['users'] || $report['deliveries'] ) {
			echo '<div class="bmc-admin__nav-note">داده‌های نسخهٔ قدیمی شناسایی شد. از بخش <strong>ابزارها</strong> مهاجرت را انجام دهید.</div>';
		}

		echo '</nav>';
	}

	private static function render_notices() {
		if ( isset( $_GET['bmc_saved'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>تنظیمات ذخیره شد.</p></div>';
		}
		if ( isset( $_GET['bmc_error'] ) ) {
			echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['bmc_error'] ) ) ) . '</p></div>';
		}
	}

	public static function handle_post() {
		if ( empty( $_POST['bmc_settings_nonce'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}

		check_admin_referer( 'bmc_save_settings', 'bmc_settings_nonce' );

		$post   = wp_unslash( $_POST );
		$tab    = isset( $post['bmc_tab'] ) ? sanitize_key( $post['bmc_tab'] ) : 'server';
		$values = self::collect_values( $tab, $post );

		if ( $values ) {
			BMC_Settings::save( $values );
		}

		if ( class_exists( 'BMC_Account_Endpoints' ) ) {
			BMC_Account_Endpoints::queue_flush_if_changed();
		}

		$args = array(
			'page'      => self::SLUG,
			'tab'       => $tab,
			'bmc_saved' => 1,
		);

		$redirect = add_query_arg( $args, admin_url( 'admin.php' ) );

		wp_safe_redirect( $redirect );
		exit;
	}

	public static function collect_values( $tab, array $post ) {
		$values         = array();
		$bmc_known_keys = BMC_Settings::defaults();

		switch ( $tab ) {
			case 'server':
				$values['server_name']         = sanitize_text_field( $post['server_name'] ?? '' );
				$values['server_ip']           = sanitize_text_field( $post['server_ip'] ?? '' );
				$values['username_policy']     = in_array( $post['username_policy'] ?? '', array( 'premium', 'any' ), true ) ? $post['username_policy'] : 'any';
				$values['link_mode']           = in_array( $post['link_mode'] ?? '', array( 'panel', 'mc', 'both' ), true ) ? $post['link_mode'] : 'both';
				$values['force_link']          = BMC_Settings::normalize_yesno( $post['force_link'] ?? 'no' );
				$values['unlink_allowed']      = BMC_Settings::normalize_yesno( $post['unlink_allowed'] ?? 'no' );
				$values['default_linked_role'] = sanitize_text_field( $post['default_linked_role'] ?? '' );
				$values['legacy_compat']       = BMC_Settings::normalize_yesno( $post['legacy_compat'] ?? 'no' );
				$values['debug_log']           = BMC_Settings::normalize_yesno( $post['debug_log'] ?? 'no' );
				$values['code_ttl']            = (int) ( $post['code_ttl'] ?? 300 );
				$values['code_length']         = (int) ( $post['code_length'] ?? 8 );
				$values['code_alphabet']       = in_array( $post['code_alphabet'] ?? '', array( 'safe', 'digits', 'full' ), true ) ? $post['code_alphabet'] : 'safe';
				$values['code_command_hint']   = sanitize_text_field( $post['code_command_hint'] ?? '' );
				$values['delivery_expiry']     = array(
					'value' => (int) ( $post['delivery_expiry_value'] ?? 30 ),
					'unit'  => sanitize_text_field( $post['delivery_expiry_unit'] ?? 'days' ),
				);
				$values['delivery_status']     = isset( $post['delivery_status'] ) && is_array( $post['delivery_status'] ) ? array_map( 'sanitize_key', $post['delivery_status'] ) : array();
				$values['ssl_verify']          = BMC_Settings::normalize_yesno( $post['ssl_verify'] ?? 'yes' );
				$values['mojang_check']        = BMC_Settings::normalize_yesno( $post['mojang_check'] ?? 'yes' );
				$values['cache_exclude']       = BMC_Settings::normalize_yesno( $post['cache_exclude'] ?? 'yes' );
				$values['cf_api_token']        = sanitize_text_field( $post['cf_api_token'] ?? '' );
				$values['cf_zone_id']          = sanitize_text_field( $post['cf_zone_id'] ?? '' );
				$values['cf_cache_rule']       = BMC_Settings::normalize_yesno( $post['cf_cache_rule'] ?? 'no' );
				break;

			case 'products':
				$values['sync_products'] = isset( $post['sync_products'] ) && is_array( $post['sync_products'] ) ? array_map( 'absint', $post['sync_products'] ) : array();

				$roles = array();
				if ( isset( $post['product_role'] ) && is_array( $post['product_role'] ) ) {
					foreach ( $post['product_role'] as $pid => $role ) {
						$roles[ absint( $pid ) ] = sanitize_text_field( $role );
					}
				}
				$values['product_roles'] = $roles;

				$durations = array();
				if ( isset( $post['product_role_duration'] ) && is_array( $post['product_role_duration'] ) ) {
					foreach ( $post['product_role_duration'] as $pid => $days ) {
						$pid = absint( $pid );
						if ( ! $pid || '' === trim( (string) $days ) ) {
							continue;
						}
						$durations[ $pid ] = max( 0, min( 36500, (int) $days ) );
					}
				}
				$values['product_role_duration'] = $durations;

				$levels = array();
				if ( isset( $post['rank_level'] ) && is_array( $post['rank_level'] ) ) {
					$levels = BMC_Ranks::save_manual_levels( $post['rank_level'] );
				}
				$values['rank_levels'] = $levels;

				$values['rank_guard']      = BMC_Settings::normalize_yesno( $post['rank_guard'] ?? 'yes' );
				$values['rank_hide_lower'] = BMC_Settings::normalize_yesno( $post['rank_hide_lower'] ?? 'yes' );

				$values['role_duration_default'] = isset( $post['role_duration_default'] ) ? max( 0, min( 36500, (int) $post['role_duration_default'] ) ) : 0;

				$product_keys = array();

				if ( isset( $post['product_key_type'] ) && is_array( $post['product_key_type'] ) ) {
					$key_values = isset( $post['product_key_value'] ) && is_array( $post['product_key_value'] ) ? $post['product_key_value'] : array();

					foreach ( $post['product_key_type'] as $pid => $type ) {
						$pid = absint( $pid );

						if ( ! $pid ) {
							continue;
						}

						$product_keys[ $pid ] = array(
							'type'  => in_array( $type, array( 'name', 'id', 'slug', 'custom' ), true ) ? $type : 'name',
							'value' => isset( $key_values[ $pid ] ) ? sanitize_text_field( $key_values[ $pid ] ) : '',
						);
					}
				}

				$values['product_key_default']    = in_array( $post['product_key_default'] ?? '', array( 'name', 'id', 'slug', 'sku' ), true ) ? $post['product_key_default'] : 'name';
				$values['product_keys']           = $product_keys;
				$values['revoke_roles_on_refund'] = BMC_Settings::normalize_yesno( $post['revoke_roles_on_refund'] ?? 'yes' );
				break;

			case 'login':
				$values['page_link']            = (int) ( $post['page_link'] ?? 0 );
				$values['otp_ttl']              = (int) ( $post['otp_ttl'] ?? 120 );
				$values['otp_length']           = (int) ( $post['otp_length'] ?? 5 );
				$values['otp_rate_limit']       = (int) ( $post['otp_rate_limit'] ?? 120 );
				$values['otp_max_attempts']     = (int) ( $post['otp_max_attempts'] ?? 5 );
				$values['otp_resend_limit']     = (int) ( $post['otp_resend_limit'] ?? 3 );
				$values['email_enabled']        = BMC_Settings::normalize_yesno( $post['email_enabled'] ?? 'no' );
				$values['email_tpl_subject']    = sanitize_text_field( $post['email_tpl_subject'] ?? '' );
				$values['email_tpl_body']       = wp_kses_post( $post['email_tpl_body'] ?? '' );

				$keys = array();
				if ( ! empty( $post['mobile_meta_keys'] ) ) {
					$raw  = is_array( $post['mobile_meta_keys'] ) ? implode( ',', $post['mobile_meta_keys'] ) : $post['mobile_meta_keys'];
					$keys = array_filter( array_map( 'sanitize_key', array_map( 'trim', explode( ',', $raw ) ) ) );
				}
				$values['mobile_meta_keys'] = array_values( $keys );

				$methods = array();

				if ( isset( $post['verify_methods'] ) && is_array( $post['verify_methods'] ) ) {
					$methods = array_values( array_intersect( array_map( 'sanitize_key', $post['verify_methods'] ), array( 'email', 'dashboard' ) ) );
				}

				$values['verify_methods']       = $methods ? $methods : array( 'dashboard' );
				$values['verify_default']       = in_array( $post['verify_default'] ?? '', $values['verify_methods'], true ) ? $post['verify_default'] : $values['verify_methods'][0];
				$values['otp_dashboard_widget'] = BMC_Settings::normalize_yesno( $post['otp_dashboard_widget'] ?? 'yes' );
				$values['otp_dashboard_box']    = BMC_Settings::normalize_yesno( $post['otp_dashboard_box'] ?? 'yes' );
				$values['myaccount_card']       = BMC_Settings::normalize_yesno( $post['myaccount_card'] ?? 'yes' );

				$values['link_width']              = in_array( $post['link_width'] ?? '', array( 'narrow', 'wide' ), true ) ? $post['link_width'] : 'narrow';
				$values['link_avatar_size']        = (int) ( $post['link_avatar_size'] ?? 96 );
				$values['link_show_steps']         = BMC_Settings::normalize_yesno( $post['link_show_steps'] ?? 'yes' );
				$values['link_step_1']             = sanitize_textarea_field( $post['link_step_1'] ?? '' );
				$values['link_step_2']             = sanitize_textarea_field( $post['link_step_2'] ?? '' );
				$values['link_step_3']             = sanitize_textarea_field( $post['link_step_3'] ?? '' );
				$values['link_player_label']       = sanitize_text_field( $post['link_player_label'] ?? '' );
				$values['link_player_placeholder'] = sanitize_text_field( $post['link_player_placeholder'] ?? '' );
				$values['link_submit_text']        = sanitize_text_field( $post['link_submit_text'] ?? '' );
				$values['link_code_hint']          = sanitize_textarea_field( $post['link_code_hint'] ?? '' );
				$values['link_copy_text']          = sanitize_text_field( $post['link_copy_text'] ?? '' );
				$values['link_regen_text']         = sanitize_text_field( $post['link_regen_text'] ?? '' );
				$values['link_show_otp_card']      = BMC_Settings::normalize_yesno( $post['link_show_otp_card'] ?? 'yes' );
				$values['link_otp_title']          = sanitize_text_field( $post['link_otp_title'] ?? '' );
				$values['link_show_uuid']          = BMC_Settings::normalize_yesno( $post['link_show_uuid'] ?? 'yes' );
				$values['link_show_linked_at']     = BMC_Settings::normalize_yesno( $post['link_show_linked_at'] ?? 'yes' );
				$values['link_show_shop_button']   = BMC_Settings::normalize_yesno( $post['link_show_shop_button'] ?? 'yes' );
				$values['link_show_unlink']        = BMC_Settings::normalize_yesno( $post['link_show_unlink'] ?? 'yes' );
				$values['link_login_title']        = sanitize_text_field( $post['link_login_title'] ?? '' );
				$values['link_login_body']         = sanitize_textarea_field( $post['link_login_body'] ?? '' );
				$values['link_login_button']       = sanitize_text_field( $post['link_login_button'] ?? '' );

				$values['ma_connect_enabled']  = BMC_Settings::normalize_yesno( $post['ma_connect_enabled'] ?? 'no' );
				$values['ma_connect_title']    = sanitize_text_field( $post['ma_connect_title'] ?? '' );
				$values['ma_connect_slug']     = sanitize_title( $post['ma_connect_slug'] ?? '' );
				$values['ma_connect_icon']     = sanitize_key( $post['ma_connect_icon'] ?? '' );
				$values['ma_connect_position'] = sanitize_key( $post['ma_connect_position'] ?? '' );
				$values['ma_connect_badge']    = BMC_Settings::normalize_yesno( $post['ma_connect_badge'] ?? 'no' );
				break;

			case 'messages':
				$values['txt_link_title']       = sanitize_text_field( $post['txt_link_title'] ?? '' );
				$values['txt_not_linked_title'] = sanitize_text_field( $post['txt_not_linked_title'] ?? '' );
				$values['txt_linked_title']     = sanitize_text_field( $post['txt_linked_title'] ?? '' );
				$values['txt_cart_blocked']     = sanitize_textarea_field( $post['txt_cart_blocked'] ?? '' );
				$values['txt_thankyou']         = sanitize_textarea_field( $post['txt_thankyou'] ?? '' );
				break;

			case 'deliveries':
				$values['delivery_report_enabled'] = BMC_Settings::normalize_yesno( $post['delivery_report_enabled'] ?? 'yes' );
				$values['delivery_note_user']      = BMC_Settings::normalize_yesno( $post['delivery_note_user'] ?? 'yes' );
				$values['delivery_show_attempts']  = BMC_Settings::normalize_yesno( $post['delivery_show_attempts'] ?? 'yes' );
				$values['delivery_stuck_days']     = max( 1, min( 90, (int) ( $post['delivery_stuck_days'] ?? 3 ) ) );
				break;

			case 'tools':
				$values['update_enabled']      = BMC_Settings::normalize_yesno( $post['update_enabled'] ?? 'yes' );
				$values['update_channel']      = in_array( $post['update_channel'] ?? '', array( 'stable', 'prerelease' ), true ) ? $post['update_channel'] : 'stable';
				$values['update_repo']         = sanitize_text_field( $post['update_repo'] ?? 'iobsifox/BazzarMc' );
				$values['update_token']        = sanitize_text_field( $post['update_token'] ?? '' );
				$values['update_ttl']          = max( 1, min( 168, (int) ( $post['update_ttl'] ?? 6 ) ) );
				$values['update_auto']         = BMC_Settings::normalize_yesno( $post['update_auto'] ?? 'no' );
				$values['update_notice']       = BMC_Settings::normalize_yesno( $post['update_notice'] ?? 'yes' );
				$values['update_show_jar']     = BMC_Settings::normalize_yesno( $post['update_show_jar'] ?? 'yes' );
				$values['update_notify_email'] = sanitize_text_field( $post['update_notify_email'] ?? '' );
				$values['elementor_enabled']   = BMC_Settings::normalize_yesno( $post['elementor_enabled'] ?? 'yes' );
				$values['safe_guard']          = BMC_Settings::normalize_yesno( $post['safe_guard'] ?? 'yes' );
				$values['safe_autorecover']    = BMC_Settings::normalize_yesno( $post['safe_autorecover'] ?? 'yes' );
				$values['safe_debug_display']  = BMC_Settings::normalize_yesno( $post['safe_debug_display'] ?? 'no' );
				$values['safe_crash_limit']    = max( 1, min( 10, (int) ( $post['safe_crash_limit'] ?? 2 ) ) );
				$values['safe_notify_email']   = sanitize_text_field( $post['safe_notify_email'] ?? '' );
				break;

			case 'purge':
				$values['purge_on_uninstall'] = BMC_Settings::normalize_yesno( $post['purge_on_uninstall'] ?? 'no' );
				break;
		}

		foreach ( $post as $bmc_posted_key => $bmc_posted_value ) {
			if ( isset( $values[ $bmc_posted_key ] ) ) {
				continue;
			}

			if ( ! array_key_exists( $bmc_posted_key, $bmc_known_keys ) ) {
				continue;
			}

			if ( is_array( $bmc_posted_value ) !== is_array( $bmc_known_keys[ $bmc_posted_key ] ) ) {
				continue;
			}

			$values[ $bmc_posted_key ] = $bmc_posted_value;
		}

		return apply_filters( 'bmc_admin_save_values', $values, $tab, $post );
	}

	public static function ajax_action() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی ندارید.' ), 403 );
		}

		check_admin_referer( 'bmc_admin', 'security' );

		$do = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';

		switch ( $do ) {
			case 'revoke_rank':
				$user_id = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : ( isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0 );
				$player  = isset( $_POST['player'] ) ? sanitize_text_field( wp_unslash( $_POST['player'] ) ) : '';
				$target  = isset( $_POST['target'] ) ? sanitize_text_field( wp_unslash( $_POST['target'] ) ) : '';

				if ( ! $user_id && '' !== $player && class_exists( 'BMC_Link' ) ) {
					$u = BMC_Link::find_user_by_player( $player );
					if ( $u ) {
						$user_id = (int) $u->ID;
					}
				}

				if ( ! $user_id ) {
					wp_send_json_error( array( 'message' => 'کاربر یا بازیکن مورد نظر یافت نشد.' ), 400 );
				}

				$ok = BMC_Roles::revoke_user_rank( $user_id, $target );

				if ( ! $ok ) {
					wp_send_json_error( array( 'message' => 'رنک فعالی برای لغو یافت نشد.' ), 400 );
				}

				wp_send_json_success(
					array(
						'message' => 'رنک کاربر با موفقیت لغو شد و در همگام‌سازی بعدی از ماینکرافت نیز حذف می‌شود.',
					)
				);
				break;

			case 'regenerate_token':
				$token = BMC_Settings::regenerate_token();
				wp_send_json_success(
					array(
						'message' => 'توکن جدید ساخته شد. آن را در پلاگین ماینکرافت به‌روزرسانی کنید.',
						'token'   => $token,
					)
				);
				break;

			case 'test_email':
				$to = isset( $_POST['to'] ) ? sanitize_text_field( wp_unslash( $_POST['to'] ) ) : '';
				$to = BMC_Helpers::sanitize_email( $to );

				if ( ! $to ) {
					$current_user = wp_get_current_user();
					if ( $current_user && is_email( $current_user->user_email ) ) {
						$to = $current_user->user_email;
					}
				}

				if ( ! $to || ! is_email( $to ) ) {
					wp_send_json_error( array( 'message' => 'لطفاً یک آدرس ایمیل معتبر وارد کنید.' ), 400 );
				}

				$code   = BMC_Helpers::random_otp( BMC_Settings::int( 'otp_length', 5, 4, 8 ) );
				$result = BMC_Verify::send_email_code( $to, $code, array( 'player' => 'مدیر سایت', 'type' => 'test' ) );

				if ( empty( $result['success'] ) ) {
					wp_send_json_error( array( 'message' => $result['message'] ), 400 );
				}

				wp_send_json_success( array( 'message' => 'ایمیل آزمایشی با موفقیت به ' . $to . ' ارسال شد.' ) );
				break;

			case 'test_connection':
			case 'ping_api':
				$start = microtime( true );
				$token = BMC_Settings::api_token();
				$url   = rest_url( BMC_REST_NS . '/ping' );
				$res   = wp_remote_post(
					$url,
					array(
						'timeout' => 12,
						'headers' => array( 'X-BMC-Token' => $token ),
					)
				);
				$elapsed = round( ( microtime( true ) - $start ) * 1000 );

				if ( is_wp_error( $res ) ) {
					wp_send_json_error( array( 'message' => 'خطای اتصال: ' . $res->get_error_message() ), 400 );
				}

				$code = wp_remote_retrieve_response_code( $res );
				if ( 200 !== $code ) {
					wp_send_json_error( array( 'message' => 'سرور کد خطا داد: ' . $code ), 400 );
				}

				$body = json_decode( wp_remote_retrieve_body( $res ), true );
				wp_send_json_success(
					array(
						'message' => 'پاسخ در ' . BMC_Helpers::to_persian_digits( $elapsed ) . ' میلی‌ثانیه دریافت شد (نسخهٔ ' . ( isset( $body['version'] ) ? $body['version'] : '?' ) . ').',
						'ms'      => $elapsed,
						'body'    => $body,
					)
				);
				break;

			case 'force_unlink':
			case 'unlink_user':
				$user_id = isset( $_POST['user_id'] ) ? absint( $_POST['user_id'] ) : ( isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0 );
				if ( ! $user_id ) {
					wp_send_json_error( array( 'message' => 'شناسهٔ کاربر نامعتبر است.' ), 400 );
				}
				$player = class_exists( 'BMC_Link' ) ? BMC_Link::get_player( $user_id ) : '';
				if ( class_exists( 'BMC_Link' ) ) {
					BMC_Link::unlink_user( $user_id );
				}
				BMC_Logger::add( 'link', sprintf( 'اتصال کاربر #%d (بازیکن %s) توسط مدیر قطع شد.', $user_id, $player ? $player : '—' ), array( 'user_id' => $user_id ), 'warning' );
				wp_send_json_success( array( 'message' => 'اتصال اکانت ماینکرافت کاربر با موفقیت قطع شد.' ) );
				break;

			case 'bulk_unlink':
				$ids = isset( $_POST['ids'] ) ? array_map( 'absint', (array) $_POST['ids'] ) : array();
				$unlinked = 0;
				foreach ( $ids as $u_id ) {
					if ( $u_id && class_exists( 'BMC_Link' ) ) {
						BMC_Link::unlink_user( $u_id );
						$unlinked++;
					}
				}
				wp_send_json_success( array( 'message' => sprintf( 'اتصال %s کاربر قطع شد.', BMC_Helpers::to_persian_digits( $unlinked ) ) ) );
				break;

			case 'manual_grant':
				$player = isset( $_POST['player'] ) ? sanitize_text_field( wp_unslash( $_POST['player'] ) ) : '';
				$item   = isset( $_POST['item'] ) ? sanitize_text_field( wp_unslash( $_POST['item'] ) ) : '';
				$amount = isset( $_POST['amount'] ) ? max( 1, (int) $_POST['amount'] ) : 1;
				$note   = isset( $_POST['note'] ) ? sanitize_text_field( wp_unslash( $_POST['note'] ) ) : 'اعطای دستی توسط مدیر';
				$timing = isset( $_POST['timing'] ) && 'join' === $_POST['timing'] ? 'join' : 'now';

				if ( '' === $player || '' === $item ) {
					wp_send_json_error( array( 'message' => 'نام بازیکن و آیتم/پاداش الزامی هستند.' ), 400 );
				}

				$grant_id = BMC_Deliveries::create_manual_grant(
					array(
						'player' => $player,
						'item'   => $item,
						'amount' => $amount,
						'note'   => $note,
						'source' => 'manual',
						'timing' => $timing,
					)
				);

				if ( ! $grant_id ) {
					wp_send_json_error( array( 'message' => 'ثبت پاداش دستی در دیتابیس با شکست مواجه شد.' ), 500 );
				}

				wp_send_json_success( array( 'message' => sprintf( 'پاداش با موفقیت برای بازیکن %s در صف تحویل ثبت شد.', $player ), 'id' => $grant_id ) );
				break;

			case 'check_updates':
				if ( class_exists( 'BMC_Updater' ) ) {
					delete_transient( 'bmc_update_latest_release' );
					$status = BMC_Updater::check( true );
					wp_send_json_success(
						array(
							'message' => ! empty( $status['has_update'] )
								? 'نسخهٔ جدید ' . $status['latest'] . ' در دسترس است.'
								: 'افزونه و پلاگین به‌روز هستند.',
							'status'  => $status,
						)
					);
				}
				wp_send_json_error( array( 'message' => 'ماژول به‌روزرسانی فعال نیست.' ), 400 );
				break;

			case 'run_cron':
				$result = BMC_Cron::run_now();
				wp_send_json_success(
					array(
						'message' => sprintf( 'نگهداری انجام شد: %d تحویل منقضی و %d کد پاک شد.', $result['deliveries'], $result['codes'] ),
					)
				);
				break;

			case 'flush_permalinks':
				flush_rewrite_rules();

				if ( class_exists( 'BMC_Account_Endpoints' ) ) {
					delete_option( BMC_Account_Endpoints::FLUSH_OPTION );
					update_option( BMC_Account_Endpoints::FLUSH_OPTION . '_slugs', BMC_Account_Endpoints::slugs(), false );
				}

				wp_send_json_success( array( 'message' => 'پیوندهای یکتا بازسازی شد.' ) );
				break;

			case 'purge_cache':
				$results = BMC_Cache::purge_all();
				$parts   = array();

				foreach ( $results as $name => $result ) {
					if ( ! empty( $result['success'] ) ) {
						$parts[] = $name . ': ' . ( isset( $result['message'] ) ? $result['message'] : 'انجام شد' );
					} else {
						$parts[] = $name . ': ناموفق — ' . ( isset( $result['message'] ) ? $result['message'] : '' );
					}
				}

				wp_send_json_success( array( 'message' => $parts ? implode( ' | ', $parts ) : 'پاک‌سازی کش انجام شد.' ) );
				break;

			case 'cf_cache_rule':
				$result = BMC_Cache::cloudflare_upsert_cache_rule();

				if ( empty( $result['success'] ) ) {
					wp_send_json_error( array( 'message' => isset( $result['message'] ) ? $result['message'] : 'ناموفق بود.' ), 400 );
				}

				wp_send_json_success( array( 'message' => 'قاعدهٔ کش Cloudflare ذخیره شد.' ) );
				break;

			case 'clear_logs':
			case 'clear_old_logs':
				$bmc_days  = 'clear_old_logs' === $do ? 30 : 0;
				$bmc_count = BMC_Logger::clear( $bmc_days );

				if ( -1 === $bmc_count ) {
					wp_send_json_error( array( 'message' => 'جدول لاگ‌ها پیدا نشد؛ از تب ابزارها «بازسازی جدول‌ها» را بزنید و دوباره تلاش کنید.' ), 400 );
				}

				if ( -2 === $bmc_count ) {
					wp_send_json_error( array( 'message' => 'پاک‌کردن لاگ‌ها ناموفق بود؛ کاربر دیتابیس اجازهٔ DELETE روی این جدول ندارد یا خطای دیتابیس رخ داد. جزئیات در لاگ خطای وردپرس است.' ), 400 );
				}

				if ( 0 === $bmc_count ) {
					wp_send_json_success( array( 'message' => $bmc_days ? 'لاگ قدیمی‌تری از ' . $bmc_days . ' روز پیش وجود نداشت.' : 'لاگی برای پاک‌کردن وجود نداشت.' ) );
				}

				wp_send_json_success(
					array(
						'message' => $bmc_days
							? 'لاگ‌های قدیمی‌تر از ' . BMC_Helpers::to_persian_digits( $bmc_days ) . ' روز پاک شدند (' . BMC_Helpers::to_persian_digits( $bmc_count ) . ' ردیف).'
							: 'همهٔ لاگ‌ها پاک شدند (' . BMC_Helpers::to_persian_digits( $bmc_count ) . ' ردیف).',
					)
				);
				break;

			case 'rebuild_tables':
				BMC_DB::install();
				wp_send_json_success( array( 'message' => 'جدول‌ها بازسازی/به‌روزرسانی شدند.' ) );
				break;

			case 'create_pages':
				BMC_Migrate::maybe_create_pages();
				wp_send_json_success(
					array(
						'message' => 'صفحه‌های اتصال و ورود ساخته/به‌روزرسانی شدند.',
						'link'    => (int) BMC_Settings::get( 'page_link' ),
					)
				);
				break;

			case 'run_migration':
				set_time_limit( 300 );
				$result = BMC_Migrate::run();
				wp_send_json_success(
					array(
						'message' => sprintf(
							'مهاجرت انجام شد: %d کاربر، %d تحویل، %d تنظیم.',
							$result['users'],
							$result['deliveries'],
							$result['options']
						),
					)
				);
				break;

			case 'run_health':
				set_time_limit( 120 );
				$checks = BMC_Safe::health();
				$bad    = 0;

				foreach ( $checks as $check ) {
					if ( 'fail' === $check['status'] ) {
						$bad++;
					}
				}

				wp_send_json_success(
					array(
						'message' => sprintf( 'آزمون سلامت انجام شد: %d بررسی، %d مورد نیازمند اقدام.', count( $checks ), $bad ),
						'checks'  => $checks,
					)
				);
				break;

			case 'safe_on':
				BMC_Safe::activate( 'on' );
				wp_send_json_success( array( 'message' => 'حالت ایمن فعال شد؛ بخش‌های غیرضروری خاموش شدند.' ) );
				break;

			case 'safe_off':
				BMC_Safe::deactivate();
				wp_send_json_success( array( 'message' => 'حالت ایمن خاموش شد و همهٔ بخش‌ها دوباره فعال‌اند.' ) );
				break;

			case 'safe_recover':
				BMC_Safe::recover();
				wp_send_json_success( array( 'message' => 'بازیابی انجام شد.' ) );
				break;

			case 'clear_crash':
				BMC_Safe::reset();
				wp_send_json_success( array( 'message' => 'گزارش خطاهای فاحش پاک شد.' ) );
				break;

			default:
				wp_send_json_error( array( 'message' => 'عملیات نامعتبر است.' ), 400 );
		}
	}

	public static function maybe_export_csv() {
		if ( empty( $_GET['bmc_export'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}

		check_admin_referer( 'bmc_export', 'bmc_nonce' );

		$result = BMC_Deliveries::query( array( 'per_page' => 100, 'paged' => 1 ) );
		$all    = array();
		$pages  = min( 50, (int) $result['pages'] );

		for ( $page = 1; $page <= $pages; $page++ ) {
			$chunk = BMC_Deliveries::query( array( 'per_page' => 100, 'paged' => $page ) );
			$all   = array_merge( $all, $chunk['items'] );
		}

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=bazzarmc-deliveries-' . gmdate( 'Ymd-His' ) . '.csv' );

		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" );
		fputcsv( $out, array( 'id', 'order_id', 'user_id', 'player', 'product_id', 'variation_id', 'item', 'amount', 'status', 'created_at', 'delivered_at', 'expires_at' ) );

		foreach ( $all as $row ) {
			fputcsv(
				$out,
				array(
					$row->id,
					$row->order_id,
					$row->user_id,
					$row->player,
					$row->product_id,
					$row->variation_id,
					$row->item,
					$row->amount,
					BMC_Deliveries::status_label( $row->status ),
					$row->created_at,
					$row->delivered_at,
					$row->expires_at,
				)
			);
		}

		fclose( $out );
		exit;
	}
}
