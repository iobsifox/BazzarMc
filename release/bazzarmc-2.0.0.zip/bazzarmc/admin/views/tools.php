<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tables = BMC_DB::table_status();
$logs   = BMC_Logger::recent( 40 );

$bmc_safe_on     = class_exists( 'BMC_Safe' ) && BMC_Safe::safe_mode();
$bmc_safe_reason = class_exists( 'BMC_Safe' ) ? BMC_Safe::safe_mode_reason() : '';
$bmc_safe_state  = class_exists( 'BMC_Safe' ) ? BMC_Safe::state() : array();
$bmc_safe_errors = class_exists( 'BMC_Safe' ) ? BMC_Safe::errors() : array();
$bmc_boot_errors = get_option( 'bmc_bootstrap_errors', array() );
$bmc_boot_errors = is_array( $bmc_boot_errors ) ? $bmc_boot_errors : array();
$bmc_update      = class_exists( 'BMC_Updater' ) ? BMC_Updater::status() : array();
$token           = BMC_Settings::api_token();
$masked_token    = substr( $token, 0, 4 ) . '••••••••••••' . substr( $token, -4 );
?>

<div class="bmc-update-cards-grid">
	<div class="bmc-update-card">
		<div class="bmc-update-card__head">
			<div class="bmc-inline">
				<span class="bmc-update-card__icon"><?php bmc_icon( 'wordpress', array( 'size' => 20 ) ); ?></span>
				<div>
					<strong>افزونهٔ وردپرس (WordPress Plugin)</strong>
					<small class="bmc-dim">مخزن GitHub: <code>iobsifox/BazzarMc</code></small>
				</div>
			</div>
			<?php if ( ! empty( $bmc_update['has_update'] ) ) : ?>
				<span class="bmc-pill is-pending">نسخهٔ جدید آماده است</span>
			<?php else : ?>
				<span class="bmc-pill is-done">به‌روز (Up to date)</span>
			<?php endif; ?>
		</div>
		<div class="bmc-update-card__body">
			<div class="bmc-update-versions">
				<div>
					<span class="bmc-label-dim">نسخهٔ فعلی</span>
					<strong dir="ltr" class="bmc-ver">v<?php echo esc_html( BMC_VERSION ); ?></strong>
				</div>
				<div>
					<span class="bmc-label-dim">آخرین نسخهٔ منتشرشده</span>
					<strong dir="ltr" class="bmc-ver"><?php echo ! empty( $bmc_update['latest'] ) ? 'v' . esc_html( $bmc_update['latest'] ) : 'v' . esc_html( BMC_VERSION ); ?></strong>
				</div>
			</div>
			<p class="bmc-update-note">
				پشتیبان‌گیری خودکار پیش از به‌روزرسانی با قابلیت بازگشت به نسخه قبل فعال است.
			</p>
		</div>
		<div class="bmc-update-card__foot">
			<button type="button" class="button button-primary bmc-action" data-do="check_updates">
				<?php bmc_icon( 'sync', array( 'size' => 14 ) ); ?>
				<span>بررسی و دریافت به‌روزرسانی</span>
			</button>
			<?php if ( ! empty( $bmc_update['url'] ) ) : ?>
				<a href="<?php echo esc_url( $bmc_update['url'] ); ?>" target="_blank" rel="noopener noreferrer" class="bmc-link-dim">مشاهده چنج‌لاگ در گیت‌هاب ↗</a>
			<?php endif; ?>
		</div>
	</div>

	<div class="bmc-update-card">
		<div class="bmc-update-card__head">
			<div class="bmc-inline">
				<span class="bmc-update-card__icon"><?php bmc_icon( 'sports_esports', array( 'size' => 20 ) ); ?></span>
				<div>
					<strong>پلاگین سرور ماینکرافت (Minecraft Jar)</strong>
					<small class="bmc-dim">فایل سرور: <code>BazzarMC-<?php echo esc_html( BMC_VERSION ); ?>.jar</code></small>
				</div>
			</div>
			<span class="bmc-pill is-done">همگام با هسته</span>
		</div>
		<div class="bmc-update-card__body">
			<div class="bmc-update-versions">
				<div>
					<span class="bmc-label-dim">نسخهٔ سرور</span>
					<strong dir="ltr" class="bmc-ver">v<?php echo esc_html( BMC_VERSION ); ?></strong>
				</div>
				<div>
					<span class="bmc-label-dim">وضعیت سازگاری</span>
					<strong class="bmc-ver" style="color:var(--bmc-accent)">Paper/Spigot 1.16+</strong>
				</div>
			</div>
			<p class="bmc-update-note">
				فایل jar جدید به صورت مستقیم در هر ریلیز گیت‌هاب پیوست و قابل دانلود است.
			</p>
		</div>
		<div class="bmc-update-card__foot">
			<?php if ( ! empty( $bmc_update['mc_jar_url'] ) ) : ?>
				<a href="<?php echo esc_url( $bmc_update['mc_jar_url'] ); ?>" class="button" download>
					<?php bmc_icon( 'file_download', array( 'size' => 14 ) ); ?>
					<span>دانلود مستقیم فایل jar</span>
				</a>
			<?php else : ?>
				<a href="https://github.com/iobsifox/BazzarMc/releases" target="_blank" rel="noopener noreferrer" class="button">
					<?php bmc_icon( 'file_download', array( 'size' => 14 ) ); ?>
					<span>دانلود از ریلیزهای گیت‌هاب</span>
				</a>
			<?php endif; ?>
		</div>
	</div>
</div>

<section class="bmc-box">
	<div class="bmc-box__head">
		<div class="bmc-inline">
			<h2><?php bmc_icon( 'shield', array( 'size' => 18 ) ); ?> امنیت و کنترل احراز هویت REST API</h2>
			<span class="bmc-pill is-done">احراز هویت توکن‌محور فعال</span>
		</div>
	</div>
	<div class="bmc-box__body">
		<div class="bmc-security-grid">
			<div class="bmc-sec-item">
				<label>توکن امنیتی API (API Key)</label>
				<div class="bmc-token-reveal-wrap">
					<code class="bmc-masked-token" id="bmcMaskedToken"><?php echo esc_html( $masked_token ); ?></code>
					<code class="bmc-masked-token" id="bmcFullToken" style="display:none"><?php echo esc_html( $token ); ?></code>
					<button type="button" class="button button-small" id="bmcToggleTokenReveal">نمایش کامل</button>
					<button type="button" class="button button-small bmc-action" data-do="regenerate_token" data-confirm="1">ساخت مجدد (Rotate)</button>
				</div>
				<small class="bmc-dim">این کلید محرمانه را فقط در config.yml سرور خود قرار دهید.</small>
			</div>

			<div class="bmc-sec-item">
				<label>محدودکنندهٔ نرخ درخواست‌ها (Rate Limiter)</label>
				<div class="bmc-rate-status">
					<span class="bmc-pill is-done">فعال — حداکثر ۶۰ درخواست در دقیقه برای هر IP</span>
				</div>
				<small class="bmc-dim">حفاظت خودکار در برابر حملات محروم‌سازی از سرویس (DDoS/Brute-force).</small>
			</div>
		</div>
	</div>
</section>

<section class="bmc-box">
	<div class="bmc-box__head">
		<div class="bmc-inline">
			<h2><?php bmc_icon( 'list_alt', array( 'size' => 18 ) ); ?> لاگ فعالیت‌ها و ردپای حسابرسی (Activity Audit Log)</h2>
			<span class="bmc-pill is-info"><?php echo esc_html( BMC_Helpers::to_persian_digits( count( $logs ) ) ); ?> رویداد ثبت‌شده</span>
		</div>
		<div class="bmc-inline">
			<button type="button" class="button button-small bmc-action" data-do="clear_old_logs">پاک‌سازی لاگ‌های قدیمی‌تر از ۳۰ روز</button>
			<button type="button" class="button button-small button-link-delete bmc-action" data-do="clear_logs" data-confirm="1">پاک‌کردن همهٔ لاگ‌ها</button>
		</div>
	</div>
	<div class="bmc-box__body bmc-box__body--flush">
		<?php if ( empty( $logs ) ) : ?>
			<p class="bmc-empty">هیچ رویدادی در لاگ ثبت نشده است.</p>
		<?php else : ?>
			<table class="bmc-table bmc-table--full">
				<thead>
					<tr>
						<th style="width:160px">زمان (Timestamp)</th>
						<th style="width:100px">کانال</th>
						<th style="width:90px">سطح</th>
						<th>شرح رویداد و جزئیات</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $logs as $log ) : ?>
						<tr class="bmc-log-row bmc-log-row--<?php echo esc_attr( $log->level ); ?>">
							<td class="bmc-dim"><?php echo esc_html( BMC_Jalali::format( $log->created_at ) ); ?></td>
							<td><span class="bmc-channel-pill"><?php echo esc_html( $log->channel ); ?></span></td>
							<td><span class="bmc-pill is-<?php echo 'error' === $log->level ? 'expired' : ( 'warning' === $log->level ? 'pending' : 'done' ); ?>"><?php echo esc_html( $log->level ); ?></span></td>
							<td>
								<?php echo esc_html( $log->message ); ?>
								<?php if ( ! empty( $log->context ) ) : ?>
									<code class="bmc-dim" dir="ltr"><?php echo esc_html( $log->context ); ?></code>
								<?php endif; ?>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php endif; ?>
	</div>
</section>

<section class="bmc-box">
	<div class="bmc-box__head">
		<div class="bmc-inline">
			<h2><?php bmc_icon( 'health_and_safety', array( 'size' => 18 ) ); ?> محافظ پایداری و سلامت سیستم</h2>
			<span class="bmc-pill <?php echo $bmc_safe_on ? 'is-cancelled' : 'is-done'; ?>">
				<?php echo $bmc_safe_on ? 'حالت ایمن فعال است' : 'سیستم سالم و نرمال'; ?>
			</span>
		</div>
		<button type="button" class="button button-primary bmc-action" data-do="run_health">
			<?php bmc_icon( 'medical_services', array( 'size' => 15 ) ); ?>
			<span>بررسی جامع سلامت سایت</span>
		</button>
	</div>
	<div class="bmc-box__body">
		<p class="bmc-hint">
			موتور پایداری افزونه خطاهای مهلک را شمارش کرده و در صورت بروز خطا از ایجاد صفحه سفید یا قطعی سایت محافظت می‌کند.
		</p>
		<div id="bmcHealthResult" style="display:none;margin-top:14px"></div>
	</div>
</section>

<?php
BMC_Admin::form_open( 'tools' );

BMC_Admin::section_open( 'تنظیمات به‌روزرسانی خودکار و نگهداری لاگ‌ها' );

BMC_Admin::row(
	'بررسی به‌روزرسانی افزونه',
	BMC_Admin::toggle( 'update_enabled', $settings['update_enabled'], 'بررسی دوره‌ای ریلیزهای گیت‌هاب فعال باشد' )
);

BMC_Admin::row(
	'کانال انتشار',
	BMC_Admin::select(
		'update_channel',
		$settings['update_channel'],
		array(
			'stable' => 'پایدار (Stable Releases — پیشنهادی)',
			'beta'   => 'پیش‌انتشار و آزمایشی (Beta / Pre-release)',
		)
	)
);

BMC_Admin::row(
	'فاصلهٔ بررسی (ساعت)',
	BMC_Admin::input( 'update_ttl', (int) $settings['update_ttl'], array( 'type' => 'number', 'min' => 1, 'max' => 168, 'class' => 'bmc-input--sm' ) )
);

BMC_Admin::row(
	'به‌روزرسانی کاملاً خودکار',
	BMC_Admin::toggle( 'update_auto', $settings['update_auto'], 'افزونه در صورت انتشار نسخهٔ جدید، خودش آپدیت شود' )
);

BMC_Admin::section_close();

BMC_Admin::form_close( 'ذخیرهٔ تنظیمات ابزارها' );
?>
