<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$synced                 = array_map( 'absint', (array) $settings['sync_products'] );
$product_role           = (array) $settings['product_roles'];
$product_keys           = (array) $settings['product_keys'];
$product_duration       = (array) $settings['product_role_duration'];
$role_default_duration   = (int) $settings['role_duration_default'];
$rank_levels             = (array) $settings['rank_levels'];
$bmc_rank_defs           = BMC_Ranks::definitions();
$bmc_rank_status         = BMC_Ranks::status();
$bmc_active_users        = BMC_Roles::users_with_active_grants( 50 );

$bmc_key_options = array(
	'name'   => 'نام محصول (نام ووکامرس)',
	'id'     => 'شناسهٔ محصول (ID)',
	'slug'   => 'نامک / slug',
	'custom' => 'دلخواه (متن دستی)',
	'sku'    => 'کد کالا (SKU)',
);

$products = array();
if ( function_exists( 'wc_get_products' ) ) {
	$products = wc_get_products(
		array(
			'limit'   => 500,
			'status'  => array( 'publish', 'private', 'draft' ),
			'orderby' => 'title',
			'order'   => 'ASC',
			'return'  => 'objects',
		)
	);
}

$expiring_count = 0;
$now_ts = BMC_Helpers::now_timestamp();
foreach ( $bmc_active_users as $u_item ) {
	$r = $u_item['rank'];
	if ( empty( $r['permanent'] ) && ! empty( $r['expires_at'] ) ) {
		$exp_ts = strtotime( (string) $r['expires_at'] );
		if ( $exp_ts && ( $exp_ts - $now_ts ) <= ( 7 * DAY_IN_SECONDS ) && ( $exp_ts - $now_ts ) > 0 ) {
			$expiring_count++;
		}
	}
}
?>

<div class="bmc-rank-digest-strip">
	<div class="bmc-digest-item">
		<span class="bmc-digest-icon"><?php bmc_icon( 'military_tech', array( 'size' => 24 ) ); ?></span>
		<div>
			<strong><?php echo esc_html( BMC_Helpers::to_persian_digits( count( $bmc_active_users ) ) ); ?> کاربر دارای رنک فعال</strong>
			<small class="bmc-dim">قانون تک‌رنک فعال برای تمامی کاربران برقرار است</small>
		</div>
	</div>

	<?php if ( $expiring_count > 0 ) : ?>
		<div class="bmc-digest-item is-warn">
			<span class="bmc-digest-icon"><?php bmc_icon( 'timer', array( 'size' => 24 ) ); ?></span>
			<div>
				<strong><?php echo esc_html( BMC_Helpers::to_persian_digits( $expiring_count ) ); ?> رنک در حال انقضا در ۷ روز آینده</strong>
				<small>اطلاع‌رسانی خودکار پیش از انقضا فعال است</small>
			</div>
		</div>
	<?php endif; ?>

	<div class="bmc-digest-item">
		<span class="bmc-digest-icon"><?php bmc_icon( 'sync', array( 'size' => 24 ) ); ?></span>
		<div>
			<strong>همگام‌سازی دوطرفه با LuckPerms</strong>
			<small class="bmc-dim">
				<?php echo $bmc_rank_status['synced_at'] ? esc_html( BMC_Jalali::format( $bmc_rank_status['synced_at'] ) ) : 'در انتظار دریافت اولین گزارش'; ?>
			</small>
		</div>
	</div>
</div>

<section class="bmc-box">
	<div class="bmc-box__head">
		<div class="bmc-inline">
			<h2><?php bmc_icon( 'badge', array( 'size' => 18 ) ); ?> کاربران دارای رنک فعال و وضعیت همگام‌سازی (Active Ranks)</h2>
			<span class="bmc-pill is-info"><?php echo esc_html( BMC_Helpers::to_persian_digits( count( $bmc_active_users ) ) ); ?> فعال</span>
		</div>
	</div>
	<div class="bmc-box__body bmc-box__body--flush">
		<?php if ( ! empty( $bmc_active_users ) ) : ?>
			<table class="bmc-table bmc-table--full">
				<thead>
					<tr>
						<th>کاربر سایت</th>
						<th>بازیکن و پلتفرم</th>
						<th>رنک فعال</th>
						<th>سطح (Priority)</th>
						<th>مدت اعتبار و انقضا</th>
						<th>وضعیت همگامی (LuckPerms)</th>
						<th>عملیات</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $bmc_active_users as $bmc_u_item ) : ?>
						<?php
						$bmc_u_id   = (int) $bmc_u_item['user_id'];
						$bmc_u_user = $bmc_u_item['user'];
						$bmc_u_play = $bmc_u_item['player'];
						$bmc_u_rank = $bmc_u_item['rank'];
						$bmc_plat   = class_exists( 'BMC_Link' ) ? BMC_Link::detect_platform( $bmc_u_play ) : 'java';
						$bmc_r_name = ! empty( $bmc_u_rank['label'] ) ? $bmc_u_rank['label'] : ( ! empty( $bmc_u_rank['role_label'] ) ? $bmc_u_rank['role_label'] : $bmc_u_rank['key'] );
						$bmc_r_time = ! empty( $bmc_u_rank['permanent'] ) ? 'دائمی (Permanent)' : ( ! empty( $bmc_u_rank['remaining_human'] ) ? $bmc_u_rank['remaining_human'] : '—' );
						if ( ! empty( $bmc_u_rank['expires_jalali'] ) ) {
							$bmc_r_time .= ' (تا ' . $bmc_u_rank['expires_jalali'] . ')';
						}
						$is_in_sync = ! empty( $bmc_u_rank['still_has_role'] ) || ! empty( $bmc_u_rank['source'] );
						?>
						<tr>
							<td>
								<strong><?php echo esc_html( $bmc_u_user->display_name ); ?></strong>
								<small class="bmc-dim">(<?php echo esc_html( $bmc_u_user->user_email ); ?>)</small>
							</td>
							<td>
								<?php if ( $bmc_u_play ) : ?>
									<span class="bmc-player-cell">
										<img src="<?php echo esc_url( BMC_Helpers::mc_head( $bmc_u_play, 20 ) ); ?>" width="20" height="20" alt="" />
										<code dir="ltr"><?php echo esc_html( $bmc_u_play ); ?></code>
										<span class="bmc-platform-chip bmc-platform-chip--<?php echo esc_attr( $bmc_plat ); ?>"><?php echo 'bedrock' === $bmc_plat ? 'Bedrock' : 'Java'; ?></span>
									</span>
								<?php else : ?>
									<span class="bmc-dim">اکانت متصل نیست</span>
								<?php endif; ?>
							</td>
							<td><span class="bmc-pill is-done"><?php echo esc_html( $bmc_r_name ); ?></span></td>
							<td><span class="bmc-mono">سطح <?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_u_rank['level'] ) ); ?></span></td>
							<td><?php echo esc_html( $bmc_r_time ); ?></td>
							<td>
								<span class="bmc-sync-chip <?php echo $is_in_sync ? 'is-synced' : 'is-pending'; ?>">
									<?php echo $is_in_sync ? 'همگام (In sync)' : 'در انتظار همگامی'; ?>
								</span>
							</td>
							<td>
								<button type="button" class="button button-small button-link-delete bmc-action" data-do="revoke_rank" data-id="<?php echo esc_attr( $bmc_u_id ); ?>" data-confirm="1" data-reload="1">
									لغو و سلب رنک
								</button>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		<?php else : ?>
			<p class="bmc-empty">در حال حاضر کاربری با رنک فعال ثبت نشده است.</p>
		<?php endif; ?>
	</div>
</section>

<?php
BMC_Admin::form_open( 'products' );

BMC_Admin::section_open(
	'نگاشت محصولات ووکامرس به رنک‌ها و پاداش‌های بازی (Rank Mapping)',
	'محصولاتی که بعد از خرید باید رنک یا آیتم به بازیکن اعطا کنند را فعال کنید. سطح رنک بزرگ‌تر به معنی رنک بالاتر است و سیستم به صورت خودکار مانع از خرید رنک پایین‌تر توسط کاربر می‌شود.'
);

BMC_Admin::row(
	'جلوگیری از خرید رنک پایین‌تر (Downgrade Protection)',
	BMC_Admin::toggle( 'rank_guard', $settings['rank_guard'], 'کاربری که رنک بالاتر دارد نتواند رنک پایین‌تر بخرد' ),
	'اگر آیتم رنک پایین‌تر در سبد خرید باشد، تسویه‌حساب مسدود شده و پیام راهنما جهت ارتقای رنک نمایش داده می‌شود.'
);

BMC_Admin::row(
	'پنهان‌کردن رنک‌های پایین‌تر در فروشگاه',
	BMC_Admin::toggle( 'rank_hide_lower', $settings['rank_hide_lower'], 'محصولات رنک پایین‌تر در کاتالوگ فروشگاه به کاربر دارای رنک بالاتر نشان داده نشود' )
);

BMC_Admin::row(
	'اعتبار پیش‌فرض رنک‌ها',
	BMC_Admin::input( 'role_duration_default', $role_default_duration, array( 'type' => 'number', 'min' => 0, 'max' => 36500, 'class' => 'bmc-input--sm' ) ) . ' <span class="bmc-suffix">روز (۰ = دائمی)</span>',
	'مدت فعال ماندن نقش پس از خرید. در صورت پایان اعتبار، رنک به‌صورت خودکار هر ساعت بازبینی و منقضی می‌شود.'
);

BMC_Admin::row(
	'بازپس‌گیری رنک هنگام استرداد سفارش',
	BMC_Admin::toggle( 'revoke_roles_on_refund', $settings['revoke_roles_on_refund'], 'با استرداد یا لغو سفارش ووکامرس، رنک اعطاشده بلافاصله از سایت و بازی پس گرفته شود' )
);
?>

<div class="bmc-toolbar">
	<input type="search" class="bmc-input" id="bmcProductSearch" placeholder="جست‌وجوی محصول ووکامرس…" />
	<span class="bmc-count">
		<strong id="bmcSelectedCount"><?php echo esc_html( BMC_Helpers::to_persian_digits( count( $synced ) ) ); ?></strong> محصول انتخاب‌شده برای تحویل
	</span>
</div>

<?php if ( empty( $products ) ) : ?>
	<p class="bmc-empty">محصولی در ووکامرس یافت نشد.</p>
<?php else : ?>
	<div class="bmc-product-list" id="bmcProductList">
		<?php foreach ( $products as $product ) : ?>
			<?php
			$pid      = $product->get_id();
			$checked  = in_array( $pid, $synced, true );
			$title    = $product->get_name();
			$price    = wc_price( $product->get_price() );
			$image_id = $product->get_image_id();
			$variations = array();

			if ( $product->is_type( 'variable' ) ) {
				$variations = $product->get_children();
			}
			?>
			<div class="bmc-product<?php echo $checked ? ' is-checked' : ''; ?>" data-title="<?php echo esc_attr( mb_strtolower( $title ) ); ?>">
				<label class="bmc-product__main">
					<span class="bmc-product__check">
						<input type="checkbox" name="sync_products[]" value="<?php echo esc_attr( $pid ); ?>" <?php checked( $checked ); ?> />
					</span>
					<span class="bmc-product__thumb">
						<?php echo $image_id ? wp_get_attachment_image( $image_id, array( 44, 44 ) ) : '<span class="bmc-thumb-fallback">' . bmc_get_icon( 'military_tech', array( 'size' => 20 ) ) . '</span>'; ?>
					</span>
					<span class="bmc-product__info">
						<strong><?php echo esc_html( $title ); ?></strong>
						<small><?php echo wp_kses_post( $price ); ?> • <?php echo esc_html( $product->get_type() ); ?></small>
						<code class="bmc-product__key">شناسه پیش‌فرض: <?php echo esc_html( mb_strtolower( trim( $title ) ) ); ?></code>
					</span>
				</label>
				<span class="bmc-product__key-field">
					<small>شناسهٔ تحویل در سرور</small>
					<?php echo BMC_Admin::select( 'product_key_type[' . $pid . ']', isset( $product_keys[ $pid ]['type'] ) ? $product_keys[ $pid ]['type'] : 'name', $bmc_key_options ); ?>
					<?php echo BMC_Admin::input( 'product_key_value[' . $pid . ']', isset( $product_keys[ $pid ]['value'] ) ? $product_keys[ $pid ]['value'] : '', array( 'dir' => 'ltr', 'placeholder' => 'vip' ) ); ?>
				</span>
				<span class="bmc-product__role">
					<small>نقش کاربری • سطح رنک (Priority)</small>
					<?php echo BMC_Admin::role_select( 'product_role[' . $pid . ']', isset( $product_role[ $pid ] ) ? $product_role[ $pid ] : '' ); ?>
					<span class="bmc-product__duration">
						<small>اعتبار (روز)</small>
						<?php echo BMC_Admin::input( 'product_role_duration[' . $pid . ']', isset( $product_duration[ $pid ] ) ? (int) $product_duration[ $pid ] : '', array( 'type' => 'number', 'min' => 0, 'max' => 36500, 'placeholder' => $role_default_duration ? BMC_Helpers::to_persian_digits( $role_default_duration ) : 'دائمی', 'class' => 'bmc-days' ) ); ?>
						<small>سطح</small>
						<?php echo BMC_Admin::input( 'rank_level[' . $pid . ']', isset( $rank_levels[ $pid ] ) ? (int) $rank_levels[ $pid ] : '', array( 'type' => 'number', 'min' => 0, 'max' => 9999, 'placeholder' => BMC_Helpers::to_persian_digits( BMC_Ranks::level_for_product( $pid ) ), 'class' => 'bmc-days' ) ); ?>
					</span>
				</span>
			</div>
		<?php endforeach; ?>
	</div>
<?php endif; ?>

<?php
BMC_Admin::section_close();

BMC_Admin::section_open(
	'رنک‌های تعریف‌شده در پلاگین ماینکرافت (LuckPerms Registry)',
	'پلاگین سرور ماینکرافت به صورت خودکار رنک‌های تعریف‌شده در بخش <code>ranks.list</code> فایل <code>config.yml</code> را به سایت ارسال می‌کند.'
);

if ( $bmc_rank_defs ) {
	echo '<table class="bmc-table bmc-table--full"><thead><tr><th>کلید در سرور</th><th>نام نمایشی</th><th>سطح (Priority)</th><th>گروه LuckPerms</th><th>اعتبار (روز)</th></tr></thead><tbody>';
	foreach ( $bmc_rank_defs as $bmc_def ) {
		printf(
			'<tr><td><code dir="ltr">%1$s</code></td><td><strong>%2$s</strong></td><td>سطح %3$s</td><td><code dir="ltr">%4$s</code></td><td>%5$s</td></tr>',
			esc_html( $bmc_def['key'] ),
			esc_html( '' !== $bmc_def['name'] ? $bmc_def['name'] : '—' ),
			esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_def['level'] ) ),
			esc_html( '' !== $bmc_def['role'] ? $bmc_def['role'] : '—' ),
			$bmc_def['days'] > 0 ? esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_def['days'] ) ) . ' روز' : 'دائمی'
		);
	}
	echo '</tbody></table>';
} else {
	echo '<div class="bmc-banner-info">' . bmc_get_icon( 'info', array( 'size' => 16 ) ) . ' رنک‌های سرور با اجرای دستور <code dir="ltr">bmc reload</code> در کنسول سرور به سایت همگام‌سازی می‌شوند.</div>';
}

BMC_Admin::section_close();

BMC_Admin::form_close( 'ذخیرهٔ تنظیمات رنک‌ها' );
?>
