<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$activity = class_exists( 'BMC_API' ) ? BMC_API::activity_summary() : array(
	'connected'  => false,
	'ok_ago'     => '',
	'ok_count'   => 0,
	'ok_ip'      => '',
	'fail_count' => 0,
	'fail_ago'   => '',
);

$is_connected = ! empty( $activity['connected'] );
$api_url      = BMC_Settings::api_base_url();
$token        = BMC_Settings::api_token();

$filter_platform = isset( $_GET['platform'] ) ? sanitize_key( wp_unslash( $_GET['platform'] ) ) : 'all';
$filter_search   = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
$paged           = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;

$linked_data = class_exists( 'BMC_Link' ) ? BMC_Link::get_linked_accounts(
	array(
		'platform' => $filter_platform,
		'search'   => $filter_search,
		'paged'    => $paged,
		'per_page' => 15,
	)
) : array( 'items' => array(), 'total' => 0, 'paged' => 1, 'pages' => 1 );
?>

<section class="bmc-box bmc-connection-card">
	<div class="bmc-box__head">
		<div class="bmc-inline">
			<h2><?php bmc_icon( 'power', array( 'size' => 20 ) ); ?> وضعیت اتصال سرور ماینکرافت</h2>
			<span class="bmc-status-badge <?php echo $is_connected ? 'bmc-status-badge--connected' : 'bmc-status-badge--disconnected'; ?>">
				<span class="bmc-status-badge__dot"></span>
				<?php echo $is_connected ? '● متصل (Connected)' : '● قطع ارتباط (Disconnected)'; ?>
			</span>
		</div>
		<div class="bmc-inline">
			<button type="button" class="button button-primary bmc-action" data-do="test_connection">
				<?php bmc_icon( 'sync', array( 'size' => 15 ) ); ?>
				<span>تست اتصال زنده (Test Connection)</span>
			</button>
		</div>
	</div>

	<div class="bmc-box__body">
		<div class="bmc-connection-grid">
			<div class="bmc-pairing-box">
				<label class="bmc-pairing-box__label">کد احراز هویت سرور (Site Pairing Token)</label>
				<div class="bmc-pairing-code-wrap">
					<code class="bmc-pairing-code" id="bmcTokenField"><?php echo esc_html( $token ); ?></code>
					<button type="button" class="button bmc-copy" data-copy="<?php echo esc_attr( $token ); ?>">
						<?php bmc_icon( 'content_copy', array( 'size' => 14 ) ); ?> کپی
					</button>
					<button type="button" class="button bmc-action" data-do="regenerate_token" data-confirm="1">
						<?php bmc_icon( 'refresh', array( 'size' => 14 ) ); ?> ساخت مجدد
					</button>
				</div>
				<p class="bmc-pairing-help">
					این کد را در فایل <code>config.yml</code> پلاگین ماینکرافت وارد کنید یا در کنسول سرور دستور <code dir="ltr">/bmc reload</code> را اجرا کنید.
				</p>
			</div>

			<div class="bmc-ports-box">
				<label class="bmc-pairing-box__label">وضعیت پورت‌ها و پلتفرم‌ها</label>
				<div class="bmc-ports-list">
					<div class="bmc-port-item">
						<span class="bmc-platform-chip bmc-platform-chip--java">پلتفرم جاوا (Java Edition)</span>
						<span class="bmc-pill <?php echo $is_connected ? 'is-done' : 'is-cancelled'; ?>">
							<?php echo $is_connected ? 'پورت متصل و فعال' : 'در انتظار اتصال'; ?>
						</span>
					</div>
					<div class="bmc-port-item">
						<span class="bmc-platform-chip bmc-platform-chip--bedrock">پلتفرم بدراک (Bedrock / Geyser)</span>
						<span class="bmc-pill <?php echo BMC_Settings::bool( 'bedrock_support', true ) ? 'is-done' : 'is-expired'; ?>">
							<?php echo BMC_Settings::bool( 'bedrock_support', true ) ? 'پشتیبانی فعال (Floodgate)' : 'غیرفعال'; ?>
						</span>
					</div>
				</div>
				<div class="bmc-handshake-info">
					<?php if ( $is_connected && ! empty( $activity['ok_ago'] ) ) : ?>
						آخرین هندشیک: <strong><?php echo esc_html( $activity['ok_ago'] ); ?></strong>
						<?php if ( ! empty( $activity['ok_ip'] ) ) : ?>
							<small class="bmc-dim" dir="ltr">(IP: <?php echo esc_html( $activity['ok_ip'] ); ?>)</small>
						<?php endif; ?>
					<?php else : ?>
						هنوز درخواستی از سمت سرور بازی دریافت نشده است.
					<?php endif; ?>
				</div>
			</div>
		</div>
	</div>
</section>

<section class="bmc-box">
	<div class="bmc-box__head">
		<div class="bmc-inline">
			<h2><?php bmc_icon( 'group', array( 'size' => 18 ) ); ?> جدول اکانت‌های متصل (Linked Accounts)</h2>
			<span class="bmc-pill is-info"><?php echo esc_html( BMC_Helpers::to_persian_digits( $linked_data['total'] ) ); ?> بازیکن متصل</span>
		</div>
		<div class="bmc-inline">
			<form method="get" class="bmc-inline-filter">
				<input type="hidden" name="page" value="bazzarmc" />
				<input type="hidden" name="tab" value="server" />
				<select name="platform" class="bmc-input bmc-input--sm" onchange="this.form.submit()">
					<option value="all" <?php selected( $filter_platform, 'all' ); ?>>همه پلتفرم‌ها</option>
					<option value="java" <?php selected( $filter_platform, 'java' ); ?>>فقط جاوا (Java)</option>
					<option value="bedrock" <?php selected( $filter_platform, 'bedrock' ); ?>>فقط بدراک (Bedrock)</option>
				</select>
				<input type="search" name="s" class="bmc-input bmc-input--sm" value="<?php echo esc_attr( $filter_search ); ?>" placeholder="جست‌وجوی بازیکن یا کاربر…" />
				<button type="submit" class="button button-small">فیلتر</button>
			</form>
		</div>
	</div>

	<div class="bmc-box__body bmc-box__body--flush">
		<?php if ( empty( $linked_data['items'] ) ) : ?>
			<p class="bmc-empty">هیچ اکانت متصلی با این مشخصات یافت نشد.</p>
		<?php else : ?>
			<table class="bmc-table bmc-table--full">
				<thead>
					<tr>
						<th style="width:36px"><input type="checkbox" id="bmcSelectAllUsers" /></th>
						<th>کاربر وردپرس</th>
						<th>نام کاربری ماینکرافت</th>
						<th>پلتفرم</th>
						<th>شناسه (UUID / XUID)</th>
						<th>رنک فعال</th>
						<th>تاریخ اتصال</th>
						<th>عملیات</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $linked_data['items'] as $item ) : ?>
						<?php
						$u_id   = $item['user_id'];
						$u_user = $item['user'];
						$u_play = $item['player'];
						$u_uuid = $item['uuid'];
						$u_plat = $item['platform'];
						$u_rank = $item['active_rank'];
						?>
						<tr data-user-id="<?php echo esc_attr( $u_id ); ?>">
							<td><input type="checkbox" class="bmc-user-checkbox" value="<?php echo esc_attr( $u_id ); ?>" /></td>
							<td>
								<strong><?php echo esc_html( $u_user->display_name ); ?></strong>
								<small class="bmc-dim">(<?php echo esc_html( $u_user->user_email ); ?>)</small>
							</td>
							<td class="bmc-mono">
								<span class="bmc-player-cell">
									<img src="<?php echo esc_url( BMC_Helpers::mc_head( $u_play, 22 ) ); ?>" width="22" height="22" alt="" />
									<strong><?php echo esc_html( $u_play ); ?></strong>
								</span>
							</td>
							<td>
								<span class="bmc-platform-chip bmc-platform-chip--<?php echo esc_attr( $u_plat ); ?>">
									<?php echo 'bedrock' === $u_plat ? 'Bedrock' : 'Java'; ?>
								</span>
							</td>
							<td class="bmc-mono">
								<span class="bmc-uuid-cell" title="<?php echo esc_attr( $u_uuid ); ?>">
									<?php echo esc_html( $u_uuid ? substr( $u_uuid, 0, 16 ) . '…' : '—' ); ?>
								</span>
							</td>
							<td>
								<?php if ( $u_rank && ! empty( $u_rank['label'] ) ) : ?>
									<span class="bmc-pill is-done"><?php echo esc_html( $u_rank['label'] ); ?></span>
								<?php else : ?>
									<span class="bmc-dim">بدون رنک</span>
								<?php endif; ?>
							</td>
							<td class="bmc-dim">
								<?php echo $item['linked_at'] ? esc_html( BMC_Jalali::format( $item['linked_at'] ) ) : '—'; ?>
							</td>
							<td>
								<button type="button" class="button button-small button-link-delete bmc-action" data-do="force_unlink" data-id="<?php echo esc_attr( $u_id ); ?>" data-confirm="1" data-reload="1">
									قطع اتصال
								</button>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<?php if ( $linked_data['pages'] > 1 ) : ?>
				<div class="bmc-pagination">
					<?php
					echo wp_kses_post(
						paginate_links(
							array(
								'base'      => add_query_arg( 'paged', '%#%' ),
								'format'    => '',
								'current'   => $linked_data['paged'],
								'total'     => $linked_data['pages'],
								'prev_text' => '→',
								'next_text' => '←',
							)
						)
					);
					?>
				</div>
			<?php endif; ?>
		<?php endif; ?>
	</div>
</section>

<?php
BMC_Admin::form_open( 'server' );

BMC_Admin::section_open( 'تنظیمات اتصال سرور و پلتفرم‌ها' );

BMC_Admin::row( 'نام سرور ماینکرافت', BMC_Admin::input( 'server_name', $settings['server_name'], array( 'placeholder' => 'سرور ماینکرافت ما' ) ), 'در پیام‌ها و اعلان‌های بازی نمایش داده می‌شود.' );
BMC_Admin::row( 'آدرس سرور (IP/دامنه)', BMC_Admin::input( 'server_ip', $settings['server_ip'], array( 'dir' => 'ltr', 'placeholder' => 'play.example.com' ) ) );
BMC_Admin::row( 'پشتیبانی از بازیکنان بدراک (Bedrock/Geyser)', BMC_Admin::toggle( 'bedrock_support', BMC_Settings::get( 'bedrock_support', 'yes' ), 'سازگاری با Floodgate و پیشوندهای بدراک فعال باشد' ), 'بازیکنان نسخه موبایل و ویندوز ۱۰ با پیشوندهای . یا * بدون خطا متصل می‌شوند.' );
BMC_Admin::row( 'اجباری بودن اتصال برای خرید', BMC_Admin::toggle( 'force_link', $settings['force_link'], 'کاربر پیش از تسویه‌حساب باید اکانت ماینکرافت خود را متصل کند' ) );
BMC_Admin::row( 'نقش کاربری پیش‌فرض پس از اتصال', BMC_Admin::role_select( 'default_linked_role', $settings['default_linked_role'] ) );

BMC_Admin::section_close();

BMC_Admin::section_open( 'تنظیمات امنیتی و REST API', '', 'advanced' );

BMC_Admin::row( 'اعتبارسنجی گواهی SSL', BMC_Admin::toggle( 'ssl_verify', $settings['ssl_verify'], 'گواهی SSL در درخواست‌های API بررسی شود' ) );
BMC_Admin::row( 'بررسی نام کاربری در موجانگ', BMC_Admin::toggle( 'mojang_check', $settings['mojang_check'], 'صحت نام کاربری با سرورهای رسمی موجانگ بررسی شود' ) );
BMC_Admin::row( 'استثنای خودکار از افزونه‌های کش', BMC_Admin::toggle( 'cache_exclude', $settings['cache_exclude'], 'مسیرهای REST و صفحات اتصال از کش مستثنی شوند' ) );

BMC_Admin::section_close();

BMC_Admin::form_close( 'ذخیرهٔ تنظیمات سرور' );
?>
