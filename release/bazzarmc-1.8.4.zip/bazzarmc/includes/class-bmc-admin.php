<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Admin {

	const SLUG = 'bazzarmc';

	public static function init() {
		add_action( 'admin_menu', array( __CLASS__, 'register_menu' ) );
		add_action( 'admin_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ) );
		add_action( 'admin_init', array( __CLASS__, 'handle_post' ) );
		add_action( 'admin_init', array( __CLASS__, 'maybe_export_csv' ) );

		add_action( 'wp_ajax_bmc_admin_action', array( __CLASS__, 'ajax_action' ) );

		add_filter( 'admin_body_class', array( __CLASS__, 'body_class' ) );
	}

	public static function body_class( $classes ) {
		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && false !== strpos( $screen->id, self::SLUG ) ) {
			$classes .= ' bmc-admin-page';
		}
		return $classes;
	}

	public static function register_menu() {
		$attention = class_exists( 'BMC_Tickets' ) ? (int) BMC_Tickets::needs_attention() : 0;

		if ( class_exists( 'BMC_Forms' ) && BMC_Forms::enabled() ) {
			$attention += (int) BMC_Safe::guard( 'admin:forms_count', array( 'BMC_Forms', 'needs_attention' ), 0 );
		}

		$label = 'BazzarMc';

		if ( $attention > 0 ) {
			$label .= ' <span class="update-plugins count-' . $attention . '"><span class="update-count">' . number_format_i18n( $attention ) . '</span></span>';
		}

		add_menu_page(
			'BazzarMc',
			$label,
			'manage_woocommerce',
			self::SLUG,
			array( __CLASS__, 'render_page' ),
			BMC_Icons::admin_menu_icon(),
			56
		);
	}

	public static function enqueue_assets( $hook ) {
		if ( false === strpos( (string) $hook, self::SLUG ) ) {
			return;
		}

		wp_enqueue_style( 'bmc-admin', BMC_URL . 'assets/css/bmc-admin.css', array(), BMC_VERSION );
		wp_enqueue_script( 'bmc-icons', BMC_URL . 'assets/js/bmc-icons.js', array(), BMC_VERSION, true );

		if ( BMC_Settings::bool( 'font_cdn', true ) ) {
			wp_enqueue_style( 'bmc-vazir-admin', 'https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css', array(), '33.003' );
		}

		wp_enqueue_script( 'bmc-admin', BMC_URL . 'assets/js/bmc-admin.js', array( 'jquery', 'bmc-icons' ), BMC_VERSION, true );

		wp_localize_script(
			'bmc-admin',
			'bmcAdmin',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'bmc_admin' ),
				'i18n'    => array(
					'copied'     => 'کپی شد!',
					'confirm'    => 'آیا مطمئن هستید؟',
					'working'    => 'در حال انجام…',
					'done'       => 'انجام شد',
					'error'      => 'خطا رخ داد',
				),
			)
		);

		wp_enqueue_style( 'wp-color-picker' );
		wp_enqueue_script( 'wp-color-picker' );
	}

	public static function tabs() {
		return array(
			'dashboard'  => array( 'label' => 'داشبورد', 'icon' => 'monitoring' ),
			'server'     => array( 'label' => 'اتصال سرور', 'icon' => 'power' ),
			'products'   => array( 'label' => 'محصولات و نقش‌ها', 'icon' => 'inventory_2' ),
			'shop'       => array( 'label' => 'ویترین و کارت محصول', 'icon' => 'storefront' ),
			'deliveries' => array( 'label' => 'تحویل‌ها', 'icon' => 'local_shipping' ),
			'tickets'    => array( 'label' => 'تیکت‌ها', 'icon' => 'support_agent' ),
			'forms'      => array( 'label' => 'فرم‌ها', 'icon' => 'dynamic_form' ),
			'login'      => array( 'label' => 'تأیید و حساب کاربری', 'icon' => 'badge' ),
			'checkout'   => array( 'label' => 'چک‌اوت', 'icon' => 'shopping_cart' ),
			'messages'   => array( 'label' => 'متن‌ها و قالب‌ها', 'icon' => 'mail' ),
			'tools'      => array( 'label' => 'ابزارها', 'icon' => 'build' ),
		);
	}

	public static function current_tab() {
		$tab = isset( $_GET['tab'] ) ? sanitize_key( wp_unslash( $_GET['tab'] ) ) : 'dashboard';

		if ( 'setup' === $tab ) {
			$tab = 'server';
		}

		return array_key_exists( $tab, self::tabs() ) ? $tab : 'dashboard';
	}

	public static function render_page() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}

		$tab      = self::current_tab();
		$settings = BMC_Settings::all();
		$view     = BMC_PATH . 'admin/views/' . $tab . '.php';

		self::render_notices();

		echo '<div class="bmc-admin" dir="rtl">';

		self::render_header();

		echo '<div class="bmc-admin__body">';

		self::render_nav( $tab );

		echo '<div class="bmc-admin__content">';

		if ( file_exists( $view ) ) {
			include $view;
		} else {
			echo '<div class="bmc-box">قالب این بخش یافت نشد.</div>';
		}

		echo '</div></div></div>';
	}

	private static function render_header() {
		$stats     = BMC_Deliveries::stats();
		$attention = class_exists( 'BMC_Tickets' ) ? (int) BMC_Tickets::needs_attention() : 0;
		$token     = BMC_Settings::api_token();
		$api_url = BMC_Settings::api_base_url();
		?>
		<header class="bmc-admin__header">
			<div class="bmc-admin__title">
				<span class="bmc-admin__logo"><?php bmc_icon( 'sports_esports', array( 'size' => 26 ) ); ?></span>
				<div>
					<h1>BazzarMc</h1>
					<p>اتصال فروشگاه ووکامرس به سرور ماینکرافت — نسخهٔ <?php echo esc_html( BMC_VERSION ); ?></p>
				</div>
			</div>

			<div class="bmc-admin__chips">
				<span class="bmc-chip <?php echo $attention ? 'is-warn' : 'is-ok'; ?>">
					<?php echo $attention ? bmc_get_icon( 'support_agent', array( 'size' => 15 ) ) . ' ' . esc_html( BMC_Helpers::to_persian_digits( $attention ) ) . ' تیکت نیازمند پاسخ' : bmc_get_icon( 'check_circle', array( 'size' => 15 ) ) . ' تیکت بی‌پاسخ نداریم'; ?>
				</span>
				<span class="bmc-chip <?php echo $stats['pending'] ? 'is-warn' : 'is-ok'; ?>">
					<?php echo esc_html( BMC_Helpers::to_persian_digits( $stats['pending'] ) ); ?> تحویل در انتظار
				</span>
				<span class="bmc-chip is-info">
					<?php echo esc_html( BMC_Helpers::to_persian_digits( $stats['linked_users'] ) ); ?> کاربر متصل
				</span>
			</div>

			<div class="bmc-admin__token">
				<div class="bmc-admin__token-row">
					<label>توکن اتصال سرور</label>
					<button type="button" class="button bmc-copy" data-copy="<?php echo esc_attr( $token ); ?>">کپی</button>
				</div>
				<code class="bmc-token" id="bmcTokenValue"><?php echo esc_html( $token ); ?></code>
				<div class="bmc-admin__token-row">
					<label>آدرس API</label>
					<button type="button" class="button bmc-copy" data-copy="<?php echo esc_attr( $api_url ); ?>">کپی</button>
				</div>
				<code class="bmc-token bmc-token--sm"><?php echo esc_html( $api_url ); ?></code>
			</div>
		</header>
		<?php
	}

	private static function render_nav( $current ) {
		echo '<nav class="bmc-admin__nav"><ul>';

		foreach ( self::tabs() as $key => $tab ) {
			$url   = admin_url( 'admin.php?page=' . self::SLUG . '&tab=' . $key );
			$class = $key === $current ? 'is-active' : '';
			$badge = '';

			if ( 'tickets' === $key ) {
				$attention = (int) BMC_Tickets::needs_attention();

				if ( $attention > 0 ) {
					$badge = '<span class="bmc-admin__badge">' . BMC_Helpers::to_persian_digits( $attention ) . '</span>';
				}
			}

			printf(
				'<li><a class="%1$s" href="%2$s"><span class="bmc-admin__nav-icon">%3$s</span>%4$s%5$s</a></li>',
				esc_attr( $class ),
				esc_url( $url ),
				bmc_get_icon( $tab['icon'], array( 'size' => 17 ) ),
				esc_html( $tab['label'] ),
				$badge
			);
		}

		echo '</ul>';

		$report = BMC_Migrate::migration_report();
		if ( $report['legacy_plugin'] || $report['users'] || $report['deliveries'] ) {
			echo '<div class="bmc-admin__nav-note">داده‌های نسخهٔ قدیمی شناسایی شد. از بخش <strong>ابزارها</strong> مهاجرت را انجام دهید.</div>';
		}

		echo '</nav>';
	}

	private static function render_notices() {

		if ( isset( $_GET['bmc_saved'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p>تنظیمات ذخیره شد.</p></div>';
		}
		if ( isset( $_GET['bmc_error'] ) ) {
			echo '<div class="notice notice-error is-dismissible"><p>' . esc_html( sanitize_text_field( wp_unslash( $_GET['bmc_error'] ) ) ) . '</p></div>';
		}

	}

	public static function handle_post() {
		if ( empty( $_POST['bmc_settings_nonce'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}

		check_admin_referer( 'bmc_save_settings', 'bmc_settings_nonce' );

		$post   = wp_unslash( $_POST );
		$tab    = isset( $post['bmc_tab'] ) ? sanitize_key( $post['bmc_tab'] ) : 'server';
		$values = self::collect_values( $tab, $post );

		if ( $values ) {
			BMC_Settings::save( $values );
		}

		if ( class_exists( 'BMC_Account_Endpoints' ) ) {
			BMC_Account_Endpoints::queue_flush_if_changed();
		}

		$args = array(
			'page'      => self::SLUG,
			'tab'       => $tab,
			'bmc_saved' => 1,
		);

		if ( class_exists( 'BMC_Forms' ) && BMC_Forms::$redirect ) {
			$args = array_merge( $args, BMC_Forms::$redirect );
			BMC_Forms::$redirect = array();

			if ( isset( $args['bmc_form_msg'] ) ) {
				unset( $args['bmc_saved'] );
			}
		}

		$redirect = add_query_arg( $args, admin_url( 'admin.php' ) );

		wp_safe_redirect( $redirect );
		exit;
	}

	public static function collect_values( $tab, array $post ) {
		$values         = array();
		$bmc_known_keys = BMC_Settings::defaults();

		switch ( $tab ) {
			case 'server':
				$values['server_name']         = sanitize_text_field( $post['server_name'] ?? '' );
				$values['server_ip']           = sanitize_text_field( $post['server_ip'] ?? '' );
				$values['username_policy']     = in_array( $post['username_policy'] ?? '', array( 'premium', 'any' ), true ) ? $post['username_policy'] : 'any';
				$values['link_mode']           = in_array( $post['link_mode'] ?? '', array( 'panel', 'mc', 'both' ), true ) ? $post['link_mode'] : 'both';
				$values['force_link']          = BMC_Settings::normalize_yesno( $post['force_link'] ?? 'no' );
				$values['unlink_allowed']      = BMC_Settings::normalize_yesno( $post['unlink_allowed'] ?? 'no' );
				$values['default_linked_role'] = sanitize_text_field( $post['default_linked_role'] ?? '' );
				$values['legacy_compat']       = BMC_Settings::normalize_yesno( $post['legacy_compat'] ?? 'no' );
				$values['debug_log']           = BMC_Settings::normalize_yesno( $post['debug_log'] ?? 'no' );
				$values['code_ttl']            = (int) ( $post['code_ttl'] ?? 300 );
				$values['code_length']         = (int) ( $post['code_length'] ?? 8 );
				$values['code_alphabet']       = in_array( $post['code_alphabet'] ?? '', array( 'safe', 'digits', 'full' ), true ) ? $post['code_alphabet'] : 'safe';
				$values['code_command_hint']   = sanitize_text_field( $post['code_command_hint'] ?? '' );
				$values['delivery_expiry']     = array(
					'value' => (int) ( $post['delivery_expiry_value'] ?? 30 ),
					'unit'  => sanitize_text_field( $post['delivery_expiry_unit'] ?? 'days' ),
				);
				$values['delivery_status']     = isset( $post['delivery_status'] ) && is_array( $post['delivery_status'] ) ? array_map( 'sanitize_key', $post['delivery_status'] ) : array();
				$values['ssl_verify']          = BMC_Settings::normalize_yesno( $post['ssl_verify'] ?? 'yes' );
				$values['mojang_check']        = BMC_Settings::normalize_yesno( $post['mojang_check'] ?? 'yes' );
				$values['blocks_checkout']     = in_array( $post['blocks_checkout'] ?? '', array( 'force_classic', 'notice', 'register' ), true ) ? $post['blocks_checkout'] : 'force_classic';
				$values['cache_exclude']       = BMC_Settings::normalize_yesno( $post['cache_exclude'] ?? 'yes' );
				$values['cf_api_token']        = sanitize_text_field( $post['cf_api_token'] ?? '' );
				$values['cf_zone_id']          = sanitize_text_field( $post['cf_zone_id'] ?? '' );
				$values['cf_cache_rule']       = BMC_Settings::normalize_yesno( $post['cf_cache_rule'] ?? 'no' );
				break;

			case 'products':
				$values['sync_products'] = isset( $post['sync_products'] ) && is_array( $post['sync_products'] ) ? array_map( 'absint', $post['sync_products'] ) : array();

				$roles = array();
				if ( isset( $post['product_role'] ) && is_array( $post['product_role'] ) ) {
					foreach ( $post['product_role'] as $pid => $role ) {
						$roles[ absint( $pid ) ] = sanitize_text_field( $role );
					}
				}
				$values['product_roles'] = $roles;

				$durations = array();
				if ( isset( $post['product_role_duration'] ) && is_array( $post['product_role_duration'] ) ) {
					foreach ( $post['product_role_duration'] as $pid => $days ) {
						$pid = absint( $pid );
						if ( ! $pid || '' === trim( (string) $days ) ) {
							continue;
						}
						$durations[ $pid ] = max( 0, min( 36500, (int) $days ) );
					}
				}
				$values['product_role_duration'] = $durations;

				$levels = array();
				if ( isset( $post['rank_level'] ) && is_array( $post['rank_level'] ) ) {
					$levels = BMC_Ranks::save_manual_levels( $post['rank_level'] );
				}
				$values['rank_levels'] = $levels;

				$values['rank_guard']      = BMC_Settings::normalize_yesno( $post['rank_guard'] ?? 'yes' );
				$values['rank_hide_lower'] = BMC_Settings::normalize_yesno( $post['rank_hide_lower'] ?? 'yes' );

				$values['role_duration_default'] = isset( $post['role_duration_default'] ) ? max( 0, min( 36500, (int) $post['role_duration_default'] ) ) : 0;

				$product_keys = array();

				if ( isset( $post['product_key_type'] ) && is_array( $post['product_key_type'] ) ) {
					$key_values = isset( $post['product_key_value'] ) && is_array( $post['product_key_value'] ) ? $post['product_key_value'] : array();

					foreach ( $post['product_key_type'] as $pid => $type ) {
						$pid = absint( $pid );

						if ( ! $pid ) {
							continue;
						}

						$product_keys[ $pid ] = array(
							'type'  => in_array( $type, array( 'name', 'id', 'slug', 'custom' ), true ) ? $type : 'name',
							'value' => isset( $key_values[ $pid ] ) ? sanitize_text_field( $key_values[ $pid ] ) : '',
						);
					}
				}

				$values['product_key_default']    = in_array( $post['product_key_default'] ?? '', array( 'name', 'id', 'slug', 'sku' ), true ) ? $post['product_key_default'] : 'name';
				$values['product_keys']           = $product_keys;
				$values['revoke_roles_on_refund'] = BMC_Settings::normalize_yesno( $post['revoke_roles_on_refund'] ?? 'yes' );
				break;

			case 'login':
				$values['page_link']            = (int) ( $post['page_link'] ?? 0 );
				$values['otp_ttl']              = (int) ( $post['otp_ttl'] ?? 120 );
				$values['otp_length']           = (int) ( $post['otp_length'] ?? 5 );
				$values['otp_rate_limit']       = (int) ( $post['otp_rate_limit'] ?? 120 );
				$values['otp_max_attempts']     = (int) ( $post['otp_max_attempts'] ?? 5 );
				$values['otp_resend_limit']     = (int) ( $post['otp_resend_limit'] ?? 3 );
				$values['email_enabled']        = BMC_Settings::normalize_yesno( $post['email_enabled'] ?? 'no' );
				$values['email_tpl_subject']    = sanitize_text_field( $post['email_tpl_subject'] ?? '' );
				$values['email_tpl_body']       = wp_kses_post( $post['email_tpl_body'] ?? '' );
				$values['ezlogin_sync_phone']   = BMC_Settings::normalize_yesno( $post['ezlogin_sync_phone'] ?? 'yes' );

				$keys = array();
				if ( ! empty( $post['mobile_meta_keys'] ) ) {
					$raw  = is_array( $post['mobile_meta_keys'] ) ? implode( ',', $post['mobile_meta_keys'] ) : $post['mobile_meta_keys'];
					$keys = array_filter( array_map( 'sanitize_key', array_map( 'trim', explode( ',', $raw ) ) ) );
				}
				$values['mobile_meta_keys'] = array_values( $keys );

				$methods = array();

				if ( isset( $post['verify_methods'] ) && is_array( $post['verify_methods'] ) ) {
					$methods = array_values( array_intersect( array_map( 'sanitize_key', $post['verify_methods'] ), array( 'email', 'dashboard' ) ) );
				}

				$values['verify_methods']       = $methods ? $methods : array( 'dashboard' );
				$values['verify_default']       = in_array( $post['verify_default'] ?? '', $values['verify_methods'], true ) ? $post['verify_default'] : $values['verify_methods'][0];
				$values['otp_dashboard_widget'] = BMC_Settings::normalize_yesno( $post['otp_dashboard_widget'] ?? 'yes' );
				$values['otp_dashboard_box']    = BMC_Settings::normalize_yesno( $post['otp_dashboard_box'] ?? 'yes' );
				$values['page_cart']            = (int) ( $post['page_cart'] ?? 0 );
				$values['page_checkout']        = (int) ( $post['page_checkout'] ?? 0 );
				$values['myaccount_card']       = BMC_Settings::normalize_yesno( $post['myaccount_card'] ?? 'yes' );

				$values['link_width']              = in_array( $post['link_width'] ?? '', array( 'narrow', 'wide' ), true ) ? $post['link_width'] : 'narrow';
				$values['link_avatar_size']        = (int) ( $post['link_avatar_size'] ?? 96 );
				$values['link_show_steps']         = BMC_Settings::normalize_yesno( $post['link_show_steps'] ?? 'yes' );
				$values['link_step_1']             = sanitize_textarea_field( $post['link_step_1'] ?? '' );
				$values['link_step_2']             = sanitize_textarea_field( $post['link_step_2'] ?? '' );
				$values['link_step_3']             = sanitize_textarea_field( $post['link_step_3'] ?? '' );
				$values['link_player_label']       = sanitize_text_field( $post['link_player_label'] ?? '' );
				$values['link_player_placeholder'] = sanitize_text_field( $post['link_player_placeholder'] ?? '' );
				$values['link_submit_text']        = sanitize_text_field( $post['link_submit_text'] ?? '' );
				$values['link_code_hint']          = sanitize_textarea_field( $post['link_code_hint'] ?? '' );
				$values['link_copy_text']          = sanitize_text_field( $post['link_copy_text'] ?? '' );
				$values['link_regen_text']         = sanitize_text_field( $post['link_regen_text'] ?? '' );
				$values['link_show_otp_card']      = BMC_Settings::normalize_yesno( $post['link_show_otp_card'] ?? 'yes' );
				$values['link_otp_title']          = sanitize_text_field( $post['link_otp_title'] ?? '' );
				$values['link_show_uuid']          = BMC_Settings::normalize_yesno( $post['link_show_uuid'] ?? 'yes' );
				$values['link_show_linked_at']     = BMC_Settings::normalize_yesno( $post['link_show_linked_at'] ?? 'yes' );
				$values['link_show_shop_button']   = BMC_Settings::normalize_yesno( $post['link_show_shop_button'] ?? 'yes' );
				$values['link_show_unlink']        = BMC_Settings::normalize_yesno( $post['link_show_unlink'] ?? 'yes' );
				$values['link_login_title']        = sanitize_text_field( $post['link_login_title'] ?? '' );
				$values['link_login_body']         = sanitize_textarea_field( $post['link_login_body'] ?? '' );
				$values['link_login_button']       = sanitize_text_field( $post['link_login_button'] ?? '' );

				$values['ma_connect_enabled']  = BMC_Settings::normalize_yesno( $post['ma_connect_enabled'] ?? 'no' );
				$values['ma_connect_title']    = sanitize_text_field( $post['ma_connect_title'] ?? '' );
				$values['ma_connect_slug']     = sanitize_title( $post['ma_connect_slug'] ?? '' );
				$values['ma_connect_icon']     = sanitize_key( $post['ma_connect_icon'] ?? '' );
				$values['ma_connect_position'] = sanitize_key( $post['ma_connect_position'] ?? '' );
				$values['ma_connect_badge']    = BMC_Settings::normalize_yesno( $post['ma_connect_badge'] ?? 'no' );

				$values['ma_tickets_enabled']  = BMC_Settings::normalize_yesno( $post['ma_tickets_enabled'] ?? 'no' );
				$values['ma_tickets_title']    = sanitize_text_field( $post['ma_tickets_title'] ?? '' );
				$values['ma_tickets_slug']     = sanitize_title( $post['ma_tickets_slug'] ?? '' );
				$values['ma_tickets_icon']     = sanitize_key( $post['ma_tickets_icon'] ?? '' );
				$values['ma_tickets_position'] = sanitize_key( $post['ma_tickets_position'] ?? '' );
				$values['ma_tickets_badge']    = BMC_Settings::normalize_yesno( $post['ma_tickets_badge'] ?? 'no' );
				$values['ma_tickets_dot']      = BMC_Settings::normalize_yesno( $post['ma_tickets_dot'] ?? 'no' );
				break;

			case 'checkout':
				$values['checkout_mode']         = in_array( $post['checkout_mode'] ?? '', array( 'custom', 'wc' ), true ) ? $post['checkout_mode'] : 'custom';
				$values['checkout_theme']        = in_array( $post['checkout_theme'] ?? '', array( 'dark', 'light' ), true ) ? $post['checkout_theme'] : 'dark';
				$values['checkout_accent']       = sanitize_hex_color( $post['checkout_accent'] ?? '#3ddc84' );
				$values['gate_enabled']          = BMC_Settings::normalize_yesno( $post['gate_enabled'] ?? 'no' );
				$values['gate_only_synced']      = BMC_Settings::normalize_yesno( $post['gate_only_synced'] ?? 'no' );
				$values['gate_product_page']     = BMC_Settings::normalize_yesno( $post['gate_product_page'] ?? 'no' );
				$values['checkout_show_coupon']  = BMC_Settings::normalize_yesno( $post['checkout_show_coupon'] ?? 'no' );
				$values['checkout_gift_allowed'] = BMC_Settings::normalize_yesno( $post['checkout_gift_allowed'] ?? 'no' );
				$values['font_cdn']              = BMC_Settings::normalize_yesno( $post['font_cdn'] ?? 'no' );

				$fields = array();
				foreach ( array_keys( BMC_Settings::defaults()['checkout_fields'] ) as $field_key ) {
					$fields[ $field_key ] = ! empty( $post['checkout_fields'][ $field_key ] ) ? 1 : 0;
				}
				$values['checkout_fields'] = $fields;

				$values['cart_gate']          = BMC_Settings::normalize_yesno( $post['cart_gate'] ?? 'yes' );
				$values['cart_mode']          = in_array( $post['cart_mode'] ?? '', array( 'wc', 'custom' ), true ) ? $post['cart_mode'] : 'wc';
				$values['persian_fields']     = BMC_Settings::normalize_yesno( $post['persian_fields'] ?? 'yes' );
				$values['persian_countries']  = BMC_Settings::normalize_yesno( $post['persian_countries'] ?? 'yes' );
				$values['persian_digits']     = BMC_Settings::normalize_yesno( $post['persian_digits'] ?? 'no' );
				$values['gate_hide_add_to_cart'] = BMC_Settings::normalize_yesno( $post['gate_hide_add_to_cart'] ?? 'no' );
				$values['checkout_show_summary'] = BMC_Settings::normalize_yesno( $post['checkout_show_summary'] ?? 'yes' );

				$values['cart_inline_checkout']  = BMC_Settings::normalize_yesno( $post['cart_inline_checkout'] ?? 'no' );
				$values['cart_steps_nav']        = BMC_Settings::normalize_yesno( $post['cart_steps_nav'] ?? 'yes' );
				$values['checkout_back_to_cart'] = BMC_Settings::normalize_yesno( $post['checkout_back_to_cart'] ?? 'yes' );
				$values['cart_button_text']      = sanitize_text_field( $post['cart_button_text'] ?? '' );
				$values['checkout_submit_text']  = sanitize_text_field( $post['checkout_submit_text'] ?? '' );
				$values['checkout_columns']      = in_array( $post['checkout_columns'] ?? '', array( '1', '2' ), true ) ? $post['checkout_columns'] : '2';

				$cards = array();
				if ( isset( $post['checkout_card_show'] ) && is_array( $post['checkout_card_show'] ) ) {
					$cards = array_values( array_intersect( array_map( 'sanitize_key', array_keys( $post['checkout_card_show'] ) ), array( 'mc', 'buyer', 'payment', 'extra' ) ) );
				}
				$values['checkout_cards'] = $cards;

				$card_order = array();
				if ( isset( $post['checkout_card_order'] ) && is_array( $post['checkout_card_order'] ) ) {
					foreach ( $post['checkout_card_order'] as $ck => $cv ) {
						$ck = sanitize_key( (string) $ck );
						if ( in_array( $ck, array( 'mc', 'buyer', 'payment', 'extra' ), true ) ) {
							$card_order[ $ck ] = max( 1, min( 9, (int) $cv ) );
						}
					}
				}
				$values['checkout_card_order'] = $card_order;

				$titles = array();
				if ( isset( $post['checkout_titles'] ) && is_array( $post['checkout_titles'] ) ) {
					foreach ( $post['checkout_titles'] as $tk => $tv ) {
						$tk = sanitize_key( (string) $tk );
						if ( in_array( $tk, array( 'mc', 'buyer', 'payment', 'summary', 'extra' ), true ) ) {
							$titles[ $tk ] = sanitize_text_field( (string) $tv );
						}
					}
				}
				$values['checkout_titles'] = $titles;

				$layout = array();
				if ( isset( $post['checkout_layout'] ) && is_array( $post['checkout_layout'] ) ) {
					foreach ( $post['checkout_layout'] as $fk => $conf ) {
						if ( ! is_array( $conf ) ) {
							continue;
						}

						$layout[ sanitize_key( (string) $fk ) ] = array(
							'order'       => isset( $conf['order'] ) ? (int) $conf['order'] : 0,
							'label'       => isset( $conf['label'] ) ? sanitize_text_field( (string) $conf['label'] ) : '',
							'placeholder' => isset( $conf['placeholder'] ) ? sanitize_text_field( (string) $conf['placeholder'] ) : '',
							'help'        => isset( $conf['help'] ) ? sanitize_text_field( (string) $conf['help'] ) : '',
							'width'       => isset( $conf['width'] ) ? (int) $conf['width'] : 0,
							'required'    => isset( $conf['required'] ) ? (int) $conf['required'] : -1,
							'enabled'     => isset( $conf['enabled'] ) ? (int) $conf['enabled'] : -1,
							'section'     => isset( $conf['section'] ) ? sanitize_key( (string) $conf['section'] ) : '',
						);
					}
				}
				$values['checkout_layout'] = $layout;

				$values['checkout_custom_enabled'] = BMC_Settings::normalize_yesno( $post['checkout_custom_enabled'] ?? 'yes' );

				$bmc_custom_raw   = isset( $post['checkout_custom_fields'] ) && is_array( $post['checkout_custom_fields'] ) ? $post['checkout_custom_fields'] : array();
				$bmc_custom_order = isset( $post['checkout_custom_order'] ) && is_array( $post['checkout_custom_order'] ) ? array_map( 'absint', $post['checkout_custom_order'] ) : array();

				if ( $bmc_custom_order ) {
					$bmc_sorted = array();
					$bmc_seen   = array();

					foreach ( $bmc_custom_order as $bmc_position ) {
						if ( isset( $bmc_custom_raw[ $bmc_position ] ) && ! isset( $bmc_seen[ $bmc_position ] ) ) {
							$bmc_sorted[]                = $bmc_custom_raw[ $bmc_position ];
							$bmc_seen[ $bmc_position ]   = true;
						}
					}

					foreach ( $bmc_custom_raw as $bmc_position => $bmc_item ) {
						if ( ! isset( $bmc_seen[ absint( $bmc_position ) ] ) ) {
							$bmc_sorted[] = $bmc_item;
						}
					}

					$bmc_custom_raw = $bmc_sorted;
				}

				$values['checkout_custom_fields'] = $bmc_custom_raw;
				$values['checkout_custom_order']  = array();
				break;

			case 'messages':
				$values['txt_link_title']       = sanitize_text_field( $post['txt_link_title'] ?? '' );
				$values['txt_not_linked_title'] = sanitize_text_field( $post['txt_not_linked_title'] ?? '' );
				$values['txt_not_linked_body']  = sanitize_textarea_field( $post['txt_not_linked_body'] ?? '' );
				$values['txt_linked_title']     = sanitize_text_field( $post['txt_linked_title'] ?? '' );
				$values['txt_cart_blocked']     = sanitize_textarea_field( $post['txt_cart_blocked'] ?? '' );
				$values['txt_thankyou']         = sanitize_textarea_field( $post['txt_thankyou'] ?? '' );
				break;

			case 'tickets':
				$values['tickets_enabled']         = BMC_Settings::normalize_yesno( $post['tickets_enabled'] ?? 'yes' );
				$values['tickets_per_page']        = max( 5, min( 50, (int) ( $post['tickets_per_page'] ?? 10 ) ) );
				$values['tickets_max_open']        = max( 0, min( 50, (int) ( $post['tickets_max_open'] ?? 0 ) ) );
				$values['tickets_require_product'] = BMC_Settings::normalize_yesno( $post['tickets_require_product'] ?? 'no' );
				$values['tickets_user_close']      = BMC_Settings::normalize_yesno( $post['tickets_user_close'] ?? 'yes' );
				$values['tickets_user_reopen']     = BMC_Settings::normalize_yesno( $post['tickets_user_reopen'] ?? 'yes' );
				$values['tickets_email_admin']     = BMC_Settings::normalize_yesno( $post['tickets_email_admin'] ?? 'yes' );
				$values['tickets_email_user']      = BMC_Settings::normalize_yesno( $post['tickets_email_user'] ?? 'yes' );
				$values['tickets_admin_email']     = sanitize_text_field( $post['tickets_admin_email'] ?? '' );
				$values['page_tickets']            = (int) ( $post['page_tickets'] ?? 0 );
				break;

			case 'shop':
				$bmc_shop_yesno = array(
					'shop_enabled', 'shop_hide_empty_cats', 'shop_show_count', 'shop_ajax',
					'filter_enabled', 'filter_show_all', 'filter_show_counts', 'filter_show_thumb',
					'filter_show_sort', 'filter_show_search', 'filter_show_reset', 'filter_sticky',
					'card_show_image', 'card_show_category', 'card_show_price', 'card_show_excerpt',
					'card_show_rating', 'card_show_sale_badge', 'card_show_rank_badge', 'card_show_stock',
					'card_show_meta', 'card_buy_now', 'card_qv_hint',
					'qv_enabled', 'qv_show_image', 'qv_show_price', 'qv_show_meta', 'qv_show_excerpt',
					'qv_show_description', 'qv_show_attributes', 'qv_show_rank', 'qv_show_add_to_cart',
					'qv_show_single_link',
				);

				foreach ( $bmc_shop_yesno as $bmc_key ) {
					$values[ $bmc_key ] = BMC_Settings::normalize_yesno( $post[ $bmc_key ] ?? 'no' );
				}

				$bmc_shop_ints = array(
					'shop_per_page'        => 12,
					'shop_columns'         => 3,
					'shop_columns_tablet'  => 2,
					'shop_columns_mobile'  => 1,
					'shop_gap'             => 18,
					'shop_category_depth'  => 1,
					'card_excerpt_words'   => 18,
					'card_radius'          => 18,
					'qv_width'             => 760,
					'filter_search_min'    => 2,
					'page_shop'            => 0,
					'single_redirect_page' => 0,
				);

				foreach ( $bmc_shop_ints as $bmc_key => $bmc_default ) {
					$values[ $bmc_key ] = (int) ( $post[ $bmc_key ] ?? $bmc_default );
				}

				$bmc_shop_texts = array(
					'shop_source_tag', 'shop_include', 'shop_exclude', 'shop_load_more_text', 'shop_empty_text',
					'shop_heading', 'shop_heading_icon', 'shop_count_text', 'filter_title', 'filter_icon',
					'filter_all_label', 'filter_sort_label', 'filter_search_placeholder', 'filter_reset_text',
					'card_sale_badge_text', 'card_button_text', 'card_button_text_variable', 'card_button_text_soldout',
					'card_button_icon', 'card_buy_now_text', 'qv_title_text', 'qv_single_link_text', 'qv_close_text',
					'qv_loading_text', 'qv_error_text',
				);

				foreach ( $bmc_shop_texts as $bmc_key ) {
					$values[ $bmc_key ] = sanitize_text_field( (string) ( $post[ $bmc_key ] ?? '' ) );
				}

				$bmc_shop_enums = array(
					'shop_source', 'shop_pagination', 'filter_style', 'filter_position', 'filter_default_sort',
					'card_image_ratio', 'card_align', 'card_hover', 'card_click', 'single_product_mode',
					'single_redirect_target',
				);

				foreach ( $bmc_shop_enums as $bmc_key ) {
					$values[ $bmc_key ] = (string) ( $post[ $bmc_key ] ?? '' );
				}

				$values['shop_categories'] = isset( $post['shop_categories'] ) && is_array( $post['shop_categories'] )
					? array_map( 'absint', $post['shop_categories'] )
					: array();

				$values['filter_sort_options'] = isset( $post['filter_sort_options'] ) && is_array( $post['filter_sort_options'] )
					? array_map( 'sanitize_key', $post['filter_sort_options'] )
					: array( 'menu_order' );
				break;

			case 'deliveries':
				$values['delivery_report_enabled'] = BMC_Settings::normalize_yesno( $post['delivery_report_enabled'] ?? 'yes' );
				$values['delivery_note_user']      = BMC_Settings::normalize_yesno( $post['delivery_note_user'] ?? 'yes' );
				$values['delivery_show_attempts']  = BMC_Settings::normalize_yesno( $post['delivery_show_attempts'] ?? 'yes' );
				$values['delivery_stuck_days']     = max( 1, min( 90, (int) ( $post['delivery_stuck_days'] ?? 3 ) ) );
				break;

			case 'tools':
				$values['update_enabled']      = BMC_Settings::normalize_yesno( $post['update_enabled'] ?? 'yes' );
				$values['update_channel']      = in_array( $post['update_channel'] ?? '', array( 'stable', 'prerelease' ), true ) ? $post['update_channel'] : 'stable';
				$values['update_repo']         = sanitize_text_field( $post['update_repo'] ?? 'iobsifox/BazzarMc' );
				$values['update_token']        = sanitize_text_field( $post['update_token'] ?? '' );
				$values['update_ttl']          = max( 1, min( 168, (int) ( $post['update_ttl'] ?? 6 ) ) );
				$values['update_auto']         = BMC_Settings::normalize_yesno( $post['update_auto'] ?? 'no' );
				$values['update_notice']       = BMC_Settings::normalize_yesno( $post['update_notice'] ?? 'yes' );
				$values['update_show_jar']     = BMC_Settings::normalize_yesno( $post['update_show_jar'] ?? 'yes' );
				$values['update_notify_email'] = sanitize_text_field( $post['update_notify_email'] ?? '' );
				$values['elementor_enabled'] = BMC_Settings::normalize_yesno( $post['elementor_enabled'] ?? 'yes' );
				$values['safe_guard']        = BMC_Settings::normalize_yesno( $post['safe_guard'] ?? 'yes' );
				$values['safe_autorecover']  = BMC_Settings::normalize_yesno( $post['safe_autorecover'] ?? 'yes' );
				$values['safe_debug_display'] = BMC_Settings::normalize_yesno( $post['safe_debug_display'] ?? 'no' );
				$values['safe_crash_limit']  = max( 1, min( 10, (int) ( $post['safe_crash_limit'] ?? 2 ) ) );
				$values['safe_notify_email'] = sanitize_text_field( $post['safe_notify_email'] ?? '' );
				break;

			case 'forms':
				$values['forms_enabled']        = BMC_Settings::normalize_yesno( $post['forms_enabled'] ?? 'yes' );
				$values['forms_rate_limit']     = max( 5, min( 3600, (int) ( $post['forms_rate_limit'] ?? 60 ) ) );
				$values['forms_max_per_day']    = max( 0, min( 1000, (int) ( $post['forms_max_per_day'] ?? 25 ) ) );
				$values['forms_honeypot']       = BMC_Settings::normalize_yesno( $post['forms_honeypot'] ?? 'yes' );
				$values['forms_allow_files']    = BMC_Settings::normalize_yesno( $post['forms_allow_files'] ?? 'no' );
				$values['forms_max_file_size']  = max( 1, min( 25, (int) ( $post['forms_max_file_size'] ?? 4 ) ) );
				$values['forms_notice_email']   = sanitize_text_field( $post['forms_notice_email'] ?? '' );
				$values['forms_success_message'] = sanitize_textarea_field( $post['forms_success_message'] ?? '' );
				$values['forms_error_message']  = sanitize_textarea_field( $post['forms_error_message'] ?? '' );

				if ( ! empty( $post['bmc_form_builder'] ) ) {
					BMC_Forms::save_from_post( $post );
				}
				break;

			case 'purge':
				$values['purge_on_uninstall'] = BMC_Settings::normalize_yesno( $post['purge_on_uninstall'] ?? 'no' );
				break;
		}

		foreach ( $post as $bmc_posted_key => $bmc_posted_value ) {
			if ( isset( $values[ $bmc_posted_key ] ) ) {
				continue;
			}

			if ( ! array_key_exists( $bmc_posted_key, $bmc_known_keys ) ) {
				continue;
			}

			if ( is_array( $bmc_posted_value ) !== is_array( $bmc_known_keys[ $bmc_posted_key ] ) ) {
				continue;
			}

			$values[ $bmc_posted_key ] = $bmc_posted_value;
		}

		return apply_filters( 'bmc_admin_save_values', $values, $tab, $post );
	}

	public static function ajax_action() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی ندارید.' ), 403 );
		}

		check_admin_referer( 'bmc_admin', 'security' );

		$do = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';

		switch ( $do ) {
			case 'regenerate_token':
				$token = BMC_Settings::regenerate_token();
				wp_send_json_success(
					array(
						'message' => 'توکن جدید ساخته شد. آن را در پلاگین ماینکرافت به‌روزرسانی کنید.',
						'token'   => $token,
					)
				);
				break;

			case 'test_email':
				$to = isset( $_POST['to'] ) ? sanitize_text_field( wp_unslash( $_POST['to'] ) ) : '';
				$to = BMC_Helpers::sanitize_email( $to );

				if ( ! $to ) {
					wp_send_json_error( array( 'message' => 'ایمیل معتبر وارد کنید.' ), 400 );
				}

				$code   = BMC_Helpers::random_otp( BMC_Settings::int( 'otp_length', 5, 4, 8 ) );
				$result = BMC_Verify::send_email_code( $to, $code, array( 'player' => 'تست', 'type' => 'test' ) );

				if ( empty( $result['success'] ) ) {
					wp_send_json_error( array( 'message' => $result['message'] ), 400 );
				}

				wp_send_json_success( array( 'message' => 'ایمیل آزمایشی به ' . $to . ' ارسال شد.' ) );
				break;

			case 'ping_api':
				$token = BMC_Settings::api_token();
				$url   = rest_url( BMC_REST_NS . '/ping' );
				$res   = wp_remote_post(
					$url,
					array(
						'timeout' => 12,
						'headers' => array( 'X-BMC-Token' => $token ),
					)
				);

				if ( is_wp_error( $res ) ) {
					wp_send_json_error( array( 'message' => 'خطا: ' . $res->get_error_message() ), 400 );
				}

				$body = json_decode( wp_remote_retrieve_body( $res ), true );
				wp_send_json_success(
					array(
						'message' => 'API پاسخ داد — نسخهٔ ' . ( isset( $body['version'] ) ? $body['version'] : '?' ) . '، زمان سرور: ' . ( isset( $body['time'] ) ? $body['time'] : '' ),
					)
				);
				break;

			case 'run_cron':
				$result = BMC_Cron::run_now();
				wp_send_json_success(
					array(
						'message' => sprintf( 'نگهداری انجام شد: %d تحویل منقضی و %d کد پاک شد.', $result['deliveries'], $result['codes'] ),
					)
				);
				break;

			case 'flush_permalinks':
				flush_rewrite_rules();

				if ( class_exists( 'BMC_Account_Endpoints' ) ) {
					delete_option( BMC_Account_Endpoints::FLUSH_OPTION );
					update_option( BMC_Account_Endpoints::FLUSH_OPTION . '_slugs', BMC_Account_Endpoints::slugs(), false );
				}

				wp_send_json_success( array( 'message' => 'پیوندهای یکتا بازسازی شد.' ) );
				break;

			case 'purge_cache':
				$results = BMC_Cache::purge_all();
				$parts   = array();

				foreach ( $results as $name => $result ) {
					if ( ! empty( $result['success'] ) ) {
						$parts[] = $name . ': ' . ( isset( $result['message'] ) ? $result['message'] : 'انجام شد' );
					} else {
						$parts[] = $name . ': ناموفق — ' . ( isset( $result['message'] ) ? $result['message'] : '' );
					}
				}

				wp_send_json_success( array( 'message' => $parts ? implode( ' | ', $parts ) : 'پاک‌سازی کش انجام شد.' ) );
				break;

			case 'cf_cache_rule':
				$result = BMC_Cache::cloudflare_upsert_cache_rule();

				if ( empty( $result['success'] ) ) {
					wp_send_json_error( array( 'message' => isset( $result['message'] ) ? $result['message'] : 'ناموفق بود.' ), 400 );
				}

				wp_send_json_success( array( 'message' => 'قاعدهٔ کش Cloudflare ذخیره شد.' ) );
				break;

			case 'clear_logs':
			case 'clear_old_logs':
				$bmc_days  = 'clear_old_logs' === $do ? 30 : 0;
				$bmc_count = BMC_Logger::clear( $bmc_days );

				if ( -1 === $bmc_count ) {
					wp_send_json_error( array( 'message' => 'جدول لاگ‌ها پیدا نشد؛ از تب ابزارها «بازسازی جدول‌ها» را بزنید و دوباره تلاش کنید.' ), 400 );
				}

				if ( -2 === $bmc_count ) {
					wp_send_json_error( array( 'message' => 'پاک‌کردن لاگ‌ها ناموفق بود؛ کاربر دیتابیس اجازهٔ DELETE روی این جدول ندارد یا خطای دیتابیس رخ داد. جزئیات در لاگ خطای وردپرس است.' ), 400 );
				}

				if ( 0 === $bmc_count ) {
					wp_send_json_success( array( 'message' => $bmc_days ? 'لاگ قدیمی‌تری از ' . $bmc_days . ' روز پیش وجود نداشت.' : 'لاگی برای پاک‌کردن وجود نداشت.' ) );
				}

				wp_send_json_success(
					array(
						'message' => $bmc_days
							? 'لاگ‌های قدیمی‌تر از ' . BMC_Helpers::to_persian_digits( $bmc_days ) . ' روز پاک شدند (' . BMC_Helpers::to_persian_digits( $bmc_count ) . ' ردیف).'
							: 'همهٔ لاگ‌ها پاک شدند (' . BMC_Helpers::to_persian_digits( $bmc_count ) . ' ردیف).',
					)
				);
				break;

			case 'rebuild_tables':
				BMC_DB::install();
				wp_send_json_success( array( 'message' => 'جدول‌ها بازسازی/به‌روزرسانی شدند.' ) );
				break;

			case 'create_pages':
				BMC_Migrate::maybe_create_pages();
				wp_send_json_success(
					array(
						'message' => 'صفحه‌های اتصال و ورود ساخته/به‌روزرسانی شدند.',
						'link'    => (int) BMC_Settings::get( 'page_link' ),
					)
				);
				break;

			case 'run_migration':
				set_time_limit( 300 );
				$result = BMC_Migrate::run();
				wp_send_json_success(
					array(
						'message' => sprintf(
							'مهاجرت انجام شد: %d کاربر، %d تحویل، %d تنظیم.',
							$result['users'],
							$result['deliveries'],
							$result['options']
						),
					)
				);
				break;

			case 'detect_mobile_keys':
				wp_send_json_success( array( 'keys' => BMC_Migrate::detect_mobile_meta_keys() ) );
				break;

			case 'sync_mobiles':
				set_time_limit( 300 );
				$count = BMC_Migrate::sync_mobiles();
				wp_send_json_success( array( 'message' => sprintf( 'شمارهٔ موبایل %d کاربر یکسان‌سازی شد.', $count ) ) );
				break;

			case 'delete_form':
				$id = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
				$done = $id ? BMC_Forms::delete( $id ) : 0;

				if ( ! $done ) {
					wp_send_json_error( array( 'message' => 'حذف فرم ناموفق بود.' ), 400 );
				}

				wp_send_json_success( array( 'message' => 'فرم و همهٔ ارسال‌هایش حذف شدند.' ) );
				break;

			case 'duplicate_form':
				$id     = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
				$copy   = $id ? BMC_Forms::duplicate( $id ) : new WP_Error( 'missing', 'فرم پیدا نشد.' );

				if ( is_wp_error( $copy ) ) {
					wp_send_json_error( array( 'message' => $copy->get_error_message() ), 400 );
				}

				wp_send_json_success( array( 'message' => 'کپی فرم ساخته شد (وضعیت: غیرفعال).' ) );
				break;

			case 'delete_entry':
				$id   = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
				$done = $id ? BMC_Forms::delete_entry( $id ) : 0;

				if ( ! $done ) {
					wp_send_json_error( array( 'message' => 'حذف ارسال ناموفق بود.' ), 400 );
				}

				wp_send_json_success( array( 'message' => 'ارسال حذف شد.' ) );
				break;

			case 'entry_status':
				$id     = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
				$status = isset( $_POST['status'] ) ? sanitize_key( wp_unslash( $_POST['status'] ) ) : '';
				$done   = $id && $status ? BMC_Forms::set_entry_status( $id, $status ) : false;

				if ( ! $done ) {
					wp_send_json_error( array( 'message' => 'تغییر وضعیت ناموفق بود.' ), 400 );
				}

				wp_send_json_success( array( 'message' => 'وضعیت ارسال به‌روز شد.' ) );
				break;

			case 'clear_entries':
				$id    = isset( $_POST['id'] ) ? absint( $_POST['id'] ) : 0;
				$count = $id ? BMC_Forms::delete_entries( $id ) : 0;
				wp_send_json_success( array( 'message' => sprintf( '%d ارسال حذف شد.', $count ) ) );
				break;

			case 'run_health':
				set_time_limit( 120 );
				$checks = BMC_Safe::health();
				$bad    = 0;

				foreach ( $checks as $check ) {
					if ( 'fail' === $check['status'] ) {
						$bad++;
					}
				}

				wp_send_json_success(
					array(
						'message' => sprintf( 'آزمون سلامت انجام شد: %d بررسی، %d مورد نیازمند اقدام.', count( $checks ), $bad ),
						'checks'  => $checks,
					)
				);
				break;

			case 'safe_on':
				BMC_Safe::activate( 'on' );
				wp_send_json_success( array( 'message' => 'حالت ایمن فعال شد؛ بخش‌های پرخطر افزونه خاموش شدند.' ) );
				break;

			case 'safe_off':
				BMC_Safe::deactivate();
				wp_send_json_success( array( 'message' => 'حالت ایمن خاموش شد و همهٔ بخش‌ها دوباره فعال‌اند.' ) );
				break;

			case 'safe_recover':
				BMC_Safe::recover();
				wp_send_json_success( array( 'message' => 'بازیابی انجام شد: المنتور، چک‌اوت و سبد اختصاصی و کارت داشبورد خاموش شدند.' ) );
				break;

			case 'clear_crash':
				BMC_Safe::reset();
				wp_send_json_success( array( 'message' => 'گزارش خطاهای فاحش پاک شد.' ) );
				break;

			default:
				wp_send_json_error( array( 'message' => 'عملیات نامعتبر است.' ), 400 );
		}
	}

	public static function maybe_export_csv() {
		if ( empty( $_GET['bmc_export'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}

		check_admin_referer( 'bmc_export', 'bmc_nonce' );

		if ( 'forms' === sanitize_key( wp_unslash( $_GET['bmc_export'] ) ) ) {
			self::export_forms_csv( isset( $_GET['bmc_form'] ) ? absint( $_GET['bmc_form'] ) : 0 );
		}

		$result = BMC_Deliveries::query( array( 'per_page' => 100, 'paged' => 1 ) );
		$all    = array();
		$pages  = min( 50, (int) $result['pages'] );

		for ( $page = 1; $page <= $pages; $page++ ) {
			$chunk = BMC_Deliveries::query( array( 'per_page' => 100, 'paged' => $page ) );
			$all   = array_merge( $all, $chunk['items'] );
		}

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=bazzarmc-deliveries-' . gmdate( 'Ymd-His' ) . '.csv' );

		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" );
		fputcsv( $out, array( 'id', 'order_id', 'user_id', 'player', 'product_id', 'variation_id', 'item', 'amount', 'status', 'created_at', 'delivered_at', 'expires_at' ) );

		foreach ( $all as $row ) {
			fputcsv(
				$out,
				array(
					$row->id,
					$row->order_id,
					$row->user_id,
					$row->player,
					$row->product_id,
					$row->variation_id,
					$row->item,
					$row->amount,
					BMC_Deliveries::status_label( $row->status ),
					$row->created_at,
					$row->delivered_at,
					$row->expires_at,
				)
			);
		}

		fclose( $out );
		exit;
	}

	public static function export_forms_csv( $form_id ) {
		if ( ! class_exists( 'BMC_Forms' ) || ! $form_id ) {
			wp_die( 'فرم نامعتبر است.' );
		}

		list( $head, $rows ) = BMC_Forms::export_rows( $form_id );

		nocache_headers();
		header( 'Content-Type: text/csv; charset=utf-8' );
		header( 'Content-Disposition: attachment; filename=bazzarmc-form-' . $form_id . '-' . gmdate( 'Ymd-His' ) . '.csv' );

		$out = fopen( 'php://output', 'w' );
		fwrite( $out, "\xEF\xBB\xBF" );
		fputcsv( $out, $head );

		foreach ( $rows as $row ) {
			fputcsv( $out, $row );
		}

		fclose( $out );
		exit;
	}

	public static function section_open( $title, $desc = '' ) {
		echo '<section class="bmc-box"><div class="bmc-box__head"><h2>' . esc_html( $title ) . '</h2>';
		if ( $desc ) {
			echo '<p>' . esc_html( $desc ) . '</p>';
		}
		echo '</div><div class="bmc-box__body">';
	}

	public static function section_close() {
		echo '</div></section>';
	}

	public static function form_open( $tab ) {
		echo '<form method="post" class="bmc-form">';
		wp_nonce_field( 'bmc_save_settings', 'bmc_settings_nonce' );
		echo '<input type="hidden" name="bmc_tab" value="' . esc_attr( $tab ) . '" />';
	}

	public static function form_close( $label = 'ذخیرهٔ تنظیمات' ) {
		echo '<div class="bmc-form__footer"><button type="submit" class="button button-primary button-hero bmc-save">' . esc_html( $label ) . '</button></div></form>';
	}

	public static function row( $label, $html, $hint = '' ) {
		echo '<div class="bmc-row"><div class="bmc-row__label"><label>' . esc_html( $label ) . '</label>';
		if ( $hint ) {
			echo '<span class="bmc-row__hint">' . wp_kses_post( $hint ) . '</span>';
		}
		echo '</div><div class="bmc-row__field">' . $html . '</div></div>';
	}

	public static function input( $name, $value, array $args = array() ) {
		$type  = isset( $args['type'] ) ? $args['type'] : 'text';
		$class = isset( $args['class'] ) ? ' ' . esc_attr( $args['class'] ) : '';
		$dir   = isset( $args['dir'] ) ? ' dir="' . esc_attr( $args['dir'] ) . '"' : '';
		$ph    = isset( $args['placeholder'] ) ? ' placeholder="' . esc_attr( $args['placeholder'] ) . '"' : '';
		$min   = isset( $args['min'] ) ? ' min="' . esc_attr( $args['min'] ) . '"' : '';
		$max   = isset( $args['max'] ) ? ' max="' . esc_attr( $args['max'] ) . '"' : '';
		$step  = isset( $args['step'] ) ? ' step="' . esc_attr( $args['step'] ) . '"' : '';

		return sprintf(
			'<input class="bmc-input%1$s" type="%2$s" name="%3$s" value="%4$s"%5$s%6$s%7$s%8$s%9$s />',
			$class,
			esc_attr( $type ),
			esc_attr( $name ),
			esc_attr( $value ),
			$dir,
			$ph,
			$min,
			$max,
			$step
		);
	}

	public static function textarea( $name, $value, $rows = 3, $class = '' ) {
		return sprintf(
			'<textarea class="bmc-input bmc-textarea %1$s" name="%2$s" rows="%3$d">%4$s</textarea>',
			esc_attr( $class ),
			esc_attr( $name ),
			(int) $rows,
			esc_textarea( $value )
		);
	}

	public static function select( $name, $value, array $options ) {
		$html = '<select class="bmc-input bmc-select" name="' . esc_attr( $name ) . '">';

		foreach ( $options as $key => $label ) {
			$html .= '<option value="' . esc_attr( $key ) . '" ' . selected( (string) $value, (string) $key, false ) . '>' . esc_html( $label ) . '</option>';
		}

		return $html . '</select>';
	}

	public static function toggle( $name, $value, $label = '' ) {
		$checked = BMC_Settings::normalize_yesno( $value ) === 'yes';

		return '<label class="bmc-toggle' . ( $checked ? ' is-on' : '' ) . '">'
			. '<input type="hidden" name="' . esc_attr( $name ) . '" value="no" />'
			. '<input type="checkbox" name="' . esc_attr( $name ) . '" value="yes" ' . checked( $checked, true, false ) . ' />'
			. '<span class="bmc-toggle__track"><span class="bmc-toggle__thumb"></span></span>'
			. ( $label ? '<span class="bmc-toggle__label">' . esc_html( $label ) . '</span>' : '' )
			. '</label>';
	}

	public static function role_select( $name, $value, $empty = true ) {
		$options = array();

		if ( $empty ) {
			$options[''] = '— بدون نقش —';
		}

		foreach ( wp_roles()->roles as $key => $role ) {
			$options[ $key ] = translate_user_role( $role['name'] );
		}

		return self::select( $name, $value, $options );
	}

	public static function page_select( $name, $value ) {
		$options = array( 0 => '— انتخاب کنید —' );

		$pages = get_pages( array( 'number' => 200 ) );

		foreach ( (array) $pages as $page ) {
			$options[ $page->ID ] = $page->post_title;
		}

		return self::select( $name, (int) $value, $options );
	}
}
