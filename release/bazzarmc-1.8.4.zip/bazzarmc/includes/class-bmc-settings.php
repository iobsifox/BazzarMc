<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Settings {

	const OPTION = 'bmc_settings';

	private static $cache = null;

	public static function defaults() {
		return array(

			'api_token'             => '',
			'server_name'           => 'سرور ماینکرافت',
			'server_ip'             => '',
			'username_policy'       => 'any',
			'force_link'            => 'yes',
			'default_linked_role'   => '',
			'unlink_allowed'        => 'yes',
			'legacy_compat'         => 'no',
			'debug_log'             => 'yes',
			'ssl_verify'            => 'yes',
			'mojang_check'          => 'yes',
			'cache_exclude'         => 'yes',
			'cf_api_token'          => '',
			'cf_zone_id'            => '',
			'cf_cache_rule'         => 'no',
			'blocks_checkout'       => 'force_classic',

			'link_mode'             => 'both',
			'code_ttl'              => 300,
			'code_length'           => 8,
			'code_alphabet'         => 'safe',
			'code_max_active'       => 1,
			'code_command_hint'     => '/mclink {code}',

			'sync_products'         => array(),
			'product_roles'         => array(),
			'product_role_duration' => array(),
			'rank_levels'           => array(),
			'rank_guard'            => 'yes',
			'rank_hide_lower'       => 'yes',
			'mc_ranks'              => array(),
			'mc_ranks_synced_at'    => 0,
			'mc_ranks_reported_at'  => 0,
			'role_duration_default' => 0,
			'myaccount_card'        => 'yes',
			'elementor_enabled'     => 'yes',
			'product_key_default'   => 'name',
			'product_keys'          => array(),
			'revoke_roles_on_refund' => 'yes',
			'custom_roles'          => array(),
			'delivery_expiry'       => array(
				'value' => 30,
				'unit'  => 'days',
			),
			'delivery_status'       => array( 'processing', 'completed' ),

			'ezlogin_sync_phone'    => 'yes',
			'otp_ttl'               => 120,
			'otp_length'            => 5,
			'otp_rate_limit'        => 120,
			'otp_max_attempts'      => 5,
			'otp_resend_limit'      => 3,

			'email_enabled'         => 'yes',
			'email_tpl_subject'     => 'کد اتصال ماینکرافت | {site}',
			'email_tpl_body'        => "<p>سلام {player}،</p>\n<p>کد اتصال شما: <strong style=\"font-size:22px;letter-spacing:2px\">{code}</strong></p>\n<p>این کد تا {minutes} دقیقه اعتبار دارد. آن را در بازی با دستور <code>/mclink {code}</code> وارد کنید.</p>\n<p>— {site}</p>",

			'verify_methods'        => array( 'dashboard', 'email' ),
			'verify_default'        => 'dashboard',
			'otp_dashboard_widget'  => 'yes',
			'otp_dashboard_box'     => 'yes',
			'mobile_meta_keys'      => array( 'bmc_mobile', 'mobile', 'billing_phone', 'digcell', 'digits_mobile', 'easylogin_mobile', 'bilacell_mobile', 'user_mobile', 'phone' ),

			'checkout_mode'         => 'custom',
			'gate_enabled'          => 'yes',
			'gate_only_synced'      => 'yes',
			'gate_product_page'     => 'no',
			'gate_hide_add_to_cart' => 'no',
			'cart_gate'             => 'yes',
			'cart_mode'             => 'wc',
			'persian_fields'        => 'yes',
			'persian_countries'     => 'yes',
			'persian_digits'        => 'no',
			'checkout_theme'        => 'dark',
			'checkout_accent'       => '#3ddc84',
			'checkout_show_coupon'  => 'yes',
			'checkout_show_summary' => 'yes',
			'checkout_gift_allowed' => 'yes',
			'checkout_fields'       => array(
				'first_name' => 1,
				'last_name'  => 1,
				'mobile'     => 1,
				'email'      => 1,
				'address'    => 0,
				'city'       => 0,
				'state'      => 0,
				'postcode'   => 0,
				'country'    => 0,
				'company'    => 0,
				'notes'      => 0,
			),

			'txt_not_linked_title'  => 'اکانت ماینکرافت شما متصل نیست',
			'txt_not_linked_body'   => 'برای ادامهٔ خرید و دریافت آیتم‌ها در بازی، ابتدا اکانت ماینکرافت خود را متصل کنید.',
			'txt_linked_title'      => 'اکانت متصل است',
			'txt_link_title'        => 'اتصال اکانت ماینکرافت',
			'txt_cart_blocked'      => 'برای فعال‌شدن دکمهٔ پرداخت، ابتدا اکانت ماینکرافت خود را متصل کنید.',
			'txt_thankyou'          => 'سفارش شما با موفقیت ثبت شد. آیتم‌ها پس از ورود به سرور به‌صورت خودکار تحویل داده می‌شوند.',

			'tickets_enabled'       => 'yes',
			'tickets_per_page'      => 10,
			'tickets_max_open'      => 0,
			'tickets_require_product' => 'no',
			'tickets_user_close'    => 'yes',
			'tickets_user_reopen'   => 'yes',
			'tickets_email_admin'   => 'yes',
			'tickets_email_user'    => 'yes',
			'tickets_admin_email'   => '',

			'forms_enabled'         => 'yes',
			'forms_rate_limit'      => 60,
			'forms_max_per_day'     => 25,
			'forms_honeypot'        => 'yes',
			'forms_allow_files'     => 'no',
			'forms_max_file_size'   => 4,
			'forms_notice_email'    => '',
			'forms_success_message' => 'پیام شما با موفقیت ارسال شد. به‌زودی پاسخ می‌دهیم.',
			'forms_error_message'   => 'ارسال ناموفق بود. لطفاً خطاهای مشخص‌شده را اصلاح کنید.',

			'safe_guard'            => 'yes',
			'safe_crash_limit'      => 2,
			'safe_mode'             => 'off',
			'safe_notify_email'     => '',
			'safe_debug_display'    => 'no',
			'safe_autorecover'      => 'yes',

			'cart_inline_checkout'  => 'no',
			'cart_steps_nav'        => 'yes',
			'cart_button_text'      => 'ثبت و پرداخت سفارش',
			'checkout_back_to_cart' => 'yes',
			'checkout_columns'      => '2',
			'checkout_submit_text'  => 'ثبت سفارش و پرداخت',
			'checkout_cards'        => array( 'mc', 'buyer', 'payment' ),
			'checkout_card_order'   => array(
				'mc'      => 1,
				'buyer'   => 2,
				'payment' => 3,
				'extra'   => 4,
			),
			'checkout_titles'       => array(
				'mc'      => 'اکانت ماینکرافت',
				'buyer'   => 'اطلاعات خریدار',
				'payment' => 'روش پرداخت',
				'summary' => 'خلاصهٔ سفارش',
				'extra'   => 'اطلاعات تکمیلی',
			),
			'checkout_layout'       => array(),

			'checkout_custom_enabled' => 'yes',
			'checkout_custom_fields'  => array(),
			'checkout_custom_order'   => array(),

			'link_width'            => 'narrow',
			'link_avatar_size'      => 96,
			'link_show_steps'       => 'yes',
			'link_step_1'           => 'نام کاربری ماینکرافت را وارد کنید و کد بسازید.',
			'link_step_2'           => 'کد را در بازی با دستور /mclink وارد کنید.',
			'link_step_3'           => 'اتصال تأیید می‌شود و می‌توانید خرید کنید.',
			'link_player_label'     => 'نام کاربری ماینکرافت',
			'link_player_placeholder' => 'Notch',
			'link_submit_text'      => 'ساخت کد اتصال',
			'link_code_hint'        => 'این کد را در بازی وارد کنید:',
			'link_copy_text'        => 'کپی کد',
			'link_regen_text'       => 'کد جدید',
			'link_show_otp_card'    => 'yes',
			'link_otp_title'        => 'روش جایگزین: کد تأیید',
			'link_show_uuid'        => 'yes',
			'link_show_linked_at'   => 'yes',
			'link_show_shop_button' => 'yes',
			'link_show_unlink'      => 'yes',
			'link_login_title'      => 'ابتدا وارد حساب کاربری شوید',
			'link_login_body'       => 'برای ساخت کد اتصال و پیوند اکانت ماینکرافت، باید وارد حساب کاربری خود در سایت شوید.',
			'link_login_button'     => 'ورود / عضویت',

			'shop_enabled'          => 'yes',
			'shop_source'           => 'all',
			'shop_source_tag'       => '',
			'shop_categories'       => array(),
			'shop_category_depth'   => 1,
			'shop_hide_empty_cats'  => 'yes',
			'shop_include'          => '',
			'shop_exclude'          => '',
			'shop_per_page'         => 12,
			'shop_columns'          => 3,
			'shop_columns_tablet'   => 2,
			'shop_columns_mobile'   => 1,
			'shop_gap'              => 18,
			'shop_pagination'       => 'numbers',
			'shop_load_more_text'   => 'نمایش محصولات بیشتر',
			'shop_empty_text'       => 'محصولی با این فیلترها پیدا نشد.',
			'shop_heading'          => '',
			'shop_heading_icon'     => 'storefront',
			'shop_show_count'       => 'yes',
			'shop_count_text'       => 'نمایش {shown} از {total} محصول',
			'shop_ajax'             => 'yes',

			'filter_enabled'        => 'yes',
			'filter_style'          => 'pills',
			'filter_position'       => 'top',
			'filter_title'          => '',
			'filter_icon'           => 'filter_list',
			'filter_show_all'       => 'yes',
			'filter_all_label'      => 'همهٔ محصولات',
			'filter_show_counts'    => 'yes',
			'filter_show_thumb'     => 'no',
			'filter_show_sort'      => 'yes',
			'filter_sort_label'     => 'مرتب‌سازی',
			'filter_sort_options'   => array( 'menu_order', 'date', 'price', 'price-desc', 'popularity', 'title' ),
			'filter_default_sort'   => 'menu_order',
			'filter_show_search'    => 'yes',
			'filter_search_placeholder' => 'جست‌وجوی محصول…',
			'filter_search_min'     => 2,
			'filter_show_reset'     => 'yes',
			'filter_reset_text'     => 'پاک‌کردن فیلترها',
			'filter_sticky'         => 'no',

			'card_show_image'       => 'yes',
			'card_image_ratio'      => '4:3',
			'card_show_category'    => 'yes',
			'card_show_price'       => 'yes',
			'card_show_excerpt'     => 'yes',
			'card_excerpt_words'    => 18,
			'card_show_rating'      => 'no',
			'card_show_sale_badge'  => 'yes',
			'card_sale_badge_text'  => 'تخفیف',
			'card_show_rank_badge'  => 'yes',
			'card_show_stock'       => 'no',
			'card_show_meta'        => 'yes',
			'card_button_text'      => 'افزودن به سبد خرید',
			'card_button_text_variable' => 'انتخاب گزینه‌ها',
			'card_button_text_soldout' => 'ناموجود',
			'card_button_icon'      => 'shopping_cart',
			'card_buy_now'          => 'no',
			'card_buy_now_text'     => 'خرید مستقیم',
			'card_align'            => 'center',
			'card_hover'            => 'lift',
			'card_click'            => 'quickview',
			'card_radius'           => 18,
			'card_qv_hint'          => 'yes',

			'qv_enabled'            => 'yes',
			'qv_width'              => 760,
			'qv_title_text'         => 'مشاهدهٔ سریع',
			'qv_show_image'         => 'yes',
			'qv_show_price'         => 'yes',
			'qv_show_meta'          => 'yes',
			'qv_show_excerpt'       => 'yes',
			'qv_show_description'   => 'yes',
			'qv_show_attributes'    => 'yes',
			'qv_show_rank'          => 'yes',
			'qv_show_add_to_cart'   => 'yes',
			'qv_show_single_link'   => 'yes',
			'qv_single_link_text'   => 'دیدن صفحهٔ کامل محصول',
			'qv_close_text'         => 'بستن',
			'qv_loading_text'       => 'در حال بارگذاری محصول…',
			'qv_error_text'         => 'امکان بارگذاری این محصول وجود ندارد.',

			'single_product_mode'   => 'enabled',
			'single_redirect_target' => 'shop',
			'single_redirect_page'  => 0,

			'ma_connect_enabled'    => 'yes',
			'ma_connect_title'      => 'اتصال ماینکرافت',
			'ma_connect_slug'       => 'minecraft',
			'ma_connect_icon'       => 'sports_esports',
			'ma_connect_position'   => 'after_orders',
			'ma_connect_badge'      => 'yes',

			'ma_tickets_enabled'    => 'yes',
			'ma_tickets_title'      => 'تیکت پشتیبانی',
			'ma_tickets_slug'       => 'bmc-tickets',
			'ma_tickets_icon'       => 'support_agent',
			'ma_tickets_position'   => 'before_logout',
			'ma_tickets_badge'      => 'yes',
			'ma_tickets_dot'        => 'yes',

			'page_link'             => 0,
			'page_cart'             => 0,
			'page_checkout'         => 0,
			'page_tickets'          => 0,
			'page_shop'             => 0,

			'update_enabled'        => 'yes',
			'update_channel'        => 'stable',
			'update_repo'           => 'iobsifox/BazzarMc',
			'update_token'          => '',
			'update_ttl'            => 6,
			'update_auto'           => 'no',
			'update_notice'         => 'yes',
			'update_show_jar'       => 'yes',
			'update_notify_email'   => '',

			'delivery_report_enabled' => 'yes',
			'delivery_note_user'    => 'yes',
			'delivery_show_attempts' => 'yes',
			'delivery_stuck_days'   => 3,

			'card_context'        => 'auto',
			'card_inject'         => 'yes',
			'card_context_tickets' => 'yes',
			'card_context_orders' => 'yes',
			'card_context_profile' => 'yes',
			'card_context_minecraft' => 'yes',
			'card_context_limit'  => 3,

			'nav_override'        => 'yes',
			'nav_mobile_layout'   => 'scroll',
			'nav_mobile_labels'   => 'yes',
			'nav_mobile_sticky'   => 'no',
			'nav_mobile_breakpoint' => 782,

			'email_from'          => '',
			'email_from_name'     => '',
			'email_strict'        => 'no',

			'update_check_plugins_page' => 'yes',
			'update_row_link'     => 'yes',

			'font_cdn'              => 'yes',
			'purge_on_uninstall'    => 'no',
			'install_notice_seen'   => 'no',
			'smtp_notice_seen'      => 'no',
		);
	}

	public static function all() {
		if ( null === self::$cache ) {
			$stored = get_option( self::OPTION, array() );
			if ( ! is_array( $stored ) ) {
				$stored = array();
			}
			self::$cache = array_merge( self::defaults(), $stored );
		}

		return self::$cache;
	}

	public static function sort_options() {
		return array(
			'menu_order' => 'ترتیب پیش‌فرض فروشگاه',
			'popularity' => 'پرفروش‌ترین',
			'rating'     => 'بیشترین امتیاز',
			'date'       => 'جدیدترین',
			'price'      => 'ارزان‌ترین',
			'price-desc' => 'گران‌ترین',
			'title'      => 'نام (الفبا)',
		);
	}

	public static function endpoint_positions() {
		return array(
			'after_dashboard' => 'بعد از «داشبورد»',
			'after_orders'    => 'بعد از «سفارش‌ها»',
			'before_logout'   => 'قبل از «خروج»',
			'first'           => 'اولین گزینهٔ فهرست',
			'last'            => 'آخرین گزینهٔ فهرست',
		);
	}

	public static function endpoint_icon_options() {
		return array(
			'sports_esports'      => 'دستهٔ بازی',
			'link'                => 'پیوند',
			'fingerprint'         => 'اثر انگشت',
			'badge'               => 'کارت شناسایی',
			'person'              => 'کاربر',
			'key'                 => 'کلید',
			'token'               => 'توکن',
			'qr_code_2'           => 'کد QR',
			'support_agent'       => 'پشتیبانی',
			'confirmation_number' => 'تیکت',
			'forum'               => 'گفت‌وگو',
			'chat'                => 'پیام',
			'mail'                => 'ایمیل',
			'inbox'               => 'صندوق ورودی',
			'help'                => 'راهنما',
			'contact_support'     => 'تماس با پشتیبانی',
			'storefront'          => 'فروشگاه',
			'shopping_cart'       => 'سبد خرید',
			'inventory_2'         => 'محصول',
			'dashboard'           => 'داشبورد',
			'settings'            => 'تنظیمات',
			'shield'              => 'سپر',
			'verified'            => 'تأییدشده',
			'download'            => 'دانلود',
			'receipt_long'        => 'رسید',
			'open_in_new'         => 'پیوند بیرونی',
		);
	}

	public static function get( $key, $default = null ) {
		$all = self::all();

		if ( array_key_exists( $key, $all ) ) {
			$value = $all[ $key ];
			return ( '' === $value && null !== $default ) ? $default : $value;
		}

		$defaults = self::defaults();

		if ( null !== $default ) {
			return $default;
		}

		return isset( $defaults[ $key ] ) ? $defaults[ $key ] : null;
	}

	public static function bool( $key, $default = false ) {
		$value = self::get( $key, $default );

		if ( is_bool( $value ) ) {
			return $value;
		}

		if ( is_numeric( $value ) ) {
			return (bool) $value;
		}

		return in_array( strtolower( (string) $value ), array( 'yes', 'on', 'true', '1' ), true );
	}

	public static function int( $key, $default = 0, $min = null, $max = null ) {
		$value = (int) self::get( $key, $default );

		if ( null !== $min && $value < $min ) {
			$value = $min;
		}
		if ( null !== $max && $value > $max ) {
			$value = $max;
		}

		return $value;
	}

	public static function set( $key, $value ) {
		return self::save( array( $key => $value ) );
	}

	public static function save( array $values ) {
		$all      = self::all();
		$defaults = self::defaults();

		foreach ( $values as $key => $value ) {
			if ( ! array_key_exists( $key, $defaults ) ) {
				continue;
			}

			$all[ $key ] = self::sanitize_value( $key, $value );
		}

		self::$cache = $all;

		return update_option( self::OPTION, $all, false );
	}

	private static function sanitize_value( $key, $value ) {
		$array_keys = array( 'sync_products', 'product_roles', 'product_role_duration', 'rank_levels', 'mc_ranks', 'delivery_expiry', 'checkout_fields', 'mobile_meta_keys', 'delivery_status', 'product_keys', 'verify_methods', 'custom_roles', 'checkout_cards', 'checkout_titles', 'checkout_layout', 'checkout_card_order', 'checkout_custom_fields', 'checkout_custom_order', 'shop_categories', 'filter_sort_options' );

		if ( in_array( $key, $array_keys, true ) ) {
			if ( ! is_array( $value ) ) {
				$value = array();
			}

			switch ( $key ) {
				case 'sync_products':
					return array_values( array_unique( array_filter( array_map( 'absint', $value ) ) ) );

				case 'product_roles':
					$clean = array();
					foreach ( $value as $pid => $role ) {
						$pid = absint( $pid );
						if ( $pid ) {
							$clean[ $pid ] = sanitize_text_field( $role );
						}
					}
					return $clean;

				case 'rank_levels':
					$clean = array();
					foreach ( $value as $pid => $level ) {
						$pid = absint( $pid );
						if ( ! $pid ) {
							continue;
						}
						$level = (int) $level;
						if ( $level > 0 ) {
							$clean[ $pid ] = min( 9999, $level );
						}
					}
					return $clean;

				case 'mc_ranks':
					$clean = array();
					foreach ( $value as $rank ) {
						if ( ! is_array( $rank ) ) {
							continue;
						}
						$key = sanitize_text_field( isset( $rank['key'] ) ? (string) $rank['key'] : '' );
						if ( '' === $key ) {
							continue;
						}
						$clean[] = array(
							'key'   => $key,
							'name'  => sanitize_text_field( isset( $rank['name'] ) ? (string) $rank['name'] : '' ),
							'level' => max( 0, (int) ( isset( $rank['level'] ) ? $rank['level'] : 0 ) ),
							'role'  => sanitize_text_field( isset( $rank['role'] ) ? (string) $rank['role'] : '' ),
							'days'  => max( 0, (int) ( isset( $rank['days'] ) ? $rank['days'] : 0 ) ),
						);
					}
					return $clean;

				case 'product_role_duration':
					$clean = array();
					foreach ( $value as $pid => $days ) {
						$pid = absint( $pid );
						if ( ! $pid ) {
							continue;
						}
						$days = (int) $days;
						$clean[ $pid ] = max( 0, min( 36500, $days ) );
					}
					return $clean;

				case 'delivery_expiry':
					return array(
						'value' => max( 1, isset( $value['value'] ) ? (int) $value['value'] : 30 ),
						'unit'  => in_array( isset( $value['unit'] ) ? $value['unit'] : 'days', array( 'minutes', 'hours', 'days', 'weeks' ), true ) ? $value['unit'] : 'days',
					);

				case 'delivery_status':
					$allowed = array( 'pending', 'processing', 'completed', 'on-hold' );
					return array_values( array_intersect( array_map( 'sanitize_key', $value ), $allowed ) );

				case 'mobile_meta_keys':
					$clean = array();
					foreach ( $value as $mk ) {
						$mk = sanitize_key( $mk );
						if ( $mk ) {
							$clean[] = $mk;
						}
					}
					return array_values( array_unique( $clean ) );

				case 'checkout_fields':
					$clean = array();
					foreach ( $value as $fk => $fv ) {
						$clean[ sanitize_key( $fk ) ] = (int) (bool) $fv;
					}
					return $clean;

				case 'verify_methods':
					$allowed = array( 'email', 'dashboard' );
					$clean   = array_values( array_intersect( array_map( 'sanitize_key', $value ), $allowed ) );
					return $clean ? $clean : array( 'dashboard' );

				case 'product_keys':
					$clean = array();
					foreach ( $value as $pid => $conf ) {
						$pid = absint( $pid );
						if ( ! $pid || ! is_array( $conf ) ) {
							continue;
						}
						$type = isset( $conf['type'] ) ? sanitize_key( $conf['type'] ) : 'name';
						if ( ! in_array( $type, array( 'name', 'id', 'slug', 'custom', 'sku' ), true ) ) {
							$type = 'name';
						}
						$clean[ $pid ] = array(
							'type'  => $type,
							'value' => sanitize_text_field( isset( $conf['value'] ) ? $conf['value'] : '' ),
						);
					}
					return $clean;

				case 'checkout_cards':
					$allowed = array( 'mc', 'buyer', 'payment', 'extra' );
					$clean   = array_values( array_intersect( array_map( 'sanitize_key', (array) $value ), $allowed ) );
					return $clean ? $clean : array( 'mc', 'buyer', 'payment' );

				case 'checkout_card_order':
					$clean = array();
					foreach ( array( 'mc', 'buyer', 'payment', 'extra' ) as $ck ) {
						$clean[ $ck ] = isset( $value[ $ck ] ) ? max( 1, min( 9, (int) $value[ $ck ] ) ) : 1;
					}
					return $clean;

				case 'checkout_titles':
					$clean = array();
					foreach ( array( 'mc', 'buyer', 'payment', 'summary', 'extra' ) as $tk ) {
						$clean[ $tk ] = isset( $value[ $tk ] ) ? sanitize_text_field( $value[ $tk ] ) : '';
					}
					return $clean;

				case 'checkout_layout':
					$clean = array();
					foreach ( (array) $value as $fk => $conf ) {
						$fk = sanitize_key( (string) $fk );
						if ( ! $fk || ! is_array( $conf ) ) {
							continue;
						}
						$width = isset( $conf['width'] ) ? (int) $conf['width'] : 0;
						if ( ! in_array( $width, array( 0, 25, 33, 50, 66, 75, 100 ), true ) ) {
							$width = 0;
						}
						$required = isset( $conf['required'] ) ? (int) $conf['required'] : -1;

						if ( ! in_array( $required, array( -1, 0, 1 ), true ) ) {
							$required = -1;
						}

						$enabled = isset( $conf['enabled'] ) ? (int) $conf['enabled'] : -1;

						if ( ! in_array( $enabled, array( -1, 0, 1 ), true ) ) {
							$enabled = -1;
						}

						$section = isset( $conf['section'] ) ? sanitize_key( (string) $conf['section'] ) : '';

						$clean[ $fk ] = array(
							'order'       => isset( $conf['order'] ) ? max( 0, min( 999, (int) $conf['order'] ) ) : 0,
							'label'       => sanitize_text_field( isset( $conf['label'] ) ? $conf['label'] : '' ),
							'placeholder' => sanitize_text_field( isset( $conf['placeholder'] ) ? $conf['placeholder'] : '' ),
							'help'        => sanitize_text_field( isset( $conf['help'] ) ? $conf['help'] : '' ),
							'width'       => $width,
							'required'    => $required,
							'enabled'     => $enabled,
							'section'     => in_array( $section, array( '', 'mc', 'buyer', 'shipping', 'order', 'payment', 'extra' ), true ) ? $section : '',
						);
					}
					return $clean;

				case 'checkout_custom_fields':
					return class_exists( 'BMC_Checkout_Fields' ) ? BMC_Checkout_Fields::normalize_list( $value ) : array();

				case 'checkout_custom_order':
					return array_values( array_filter( array_map( 'absint', (array) $value ), 'strlen' ) );

				case 'shop_categories':
					return array_values( array_unique( array_filter( array_map( 'absint', (array) $value ) ) ) );

				case 'filter_sort_options':
					$allowed = array_keys( self::sort_options() );
					$clean   = array_values( array_intersect( array_map( 'sanitize_key', (array) $value ), $allowed ) );
					return $clean ? $clean : array( 'menu_order' );

				case 'custom_roles':
					$clean = array();
					foreach ( $value as $pid => $conf ) {
						$pid = absint( $pid );
						if ( ! $pid || ! is_array( $conf ) ) {
							continue;
						}
						$slug = sanitize_key( isset( $conf['slug'] ) ? $conf['slug'] : '' );
						if ( ! $slug ) {
							continue;
						}
						$clean[ $pid ] = array(
							'slug' => $slug,
							'name' => sanitize_text_field( isset( $conf['name'] ) ? $conf['name'] : $slug ),
						);
					}
					return $clean;
			}
		}

		$int_keys = array(
			'code_ttl'         => array( 60, 3600 ),
			'code_length'      => array( 4, 16 ),
			'code_max_active'  => array( 1, 10 ),
			'otp_ttl'          => array( 30, 900 ),
			'otp_length'       => array( 4, 8 ),
			'otp_rate_limit'   => array( 10, 3600 ),
			'otp_max_attempts' => array( 1, 20 ),
			'otp_resend_limit' => array( 1, 20 ),
			'page_link'        => array( 0, PHP_INT_MAX ),
			'page_cart'        => array( 0, PHP_INT_MAX ),
			'page_checkout'    => array( 0, PHP_INT_MAX ),
			'role_duration_default' => array( 0, 36500 ),
			'mc_ranks_synced_at'   => array( 0, PHP_INT_MAX ),
			'tickets_per_page'     => array( 5, 50 ),
			'tickets_max_open'     => array( 0, 50 ),
			'mc_ranks_reported_at' => array( 0, PHP_INT_MAX ),
			'safe_crash_limit'   => array( 1, 10 ),
			'forms_rate_limit'   => array( 5, 3600 ),
			'forms_max_per_day'  => array( 0, 1000 ),
			'forms_max_file_size' => array( 1, 25 ),
			'link_avatar_size'   => array( 32, 192 ),
			'shop_per_page'      => array( 1, 96 ),
			'shop_columns'       => array( 1, 6 ),
			'shop_columns_tablet' => array( 1, 5 ),
			'shop_columns_mobile' => array( 1, 3 ),
			'shop_gap'           => array( 0, 80 ),
			'shop_category_depth' => array( 1, 4 ),
			'card_excerpt_words' => array( 0, 80 ),
			'card_radius'        => array( 0, 48 ),
			'qv_width'           => array( 360, 1400 ),
			'filter_search_min'  => array( 1, 8 ),
			'single_redirect_page' => array( 0, PHP_INT_MAX ),
			'page_shop'          => array( 0, PHP_INT_MAX ),
			'update_ttl'         => array( 1, 168 ),
			'delivery_stuck_days' => array( 1, 90 ),
			'card_context_limit' => array( 1, 10 ),
			'nav_mobile_breakpoint' => array( 320, 1600 ),
		);

		if ( isset( $int_keys[ $key ] ) ) {
			$bound = $int_keys[ $key ];
			return max( $bound[0], min( $bound[1], (int) $value ) );
		}

		$yesno = array(
			'force_link', 'unlink_allowed', 'legacy_compat', 'debug_log', 'email_enabled',
			'gate_enabled', 'gate_only_synced', 'gate_product_page',
			'gate_hide_add_to_cart', 'checkout_show_coupon', 'checkout_show_summary',
			'checkout_gift_allowed', 'font_cdn', 'install_notice_seen',
			'purge_on_uninstall', 'ssl_verify', 'mojang_check', 'cache_exclude',
			'cf_cache_rule', 'revoke_roles_on_refund', 'ezlogin_sync_phone',
			'otp_dashboard_widget', 'otp_dashboard_box', 'cart_gate', 'persian_fields', 'persian_digits',
			'persian_countries', 'smtp_notice_seen', 'myaccount_card', 'rank_guard', 'rank_hide_lower', 'tickets_enabled', 'tickets_require_product',
			'tickets_user_close', 'tickets_user_reopen', 'tickets_email_admin', 'tickets_email_user',
			'forms_honeypot', 'forms_allow_files', 'safe_guard', 'safe_autorecover', 'safe_debug_display',
			'cart_inline_checkout', 'cart_steps_nav', 'checkout_back_to_cart', 'checkout_custom_enabled',
			'link_show_steps', 'link_show_otp_card', 'link_show_uuid', 'link_show_linked_at',
			'link_show_shop_button', 'link_show_unlink',
			'shop_enabled', 'shop_hide_empty_cats', 'shop_show_count', 'shop_ajax',
			'filter_enabled', 'filter_show_all', 'filter_show_counts', 'filter_show_thumb',
			'filter_show_sort', 'filter_show_search', 'filter_show_reset', 'filter_sticky',
			'card_show_image', 'card_show_category', 'card_show_price', 'card_show_excerpt',
			'card_show_rating', 'card_show_sale_badge', 'card_show_rank_badge', 'card_show_stock',
			'card_show_meta', 'card_buy_now', 'card_qv_hint',
			'qv_enabled', 'qv_show_image', 'qv_show_price', 'qv_show_meta', 'qv_show_excerpt',
			'qv_show_description', 'qv_show_attributes', 'qv_show_rank', 'qv_show_add_to_cart',
			'qv_show_single_link',
			'ma_connect_enabled', 'ma_connect_badge', 'ma_tickets_enabled', 'ma_tickets_badge', 'ma_tickets_dot',
			'update_enabled', 'update_auto', 'update_notice', 'update_show_jar',
			'delivery_report_enabled', 'delivery_note_user', 'delivery_show_attempts',
			'card_context_tickets', 'card_context_orders', 'card_context_profile', 'card_context_minecraft',
			'nav_override', 'nav_mobile_labels', 'nav_mobile_sticky', 'email_strict', 'card_inject', 'myaccount_card',
			'update_check_plugins_page', 'update_row_link',
		);

		if ( in_array( $key, $yesno, true ) ) {
			return BMC_Settings::normalize_yesno( $value );
		}

		$enums = array(
						'blocks_checkout'   => array( 'force_classic', 'notice', 'register' ),
			'cart_mode'         => array( 'wc', 'custom' ),
			'product_key_default' => array( 'name', 'id', 'slug', 'sku' ),
			'checkout_mode'     => array( 'custom', 'wc' ),
			'checkout_theme'    => array( 'dark', 'light' ),
			'link_mode'         => array( 'panel', 'mc', 'both' ),
			'username_policy'   => array( 'any', 'premium' ),
			'code_alphabet'     => array( 'safe', 'digits', 'full' ),
			'safe_mode'         => array( 'off', 'on', 'auto' ),
			'link_width'        => array( 'narrow', 'wide' ),
			'checkout_columns'  => array( '1', '2' ),
			'shop_source'       => array( 'all', 'ranks', 'mc', 'tag' ),
			'shop_pagination'   => array( 'numbers', 'load_more', 'none' ),
			'filter_style'      => array( 'pills', 'tabs', 'chips', 'select' ),
			'filter_position'   => array( 'top', 'side' ),
			'filter_default_sort' => array( 'menu_order', 'date', 'price', 'price-desc', 'popularity', 'rating', 'title' ),
			'card_align'        => array( 'right', 'center' ),
			'card_hover'        => array( 'lift', 'glow', 'none' ),
			'card_click'        => array( 'quickview', 'single', 'none' ),
			'single_product_mode' => array( 'enabled', 'disabled', 'redirect' ),
			'single_redirect_target' => array( 'shop', 'home', 'page' ),
			'ma_connect_position' => array( 'after_dashboard', 'after_orders', 'before_logout', 'first', 'last' ),
			'ma_tickets_position' => array( 'after_dashboard', 'after_orders', 'before_logout', 'first', 'last' ),
			'update_channel'      => array( 'stable', 'prerelease' ),
			'card_context'        => array( 'dashboard', 'auto' ),
			'nav_mobile_layout'   => array( 'scroll', 'vertical', 'grid', 'icons', 'dropdown', 'collapse' ),
		);

		if ( isset( $enums[ $key ] ) ) {
			$value = sanitize_key( (string) $value );
			return in_array( $value, $enums[ $key ], true ) ? $value : $enums[ $key ][0];
		}

		if ( 'verify_default' === $key ) {
			$value    = sanitize_key( (string) $value );
			$methods  = (array) self::get( 'verify_methods', array( 'dashboard' ) );
			return in_array( $value, $methods, true ) ? $value : ( isset( $methods[0] ) ? $methods[0] : 'dashboard' );
		}

		if ( 'cf_api_token' === $key ) {
			return preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $value );
		}

		if ( 'cf_zone_id' === $key ) {
			return preg_replace( '/[^A-Za-z0-9]/', '', (string) $value );
		}

		$multiline = array( 'email_tpl_body', 'txt_not_linked_body' );
		if ( in_array( $key, $multiline, true ) ) {
			return wp_kses_post( $value );
		}

		$textarea = array( 'code_command_hint', 'txt_cart_blocked', 'txt_thankyou', 'forms_success_message', 'forms_error_message', 'link_login_body', 'link_step_1', 'link_step_2', 'link_step_3', 'link_code_hint' );
		if ( in_array( $key, $textarea, true ) ) {
			return sanitize_textarea_field( $value );
		}

		if ( 'api_token' === $key ) {
			return preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $value );
		}

		if ( 'update_repo' === $key ) {
			$repo = preg_replace( '/[^A-Za-z0-9_.\-\/]/', '', (string) $value );
			$repo = trim( $repo, '/' );

			if ( 1 !== substr_count( $repo, '/' ) ) {
				return 'iobsifox/BazzarMc';
			}

			return $repo;
		}

		if ( 'update_token' === $key ) {
			return preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $value );
		}

		if ( 'email_from' === $key ) {
			return sanitize_email( (string) $value );
		}

		if ( 'email_from_name' === $key ) {
			return preg_replace( '/[\r\n\t"]+/', '', sanitize_text_field( (string) $value ) );
		}

		if ( 'forms_notice_email' === $key || 'safe_notify_email' === $key || 'tickets_admin_email' === $key || 'update_notify_email' === $key ) {
			$parts = preg_split( '/[\s,;]+/', (string) $value );
			$clean = array();
			foreach ( (array) $parts as $part ) {
				$part = sanitize_email( trim( (string) $part ) );
				if ( $part ) {
					$clean[] = $part;
				}
			}
			return implode( ', ', array_slice( array_unique( $clean ), 0, 10 ) );
		}

		if ( in_array( $key, array( 'ma_connect_slug', 'ma_tickets_slug' ), true ) ) {
			$slug     = sanitize_title( (string) $value );
			$fallback = 'ma_tickets_slug' === $key ? 'bmc-tickets' : 'minecraft';

			if ( '' === $slug ) {
				return $fallback;
			}

			if ( class_exists( 'BMC_Account_Endpoints' ) && in_array( $slug, BMC_Account_Endpoints::reserved(), true ) ) {
				return $fallback;
			}

			$slug = preg_replace( '/[^a-z0-9_\-]/', '', $slug );

			return '' === $slug ? $fallback : $slug;
		}

		if ( 'card_image_ratio' === $key ) {
			$ratio = preg_replace( '/[^0-9:]/', '', (string) $value );

			return in_array( $ratio, array( 'auto', '1:1', '4:3', '3:4', '16:9' ), true ) ? $ratio : '4:3';
		}

		if ( 'checkout_accent' === $key ) {
			return preg_match( '/^#[0-9a-fA-F]{6}$/', (string) $value ) ? $value : '#3ddc84';
		}

		return sanitize_text_field( $value );
	}

	public static function normalize_yesno( $value ) {
		if ( is_bool( $value ) ) {
			return $value ? 'yes' : 'no';
		}
		return in_array( strtolower( (string) $value ), array( 'yes', 'on', 'true', '1' ), true ) ? 'yes' : 'no';
	}

	public static function api_token() {
		$token = (string) self::get( 'api_token' );

		if ( ! $token ) {
			$token = BMC_Helpers::random_token( 40 );
			self::set( 'api_token', $token );
		}

		return $token;
	}

	public static function regenerate_token() {
		$token = BMC_Helpers::random_token( 40 );
		self::set( 'api_token', $token );
		BMC_Logger::add( 'api', 'توکن API بازسازی شد', array(), 'warning' );
		return $token;
	}

	public static function api_base_url() {
		return esc_url_raw( rest_url( BMC_REST_NS ) );
	}

	public static function panel_code_enabled() {
		return in_array( self::get( 'link_mode' ), array( 'panel', 'both' ), true );
	}

	public static function mc_request_enabled() {
		return in_array( self::get( 'link_mode' ), array( 'mc', 'both' ), true );
	}

	public static function delivery_expiry_seconds() {
		return BMC_Helpers::duration_to_seconds( self::get( 'delivery_expiry' ), 30 * DAY_IN_SECONDS );
	}

	public static function custom_checkout() {
		return 'custom' === self::get( 'checkout_mode' );
	}

	public static function verify_methods() {
		$methods = (array) self::get( 'verify_methods', array( 'dashboard' ) );
		$methods = array_values( array_intersect( $methods, array( 'email', 'dashboard' ) ) );

		return $methods ? $methods : array( 'dashboard' );
	}

	public static function verify_enabled( $channel ) {
		return in_array( (string) $channel, self::verify_methods(), true );
	}

	public static function verify_default() {
		$default  = (string) self::get( 'verify_default', 'dashboard' );
		$methods  = self::verify_methods();

		return in_array( $default, $methods, true ) ? $default : $methods[0];
	}

	public static function ssl_verify() {
		return self::bool( 'ssl_verify', true );
	}

	public static function ezlogin_active() {
		return defined( 'EZ_LOGIN_VERSION' )
			|| function_exists( 'ez_login_find_user_by_phone' )
			|| function_exists( 'ez_login_normalize_phone' )
			|| ( function_exists( 'is_plugin_active' ) && is_plugin_active( 'ez-login/ez-login.php' ) );
	}

	public static function product_key_conf( $product_id ) {
		$keys = (array) self::get( 'product_keys', array() );
		$pid  = absint( $product_id );

		$default = self::get( 'product_key_default', 'name' );

		if ( ! in_array( $default, array( 'name', 'id', 'slug', 'sku' ), true ) ) {
			$default = 'name';
		}

		if ( isset( $keys[ $pid ] ) && is_array( $keys[ $pid ] ) ) {
			$type  = isset( $keys[ $pid ]['type'] ) ? $keys[ $pid ]['type'] : 'name';
			$value = isset( $keys[ $pid ]['value'] ) ? trim( (string) $keys[ $pid ]['value'] ) : '';

			if ( 'custom' === $type && '' === $value ) {
				$type = $default;
			}

			return array(
				'type'  => $type,
				'value' => $value,
			);
		}

		return array(
			'type'  => $default,
			'value' => '',
		);
	}

	public static function product_key( $product_id, $variation_id = 0 ) {
		$conf      = self::product_key_conf( $product_id );
		$type      = $conf['type'];
		$target_id = $variation_id ? absint( $variation_id ) : absint( $product_id );
		$product   = function_exists( 'wc_get_product' ) ? wc_get_product( $target_id ) : null;

		if ( 'id' === $type ) {
			return (string) $target_id;
		}

		if ( 'slug' === $type ) {
			if ( $product ) {
				return (string) $product->get_slug();
			}
			$post = get_post( $target_id );
			return $post ? (string) $post->post_name : '';
		}

		if ( 'sku' === $type ) {
			if ( $product ) {
				$sku = trim( (string) $product->get_sku() );

				if ( '' !== $sku ) {
					return $sku;
				}
			}
		}

		if ( 'custom' === $type && '' !== trim( $conf['value'] ) ) {
			return trim( $conf['value'] );
		}

		if ( $product ) {
			$name = trim( (string) $product->get_name() );
			return function_exists( 'mb_strtolower' ) ? mb_strtolower( $name ) : strtolower( $name );
		}

		return '';
	}

	public static function cart_gate_enabled() {
		return self::bool( 'gate_enabled', true ) && self::bool( 'cart_gate', true );
	}
}
