<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;

class BMC_EL_Account_Nav extends BMC_EL_Base {

	public function get_name() {
		return 'bmc-account-nav';
	}

	public function get_title() {
		return self::txt( 'Account Navigation', 'ناوبری حساب کاربری' );
	}

	public function get_icon() {
		return 'eicon-navigation-horizontal';
	}

	protected function bmc_slug() {
		return 'account-nav';
	}

	protected function extra_keywords() {
		return array( 'nav', 'menu', 'my account', 'منو', 'ناوبری', 'حساب کاربری' );
	}

	protected function content_controls() {
		$this->start_controls_section(
			'bmc_sec_content',
			array(
				'label' => 'منوی حساب کاربری',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'bmc_notice',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => 'فهرست بخش‌های حساب کاربری ووکامرس به‌همراه بخش‌های BazzarMc (اتصال ماینکرافت و تیکت پشتیبانی). برای طراحی کامل صفحهٔ حساب کاربری، این ویجت را کنار «محتوای حساب کاربری» قرار دهید.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_control(
			'layout',
			array(
				'label'   => 'چیدمان',
				'type'    => Controls_Manager::SELECT,
				'default' => 'vertical',
				'options' => array(
					'vertical'   => 'عمودی (ستون کناری)',
					'horizontal' => 'افقی (نوار بالا)',
					'pills'      => 'قرصی (دکمه‌های گرد)',
				),
			)
		);

		$this->add_control(
			'title',
			array(
				'label'   => 'عنوان منو',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'title_icon',
			array(
				'label'     => 'آیکون عنوان',
				'type'      => Controls_Manager::TEXT,
				'default'   => 'menu_book',
				'condition' => array(
					'title!' => '',
				),
			)
		);

		$this->add_control(
			'icons',
			array(
				'label'        => 'نمایش آیکون‌ها',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'counts',
			array(
				'label'        => 'نمایش شمارندهٔ تیکت‌ها',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'active_only',
			array(
				'label'        => 'فقط بخش فعال (برای سربرگ موبایل)',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'items',
			array(
				'label'       => 'بخش‌های نمایش داده‌شده',
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'default'     => array(),
				'options'     => $this->endpoint_options(),
				'description' => 'خالی = همهٔ بخش‌ها. ترتیب انتخاب شما اعمال می‌شود.',
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'label',
			array(
				'label'   => 'عنوان',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$repeater->add_control(
			'url',
			array(
				'label'   => 'پیوند',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$repeater->add_control(
			'icon',
			array(
				'label'   => 'آیکون (نام آیکون متریال)',
				'type'    => Controls_Manager::TEXT,
				'default' => 'open_in_new',
			)
		);

		$this->add_control(
			'extra_items',
			array(
				'label'       => 'موارد دلخواه',
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(),
				'title_field' => '{{{ label }}}',
			)
		);

		$this->add_control(
			'mobile_heading',
			array(
				'type'  => Controls_Manager::HEADING,
				'label' => 'طراحی موبایل',
			)
		);

		$this->add_control(
			'mobile',
			array(
				'label'       => 'چیدمان موبایل',
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'description' => 'خالی = همان تنظیم کلی افزونه. این چیدمان فقط در عرض‌های کوچک‌تر از «عرض شکست» اعمال می‌شود.',
				'options'     => array(
					''         => 'پیش‌فرض افزونه',
					'scroll'   => 'افقی لغزان (یک ردیف قابل کشیدن)',
					'grid'     => 'شبکهٔ سه‌ستونی',
					'icons'    => 'آیکونی فشرده',
					'dropdown' => 'فهرست کشویی',
					'collapse' => 'جمع‌شونده',
					'vertical' => 'عمودی',
				),
			)
		);

		$this->add_control(
			'mobile_labels',
			array(
				'label'        => 'برچسب آیتم‌ها در موبایل',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'description'  => 'خاموش = فقط آیکون‌ها (مناسب چیدمان افقی لغزان).',
			)
		);

		$this->add_control(
			'mobile_sticky',
			array(
				'label'        => 'منوی چسبان در موبایل',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'description'  => 'هنگام اسکرول، منو در بالای نمایشگر می‌ماند.',
			)
		);

		$this->add_control(
			'breakpoint',
			array(
				'label'   => 'عرض شکست (پیکسل)',
				'type'    => Controls_Manager::NUMBER,
				'default' => '',
				'min'     => 320,
				'max'     => 1600,
				'description' => 'خالی = مقدار تنظیمات افزونه (۷۸۲).',
			)
		);

		$this->end_controls_section();
	}

	private function endpoint_options() {
		$connect = class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::slug( 'connect' ) : 'minecraft';
		$tickets = class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::slug( 'tickets' ) : 'bmc-tickets';

		$options = array(
			'dashboard'       => 'داشبورد',
			'orders'          => 'سفارش‌ها',
			'downloads'       => 'دانلودها',
			'edit-address'    => 'آدرس‌ها',
			'payment-methods' => 'روش‌های پرداخت',
			'edit-account'    => 'جزئیات حساب',
			$connect          => class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::title( 'connect' ) : 'اتصال ماینکرافت',
			$tickets          => class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::title( 'tickets' ) : 'تیکت پشتیبانی',
			'customer-logout' => 'خروج',
		);

		if ( function_exists( 'wc_get_account_menu_items' ) && is_user_logged_in() ) {
			foreach ( array_keys( (array) wc_get_account_menu_items() ) as $endpoint ) {
				if ( ! isset( $options[ $endpoint ] ) ) {
					$options[ $endpoint ] = $endpoint;
				}
			}
		}

		return $options;
	}

	protected function style_controls() {
		$this->start_controls_section(
			'bmc_sec_nav_style',
			array(
				'label' => 'منو',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'item_typography',
				'label'    => 'تایپوگرافی موارد',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-nav__label',
			)
		);

		$this->add_responsive_control(
			'item_gap',
			array(
				'label'      => 'فاصلهٔ بین موارد',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__list' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'item_padding',
			array(
				'label'      => 'فاصلهٔ داخلی موارد',
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'item_radius',
			array(
				'label'      => 'گردی موارد',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item a' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'icon_size',
			array(
				'label'      => 'اندازهٔ آیکون',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 12,
						'max' => 34,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__icon .bmc-ico' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->start_controls_tabs( 'bmc_nav_tabs' );

		$this->start_controls_tab(
			'bmc_nav_normal',
			array(
				'label' => 'عادی',
			)
		);

		$this->add_control(
			'item_color',
			array(
				'label'     => 'رنگ متن',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item a' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'item_bg',
			array(
				'label'     => 'پس‌زمینه',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item a' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'item_border_color',
			array(
				'label'     => 'رنگ حاشیه',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item a' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'bmc_nav_hover',
			array(
				'label' => 'هاور',
			)
		);

		$this->add_control(
			'item_hover_color',
			array(
				'label'     => 'رنگ متن',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item a:hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'item_hover_bg',
			array(
				'label'     => 'پس‌زمینه',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item a:hover' => 'background: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'bmc_nav_active',
			array(
				'label' => 'بخش فعال',
			)
		);

		$this->add_control(
			'item_active_color',
			array(
				'label'     => 'رنگ متن',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item.is-active a' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'item_active_bg',
			array(
				'label'     => 'پس‌زمینه',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item.is-active a' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'item_active_border',
			array(
				'label'     => 'رنگ حاشیه',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item.is-active a' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				'label'    => 'تایپوگرافی عنوان منو',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-nav__title',
			)
		);

		$this->end_controls_section();
	}

	protected function render_inner( $settings ) {
		if ( ! is_user_logged_in() ) {
			$placeholder = $this->editor_placeholder( 'منوی حساب کاربری فقط برای کاربر واردشده نمایش داده می‌شود.' );

			return '' !== $placeholder ? $placeholder : BMC_Public::login_notice( 'برای مشاهدهٔ منوی حساب کاربری وارد حساب شوید.' );
		}

		$args = array(
			'layout'      => (string) $settings['layout'],
			'icons'       => 'yes' === $settings['icons'],
			'counts'      => 'yes' === $settings['counts'],
			'active_only' => 'yes' === $settings['active_only'],
			'title'       => (string) $settings['title'],
			'title_icon'  => (string) $settings['title_icon'],
			'items'       => array_map( 'sanitize_key', (array) $settings['items'] ),
			'extra'       => $this->clean_extra( $settings['extra_items'] ),
			'mobile'      => isset( $settings['mobile'] ) ? sanitize_key( (string) $settings['mobile'] ) : '',
			'breakpoint'  => isset( $settings['breakpoint'] ) ? absint( $settings['breakpoint'] ) : 0,
		);

		if ( ! empty( $settings['mobile_labels'] ) ) {
			$args['mobile_labels'] = 'yes' === $settings['mobile_labels'];
		}

		if ( ! empty( $settings['mobile_sticky'] ) ) {
			$args['mobile_sticky'] = 'yes' === $settings['mobile_sticky'];
		}

		return BMC_Public::render_account_nav( $args );
	}

	private function clean_extra( $items ) {
		$out = array();

		foreach ( (array) $items as $item ) {
			if ( empty( $item['label'] ) || empty( $item['url'] ) ) {
				continue;
			}

			$out[] = array(
				'label' => sanitize_text_field( (string) $item['label'] ),
				'url'   => esc_url_raw( (string) $item['url'] ),
				'icon'  => sanitize_key( (string) ( isset( $item['icon'] ) ? $item['icon'] : '' ) ),
			);
		}

		return $out;
	}
}
