<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_atts        = isset( $bmc_atts ) ? (array) $bmc_atts : array();
$bmc_title       = ! empty( $bmc_atts['title'] ) ? $bmc_atts['title'] : BMC_Settings::get( 'txt_login_title', 'ورود با شمارهٔ موبایل' );
$bmc_redirect    = ! empty( $bmc_atts['redirect'] ) ? esc_url_raw( $bmc_atts['redirect'] ) : '';
$bmc_otp_len     = BMC_Settings::int( 'sms_otp_length', 5, 4, 8 );
$bmc_otp_ttl     = BMC_Settings::int( 'sms_otp_ttl', 120, 30, 900 );
$bmc_theme       = 'light' === BMC_Settings::get( 'checkout_theme' ) ? ' bmc-theme-light' : '';
$bmc_integrations = BMC_Auth::detected_integrations();
$bmc_sms_ready   = BMC_SMS::is_ready();
$bmc_channels    = BMC_Verify::enabled();
$bmc_channel_ui  = count( $bmc_channels ) > 1 ? BMC_Verify::channel_selector() : '';
$bmc_dashbox     = is_user_logged_in() ? BMC_Verify::panel_box() : '';

if ( ! $bmc_redirect && isset( $_GET['redirect_to'] ) ) {
	$bmc_redirect = esc_url_raw( wp_unslash( $_GET['redirect_to'] ) );
}
?>
<div class="bmc-wrap<?php echo esc_attr( $bmc_theme ); ?>" id="bmcLoginWrap"
	data-otp-length="<?php echo esc_attr( $bmc_otp_len ); ?>"
	data-otp-ttl="<?php echo esc_attr( $bmc_otp_ttl ); ?>"
	data-redirect="<?php echo esc_attr( $bmc_redirect ); ?>">

	<div class="bmc-container bmc-container--narrow">

		<div class="bmc-card bmc-fade">
			<div class="bmc-card__head" style="border:0;padding:0;margin-bottom:6px">
				<div style="width:100%;text-align:center">
					<span class="bmc-kicker">🔐 ورود سریع</span>
					<h2 class="bmc-title" style="font-size:22px"><?php echo esc_html( $bmc_title ); ?></h2>
					<p class="bmc-subtitle">بدون رمز عبور؛ فقط با شمارهٔ موبایل و کد یکبارمصرف.</p>
				</div>
			</div>

			<?php if ( ! BMC_Settings::bool( 'otp_login', true ) ) : ?>
				<div class="bmc-alert bmc-alert--warn">
					<span class="bmc-alert__icon">⚠️</span>
					<div>ورود با موبایل توسط مدیر سایت غیرفعال شده است.</div>
				</div>
			<?php endif; ?>

			<?php if ( ! $bmc_sms_ready ) : ?>
				<div class="bmc-alert bmc-alert--warn">
					<span class="bmc-alert__icon">📵</span>
					<div>سامانهٔ پیامک هنوز پیکربندی نشده است. تا زمان تکمیل تنظیمات، کد از طریق ایمیل ارسال می‌شود.</div>
				</div>
			<?php endif; ?>

			<?php if ( $bmc_integrations && 'no' !== BMC_Settings::get( 'use_external_login' ) ) : ?>
				<div class="bmc-alert bmc-alert--info">
					<span class="bmc-alert__icon">🔗</span>
					<div>
						افزونه‌های ورود پیامکی شناسایی شد:
						<strong><?php echo esc_html( implode( '، ', array_keys( $bmc_integrations ) ) ); ?></strong>.
						شمارهٔ موبایل ثبت‌شده در آن افزونه‌ها به‌صورت خودکار خوانده می‌شود.
					</div>
				</div>
			<?php endif; ?>

			<?php if ( $bmc_dashbox ) : ?>
				<?php echo $bmc_dashbox; ?>
			<?php endif; ?>

			<div id="bmcLoginAlert"></div>

			<form id="bmcLoginStep1" autocomplete="off">
				<div class="bmc-field">
					<label class="bmc-label" for="bmcMobileInput">شمارهٔ موبایل</label>
					<input class="bmc-input" type="tel" id="bmcMobileInput" name="mobile" dir="ltr"
						inputmode="numeric" maxlength="14" placeholder="09xxxxxxxxx"
						style="text-align:center;font-size:18px;letter-spacing:2px" />
					<?php if ( $bmc_channel_ui ) : ?>
						<div style="margin-top:14px">
							<span class="bmc-label">روش دریافت کد</span>
							<?php echo $bmc_channel_ui; ?>
							<p class="bmc-hint bmc-channel-hint">کد تأیید به این شماره پیامک می‌شود.</p>
						</div>
					<?php else : ?>
						<p class="bmc-hint">کد تأیید به این شماره پیامک می‌شود.</p>
					<?php endif; ?>
				</div>

				<button type="submit" class="bmc-btn bmc-btn--block" id="bmcSendCodeBtn">
					<span class="bmc-spin"></span>
					<span>دریافت کد تأیید</span>
				</button>

				<p class="bmc-resend">
					اگر حساب کاربری ندارید، با واردکردن شمارهٔ موبایل به‌صورت خودکار ساخته می‌شود.
				</p>
			</form>

			<form id="bmcLoginStep2" class="bmc-hidden" autocomplete="off" style="margin-top:6px">
				<p class="bmc-subtitle" style="text-align:center">
					کد <?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_otp_len ) ); ?> رقمی ارسال‌شده به
					<strong id="bmcMaskedMobile" dir="ltr" style="display:inline-block"></strong> را وارد کنید.
				</p>

				<div class="bmc-otp-inputs" id="bmcOtpBoxes">
					<?php for ( $bmc_i = 0; $bmc_i < $bmc_otp_len; $bmc_i++ ) : ?>
						<input type="text" inputmode="numeric" maxlength="1" pattern="[0-9]" data-index="<?php echo esc_attr( $bmc_i ); ?>" />
					<?php endfor; ?>
				</div>

				<p class="bmc-resend">
					<span id="bmcResendTimer"></span>
					<button type="button" id="bmcResendBtn" disabled>ارسال مجدد کد</button>
				</p>

				<button type="submit" class="bmc-btn bmc-btn--block" id="bmcVerifyBtn" style="margin-top:6px">
					<span class="bmc-spin"></span>
					<span>ورود به حساب</span>
				</button>

				<button type="button" class="bmc-btn bmc-btn--ghost bmc-btn--block" id="bmcChangeMobile" style="margin-top:10px">
					تغییر شمارهٔ موبایل
				</button>
			</form>

			<div style="margin-top:20px;text-align:center">
				<a class="bmc-subtitle" href="<?php echo esc_url( wp_login_url( $bmc_redirect ? $bmc_redirect : '' ) ); ?>" style="font-size:13px">
					ورود با نام کاربری و رمز عبور
				</a>
			</div>
		</div>

	</div>
</div>
