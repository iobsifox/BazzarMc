(function ($) {
	'use strict';

	if (typeof bmcAdmin === 'undefined') {
		return;
	}

	function toast(message, type) {
		$('.bmc-toast').remove();
		var $t = $('<div class="bmc-toast"></div>').addClass(type ? 'is-' + type : '').text(message);
		$('body').append($t);
		setTimeout(function () { $t.fadeOut(220, function () { $t.remove(); }); }, 4200);
	}

	$(document).on('click', '.bmc-copy', function () {
		var text = $(this).data('copy');
		var $btn = $(this);
		var original = $btn.text();

		var done = function () {
			$btn.text(bmcAdmin.i18n.copied);
			setTimeout(function () { $btn.text(original); }, 1600);
		};

		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(String(text)).then(done).catch(function () { fallback(text, done); });
		} else {
			fallback(text, done);
		}
	});

	function fallback(text, cb) {
		var $tmp = $('<textarea>').val(text).css({ position: 'fixed', top: '-1000px', opacity: 0 }).appendTo('body');
		$tmp[0].select();
		try {
			document.execCommand('copy');
			cb();
		} catch (e) {
			toast('کپی ناموفق بود.', 'error');
		}
		$tmp.remove();
	}

	$(document).on('click', '.bmc-action', function (e) {
		e.preventDefault();

		var $btn = $(this);
		var action = $btn.data('do');

		if ($btn.data('confirm') && !window.confirm(bmcAdmin.i18n.confirm)) {
			return;
		}

		var data = { action: 'bmc_admin_action', security: bmcAdmin.nonce, 'do': action };

		var extra = $btn.data('extra');
		if (extra) {
			$.each(String(extra).split(','), function (i, pair) {
				var parts = pair.split(':');
				if (parts.length === 2) {
					data[parts[0]] = $(parts[1]).val();
				}
			});
		}

		var original = $btn.html();
		$btn.prop('disabled', true).html(bmcAdmin.i18n.working);

		$.post(bmcAdmin.ajaxUrl, data)
			.done(function (res) {
				if (res && res.success) {
					toast(res.data.message || bmcAdmin.i18n.done, 'ok');
					handleSpecial(action, res.data);
				} else {
					toast((res && res.data && res.data.message) ? res.data.message : bmcAdmin.i18n.error, 'error');
				}
			})
			.fail(function (xhr) {
				var msg = (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ? xhr.responseJSON.data.message : bmcAdmin.i18n.error;
				toast(msg, 'error');
			})
			.always(function () {
				$btn.prop('disabled', false).html(original);
			});
	});

	function handleSpecial(action, data) {
		if (action === 'regenerate_token' && data.token) {
			$('#bmcTokenValue, #bmcTokenField').text(data.token);
			$('.bmc-copy[data-copy]').each(function () {
				if ($(this).data('copy').length === data.token.length) {
					$(this).attr('data-copy', data.token);
				}
			});
		}

		if (action === 'detect_mobile_keys' && data.keys) {
			var $target = $('#bmcDetectedKeys');
			$target.empty();

			if (!data.keys.length) {
				$target.append('<div class="bmc-note">کلیدی با مقدار شبیه شمارهٔ موبایل پیدا نشد.</div>');
				return;
			}

			$.each(data.keys, function (i, row) {
				$target.append(
					'<div class="bmc-key-row"><code>' + row.meta_key + '</code><span>' + row.c + ' کاربر</span>' +
					'<button type="button" class="button button-small bmc-add-key" data-key="' + row.meta_key + '">افزودن به لیست</button></div>'
				);
			});
		}
	}

	$(document).on('click', '.bmc-add-key', function () {
		var key = $(this).data('key');
		var $input = $('input[name="mobile_meta_keys"]');
		var current = ($input.val() || '').split(',').map(function (v) { return v.trim(); }).filter(Boolean);

		if (current.indexOf(key) === -1) {
			current.push(key);
			$input.val(current.join(','));
			toast('کلید «' + key + '» اضافه شد. فرم را ذخیره کنید.', 'ok');
		}
	});

	$(document).on('click', '.bmc-delivery-action', function () {
		var $btn = $(this);
		var action = $btn.data('do');

		if (action === 'delete' && !window.confirm(bmcAdmin.i18n.confirm)) {
			return;
		}

		$btn.prop('disabled', true);

		$.post(bmcAdmin.ajaxUrl, {
			action: 'bmc_admin_delivery_action',
			security: bmcAdmin.nonce,
			id: $btn.data('id'),
			'do': action
		}).done(function (res) {
			if (res && res.success) {
				toast(res.data.message, 'ok');
				var $row = $btn.closest('tr');
				if (action === 'delete') {
					$row.fadeOut(200, function () { $row.remove(); });
				} else {
					setTimeout(function () { window.location.reload(); }, 700);
				}
			} else {
				toast((res && res.data && res.data.message) ? res.data.message : bmcAdmin.i18n.error, 'error');
				$btn.prop('disabled', false);
			}
		}).fail(function () {
			toast(bmcAdmin.i18n.error, 'error');
			$btn.prop('disabled', false);
		});
	});

	$(document).on('input', '#bmcProductSearch', function () {
		var q = $(this).val().trim().toLowerCase();

		$('.bmc-product').each(function () {
			var title = $(this).data('title') || '';
			var match = !q || String(title).indexOf(q) !== -1;
			$(this).toggle(match);
		});

		$('.bmc-variations').each(function () {
			var anyVisible = $(this).find('.bmc-product:visible').length > 0;
			$(this).toggle(anyVisible);
		});
	});

	function updateCount() {
		var count = $('input[name="sync_products[]"]:checked').length;
		$('#bmcSelectedCount').text(count.toLocaleString('fa-IR'));
	}

	$(document).on('change', 'input[name="sync_products[]"]', function () {
		$(this).closest('.bmc-product').toggleClass('is-checked', this.checked);
		updateCount();
	});

	if ($.fn.wpColorPicker) {
		$('.bmc-color').wpColorPicker();
	}

	updateCount();
})(jQuery);
