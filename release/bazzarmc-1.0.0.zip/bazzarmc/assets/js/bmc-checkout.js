(function ($) {
	'use strict';

	function ico(name) {
		return window.bmcIcon ? window.bmcIcon(name) : '';
	}


	if (typeof bmcCheckout === 'undefined') {
		return;
	}

	var $form = $('#bmcCheckoutForm');
	if (!$form.length) {
		return;
	}

	function alertBox(type, message) {
		var icons = { error: ico('error'), ok: ico('check_circle'), info: ico('info'), warn: ico('warning') };
		if (!message) {
			$('#bmcCheckoutAlert').html('');
			return;
		}
		$('#bmcCheckoutAlert').html(
			'<div class="bmc-alert bmc-alert--' + type + ' bmc-fade"><span class="bmc-alert__icon">' +
			(icons[type] || ico('info')) + '</span><div>' + message + '</div></div>'
		);
		window.scrollTo({ top: 0, behavior: 'smooth' });
	}

	function loading($btn, on) {
		if (on) {
			$btn.addClass('is-loading').prop('disabled', true);
		} else {
			$btn.removeClass('is-loading').prop('disabled', false);
		}
	}

	function ajax(action, data) {
		return $.post(bmcCheckout.ajaxUrl, $.extend({ action: action, security: bmcCheckout.nonce }, data || {}));
	}

	$('#bmcGiftToggle').on('change', function () {
		var checked = $(this).is(':checked');
		$('#bmcGiftPlayer').prop('required', checked).closest('#bmcGiftFields').css('opacity', checked ? 1 : 0.45);
		if (checked) {
			$('#bmcGiftPlayer').trigger('focus');
		}
	});

	if ($('#bmcGiftToggle').length) {
		$('#bmcGiftPlayer').closest('#bmcGiftFields').css('opacity', 0.45);
	}

	var headTimer = null;
	$('#bmcGiftPlayer').on('input', function () {
		var value = $(this).val().trim();
		clearTimeout(headTimer);
		if (value.length < 3) {
			$('#bmcCheckoutHead').attr('src', 'https://mc-heads.net/avatar/MHF_Question/96');
			return;
		}
		headTimer = setTimeout(function () {
			$('#bmcCheckoutHead').attr('src', 'https://mc-heads.net/avatar/' + encodeURIComponent(value) + '/96?t=' + Date.now());
		}, 400);
	});

	$(document).on('change', 'input[name="payment_method"]', function () {
		$('.bmc-pay__option').removeClass('is-selected');
		$(this).closest('.bmc-pay__option').addClass('is-selected');
	});

	function renderSummary(data) {
		if (!data) {
			return;
		}

		if (data.items) {
			var html = '';
			$.each(data.items, function (i, item) {
				html += '<li class="bmc-summary__item">' +
					(item.image ? '<img class="bmc-summary__thumb" src="' + item.image + '" alt="" />' : '<span class="bmc-summary__thumb" style="display:grid;place-items:center">' + ico('inventory_2') + '</span>') +
					'<span class="bmc-summary__name">' + item.name +
					'<small>تعداد: ' + item.qty + (item.synced ? ' • تحویل در بازی' : '') + '</small></span>' +
					'<span class="bmc-summary__price">' + item.total + '</span></li>';
			});
			$('#bmcItems').html(html);
		}

		if (data.totals) {
			var totals = '';
			$.each(data.totals, function (i, row) {
				totals += '<div class="bmc-summary__row ' + (row['class'] || '') + '"><span>' + row.label + '</span><span>' + row.value + '</span></div>';
			});
			$('#bmcTotals').html(totals);
		}

		if (data.grand_total) {
			$('#bmcGrandTotal').html(data.grand_total);
		}

		if (data.item_count !== undefined) {
			$('#bmcCartCount').text(data.item_count + ' کالا');
		}

		if (data.coupons) {
			var tags = '';
			$.each(data.coupons, function (i, code) {
				tags += '<span class="bmc-tag">' + code + ' <button type="button" data-coupon="' + code + '">×</button></span>';
			});
			$('#bmcCouponTags').html(tags);
		}
	}

	$('#bmcApplyCoupon').on('click', function () {
		var code = $('#bmcCouponInput').val().trim();
		if (!code) {
			return;
		}
		var $btn = $(this);
		loading($btn, true);

		ajax('bmc_apply_coupon', { coupon: code })
			.done(function (res) {
				if (res && res.success) {
					renderSummary(res.data);
					$('#bmcCouponInput').val('');
					alertBox('ok', res.data.message || 'کد تخفیف اعمال شد.');
				} else {
					alertBox('error', (res && res.data && res.data.message) ? res.data.message : 'کد تخفیف معتبر نیست.');
				}
			})
			.fail(function (xhr) {
				alertBox('error', (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ? xhr.responseJSON.data.message : 'خطا در اعمال کد تخفیف.');
			})
			.always(function () {
				loading($btn, false);
			});
	});

	$(document).on('click', '#bmcCouponTags button', function () {
		var code = $(this).data('coupon');
		ajax('bmc_remove_coupon', { coupon: code }).done(function (res) {
			if (res && res.success) {
				renderSummary(res.data);
			}
		});
	});

	$form.on('submit', function (e) {
		e.preventDefault();

		alertBox('', '');

		var $btn = $('#bmcPlaceOrder');

		if ($('#bmcGiftToggle').length && $('#bmcGiftToggle').is(':checked')) {
			var giftPlayer = ($('#bmcGiftPlayer').val() || '').trim();
			if (!/^[A-Za-z0-9_]{3,16}$/.test(giftPlayer)) {
				alertBox('error', bmcCheckout.i18n.fillPlayer + ' (۳ تا ۱۶ کاراکتر انگلیسی)');
				$('#bmcGiftPlayer').trigger('focus');
				return;
			}
		}

		if (!$('input[name="payment_method"]:checked').length) {
			alertBox('error', 'روش پرداخت را انتخاب کنید.');
			return;
		}

		var invalid = null;
		$form.find('input[required], select[required], textarea[required]').each(function () {
			if (!$(this).val()) {
				invalid = this;
				return false;
			}
		});

		if (invalid) {
			var label = $(invalid).closest('.bmc-field').find('.bmc-label').text() || $(invalid).attr('placeholder') || 'فیلد';
			alertBox('error', 'فیلد «' + label.replace('*', '').trim() + '» را تکمیل کنید.');
			$(invalid).trigger('focus');
			return;
		}

		loading($btn, true);
		$btn.find('span:last').text(bmcCheckout.i18n.processing);

		var data = $form.serialize();
		var endpoint = bmcCheckout.wcAjaxUrl ? bmcCheckout.wcAjaxUrl.replace('%%endpoint%%', 'checkout') : '';

		if (!endpoint) {
			alertBox('error', 'آدرس چک‌اوت ووکامرس در دسترس نیست.');
			loading($btn, false);
			return;
		}

		$.ajax({
			type: 'POST',
			url: endpoint,
			data: data,
			dataType: 'json'
		}).done(function (response) {
			if (response && response.result === 'success' && response.redirect) {
				alertBox('ok', 'در حال انتقال به درگاه پرداخت…');
				window.location.href = response.redirect;
				return;
			}

			if (response && response.result === 'failure') {
				var messages = response.messages || bmcCheckout.i18n.error;
				alertBox('error', messages);

				if (response.reload) {
					setTimeout(function () { window.location.reload(); }, 2200);
				}
			} else {
				alertBox('error', bmcCheckout.i18n.error);
			}

			loading($btn, false);
			$btn.find('span:last').text('پرداخت و ثبت سفارش');
		}).fail(function (xhr) {
			var msg = bmcCheckout.i18n.error;

			if (xhr && xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) {
				msg = xhr.responseJSON.data.message;
			}

			alertBox('error', msg);
			loading($btn, false);
			$btn.find('span:last').text('پرداخت و ثبت سفارش');
		});
	});

	ajax('bmc_checkout_summary', {}).done(function (res) {
		if (res && res.success) {
			renderSummary(res.data);
		}
	});
})(jQuery);
