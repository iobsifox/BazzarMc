(function ($) {
	'use strict';

	function ico(name) {
		return window.bmcIcon ? window.bmcIcon(name) : '';
	}


	if (typeof bmcLink === 'undefined') {
		return;
	}

	var POLL_INTERVAL = 3000;
	var timerInterval = null;
	var pollInterval = null;
	var state = window.bmcLinkState || { active: null, commandTemplate: '/mclink {code}' };
	var currentCode = '';
	var expiresAt = 0;
	var totalTtl = 0;

	var $box = $('#bmcLinkBox');
	if (!$box.length) {
		return;
	}

	function alertBox(type, message) {
		var $target = $('#bmcLinkAlert');
		if (!$target.length) {
			return;
		}
		if (!message) {
			$target.html('');
			return;
		}
		var icons = { error: ico('error'), ok: ico('check_circle'), info: ico('info'), warn: ico('warning') };
		$target.html(
			'<div class="bmc-alert bmc-alert--' + type + ' bmc-fade"><span class="bmc-alert__icon">' +
			(icons[type] || ico('info')) + '</span><div>' + message + '</div></div>'
		);
	}

	function loading($btn, on) {
		if (on) {
			$btn.addClass('is-loading').prop('disabled', true);
		} else {
			$btn.removeClass('is-loading').prop('disabled', false);
		}
	}

	function post(action, data) {
		data = $.extend({ action: action, security: bmcLink.nonce }, data || {});
		return $.post(bmcLink.ajaxUrl, data);
	}

	function pad(n) {
		return n < 10 ? '0' + n : '' + n;
	}

	var headTimer = null;
	$('#bmcPlayerInput').on('input', function () {
		var value = $(this).val().trim();
		clearTimeout(headTimer);
		if (value.length < 3) {
			$('#bmcHeadPreview').attr('src', bmcLink.headUrl);
			return;
		}
		headTimer = setTimeout(function () {
			$('#bmcHeadPreview').attr('src', 'https://mc-heads.net/avatar/' + encodeURIComponent(value) + '/48?t=' + Date.now());
		}, 350);
	});

	function startTimer(seconds) {
		totalTtl = seconds;
		expiresAt = Date.now() + seconds * 1000;
		clearInterval(timerInterval);
		tick();
		timerInterval = setInterval(tick, 1000);
	}

	function tick() {
		var left = Math.max(0, Math.floor((expiresAt - Date.now()) / 1000));
		var $timer = $('#bmcTimer');
		var $value = $('#bmcTimerValue');

		$value.text(pad(Math.floor(left / 60)) + ':' + pad(left % 60));

		var pct = totalTtl > 0 ? (left / totalTtl) * 100 : 0;
		$('#bmcProgressBar').css('width', pct + '%');

		if (left <= 60) {
			$timer.addClass('is-urgent');
			$('#bmcCodeValue').addClass('is-urgent');
		} else {
			$timer.removeClass('is-urgent');
			$('#bmcCodeValue').removeClass('is-urgent');
		}

		if (left <= 0) {
			clearInterval(timerInterval);
			clearInterval(pollInterval);
			$('#bmcCodeText').text('——');
			$('#bmcCodePanel').addClass('bmc-hidden');
			$('#bmcLinkForm').removeClass('bmc-hidden');
			alertBox('warn', bmcLink.i18n.expired + ' کد جدید بسازید.');
		}
	}

	function showCode(code, ttl, player) {
		currentCode = code;
		$('#bmcCodeText').text(code);
		$('#bmcCodePanel').removeClass('bmc-hidden').addClass('bmc-fade');
		$('#bmcLinkForm').addClass('bmc-hidden');
		$('#bmcCommandText code').text(state.commandTemplate.replace('{code}', code).replace('{player}', player || ''));
		startTimer(ttl);
		startPolling();
	}

	function startPolling() {
		clearInterval(pollInterval);
		pollInterval = setInterval(function () {
			post('bmc_code_state', {}).done(function (res) {
				if (!res || !res.success) {
					return;
				}
				if (res.data.state === 'linked') {
					clearInterval(pollInterval);
					clearInterval(timerInterval);
					onLinked(res.data.player);
				}
			});
		}, POLL_INTERVAL);
	}

	function onLinked(player) {
		alertBox('ok', '<strong>' + bmcLink.i18n.connected + '</strong> اکانت «' + player + '» با موفقیت متصل شد. صفحه در حال بارگذاری مجدد…');
		setTimeout(function () {
			window.location.reload();
		}, 1600);
	}

	function generateCode(player, $btn) {
		alertBox('', '');
		loading($btn, true);

		post('bmc_generate_code', { player: player })
			.done(function (res) {
				if (res && res.success) {
					showCode(res.data.code, res.data.expires_in || res.data.ttl, res.data.player);
				} else {
					var msg = (res && res.data && res.data.message) ? res.data.message : 'خطا در ساخت کد.';
					alertBox('error', msg);
					$('#bmcLinkForm').removeClass('bmc-hidden').addClass('bmc-shake');
					setTimeout(function () { $('#bmcLinkForm').removeClass('bmc-shake'); }, 600);
				}
			})
			.fail(function (xhr) {
				var msg = (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ? xhr.responseJSON.data.message : 'خطای ارتباط با سرور.';
				alertBox('error', msg);
			})
			.always(function () {
				loading($btn, false);
			});
	}

	$('#bmcLinkForm').on('submit', function (e) {
		e.preventDefault();
		var player = $('#bmcPlayerInput').val().trim();
		if (!player) {
			alertBox('error', 'نام کاربری ماینکرافت را وارد کنید.');
			return;
		}
		generateCode(player, $('#bmcGenerateBtn'));
	});

	$('#bmcRegenerateBtn').on('click', function () {
		var player = (state.active && state.active.player) ? state.active.player : $('#bmcPlayerInput').val().trim();
		if (!player) {
			$('#bmcCodePanel').addClass('bmc-hidden');
			$('#bmcLinkForm').removeClass('bmc-hidden');
			return;
		}
		generateCode(player, $('#bmcRegenerateBtn'));
	});

	$('#bmcCopyBtn').on('click', function () {
		var text = currentCode;
		if (!text) {
			return;
		}
		var done = function () {
			var $btn = $('#bmcCopyBtn');
			$btn.html(ico('check') + ' ' + bmcLink.i18n.copied);
			setTimeout(function () { $btn.html(ico('content_paste') + ' کپی کد'); }, 1800);
		};

		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(text).then(done).catch(function () { fallbackCopy(text, done); });
		} else {
			fallbackCopy(text, done);
		}
	});

	function fallbackCopy(text, cb) {
		var $tmp = $('<input>').val(text).css({ position: 'fixed', top: '-1000px', opacity: 0 }).appendTo('body');
		$tmp[0].select();
		try {
			document.execCommand('copy');
			cb();
		} catch (err) {
			alertBox('warn', bmcLink.i18n.copyError);
		}
		$tmp.remove();
	}

	$('#bmcUnlinkBtn').on('click', function () {
		if (!window.confirm(bmcLink.i18n.confirmUnlink)) {
			return;
		}
		var $btn = $(this);
		loading($btn, true);
		post('bmc_unlink', {}).done(function (res) {
			if (res && res.success) {
				window.location.reload();
			}
		}).fail(function () {
			loading($btn, false);
		});
	});

	var otpChannel = '';
	var otpDelivery = '';

	$('.bmc-otp-channel').on('click', function () {
		otpChannel = $(this).data('channel');
		otpDelivery = $(this).data('delivery') || '';
		var $btn = $(this);
		loading($btn, true);
		$('#bmcOtpAlert').html('');

		var player = $('#bmcOtpPlayer').val().trim();
		if (!player) {
			loading($btn, false);
			$('#bmcOtpAlert').html('<div class="bmc-alert bmc-alert--error"><span class="bmc-alert__icon">' + ico('warning') + '</span><div>ابتدا نام کاربری ماینکرافت را وارد کنید.</div></div>');
			return;
		}

		$.post(bmcLink.ajaxUrl, {
			action: 'bmc_request_link_otp',
			security: bmcLink.nonce,
			identifier_type: otpChannel,
			channel: otpDelivery,
			player: player
		}).done(function (res) {
			if (res && res.success) {
				$('#bmcOtpCodeField').removeClass('bmc-hidden');
				$('#bmcOtpSubmit').removeClass('bmc-hidden');
				if (res.data.channel === 'dashboard' && res.data.code) {
					$('#bmcOtpHint').text('کد در داشبورد و پنل کاربری شما نمایش داده شد؛ همین‌جا هم پر شده است.');
					$('#bmcOtpCode').val(res.data.code);
					$('#bmcDashCodeInline').text(res.data.code);
				} else {
					$('#bmcOtpHint').text('کد از راه ' + (res.data.channel === 'email' ? 'ایمیل' : 'پیامک') + ' به ' + (res.data.masked || 'شما') + ' ارسال شد.');
					$('#bmcOtpCode').trigger('focus');
				}
			} else {
				var msg = (res && res.data && res.data.message) ? res.data.message : 'ارسال کد ناموفق بود.';
				$('#bmcOtpAlert').html('<div class="bmc-alert bmc-alert--error"><span class="bmc-alert__icon">' + ico('warning') + '</span><div>' + msg + '</div></div>');
			}
		}).always(function () {
			loading($btn, false);
		});
	});

	$('#bmcOtpLinkForm').on('submit', function (e) {
		e.preventDefault();
		var code = $('#bmcOtpCode').val().trim();
		if (!code || !otpChannel) {
			return;
		}

		var $btn = $('#bmcOtpSubmit');
		loading($btn, true);

		$.post(bmcLink.ajaxUrl, {
			action: 'bmc_verify_link_otp',
			security: bmcLink.nonce,
			identifier_type: otpChannel,
			code: code
		}).done(function (res) {
			if (res && res.success) {
				onLinked(res.data.player || '');
			} else {
				var msg = (res && res.data && res.data.message) ? res.data.message : 'کد نامعتبر است.';
				$('#bmcOtpAlert').html('<div class="bmc-alert bmc-alert--error"><span class="bmc-alert__icon">' + ico('warning') + '</span><div>' + msg + '</div></div>');
			}
		}).always(function () {
			loading($btn, false);
		});
	});

	if (state.active && state.active.expires_in > 0) {
		$('#bmcCodePanel').removeClass('bmc-hidden');

		if (state.active.code_plain) {
			currentCode = state.active.code_plain;
			$('#bmcCodeText').text(currentCode);
			$('#bmcCommandText code').text(state.commandTemplate.replace('{code}', currentCode).replace('{player}', state.active.player || ''));
		} else {
			$('#bmcCodeText').text('کد فعال');
			$('#bmcCommandText code').text(state.commandTemplate.replace('{code}', '****'));
			$('#bmcCopyBtn').prop('disabled', true).attr('title', 'برای دیدن کد، روی «کد جدید» بزنید');
		}

		startTimer(state.active.expires_in);
		startPolling();
	}
})(jQuery);
