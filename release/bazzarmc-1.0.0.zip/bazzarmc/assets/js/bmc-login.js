(function ($) {
	'use strict';

	if (typeof bmcLogin === 'undefined') {
		return;
	}

	var $wrap = $('#bmcLoginWrap');
	if (!$wrap.length) {
		return;
	}

	var otpLength = parseInt($wrap.data('otp-length'), 10) || 5;
	var otpTtl = parseInt($wrap.data('otp-ttl'), 10) || 120;
	var redirect = $wrap.data('redirect') || '';
	var mobile = '';
	var resendTimer = null;

	var FA = ['۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹'];

	function toEn(str) {
		for (var i = 0; i < 10; i++) {
			str = str.split(FA[i]).join(i);
		}
		return str;
	}

	function alertBox(type, message) {
		var icons = { error: '⚠️', ok: '✅', info: 'ℹ️', warn: '⚠️' };
		if (!message) {
			$('#bmcLoginAlert').html('');
			return;
		}
		$('#bmcLoginAlert').html(
			'<div class="bmc-alert bmc-alert--' + type + ' bmc-fade"><span class="bmc-alert__icon">' +
			(icons[type] || 'ℹ️') + '</span><div>' + message + '</div></div>'
		);
	}

	function loading($btn, on) {
		if (on) {
			$btn.addClass('is-loading').prop('disabled', true);
		} else {
			$btn.removeClass('is-loading').prop('disabled', false);
		}
	}

	function post(action, data) {
		return $.post(bmcLogin.ajaxUrl, $.extend({ action: action, security: bmcLogin.nonce, redirect_to: redirect }, data || {}));
	}

	function currentChannel() {
		var $checked = $('.bmc-channels input[name="bmc_channel"]:checked');

		return $checked.length ? $checked.val() : ($('.bmc-channels').length ? '' : '');
	}

	$(document).on('change', '.bmc-channels input[name="bmc_channel"]', function () {
		$('.bmc-channel').removeClass('is-active');
		$(this).closest('.bmc-channel').addClass('is-active');

		var hint = '';

		if ($(this).val() === 'dashboard') {
			hint = 'کد به‌جای پیامک، در داشبورد و پنل کاربری شما نمایش داده می‌شود (نیازمند ورود).';
		} else if ($(this).val() === 'email') {
			hint = 'کد به ایمیل ثبت‌شده در حساب شما ارسال می‌شود.';
		} else {
			hint = 'کد تأیید به این شماره پیامک می‌شود.';
		}

		$('.bmc-channel-hint').text(hint);
	});

	$('#bmcMobileInput').on('input', function () {
		this.value = toEn(this.value).replace(/[^0-9+]/g, '');
	});

	$('#bmcLoginStep1').on('submit', function (e) {
		e.preventDefault();

		mobile = toEn($('#bmcMobileInput').val().trim());

		if (!/^0?9\d{9}$/.test(mobile) && !/^\+?989\d{9}$/.test(mobile)) {
			alertBox('error', 'شمارهٔ موبایل را کامل و درست وارد کنید. مثال: ۰۹۱۲۳۴۵۶۷۸۹');
			$('#bmcLoginStep1').addClass('bmc-shake');
			setTimeout(function () { $('#bmcLoginStep1').removeClass('bmc-shake'); }, 600);
			return;
		}

		var $btn = $('#bmcSendCodeBtn');
		loading($btn, true);
		alertBox('', '');

		post('bmc_login_request', { mobile: mobile, channel: currentChannel() })
			.done(function (res) {
				if (res && res.success) {
					gotoStep2(res.data);
				} else {
					var msg = (res && res.data && res.data.message) ? res.data.message : 'ارسال کد ناموفق بود.';
					alertBox('error', msg);
				}
			})
			.fail(function (xhr) {
				var msg = (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ? xhr.responseJSON.data.message : 'خطای ارتباط با سرور.';
				alertBox('error', msg);
			})
			.always(function () {
				loading($btn, false);
			});
	});

	function gotoStep2(data) {
		$('#bmcLoginStep1').addClass('bmc-hidden');
		$('#bmcLoginStep2').removeClass('bmc-hidden').addClass('bmc-fade');
		$('#bmcMaskedMobile').text(data.masked || mobile);

		if (data.is_new) {
			alertBox('info', 'حساب کاربری جدیدی برای این شماره ساخته می‌شود.');
		}
		if (data.channel === 'email') {
			alertBox('info', 'کد تأیید به ایمیل حساب شما فرستاده شد.');
		}

		if (data.channel === 'dashboard') {
			alertBox('info', 'کد تأیید در داشبورد و پنل کاربری شما نمایش داده شد.');

			if (data.code) {
				fillBoxes(String(data.code));
			}
		}

		clearBoxes();
		$('#bmcOtpBoxes input').first().trigger('focus');
		startResendTimer(data.expires_in || otpTtl);
	}

	function startResendTimer(seconds) {
		clearInterval(resendTimer);
		var left = seconds;
		updateResend(left);

		resendTimer = setInterval(function () {
			left--;
			updateResend(left);
			if (left <= 0) {
				clearInterval(resendTimer);
			}
		}, 1000);
	}

	function updateResend(left) {
		var $btn = $('#bmcResendBtn');
		if (left > 0) {
			$btn.prop('disabled', true).text('ارسال مجدد کد (' + left + ')');
			$('#bmcResendTimer').text('تا ارسال مجدد کد:');
		} else {
			$btn.prop('disabled', false).text('ارسال مجدد کد');
			$('#bmcResendTimer').text('کد را دریافت نکردید؟');
		}
	}

	$('#bmcResendBtn').on('click', function () {
		var $btn = $(this);
		$btn.prop('disabled', true);
		post('bmc_login_request', { mobile: mobile, resend: 1 })
			.done(function (res) {
				if (res && res.success) {
					clearBoxes();
					startResendTimer(res.data.expires_in || otpTtl);
					alertBox('ok', 'کد مجدداً ارسال شد.');
				} else {
					var msg = (res && res.data && res.data.message) ? res.data.message : 'ارسال مجدد ناموفق بود.';
					alertBox('error', msg);
					$btn.prop('disabled', false);
				}
			})
			.fail(function () {
				alertBox('error', 'ارسال مجدد ناموفق بود.');
				$btn.prop('disabled', false);
			});
	});

	function clearBoxes() {
		$('#bmcOtpBoxes input').val('').removeClass('is-filled');
	}

	function fillBoxes(code) {
		var digits = String(code).replace(/[^0-9]/g, '').split('');

		$('#bmcOtpBoxes input').each(function (index) {
			var value = digits[index] || '';
			this.value = value;
			$(this).toggleClass('is-filled', value !== '');
		});
	}

	function readCode() {
		var code = '';
		$('#bmcOtpBoxes input').each(function () {
			code += $(this).val();
		});
		return code;
	}

	$('#bmcOtpBoxes').on('input', 'input', function () {
		this.value = toEn(this.value).replace(/[^0-9]/g, '').slice(0, 1);
		$(this).toggleClass('is-filled', this.value !== '');

		if (this.value) {
			var $next = $(this).next('input');
			if ($next.length) {
				$next.trigger('focus');
			} else if (readCode().length === otpLength) {
				$('#bmcLoginStep2').trigger('submit');
			}
		}
	});

	$('#bmcOtpBoxes').on('keydown', 'input', function (e) {
		if (e.key === 'Backspace' && !this.value) {
			$(this).prev('input').trigger('focus').val('').removeClass('is-filled');
		}
		if (e.key === 'ArrowLeft') {
			$(this).next('input').trigger('focus');
		}
		if (e.key === 'ArrowRight') {
			$(this).prev('input').trigger('focus');
		}
	});

	$('#bmcOtpBoxes').on('paste', 'input', function (e) {
		var text = toEn((e.originalEvent.clipboardData || window.clipboardData).getData('text') || '');
		var digits = text.replace(/[^0-9]/g, '').slice(0, otpLength);

		if (digits.length) {
			e.preventDefault();
			$('#bmcOtpBoxes input').each(function (i) {
				$(this).val(digits[i] || '').toggleClass('is-filled', Boolean(digits[i]));
			});
			if (digits.length === otpLength) {
				$('#bmcLoginStep2').trigger('submit');
			}
		}
	});

	$('#bmcChangeMobile').on('click', function () {
		clearInterval(resendTimer);
		$('#bmcLoginStep2').addClass('bmc-hidden');
		$('#bmcLoginStep1').removeClass('bmc-hidden');
		alertBox('', '');
		$('#bmcMobileInput').trigger('focus');
	});

	$('#bmcLoginStep2').on('submit', function (e) {
		e.preventDefault();

		var code = readCode();

		if (code.length !== otpLength) {
			alertBox('error', 'کد ' + otpLength + ' رقمی را کامل وارد کنید.');
			return;
		}

		var $btn = $('#bmcVerifyBtn');
		loading($btn, true);
		alertBox('', '');

		post('bmc_login_verify', { mobile: mobile, code: code })
			.done(function (res) {
				if (res && res.success) {
					alertBox('ok', res.data.message || 'ورود موفق بود.');
					window.location.href = (res.data.redirect || redirect || window.location.href);
				} else {
					var msg = (res && res.data && res.data.message) ? res.data.message : 'کد نامعتبر است.';
					alertBox('error', msg);
					clearBoxes();
					$('#bmcOtpBoxes input').first().trigger('focus');
					loading($btn, false);
				}
			})
			.fail(function (xhr) {
				var msg = (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ? xhr.responseJSON.data.message : 'خطا در ورود.';
				alertBox('error', msg);
				clearBoxes();
				loading($btn, false);
			});
	});
})(jQuery);
