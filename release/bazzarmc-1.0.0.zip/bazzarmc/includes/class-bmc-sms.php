<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_SMS {

	private static $drivers = null;

	public static function drivers() {
		if ( null === self::$drivers ) {
			self::$drivers = array(
				'melipayamak' => new BMC_SMS_Melipayamak(),
				'ezlogin'     => new BMC_SMS_EZLogin(),
				'email'       => new BMC_SMS_Email(),
			);

			self::$drivers = apply_filters( 'bmc_sms_drivers', self::$drivers );
		}

		return self::$drivers;
	}

	public static function driver( $id ) {
		$drivers = self::drivers();
		return isset( $drivers[ $id ] ) ? $drivers[ $id ] : null;
	}

	public static function active_sms_driver() {
		$id = (string) BMC_Settings::get( 'sms_driver', 'melipayamak' );

		if ( 'none' === $id || ! BMC_Settings::bool( 'sms_enabled', true ) ) {
			return null;
		}

		$driver = self::driver( $id );

		if ( $driver && $driver->is_configured() ) {
			return $driver;
		}

		if ( 'ezlogin' !== $id && class_exists( 'BMC_EZLogin' ) && BMC_EZLogin::is_bridged() ) {
			$bridge = self::driver( 'ezlogin' );

			if ( $bridge && $bridge->is_configured() ) {
				return $bridge;
			}
		}

		return $driver;
	}

	public static function is_ready() {
		$driver = self::active_sms_driver();
		return $driver && $driver->is_configured();
	}

	public static function send_code( $channel, $to, $code, array $context = array() ) {
		if ( ! isset( $context['minutes'] ) ) {
			$ttl                = BMC_Settings::int( 'sms_otp_ttl', 120, 30, 900 );
			$context['minutes'] = BMC_Helpers::to_persian_digits( max( 1, (int) ceil( $ttl / 60 ) ) );
		}

		if ( 'mobile' === $channel ) {
			$driver = self::active_sms_driver();

			if ( ! $driver ) {
				$fallback = self::email_fallback( $to, $code, $context );
				if ( $fallback ) {
					return $fallback;
				}
				return array(
					'success' => false,
					'channel' => 'none',
					'message' => 'ارسال پیامک غیرفعال است.',
				);
			}

			$result = $driver->send_code( $to, $code, $context );

			if ( ! empty( $result['success'] ) ) {
				return array(
					'success' => true,
					'channel' => 'sms',
					'driver'  => $driver->get_id(),
					'message' => 'کد تأیید پیامک شد.',
				);
			}

			BMC_Logger::add( 'sms', 'ارسال پیامک ناموفق: ' . $result['message'], array( 'to' => $to ), 'error' );

			$fallback = self::email_fallback( $to, $code, $context );
			if ( $fallback ) {
				return $fallback;
			}

			return array(
				'success' => false,
				'channel' => 'sms',
				'message' => $result['message'],
			);
		}

		$email_driver = self::driver( 'email' );

		if ( ! BMC_Settings::bool( 'email_enabled', true ) || ! $email_driver ) {
			return array(
				'success' => false,
				'channel' => 'none',
				'message' => 'ارسال ایمیل غیرفعال است.',
			);
		}

		$result = $email_driver->send_code( $to, $code, $context );

		return array(
			'success' => ! empty( $result['success'] ),
			'channel' => 'email',
			'message' => $result['message'],
		);
	}

	private static function email_fallback( $mobile, $code, array $context ) {
		if ( ! BMC_Settings::bool( 'sms_fallback_email', true ) ) {
			return null;
		}

		$user = class_exists( 'BMC_Auth' ) ? BMC_Auth::find_user_by_mobile( $mobile ) : null;

		if ( ! $user ) {
			$user_id = isset( $context['user'] ) && is_object( $context['user'] ) ? (int) $context['user']->ID : 0;
			$user    = $user_id ? get_userdata( $user_id ) : null;
		}

		if ( ! $user || ! $user->user_email ) {
			return null;
		}

		$driver = self::driver( 'email' );
		if ( ! $driver ) {
			return null;
		}

		$result = $driver->send_code( $user->user_email, $code, $context );

		if ( empty( $result['success'] ) ) {
			return null;
		}

		BMC_Logger::add( 'sms', 'ارسال کد از طریق ایمیل (جایگزین پیامک) به ' . $user->user_email, array(), 'warning' );

		return array(
			'success'  => true,
			'channel'  => 'email',
			'message'  => 'کد تأیید به ایمیل حساب شما ارسال شد.',
			'fallback' => true,
		);
	}

	public static function send_text( $to, $text ) {
		$driver = self::active_sms_driver();

		if ( ! $driver ) {
			return array(
				'success' => false,
				'message' => 'ارسال پیامک غیرفعال است.',
			);
		}

		return $driver->send_text( $to, $text );
	}

	public static function test( $to ) {
		$to = BMC_Helpers::normalize_mobile( $to );

		if ( ! $to ) {
			return array(
				'success' => false,
				'message' => 'شمارهٔ موبایل نامعتبر است.',
			);
		}

		$code = BMC_Helpers::random_otp( BMC_Settings::int( 'sms_otp_length', 5, 4, 8 ) );

		return self::send_code(
			'mobile',
			$to,
			$code,
			array(
				'type'    => 'login',
				'minutes' => BMC_Helpers::to_persian_digits( 2 ),
			)
		);
	}

	public static function status() {
		$out = array();

		foreach ( self::drivers() as $id => $driver ) {
			$out[ $id ] = array(
				'label'      => $driver->get_label(),
				'configured' => $driver->is_configured(),
			);
		}

		return $out;
	}
}
