<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Roles {

	const META = 'bmc_role_grants';

	public static function init() {
		add_action( 'bmc_maintenance', array( __CLASS__, 'expire_due' ) );
	}

	public static function duration_days( $product_id ) {
		$durations = (array) BMC_Settings::get( 'product_role_duration', array() );
		$pid       = absint( $product_id );

		if ( $pid && isset( $durations[ $pid ] ) && '' !== $durations[ $pid ] && null !== $durations[ $pid ] ) {
			return max( 0, (int) $durations[ $pid ] );
		}

		return max( 0, (int) BMC_Settings::get( 'role_duration_default', 0 ) );
	}

	public static function role_label( $role ) {
		$role  = (string) $role;
		$names = function_exists( 'wp_roles' ) ? (array) wp_roles()->role_names : array();

		if ( isset( $names[ $role ] ) ) {
			return translate_user_role( $names[ $role ] );
		}

		return $role;
	}

	public static function protected_roles() {
		return array( 'administrator', 'shop_manager', 'editor', 'author' );
	}

	public static function grants( $user_id ) {
		$user_id = absint( $user_id );

		if ( ! $user_id ) {
			return array();
		}

		$grants = get_user_meta( $user_id, self::META, true );

		return is_array( $grants ) ? array_values( $grants ) : array();
	}

	public static function record_grant( $user_id, $role, array $args = array() ) {
		$user_id = absint( $user_id );
		$role    = sanitize_text_field( (string) $role );

		if ( ! $user_id || '' === $role || ! function_exists( 'wp_roles' ) || ! array_key_exists( $role, wp_roles()->roles ) ) {
			return null;
		}

		$product_id   = absint( isset( $args['product_id'] ) ? $args['product_id'] : 0 );
		$variation_id = absint( isset( $args['variation_id'] ) ? $args['variation_id'] : 0 );
		$order_id     = absint( isset( $args['order_id'] ) ? $args['order_id'] : 0 );
		$label        = sanitize_text_field( (string) ( isset( $args['label'] ) ? $args['label'] : '' ) );
		$source       = sanitize_key( (string) ( isset( $args['source'] ) ? $args['source'] : 'order' ) );
		$days         = isset( $args['days'] ) ? max( 0, (int) $args['days'] ) : self::duration_days( $variation_id ? $variation_id : $product_id );

		if ( '' === $label ) {
			$label = self::role_label( $role );
		}

		$grants  = self::grants( $user_id );
		$now     = BMC_Helpers::now_timestamp();
		$match   = null;
		$match_i = -1;

		foreach ( $grants as $i => $grant ) {
			if ( isset( $grant['role'] ) && $grant['role'] === $role
				&& absint( isset( $grant['product_id'] ) ? $grant['product_id'] : 0 ) === $product_id
				&& empty( $grant['revoked_at'] ) ) {
				$match   = $grant;
				$match_i = $i;
			}
		}

		$base = $now;

		if ( is_array( $match ) && ! empty( $match['expires_at'] ) ) {
			$existing = strtotime( (string) $match['expires_at'] );

			if ( $existing && $existing > $now ) {
				$base = $existing;
			}
		}

		$record = array(
			'role'         => $role,
			'product_id'   => $product_id,
			'variation_id' => $variation_id,
			'order_id'     => $order_id,
			'label'        => $label,
			'source'       => $source,
			'days'         => $days,
			'granted_at'   => is_array( $match ) && ! empty( $match['granted_at'] ) ? (string) $match['granted_at'] : BMC_Helpers::local_datetime( $now ),
			'expires_at'   => $days > 0 ? BMC_Helpers::local_datetime( $base + ( $days * DAY_IN_SECONDS ) ) : '',
			'revoked_at'   => '',
		);

		if ( $match_i >= 0 ) {
			$grants[ $match_i ] = $record;
		} else {
			$grants[] = $record;
		}

		update_user_meta( $user_id, self::META, $grants );

		BMC_Logger::add(
			'role',
			sprintf(
				'نقش «%s» برای کاربر #%d ثبت شد%s',
				$record['label'],
				$user_id,
				$record['expires_at'] ? ' تا ' . $record['expires_at'] : ' (دائمی)'
			),
			array( 'order_id' => $order_id, 'product_id' => $product_id ),
			'info'
		);

		return $record;
	}

	public static function active_grants( $user_id ) {
		$now    = BMC_Helpers::now_timestamp();
		$out    = array();
		$changed = false;

		foreach ( self::grants( $user_id ) as $grant ) {
			if ( ! is_array( $grant ) || ! empty( $grant['revoked_at'] ) ) {
				continue;
			}

			$remaining = 0;
			$permanent = empty( $grant['expires_at'] );

			if ( ! $permanent ) {
				$expires = strtotime( (string) $grant['expires_at'] );

				if ( ! $expires ) {
					$permanent = true;
				} else {
					$remaining = $expires - $now;

					if ( $remaining <= 0 ) {
						$changed = true;
						continue;
					}
				}
			}

			$grant['permanent']         = $permanent;
			$grant['remaining']         = max( 0, $remaining );
			$grant['remaining_human']   = $permanent ? 'دائمی' : self::human_duration( $remaining );
			$grant['expires_jalali']    = $permanent ? '' : BMC_Jalali::format( $grant['expires_at'], false );
			$grant['role_label']        = self::role_label( isset( $grant['role'] ) ? $grant['role'] : '' );
			$grant['still_has_role']    = self::user_has_role( $user_id, isset( $grant['role'] ) ? $grant['role'] : '' );

			$out[] = $grant;
		}

		if ( $changed ) {
			self::expire_due_for_user( $user_id );
			return self::active_grants_raw( $user_id );
		}

		usort(
			$out,
			function ( $a, $b ) {
				if ( ! empty( $a['permanent'] ) && empty( $b['permanent'] ) ) {
					return -1;
				}

				if ( empty( $a['permanent'] ) && ! empty( $b['permanent'] ) ) {
					return 1;
				}

				return (int) $b['remaining'] - (int) $a['remaining'];
			}
		);

		return $out;
	}

	private static function active_grants_raw( $user_id ) {
		$now = BMC_Helpers::now_timestamp();
		$out = array();

		foreach ( self::grants( $user_id ) as $grant ) {
			if ( ! is_array( $grant ) || ! empty( $grant['revoked_at'] ) ) {
				continue;
			}

			$permanent = empty( $grant['expires_at'] );
			$remaining = 0;

			if ( ! $permanent ) {
				$expires = strtotime( (string) $grant['expires_at'] );

				if ( $expires ) {
					$remaining = $expires - $now;

					if ( $remaining <= 0 ) {
						continue;
					}
				} else {
					$permanent = true;
				}
			}

			$grant['permanent']       = $permanent;
			$grant['remaining']       = max( 0, $remaining );
			$grant['remaining_human'] = $permanent ? 'دائمی' : self::human_duration( $remaining );
			$grant['expires_jalali']  = $permanent ? '' : BMC_Jalali::format( $grant['expires_at'], false );
			$grant['role_label']      = self::role_label( isset( $grant['role'] ) ? $grant['role'] : '' );
			$grant['still_has_role']  = self::user_has_role( $user_id, isset( $grant['role'] ) ? $grant['role'] : '' );

			$out[] = $grant;
		}

		return $out;
	}

	public static function user_has_role( $user_id, $role ) {
		$role = (string) $role;

		if ( '' === $role ) {
			return false;
		}

		$user = new WP_User( absint( $user_id ) );

		return $user->exists() && in_array( $role, (array) $user->roles, true );
	}

	public static function expire_due() {
		$revoked = 0;

		if ( ! class_exists( 'WP_User_Query' ) ) {
			return 0;
		}

		$query = new WP_User_Query(
			array(
				'fields'      => 'ID',
				'number'      => 500,
				'count_total' => false,
				'meta_key'    => self::META, // phpcs:ignore WordPress.DB.SlowDBQuery
			)
		);

		foreach ( (array) $query->get_results() as $user_id ) {
			$revoked += self::expire_due_for_user( absint( $user_id ) );
		}

		return $revoked;
	}

	public static function expire_due_for_user( $user_id ) {
		$user_id = absint( $user_id );

		if ( ! $user_id ) {
			return 0;
		}

		$grants  = self::grants( $user_id );
		$now     = BMC_Helpers::now_timestamp();
		$revoked = 0;
		$dirty   = false;

		foreach ( $grants as $i => $grant ) {
			if ( ! is_array( $grant ) || ! empty( $grant['revoked_at'] ) || empty( $grant['expires_at'] ) ) {
				continue;
			}

			$expires = strtotime( (string) $grant['expires_at'] );

			if ( ! $expires || $expires > $now ) {
				continue;
			}

			$role = isset( $grant['role'] ) ? (string) $grant['role'] : '';

			$grants[ $i ]['revoked_at'] = BMC_Helpers::local_datetime( $now );
			$dirty                      = true;
			$revoked                   += self::maybe_remove_role( $user_id, $role, $grants );
		}

		if ( $dirty ) {
			update_user_meta( $user_id, self::META, $grants );
		}

		return $revoked;
	}

	private static function maybe_remove_role( $user_id, $role, array $grants = array() ) {
		$role = (string) $role;

		if ( '' === $role || in_array( $role, self::protected_roles(), true ) ) {
			return 0;
		}

		if ( ! self::user_has_role( $user_id, $role ) ) {
			return 0;
		}

		$now = BMC_Helpers::now_timestamp();

		foreach ( $grants as $grant ) {
			if ( ! is_array( $grant ) || ! empty( $grant['revoked_at'] ) ) {
				continue;
			}

			if ( ! isset( $grant['role'] ) || $grant['role'] !== $role ) {
				continue;
			}

			if ( empty( $grant['expires_at'] ) ) {
				return 0;
			}

			$expires = strtotime( (string) $grant['expires_at'] );

			if ( $expires && $expires > $now ) {
				return 0;
			}
		}

		$user = new WP_User( $user_id );

		if ( $user->exists() ) {
			$user->remove_role( $role );

			BMC_Logger::add(
				'role',
				sprintf( 'نقش «%s» کاربر #%d به پایان اعتبار رسید و حذف شد.', self::role_label( $role ), $user_id ),
				array(),
				'warning'
			);

			do_action( 'bmc_role_expired', $user_id, $role );

			return 1;
		}

		return 0;
	}

	public static function revoke_for_order( $order_id ) {
		$order_id = absint( $order_id );

		if ( ! $order_id || ! class_exists( 'WP_User_Query' ) ) {
			return 0;
		}

		$query = new WP_User_Query(
			array(
				'fields'      => 'ID',
				'number'      => 500,
				'count_total' => false,
				'meta_key'    => self::META, // phpcs:ignore WordPress.DB.SlowDBQuery
			)
		);

		$removed = 0;

		foreach ( (array) $query->get_results() as $user_id ) {
			$user_id = absint( $user_id );
			$grants  = self::grants( $user_id );
			$dirty   = false;

			foreach ( $grants as $i => $grant ) {
				if ( ! is_array( $grant ) || ! empty( $grant['revoked_at'] ) ) {
					continue;
				}

				if ( absint( isset( $grant['order_id'] ) ? $grant['order_id'] : 0 ) !== $order_id ) {
					continue;
				}

				$grants[ $i ]['revoked_at'] = BMC_Helpers::local_datetime();
				$dirty                      = true;
				$removed                   += self::maybe_remove_role( $user_id, isset( $grant['role'] ) ? (string) $grant['role'] : '', $grants );
			}

			if ( $dirty ) {
				update_user_meta( $user_id, self::META, $grants );
			}
		}

		return $removed;
	}

	public static function human_duration( $seconds ) {
		$seconds = max( 0, (int) $seconds );
		$days    = (int) floor( $seconds / DAY_IN_SECONDS );
		$hours   = (int) floor( ( $seconds % DAY_IN_SECONDS ) / HOUR_IN_SECONDS );
		$minutes = (int) floor( ( $seconds % HOUR_IN_SECONDS ) / MINUTE_IN_SECONDS );

		$parts = array();

		if ( $days > 0 ) {
			$parts[] = BMC_Helpers::to_persian_digits( $days ) . ' روز';
		}

		if ( $hours > 0 ) {
			$parts[] = BMC_Helpers::to_persian_digits( $hours ) . ' ساعت';
		}

		if ( empty( $parts ) && $minutes > 0 ) {
			$parts[] = BMC_Helpers::to_persian_digits( $minutes ) . ' دقیقه';
		}

		if ( empty( $parts ) ) {
			$parts[] = 'کمتر از یک دقیقه';
		}

		return implode( ' و ', array_slice( $parts, 0, 2 ) );
	}
}
