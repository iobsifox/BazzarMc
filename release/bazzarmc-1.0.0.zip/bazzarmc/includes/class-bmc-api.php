<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_API {

	public static function init() {
		add_action( 'rest_api_init', array( __CLASS__, 'register_routes' ) );
		add_filter( 'rest_pre_dispatch', array( __CLASS__, 'no_cache_headers' ), 10, 3 );
	}

	public static function register_routes() {
		register_rest_route(
			BMC_REST_NS,
			'/ping',
			array(
				'methods'             => array( 'GET', 'POST' ),
				'callback'            => array( __CLASS__, 'endpoint_ping' ),
				'permission_callback' => array( __CLASS__, 'auth' ),
			)
		);

		register_rest_route(
			BMC_REST_NS,
			'/link/redeem',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'endpoint_link_redeem' ),
				'permission_callback' => array( __CLASS__, 'auth' ),
			)
		);

		register_rest_route(
			BMC_REST_NS,
			'/link/request',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'endpoint_link_request' ),
				'permission_callback' => array( __CLASS__, 'auth' ),
			)
		);

		register_rest_route(
			BMC_REST_NS,
			'/link/verify',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'endpoint_link_verify' ),
				'permission_callback' => array( __CLASS__, 'auth' ),
			)
		);

		register_rest_route(
			BMC_REST_NS,
			'/player',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'endpoint_player' ),
				'permission_callback' => array( __CLASS__, 'auth' ),
			)
		);

		register_rest_route(
			BMC_REST_NS,
			'/deliveries',
			array(
				'methods'             => 'GET',
				'callback'            => array( __CLASS__, 'endpoint_deliveries' ),
				'permission_callback' => array( __CLASS__, 'auth' ),
			)
		);

		register_rest_route(
			BMC_REST_NS,
			'/deliveries/mark',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'endpoint_mark_delivered' ),
				'permission_callback' => array( __CLASS__, 'auth' ),
			)
		);

		register_rest_route(
			BMC_REST_NS,
			'/unlink',
			array(
				'methods'             => 'POST',
				'callback'            => array( __CLASS__, 'endpoint_unlink' ),
				'permission_callback' => array( __CLASS__, 'auth' ),
			)
		);

		if ( BMC_Settings::bool( 'legacy_compat', false ) ) {
			register_rest_route(
				BMC_LEGACY_REST_NS,
				'/request-link',
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'legacy_request_link' ),
					'permission_callback' => array( __CLASS__, 'auth' ),
				)
			);
			register_rest_route(
				BMC_LEGACY_REST_NS,
				'/verify-link',
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'legacy_verify_link' ),
					'permission_callback' => array( __CLASS__, 'auth' ),
				)
			);
			register_rest_route(
				BMC_LEGACY_REST_NS,
				'/pending',
				array(
					'methods'             => 'GET',
					'callback'            => array( __CLASS__, 'legacy_pending' ),
					'permission_callback' => array( __CLASS__, 'auth' ),
				)
			);
			register_rest_route(
				BMC_LEGACY_REST_NS,
				'/mark-delivered',
				array(
					'methods'             => 'POST',
					'callback'            => array( __CLASS__, 'legacy_mark_delivered' ),
					'permission_callback' => array( __CLASS__, 'auth' ),
				)
			);
		}
	}

	public static function auth( $request ) {
		$stored = BMC_Settings::api_token();

		$provided = $request->get_header( 'X_BMC_Token' );
		if ( ! $provided ) {
			$provided = $request->get_param( 'token' );
		}
		if ( ! $provided ) {
			$provided = $request->get_header( 'Authorization' );
			if ( $provided && 0 === stripos( $provided, 'Bearer ' ) ) {
				$provided = trim( substr( $provided, 7 ) );
			}
		}

		$provided = sanitize_text_field( (string) $provided );

		if ( ! $stored || ! BMC_Helpers::equals( $provided, $stored ) ) {
			return new WP_Error( 'bmc_invalid_token', 'توکن نامعتبر است.', array( 'status' => 403 ) );
		}

		return true;
	}

	public static function no_cache_headers( $result, $server, $request ) {
		$route = method_exists( $request, 'get_route' ) ? (string) $request->get_route() : '';

		if ( false !== strpos( $route, 'bazzarmc' ) || false !== strpos( $route, 'storelinkformc' ) ) {
			nocache_headers();
			header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
			header( 'Pragma: no-cache' );
		}

		return $result;
	}

	public static function endpoint_ping( $request ) {
		return self::respond(
			array(
				'success' => true,
				'plugin'  => 'BazzarMc',
				'version' => BMC_VERSION,
				'time'    => current_time( 'mysql' ),
				'site'    => get_bloginfo( 'name' ),
				'sms'     => BMC_SMS::is_ready(),
			)
		);
	}

	public static function endpoint_link_redeem( $request ) {
		$code   = (string) $request->get_param( 'code' );
		$player = (string) $request->get_param( 'player' );
		$uuid   = (string) $request->get_param( 'uuid' );

		if ( ! BMC_Settings::panel_code_enabled() ) {
			return self::respond( array( 'success' => false, 'error' => 'روش اتصال از پنل غیرفعال است.', 'code' => 'DISABLED' ), 403 );
		}

		if ( self::rate_limited( 'redeem', 10 ) ) {
			return self::respond( array( 'success' => false, 'error' => 'تعداد درخواست‌ها زیاد است. کمی صبر کنید.', 'code' => 'RATE' ), 429 );
		}

		$result = BMC_Link::redeem_panel_code( $code, $player, $uuid );

		BMC_Logger::add(
			'api',
			'درخواست redeem کد اتصال',
			array(
				'player'  => $player,
				'success' => ! empty( $result['success'] ),
				'code'    => isset( $result['code'] ) ? $result['code'] : '',
			),
			! empty( $result['success'] ) ? 'success' : 'warning'
		);

		if ( empty( $result['success'] ) ) {
			return self::respond(
				array(
					'success' => false,
					'error'   => $result['message'],
					'code'    => isset( $result['code'] ) ? $result['code'] : 'ERROR',
				),
				400
			);
		}

		return self::respond(
			array(
				'success'      => true,
				'message'      => $result['message'],
				'player'       => $result['player'],
				'user_id'      => $result['user_id'],
				'display_name' => isset( $result['display_name'] ) ? $result['display_name'] : '',
			)
		);
	}

	public static function endpoint_link_request( $request ) {
		$player = (string) $request->get_param( 'player' );
		$mobile = (string) $request->get_param( 'mobile' );
		$email  = (string) $request->get_param( 'email' );

		if ( ! BMC_Settings::mc_request_enabled() ) {
			return self::respond( array( 'success' => false, 'error' => 'این روش اتصال غیرفعال است.', 'code' => 'DISABLED' ), 403 );
		}

		if ( self::rate_limited( 'request', 30 ) ) {
			return self::respond( array( 'success' => false, 'error' => 'لطفاً کمی صبر کنید.', 'code' => 'RATE' ), 429 );
		}

		if ( $mobile ) {
			$type  = 'mobile';
			$value = $mobile;
		} elseif ( $email ) {
			$type  = 'email';
			$value = $email;
		} else {
			return self::respond( array( 'success' => false, 'error' => 'شمارهٔ موبایل یا ایمیل الزامی است.', 'code' => 'FORMAT' ), 400 );
		}

		$result = BMC_Link::request_link_otp( $type, $value, $player );

		if ( empty( $result['success'] ) ) {
			return self::respond(
				array(
					'success' => false,
					'error'   => $result['message'],
					'code'    => isset( $result['code'] ) ? $result['code'] : 'ERROR',
				),
				400
			);
		}

		return self::respond(
			array(
				'success'    => true,
				'message'    => $result['message'],
				'channel'    => $result['channel'],
				'expires_in' => $result['expires_in'],
			)
		);
	}

	public static function endpoint_link_verify( $request ) {
		$player = (string) $request->get_param( 'player' );
		$code   = (string) $request->get_param( 'code' );
		$mobile = (string) $request->get_param( 'mobile' );
		$email  = (string) $request->get_param( 'email' );

		if ( self::rate_limited( 'verify', 20 ) ) {
			return self::respond( array( 'success' => false, 'error' => 'تعداد تلاش‌ها زیاد است.', 'code' => 'RATE' ), 429 );
		}

		if ( $mobile ) {
			$type  = 'mobile';
			$value = $mobile;
		} elseif ( $email ) {
			$type  = 'email';
			$value = $email;
		} else {
			return self::respond( array( 'success' => false, 'error' => 'مشخصات گیرنده لازم است.', 'code' => 'FORMAT' ), 400 );
		}

		$result = BMC_Link::verify_link_otp( $type, $value, $code );

		if ( empty( $result['success'] ) ) {
			return self::respond(
				array(
					'success' => false,
					'error'   => $result['message'],
					'code'    => isset( $result['code'] ) ? $result['code'] : 'ERROR',
				),
				400
			);
		}

		return self::respond(
			array(
				'success' => true,
				'message' => $result['message'],
				'player'  => $player,
			)
		);
	}

	public static function endpoint_player( $request ) {
		$player = sanitize_text_field( (string) $request->get_param( 'player' ) );

		if ( ! BMC_Helpers::valid_player_name( $player ) ) {
			return self::respond( array( 'success' => false, 'error' => 'نام کاربری نامعتبر است.' ), 400 );
		}

		$user = BMC_Link::find_user_by_player( $player );

		if ( ! $user ) {
			return self::respond(
				array(
					'success' => true,
					'linked'  => false,
					'player'  => $player,
				)
			);
		}

		$pending = BMC_Deliveries::pending_for_player( $player );

		return self::respond(
			array(
				'success'      => true,
				'linked'       => true,
				'player'       => $player,
				'uuid'         => BMC_Link::get_linked_uuid( $user->ID ),
				'user_id'      => $user->ID,
				'display_name' => BMC_Link::display_name( $user->ID ),
				'roles'        => $user->roles,
				'linked_at'    => (int) get_user_meta( $user->ID, BMC_Link::META_LINKED_AT, true ),
				'pending'      => count( $pending ),
			)
		);
	}

	public static function endpoint_deliveries( $request ) {
		$player = sanitize_text_field( (string) $request->get_param( 'player' ) );
		$limit  = min( 200, max( 1, (int) $request->get_param( 'limit' ) ) );

		if ( ! BMC_Helpers::valid_player_name( $player ) ) {
			return self::respond( array( 'success' => false, 'error' => 'پارامتر player الزامی است.' ), 400 );
		}

		$rows = BMC_Deliveries::pending_for_player( $player, $limit );

		$items = array();
		foreach ( $rows as $row ) {
			$items[] = array(
				'id'           => (int) $row->id,
				'order_id'     => (int) $row->order_id,
				'item'         => $row->item,
				'key'          => self::delivery_key( $row ),
				'slug'         => isset( $row->slug ) ? (string) $row->slug : '',
				'sku'          => isset( $row->sku ) ? (string) $row->sku : '',
				'product_id'   => (int) $row->product_id,
				'variation_id' => (int) $row->variation_id,
				'amount'       => (int) $row->amount,
				'created_at'   => $row->created_at,
			);
		}

		return self::respond(
			array(
				'success'    => true,
				'player'     => $player,
				'count'      => count( $items ),
				'deliveries' => $items,
			)
		);
	}

	public static function delivery_key( $row ) {
		$key = isset( $row->delivery_key ) ? trim( (string) $row->delivery_key ) : '';

		if ( '' !== $key ) {
			return $key;
		}

		$fallback = (string) BMC_Settings::product_key( (int) $row->product_id, (int) $row->variation_id );

		if ( '' !== trim( $fallback ) ) {
			return $fallback;
		}

		return isset( $row->item ) ? (string) $row->item : '';
	}

	public static function endpoint_mark_delivered( $request ) {
		$id     = (int) $request->get_param( 'id' );
		$player = sanitize_text_field( (string) $request->get_param( 'player' ) );

		if ( ! $id ) {
			return self::respond( array( 'success' => false, 'error' => 'شناسهٔ تحویل (id) الزامی است.' ), 400 );
		}

		$result = BMC_Deliveries::mark_delivered( $id, $player );

		return self::respond(
			array(
				'success' => ! empty( $result['success'] ),
				'message' => $result['message'],
			),
			empty( $result['success'] ) ? 400 : 200
		);
	}

	public static function endpoint_unlink( $request ) {
		$player = sanitize_text_field( (string) $request->get_param( 'player' ) );
		$user   = BMC_Link::find_user_by_player( $player );

		if ( ! $user ) {
			return self::respond( array( 'success' => false, 'error' => 'بازیکن متصل یافت نشد.' ), 404 );
		}

		BMC_Link::unlink_user( $user->ID );

		return self::respond(
			array(
				'success' => true,
				'message' => 'اتصال قطع شد.',
			)
		);
	}

	public static function legacy_request_link( $request ) {
		$email  = (string) $request->get_param( 'email' );
		$player = (string) $request->get_param( 'player' );

		$result = BMC_Link::request_link_otp( 'email', $email, $player );

		if ( empty( $result['success'] ) ) {
			return new WP_REST_Response( array( 'error' => $result['message'] ), 400 );
		}

		return new WP_REST_Response( array( 'success' => true, 'message' => 'Verification code sent.' ), 200 );
	}

	public static function legacy_verify_link( $request ) {
		$email = (string) $request->get_param( 'email' );
		$code  = (string) $request->get_param( 'code' );

		$result = BMC_Link::verify_link_otp( 'email', $email, $code );

		if ( empty( $result['success'] ) ) {
			return new WP_REST_Response( array( 'error' => $result['message'] ), 400 );
		}

		return new WP_REST_Response( array( 'success' => true, 'message' => 'Your account has been linked!' ), 200 );
	}

	public static function legacy_pending( $request ) {
		$player = sanitize_text_field( (string) $request->get_param( 'player' ) );
		$rows   = BMC_Deliveries::pending_for_player( $player );

		$items = array();
		foreach ( $rows as $row ) {
			$items[] = array(
				'id'           => (int) $row->id,
				'order_id'     => (int) $row->order_id,
				'item'         => $row->item,
				'product_id'   => (int) $row->product_id,
				'variation_id' => (int) $row->variation_id,
				'amount'       => (int) $row->amount,
			);
		}

		return new WP_REST_Response( array( 'success' => true, 'deliveries' => $items ), 200 );
	}

	public static function legacy_mark_delivered( $request ) {
		$id     = (int) $request->get_param( 'id' );
		$result = BMC_Deliveries::mark_delivered( $id );

		return new WP_REST_Response(
			array(
				'success' => ! empty( $result['success'] ),
				'message' => $result['message'],
			),
			200
		);
	}

	private static function respond( array $data, $status = 200 ) {
		return new WP_REST_Response( $data, $status );
	}

	private static function rate_limited( $action, $seconds = 15 ) {
		$key  = 'bmc_api_rl_' . $action . '_' . md5( BMC_Helpers::client_ip() );
		$hits = (int) get_transient( $key );

		if ( $hits >= 5 ) {
			return true;
		}

		set_transient( $key, $hits + 1, $seconds );

		return false;
	}
}
