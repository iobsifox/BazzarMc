<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Cache {

	public static function init() {
		if ( ! BMC_Settings::bool( 'cache_exclude', true ) ) {
			return;
		}

		add_action( 'init', array( __CLASS__, 'define_exclusions' ), 1 );
		add_action( 'template_redirect', array( __CLASS__, 'nocache_current_page' ), 0 );
		add_action( 'rest_api_init', array( __CLASS__, 'nocache_rest' ), 0 );
		add_filter( 'rocket_cache_reject_uri', array( __CLASS__, 'rocket_reject_uri' ) );
		add_filter( 'litespeed_control_set_nocache', array( __CLASS__, 'litespeed_reason' ), 10, 1 );
	}

	public static function define_exclusions() {
		if ( ! self::is_excluded_request() ) {
			return;
		}

		if ( ! defined( 'DONOTCACHEPAGE' ) ) {
			define( 'DONOTCACHEPAGE', true );
		}

		if ( ! defined( 'DONOTROCKETOPTIMIZE' ) ) {
			define( 'DONOTROCKETOPTIMIZE', true );
		}

		if ( ! defined( 'DONOTCACHCEOBJECT' ) ) {
			define( 'DONOTCACHCEOBJECT', true );
		}

		if ( ! defined( 'DONOTMINIFY' ) ) {
			define( 'DONOTMINIFY', true );
		}
	}

	public static function is_excluded_request() {
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return true;
		}

		if ( is_admin() ) {
			return false;
		}

		if ( function_exists( 'is_checkout' ) && ( is_checkout() || is_cart() ) ) {
			return true;
		}

		if ( function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( 'order-pay' ) ) {
			return true;
		}

		$page_ids = array_filter(
			array(
				(int) BMC_Settings::get( 'page_link', 0 ),
				(int) BMC_Settings::get( 'page_login', 0 ),
				(int) BMC_Settings::get( 'page_cart', 0 ),
			)
		);

		if ( $page_ids && is_singular() && in_array( (int) get_the_ID(), $page_ids, true ) ) {
			return true;
		}

		if ( is_user_logged_in() && self::current_path_has( '/my-account' ) ) {
			return true;
		}

		return false;
	}

	private static function current_path_has( $needle ) {
		$path = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';

		return false !== strpos( $path, $needle );
	}

	public static function nocache_current_page() {
		if ( ! self::is_excluded_request() ) {
			return;
		}

		nocache_headers();

		if ( ! headers_sent() ) {
			header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
			header( 'Pragma: no-cache' );
		}

		if ( function_exists( 'do_action' ) ) {
			do_action( 'litespeed_control_set_nocache', 'BazzarMc: صفحهٔ پویا' );
		}
	}

	public static function nocache_rest() {
		nocache_headers();

		if ( ! headers_sent() ) {
			header( 'Cache-Control: no-store, no-cache, must-revalidate, max-age=0' );
		}
	}

	public static function litespeed_reason( $reason ) {
		return $reason ? $reason : 'BazzarMc';
	}

	public static function rocket_reject_uri( $uris ) {
		$uris   = is_array( $uris ) ? $uris : array();
		$paths  = self::reject_paths();

		foreach ( $paths as $path ) {
			if ( $path && ! in_array( $path, $uris, true ) ) {
				$uris[] = $path;
			}
		}

		return $uris;
	}

	public static function reject_paths() {
		$paths = array(
			str_replace( array( 'http://', 'https://' ), '', untrailingslashit( (string) home_url() ) ) . '/wp-json/bazzarmc/(.*)',
		);

		foreach ( array( 'page_link', 'page_login', 'page_cart' ) as $key ) {
			$page_id = (int) BMC_Settings::get( $key, 0 );

			if ( ! $page_id ) {
				continue;
			}

			$permalink = get_permalink( $page_id );

			if ( $permalink ) {
				$paths[] = trailingslashit( (string) wp_parse_url( $permalink, PHP_URL_PATH ) ) . '(.*)';
			}
		}

		if ( function_exists( 'wc_get_page_permalink' ) ) {
			foreach ( array( 'checkout', 'cart' ) as $wc_page ) {
				$permalink = wc_get_page_permalink( $wc_page );

				if ( $permalink ) {
					$paths[] = trailingslashit( (string) wp_parse_url( $permalink, PHP_URL_PATH ) ) . '(.*)';
				}
			}
		}

		return array_values( array_unique( array_filter( $paths ) ) );
	}

	public static function cloudflare_configured() {
		return '' !== trim( (string) BMC_Settings::get( 'cf_api_token' ) )
			&& '' !== trim( (string) BMC_Settings::get( 'cf_zone_id' ) );
	}

	public static function cloudflare_request( $path, $method = 'GET', array $body = array() ) {
		$token = trim( (string) BMC_Settings::get( 'cf_api_token' ) );
		$zone  = trim( (string) BMC_Settings::get( 'cf_zone_id' ) );

		if ( ! $token || ! $zone ) {
			return array(
				'success' => false,
				'message' => 'توکن یا شناسهٔ زون Cloudflare وارد نشده است.',
			);
		}

		$url = 'https://api.cloudflare.com/client/v4/zones/' . rawurlencode( $zone ) . '/' . ltrim( $path, '/' );

		$args = array(
			'method'    => $method,
			'timeout'   => 20,
			'sslverify' => BMC_Settings::ssl_verify(),
			'headers'   => array(
				'Authorization' => 'Bearer ' . $token,
				'Content-Type'  => 'application/json',
				'Accept'        => 'application/json',
			),
		);

		if ( $body ) {
			$args['body'] = wp_json_encode( $body );
		}

		$response = wp_remote_request( $url, $args );

		if ( is_wp_error( $response ) ) {
			return array(
				'success' => false,
				'message' => $response->get_error_message(),
			);
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$json = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( ! is_array( $json ) ) {
			return array(
				'success' => false,
				'message' => 'پاسخ نامعتبر از Cloudflare (HTTP ' . $code . ').',
			);
		}

		$success = ! empty( $json['success'] );

		$message = '';

		if ( ! $success && ! empty( $json['errors'] ) && is_array( $json['errors'] ) ) {
			$parts = array();

			foreach ( $json['errors'] as $error ) {
				$parts[] = isset( $error['message'] ) ? (string) $error['message'] : wp_json_encode( $error );
			}

			$message = implode( ' | ', $parts );
		}

		return array(
			'success' => $success,
			'message' => $message,
			'data'    => isset( $json['result'] ) ? $json['result'] : null,
			'status'  => $code,
		);
	}

	public static function cloudflare_purge( array $urls = array() ) {
		if ( ! self::cloudflare_configured() ) {
			return array(
				'success' => false,
				'message' => 'Cloudflare پیکربندی نشده است.',
			);
		}

		if ( ! $urls ) {
			$urls = self::purge_urls();
		}

		return self::cloudflare_request(
			'purge_cache',
			'POST',
			array( 'files' => array_values( array_slice( $urls, 0, 30 ) ) )
		);
	}

	public static function purge_urls() {
		$urls = array( home_url( '/' ) );

		foreach ( array( 'page_link', 'page_login', 'page_cart' ) as $key ) {
			$page_id = (int) BMC_Settings::get( $key, 0 );

			if ( $page_id && get_permalink( $page_id ) ) {
				$urls[] = get_permalink( $page_id );
			}
		}

		if ( function_exists( 'wc_get_page_permalink' ) ) {
			foreach ( array( 'cart', 'checkout' ) as $wc_page ) {
				$url = wc_get_page_permalink( $wc_page );

				if ( $url ) {
					$urls[] = $url;
				}
			}
		}

		$urls[] = rest_url( 'bazzarmc/v1' );

		return array_values( array_unique( array_filter( $urls ) ) );
	}

	public static function cloudflare_upsert_cache_rule() {
		if ( ! self::cloudflare_configured() ) {
			return array(
				'success' => false,
				'message' => 'Cloudflare پیکربندی نشده است.',
			);
		}

		if ( ! BMC_Settings::bool( 'cf_cache_rule', false ) ) {
			return array(
				'success' => false,
				'message' => 'ساخت خودکار قاعدهٔ کش در تنظیمات غیرفعال است.',
			);
		}

		$expressions = array();

		foreach ( self::reject_paths() as $path ) {
			$clean = preg_replace( '#\(\.\*\)$#', '', (string) $path );
			$clean = preg_replace( '#^[^/]+#', '', $clean, 1 );

			if ( '' === $clean ) {
				continue;
			}

			$expressions[] = 'starts_with(http.request.uri.path, "' . $clean . '")';
		}

		if ( ! $expressions ) {
			return array(
				'success' => false,
				'message' => 'مسیری برای ساخت قاعده پیدا نشد.',
			);
		}

		$expression = '( ' . implode( ' or ', array_unique( $expressions ) ) . ' )';

		$rule = array(
			'action'      => 'set_cache_settings',
			'action_params' => array( 'cache' => false ),
			'description' => 'BazzarMc — عدم کش صفحات پویا',
			'enabled'     => true,
			'expression'  => $expression,
		);

		$current = self::cloudflare_request( 'rulesets/phases/http_request_cache_settings/entrypoint' );

		if ( ! empty( $current['success'] ) && ! empty( $current['data']['id'] ) ) {
			$ruleset_id = $current['data']['id'];
			$existing   = isset( $current['data']['rules'] ) ? (array) $current['data']['rules'] : array();
			$rules      = array();

			foreach ( $existing as $existing_rule ) {
				if ( isset( $existing_rule['description'] ) && false !== strpos( (string) $existing_rule['description'], 'BazzarMc' ) ) {
					continue;
				}
				$rules[] = $existing_rule;
			}

			$rules[] = $rule;

			return self::cloudflare_request( 'rulesets/' . rawurlencode( $ruleset_id ), 'PATCH', array( 'rules' => $rules ) );
		}

		return self::cloudflare_request(
			'rulesets',
			'POST',
			array(
				'kind'   => 'zone',
				'name'   => 'default',
				'phase'  => 'http_request_cache_settings',
				'rules'  => array( $rule ),
			)
		);
	}

	public static function purge_all() {
		$results = array();

		$results['transients'] = self::clear_transients();

		if ( self::cloudflare_configured() ) {
			$results['cloudflare'] = self::cloudflare_purge();
		}

		if ( function_exists( 'rocket_clean_domain' ) ) {
			rocket_clean_domain();
			$results['wp_rocket'] = array(
				'success' => true,
				'message' => 'کش WP Rocket پاک شد.',
			);
		}

		if ( class_exists( 'LiteSpeed_Cache_API' ) && method_exists( 'LiteSpeed_Cache_API', 'purge_all' ) ) {
			LiteSpeed_Cache_API::purge_all( 'BazzarMc' );
			$results['litespeed'] = array(
				'success' => true,
				'message' => 'کش LiteSpeed پاک شد.',
			);
		}

		return $results;
	}

	public static function clear_transients() {
		global $wpdb;

		$count = (int) $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$wpdb->options} WHERE option_name LIKE %s OR option_name LIKE %s",
				'\_transient\_bmc\_%',
				'\_transient\_timeout\_bmc\_%'
			)
		);

		return array(
			'success' => true,
			'message' => sprintf( '%d رکورد موقت پاک شد.', $count ),
		);
	}

	public static function status() {
		$detected = array();

		if ( defined( 'LSCWP_V' ) || class_exists( 'LiteSpeed_Cache_API' ) ) {
			$detected[] = 'LiteSpeed Cache';
		}

		if ( function_exists( 'rocket_clean_domain' ) || defined( 'WP_ROCKET_VERSION' ) ) {
			$detected[] = 'WP Rocket';
		}

		if ( defined( 'W3TC' ) ) {
			$detected[] = 'W3 Total Cache';
		}

		if ( defined( 'WPFC_EXIST' ) || class_exists( 'WpFastestCache' ) ) {
			$detected[] = 'WP Fastest Cache';
		}

		if ( defined( 'WPCACHEHOME' ) ) {
			$detected[] = 'WP Super Cache';
		}

		if ( defined( 'AUTOPTIMIZE_PLUGIN_VERSION' ) ) {
			$detected[] = 'Autoptimize';
		}

		return array(
			'enabled'    => BMC_Settings::bool( 'cache_exclude', true ),
			'detected'   => $detected,
			'cloudflare' => self::cloudflare_configured(),
			'paths'      => self::reject_paths(),
		);
	}
}
