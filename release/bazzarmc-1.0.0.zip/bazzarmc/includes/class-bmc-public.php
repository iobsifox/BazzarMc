<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Public {

	const ENDPOINT = 'minecraft';

	public static function init() {
		add_shortcode( 'bazzarmc', array( __CLASS__, 'shortcode_account' ) );
		add_shortcode( 'bazzarmc_account', array( __CLASS__, 'shortcode_account' ) );
		add_shortcode( 'bazzarmc_link', array( __CLASS__, 'shortcode_account' ) );
		add_shortcode( 'bazzarmc_login', array( __CLASS__, 'shortcode_login' ) );
		add_shortcode( 'bazzarmc_status', array( __CLASS__, 'shortcode_status' ) );
		add_shortcode( 'bazzarmc_checkout', array( __CLASS__, 'shortcode_checkout' ) );
		add_shortcode( 'bazzarmc_cart', array( __CLASS__, 'shortcode_cart' ) );

		add_filter( 'woocommerce_account_menu_items', array( __CLASS__, 'my_account_menu' ), 40 );
		add_action( 'init', array( __CLASS__, 'add_my_account_endpoint' ) );
		add_action( 'woocommerce_account_' . self::ENDPOINT . '_endpoint', array( __CLASS__, 'my_account_content' ) );
		add_filter( 'woocommerce_locate_template', array( __CLASS__, 'locate_dashboard_template' ), 20, 3 );

		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ), 15 );
	}

	public static function shortcode_account( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'title' => '',
			),
			$atts,
			'bazzarmc'
		);

		self::enqueue_base_assets();
		self::enqueue_link_assets();

		ob_start();
		$template = BMC_PATH . 'public/templates/link-box.php';

		if ( file_exists( $template ) ) {
			$bmc_atts = $atts;
			include $template;
		}

		return (string) ob_get_clean();
	}

	public static function shortcode_login( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'redirect' => '',
				'title'    => '',
			),
			$atts,
			'bazzarmc_login'
		);

		if ( is_user_logged_in() && empty( $atts['redirect'] ) ) {
			$url   = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'myaccount' ) : home_url( '/' );
			$name  = wp_get_current_user()->display_name;

			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-card bmc-card--center">'
				. '<div class="bmc-avatar"><img src="' . esc_url( BMC_Helpers::mc_head( BMC_Link::get_linked_player( get_current_user_id() ), 64 ) ) . '" alt="" /></div>'
				. '<h3 class="bmc-title">خوش آمدید ' . esc_html( $name ) . '</h3>'
				. '<p class="bmc-muted">هم‌اکنون وارد حساب کاربری خود هستید.</p>'
				. '<a class="bmc-btn" href="' . esc_url( $url ) . '">حساب کاربری من</a>'
				. '</div></div>';
		}

		self::enqueue_base_assets();
		self::enqueue_login_assets();

		ob_start();
		$template = BMC_PATH . 'public/templates/login.php';

		if ( file_exists( $template ) ) {
			$bmc_atts = $atts;
			include $template;
		}

		return (string) ob_get_clean();
	}

	public static function shortcode_status( $atts = array() ) {
		self::enqueue_base_assets();

		if ( ! is_user_logged_in() ) {
			return '<div class="bmc-badge bmc-badge--warn" dir="rtl">برای مشاهدهٔ وضعیت اتصال وارد حساب شوید.</div>';
		}

		$player = BMC_Link::get_linked_player( get_current_user_id() );

		if ( ! $player ) {
			return '<div class="bmc-badge bmc-badge--warn" dir="rtl">اکانت ماینکرافت متصل نیست — <a href="' . esc_url( self::link_page_url() ) . '">اتصال</a></div>';
		}

		return '<div class="bmc-badge bmc-badge--ok" dir="rtl">'
			. '<img src="' . esc_url( BMC_Helpers::mc_head( $player, 24 ) ) . '" alt="" width="24" height="24" /> '
			. 'متصل به <strong>' . esc_html( $player ) . '</strong>'
			. '</div>';
	}

	public static function shortcode_checkout( $atts = array() ) {
		if ( ! function_exists( 'WC' ) || ! WC()->cart || WC()->cart->is_empty() ) {
			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">سبد خرید شما خالی است.</div></div>';
		}

		self::enqueue_base_assets();

		wp_enqueue_script( 'bmc-checkout', BMC_URL . 'assets/js/bmc-checkout.js', array( 'jquery', 'bmc-icons' ), BMC_VERSION, true );
		wp_localize_script(
			'bmc-checkout',
			'bmcCheckout',
			array(
				'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
				'wcAjaxUrl' => class_exists( 'WC_AJAX' ) ? WC_AJAX::get_endpoint( '%%endpoint%%' ) : '',
				'nonce'     => wp_create_nonce( 'bmc_public' ),
				'wcNonce'   => wp_create_nonce( 'woocommerce-process_checkout' ),
				'isLinked'  => is_user_logged_in() ? BMC_Link::is_linked( get_current_user_id() ) : false,
				'linkedPlayer' => is_user_logged_in() ? BMC_Link::get_linked_player( get_current_user_id() ) : '',
				'headUrl'   => is_user_logged_in() ? BMC_Helpers::mc_head( BMC_Link::get_linked_player( get_current_user_id() ), 64 ) : '',
				'i18n'      => array(
					'processing' => 'در حال ثبت سفارش…',
					'error'      => 'خطا در ثبت سفارش',
					'fillPlayer' => 'نام کاربری ماینکرافت را وارد کنید.',
				),
			)
		);

		ob_start();

		$gate = BMC_Checkout::gate_status();

		if ( ! $gate['ok'] ) {
			BMC_Checkout::render_gate( $gate );
		} else {
			BMC_Checkout::render_checkout();
		}

		return (string) ob_get_clean();
	}

	public static function shortcode_cart( $atts = array() ) {
		if ( ! function_exists( 'WC' ) || ! class_exists( 'WooCommerce' ) ) {
			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">ووکامرس فعال نیست.</div></div>';
		}

		self::enqueue_base_assets();

		wp_enqueue_script( 'bmc-checkout', BMC_URL . 'assets/js/bmc-checkout.js', array( 'jquery', 'bmc-icons' ), BMC_VERSION, true );
		wp_localize_script(
			'bmc-checkout',
			'bmcCheckout',
			array(
				'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
				'wcAjaxUrl'    => class_exists( 'WC_AJAX' ) ? WC_AJAX::get_endpoint( '%%endpoint%%' ) : '',
				'nonce'        => wp_create_nonce( 'bmc_public' ),
				'wcNonce'      => wp_create_nonce( 'woocommerce-process_checkout' ),
				'isLinked'     => is_user_logged_in() ? BMC_Link::is_linked( get_current_user_id() ) : false,
				'linkedPlayer' => is_user_logged_in() ? BMC_Link::get_linked_player( get_current_user_id() ) : '',
				'headUrl'      => is_user_logged_in() ? BMC_Helpers::mc_head( BMC_Link::get_linked_player( get_current_user_id() ), 64 ) : '',
				'i18n'         => array(
					'processing' => 'در حال ثبت سفارش…',
					'error'      => 'خطا در ثبت سفارش',
					'fillPlayer' => 'نام کاربری ماینکرافت را وارد کنید.',
				),
			)
		);

		return BMC_Checkout::render_cart_page();
	}

	public static function add_my_account_endpoint() {
		add_rewrite_endpoint( self::ENDPOINT, EP_ROOT | EP_PAGES );
	}

	public static function my_account_menu( $items ) {
		$new = array();

		foreach ( $items as $key => $label ) {
			$new[ $key ] = $label;

			if ( 'orders' === $key ) {
				$new[ self::ENDPOINT ] = 'اتصال ماینکرافت';
			}
		}

		if ( ! isset( $new[ self::ENDPOINT ] ) ) {
			$new[ self::ENDPOINT ] = 'اتصال ماینکرافت';
		}

		return $new;
	}

	public static function my_account_content() {
		echo self::shortcode_account();
	}

	public static function link_page_url() {
		$page_id = (int) BMC_Settings::get( 'page_link', 0 );

		if ( $page_id ) {
			return (string) get_permalink( $page_id );
		}

		if ( function_exists( 'wc_get_account_endpoint_url' ) ) {
			$url = wc_get_account_endpoint_url( self::ENDPOINT );
			if ( $url && false === strpos( $url, 'wc_get_account_endpoint_url' ) ) {
				return $url;
			}
		}

		return home_url( '/' );
	}

	public static function enqueue_base_assets() {
		self::ensure_style( 'bmc-public', BMC_URL . 'assets/css/bmc-public.css', BMC_VERSION );
		self::ensure_script( 'bmc-icons', BMC_URL . 'assets/js/bmc-icons.js', array() );

		if ( BMC_Settings::bool( 'font_cdn', true ) ) {
			self::ensure_style( 'bmc-vazir', 'https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css', '33.003' );
		}

		$accent = (string) BMC_Settings::get( 'checkout_accent', '#3ddc84' );
		$theme  = 'light' === BMC_Settings::get( 'checkout_theme' ) ? 'light' : 'dark';

		$inline = '.bmc-wrap,.bmc-acard{--bmc-accent:' . esc_attr( $accent ) . ';}' .
			( 'light' === $theme ? '.bmc-wrap{--bmc-bg:#f6f7fb;--bmc-bg-2:#ffffff;--bmc-surface:#ffffff;--bmc-text:#101828;--bmc-muted:#5b6472;--bmc-border:#e5e7eb;}' : '' );

		if ( did_action( 'wp_head' ) && ! wp_style_is( 'bmc-public', 'enqueued' ) ) {
			echo '<style id="bmc-inline-vars">' . $inline . '</style>';
		} else {
			wp_add_inline_style( 'bmc-public', $inline );
		}
	}

	private static function ensure_style( $handle, $src, $ver ) {
		if ( wp_style_is( $handle, 'done' ) || wp_style_is( $handle, 'enqueued' ) ) {
			return;
		}

		if ( ! did_action( 'wp_head' ) ) {
			wp_enqueue_style( $handle, $src, array(), $ver );
			return;
		}

		printf(
			'<link rel="stylesheet" id="%1$s-css" href="%2$s" media="all" />',
			esc_attr( $handle ),
			esc_url( $src )
		);
	}

	private static function ensure_script( $handle, $src, array $deps = array( 'jquery' ) ) {
		if ( wp_script_is( $handle, 'done' ) || wp_script_is( $handle, 'enqueued' ) ) {
			return;
		}

		if ( ! did_action( 'wp_footer' ) ) {
			wp_enqueue_script( $handle, $src, $deps, BMC_VERSION, true );
			return;
		}

		printf(
			'<script src="%1$s" id="%2$s-js" defer></script>',
			esc_url( $src ),
			esc_attr( $handle )
		);
	}

	public static function enqueue_link_assets() {
		self::ensure_script( 'bmc-link', BMC_URL . 'assets/js/bmc-link.js', array( 'jquery', 'bmc-icons' ) );

		$data = array(
			'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
			'nonce'       => wp_create_nonce( 'bmc_frontend' ),
			'publicNonce' => wp_create_nonce( 'bmc_public' ),
			'loggedIn'    => is_user_logged_in(),
			'loginUrl'    => BMC_Auth::login_url(),
			'headUrl'     => BMC_Helpers::mc_head( '', 64 ),
			'i18n'        => array(
				'copied'        => 'کد کپی شد!',
				'copyError'     => 'کپی نشد؛ کد را دستی انتخاب کنید.',
				'expired'       => 'اعتبار کد تمام شد.',
				'connected'     => 'متصل شد!',
				'waiting'       => 'در انتظار ورود به بازی…',
				'confirmUnlink' => 'مطمئنید می‌خواهید اتصال اکانت ماینکرافت را قطع کنید؟',
			),
		);

		self::localize( 'bmc-link', 'bmcLink', $data );
	}

	public static function enqueue_login_assets() {
		self::ensure_script( 'bmc-login', BMC_URL . 'assets/js/bmc-login.js', array( 'jquery', 'bmc-icons' ) );

		self::localize(
			'bmc-login',
			'bmcLogin',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'bmc_public' ),
				'otpTtl'  => BMC_Settings::int( 'sms_otp_ttl', 120, 30, 900 ),
				'otpLen'  => BMC_Settings::int( 'sms_otp_length', 5, 4, 8 ),
			)
		);
	}

	private static function localize( $handle, $object, array $data ) {
		unset( $handle );

		$json = wp_json_encode( $data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );

		printf(
			'<script>var %1$s = %2$s;</script>',
			esc_js( $object ),
			$json
		);
	}

	public static function enqueue_assets() {
		$page_link  = (int) BMC_Settings::get( 'page_link', 0 );
		$page_login = (int) BMC_Settings::get( 'page_login', 0 );

		$need_link  = ( $page_link && is_page( $page_link ) ) || ( function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( self::ENDPOINT ) );
		$need_login = (bool) ( $page_login && is_page( $page_login ) );
		$need_card  = function_exists( 'is_account_page' ) && is_account_page() && BMC_Settings::bool( 'myaccount_card', true );

		if ( is_singular() ) {
			$content = (string) get_post_field( 'post_content', get_the_ID() );

			foreach ( array( 'bazzarmc', 'bazzarmc_account', 'bazzarmc_link', 'bazzarmc_status' ) as $sc ) {
				if ( has_shortcode( $content, $sc ) ) {
					$need_link = true;
					break;
				}
			}

			if ( has_shortcode( $content, 'bazzarmc_login' ) ) {
				$need_login = true;
			}

			if ( has_shortcode( $content, 'bazzarmc_checkout' ) ) {
				self::enqueue_base_assets();
			}
		}

		if ( $need_link ) {
			self::enqueue_base_assets();
			self::enqueue_link_assets();
		}

		if ( $need_login ) {
			self::enqueue_base_assets();
			self::enqueue_login_assets();
		}

		if ( $need_card ) {
			self::enqueue_base_assets();
		}
	}

	public static function locate_dashboard_template( $template, $template_name, $template_path = '' ) {
		if ( 'myaccount/dashboard.php' !== $template_name ) {
			return $template;
		}

		if ( ! BMC_Settings::bool( 'myaccount_card', true ) ) {
			return $template;
		}

		$custom = BMC_PATH . 'public/templates/wc-dashboard.php';

		return file_exists( $custom ) ? $custom : $template;
	}
}
