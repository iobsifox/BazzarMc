<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_EZLogin {

	const PHONE_META     = 'ez_phone';
	const PHONE_META_ALT = 'ez_phone_number';
	const OWN_META       = 'bmc_mobile';

	private static $default_keys = array(
		'billing_phone',
		'shipping_phone',
		'phone',
		'mobile',
		'user_phone',
		'ez_phone',
	);

	public static function init() {
		add_filter( 'ez_login_phone_meta_keys', array( __CLASS__, 'register_meta_keys' ) );
		add_filter( 'bmc_mobile_meta_keys', array( __CLASS__, 'merge_meta_keys' ) );
		add_action( 'profile_update', array( __CLASS__, 'on_profile_update' ), 20, 2 );
		add_action( 'user_register', array( __CLASS__, 'on_user_register' ), 20 );
	}

	public static function is_active() {
		return BMC_Settings::ezlogin_active();
	}

	public static function is_bridged() {
		return BMC_Settings::use_ezlogin();
	}

	public static function register_meta_keys( $keys ) {
		$keys = (array) $keys;

		foreach ( array( self::OWN_META, self::PHONE_META, self::PHONE_META_ALT, 'digits_number', 'digits_number_no' ) as $key ) {
			if ( ! in_array( $key, $keys, true ) ) {
				$keys[] = $key;
			}
		}

		return $keys;
	}

	public static function merge_meta_keys( $keys ) {
		return self::meta_keys( (array) $keys );
	}

	public static function meta_keys( array $extra = array() ) {
		$theirs = self::$default_keys;

		if ( self::is_active() ) {
			$theirs = (array) apply_filters( 'ez_login_phone_meta_keys', self::$default_keys );
		}

		$ours = (array) BMC_Settings::get( 'mobile_meta_keys', array() );

		$keys = array_merge( array( self::OWN_META, self::PHONE_META ), $theirs, $ours, $extra );
		$keys = array_map( 'sanitize_key', $keys );
		$keys = array_filter( $keys );

		return array_values( array_unique( $keys ) );
	}

	public static function normalize_phone( $phone ) {
		if ( self::is_active() && function_exists( 'ez_login_normalize_phone' ) ) {
			$normalized = (string) ez_login_normalize_phone( $phone );

			if ( '' !== $normalized ) {
				return $normalized;
			}
		}

		return BMC_Helpers::normalize_mobile( $phone );
	}

	public static function find_user_by_phone( $phone ) {
		$phone = self::normalize_phone( $phone );

		if ( '' === $phone ) {
			return false;
		}

		if ( self::is_active() && function_exists( 'ez_login_find_user_by_phone' ) ) {
			$user = ez_login_find_user_by_phone( $phone );

			if ( $user instanceof WP_User ) {
				return $user;
			}
		}

		$user = get_user_by( 'login', $phone );

		if ( $user instanceof WP_User ) {
			return $user;
		}

		return false;
	}

	public static function get_phone( $user_id ) {
		$user_id = absint( $user_id );

		if ( ! $user_id ) {
			return '';
		}

		foreach ( self::meta_keys() as $key ) {
			$value = get_user_meta( $user_id, $key, true );

			if ( is_scalar( $value ) && '' !== trim( (string) $value ) ) {
				$phone = self::normalize_phone( $value );

				if ( '' !== $phone ) {
					return $phone;
				}
			}
		}

		$user = get_userdata( $user_id );

		if ( $user && is_email( $user->user_login ) ) {
			return '';
		}

		if ( $user && preg_match( '/^09\d{9}$/', (string) $user->user_login ) ) {
			return self::normalize_phone( $user->user_login );
		}

		return '';
	}

	public static function sync_phone( $user_id, $phone ) {
		$user_id = absint( $user_id );
		$phone   = self::normalize_phone( $phone );

		if ( ! $user_id || '' === $phone ) {
			return false;
		}

		update_user_meta( $user_id, self::OWN_META, $phone );

		if ( BMC_Settings::bool( 'ezlogin_sync_phone', true ) && self::is_active() ) {
			update_user_meta( $user_id, self::PHONE_META, $phone );
		}

		do_action( 'bmc_phone_synced', $user_id, $phone );

		return true;
	}

	public static function on_profile_update( $user_id, $user ) {
		if ( ! self::is_active() || ! $user instanceof WP_User ) {
			return;
		}

		$billing = get_user_meta( $user_id, 'billing_phone', true );

		if ( $billing && ! get_user_meta( $user_id, self::PHONE_META, true ) ) {
			update_user_meta( $user_id, self::PHONE_META, self::normalize_phone( $billing ) );
		}
	}

	public static function on_user_register( $user_id ) {
		if ( ! self::is_active() ) {
			return;
		}

		$phone = self::get_phone( $user_id );

		if ( $phone && ! get_user_meta( $user_id, self::PHONE_META, true ) ) {
			update_user_meta( $user_id, self::PHONE_META, $phone );
		}
	}

	public static function auth_mode() {
		if ( self::is_active() && function_exists( 'ez_sms_get_auth_mode' ) ) {
			return (string) ez_sms_get_auth_mode();
		}

		return 'legacy';
	}

	public static function credentials_ready() {
		if ( self::is_active() && function_exists( 'ez_sms_credentials_ready' ) ) {
			return (bool) ez_sms_credentials_ready();
		}

		return false;
	}

	public static function send_mode() {
		return (string) get_option( 'ez_sms_send_mode', 'pattern' );
	}

	public static function pattern_code() {
		return absint( get_option( 'ez_sms_pattern_code', 0 ) );
	}

	public static function otp_length() {
		if ( BMC_Settings::bool( 'ezlogin_reuse_settings', true ) && self::is_active() && function_exists( 'ez_login_get_otp_length' ) ) {
			return (int) ez_login_get_otp_length();
		}

		return BMC_Settings::int( 'sms_otp_length', 5, 4, 8 );
	}

	public static function otp_ttl() {
		if ( BMC_Settings::bool( 'ezlogin_reuse_settings', true ) && self::is_active() && function_exists( 'ez_login_get_otp_expiry_minutes' ) ) {
			return (int) ez_login_get_otp_expiry_minutes() * 60;
		}

		return BMC_Settings::int( 'sms_otp_ttl', 120, 30, 900 );
	}

	public static function otp_hash_key( $phone ) {
		return 'ez_sms_otp_hash_' . self::normalize_phone( $phone );
	}

	public static function has_pending_otp( $phone ) {
		return self::is_active() && false !== get_transient( self::otp_hash_key( $phone ) );
	}

	public static function status() {
		$active  = self::is_active();
		$bridged = self::is_bridged();

		return array(
			'active'       => $active,
			'bridged'      => $bridged,
			'auth_mode'    => $active ? self::auth_mode() : '',
			'ready'        => $active ? self::credentials_ready() : false,
			'send_mode'    => $active ? self::send_mode() : '',
			'pattern_code' => $active ? self::pattern_code() : 0,
			'otp_length'   => self::otp_length(),
			'otp_ttl'      => self::otp_ttl(),
			'meta_keys'    => self::meta_keys(),
			'can_send'     => $active && function_exists( 'ez_send_sms' ),
		);
	}

	public static function status_note() {
		$status = self::status();

		if ( ! $status['active'] ) {
			return array(
				'type' => 'muted',
				'text' => 'افزونهٔ EZ-Login نصب یا فعال نیست. در صورت فعال‌شدن، به‌صورت خودکار شناسایی می‌شود.',
			);
		}

		if ( ! $status['can_send'] ) {
			return array(
				'type' => 'warn',
				'text' => 'افزونهٔ EZ-Login فعال است اما تابعٔ ارسال پیامک آن در دسترس نیست (نسخهٔ قدیمی؟).',
			);
		}

		if ( ! $status['ready'] ) {
			return array(
				'type' => 'warn',
				'text' => 'افزونهٔ EZ-Login فعال است ولی اعتبارنامهٔ پیامک آن کامل نیست؛ از تنظیمات همان افزونه ملی‌پیامک را پیکربندی کنید.',
			);
		}

		return array(
			'type' => 'ok',
			'text' => sprintf(
				'EZ-Login شناسایی شد — حالت احراز هویت: %s، روش ارسال: %s، طول کد: %d، اعتبار کد: %d ثانیه. ارسال پیامک از مسیر همان افزونه انجام می‌شود.',
				'api_key' === $status['auth_mode'] ? 'کلید API (کنسول)' : 'نام کاربری/رمز',
				'pattern' === $status['send_mode'] ? 'الگو (پترن)' : 'متن ساده',
				$status['otp_length'],
				$status['otp_ttl']
			),
		);
	}
}
