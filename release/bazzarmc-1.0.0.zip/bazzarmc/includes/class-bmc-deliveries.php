<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Deliveries {

	const STATUS_PENDING   = 0;
	const STATUS_DELIVERED = 1;
	const STATUS_EXPIRED   = 2;
	const STATUS_CANCELLED = 3;

	public static function init() {
		$statuses = (array) BMC_Settings::get( 'delivery_status', array( 'processing', 'completed' ) );

		foreach ( $statuses as $status ) {
			add_action( 'woocommerce_order_status_' . sanitize_key( $status ), array( __CLASS__, 'on_order_status' ), 20, 1 );
		}

		add_action( 'woocommerce_payment_complete', array( __CLASS__, 'on_order_status' ), 20, 1 );
		add_action( 'woocommerce_order_status_cancelled', array( __CLASS__, 'on_order_cancelled' ), 20, 1 );
		add_action( 'woocommerce_order_status_refunded', array( __CLASS__, 'on_order_cancelled' ), 20, 1 );
		add_action( 'woocommerce_order_status_failed', array( __CLASS__, 'on_order_cancelled' ), 20, 1 );

		add_filter( 'woocommerce_email_order_meta_fields', array( __CLASS__, 'email_meta_fields' ), 10, 3 );
		add_action( 'woocommerce_admin_order_data_after_billing_address', array( __CLASS__, 'admin_order_box' ), 10, 1 );

		add_action( 'wp_ajax_bmc_admin_delivery_action', array( __CLASS__, 'ajax_admin_action' ) );
	}

	public static function on_order_status( $order_id ) {
		self::create_for_order( (int) $order_id );
	}

	public static function on_order_cancelled( $order_id ) {
		global $wpdb;

		$table = BMC_DB::table( 'deliveries' );
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET status = %d, note = %s WHERE order_id = %d AND status = %d",
				self::STATUS_CANCELLED,
				'سفارش لغو/بازگشت شد',
				(int) $order_id,
				self::STATUS_PENDING
			)
		);

		self::remove_roles_for_order( (int) $order_id );
	}

	public static function create_for_order( $order_id ) {
		global $wpdb;

		if ( ! function_exists( 'wc_get_order' ) ) {
			return 0;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order ) {
			return 0;
		}

		if ( $order->get_meta( '_bmc_delivery_created' ) ) {
			return 0;
		}

		$user_id = $order->get_user_id();
		$table   = BMC_DB::table( 'deliveries' );

		$player = self::resolve_player( $order );

		if ( ! $player ) {
			BMC_Logger::add( 'delivery', sprintf( 'سفارش #%d بازیکن مشخصی نداشت؛ تحویلی ثبت نشد.', $order_id ), array(), 'warning' );
			return 0;
		}

		$synced       = array_map( 'absint', (array) BMC_Settings::get( 'sync_products', array() ) );
		$product_role = (array) BMC_Settings::get( 'product_roles', array() );
		$expires      = BMC_Helpers::expires_at( BMC_Settings::delivery_expiry_seconds() );
		$server       = (string) BMC_Settings::get( 'server_name' );
		$created      = 0;

		foreach ( $order->get_items() as $item ) {
			if ( ! is_a( $item, 'WC_Order_Item_Product' ) ) {
				continue;
			}

			$product_id   = absint( $item->get_product_id() );
			$variation_id = absint( $item->get_variation_id() );
			$sync_id      = ( $variation_id && in_array( $variation_id, $synced, true ) ) ? $variation_id : $product_id;
			$role_key     = isset( $product_role[ $variation_id ] ) ? $variation_id : $product_id;

			if ( $user_id && isset( $product_role[ $role_key ] ) && $product_role[ $role_key ] ) {
				$role = sanitize_text_field( $product_role[ $role_key ] );
				if ( array_key_exists( $role, wp_roles()->roles ) ) {
					$user = new WP_User( $user_id );
					if ( ! in_array( $role, $user->roles, true ) ) {
						$user->add_role( $role );
					}
				}
			}

			if ( ! in_array( $sync_id, $synced, true ) ) {
				continue;
			}

			$name = mb_strtolower( trim( $item->get_name() ) );
			$qty  = max( 1, (int) $item->get_quantity() );

			$product_obj  = $item->get_product();
			$slug         = $product_obj ? (string) $product_obj->get_slug() : '';
			$sku          = $product_obj ? (string) $product_obj->get_sku() : '';
			$delivery_key = (string) BMC_Settings::product_key( $product_id, $variation_id );

			if ( '' === trim( $delivery_key ) ) {
				$delivery_key = $name;
			}

			$exists = $wpdb->get_var(
				$wpdb->prepare(
					"SELECT id FROM {$table} WHERE order_id = %d AND player = %s AND product_id = %d AND variation_id = %d LIMIT 1",
					$order_id,
					$player,
					$product_id,
					$variation_id
				)
			);

			if ( $exists ) {
				continue;
			}

			$wpdb->insert(
				$table,
				array(
					'order_id'     => $order_id,
					'user_id'      => $user_id,
					'player'       => $player,
					'player_uuid'  => $user_id ? BMC_Link::get_linked_uuid( $user_id ) : '',
					'product_id'   => $product_id,
					'variation_id' => $variation_id,
					'item'         => $name,
					'delivery_key' => $delivery_key,
					'slug'         => $slug,
					'sku'          => $sku,
					'amount'       => $qty,
					'status'       => self::STATUS_PENDING,
					'server'       => $server,
					'created_at'   => current_time( 'mysql' ),
					'expires_at'   => $expires,
				),
				array( '%d', '%d', '%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s', '%d', '%d', '%s', '%s', '%s' )
			);

			$created++;
		}

		if ( $created ) {
			$order->update_meta_data( '_bmc_delivery_created', 1 );
			$order->update_meta_data( '_bmc_mc_player', $player );
			$order->save();

			BMC_Logger::add( 'delivery', sprintf( '%d تحویل برای سفارش #%d ثبت شد (%s)', $created, $order_id, $player ), array(), 'success' );

			self::notify_customer( $order, $player );
		}

		return $created;
	}

	private static function resolve_player( $order ) {
		$target = (string) $order->get_meta( '_bmc_target_type' );
		$player = '';

		if ( 'gift' === $target || 'manual' === $target ) {
			$player = (string) $order->get_meta( '_bmc_mc_player' );
		} elseif ( 'linked' === $target ) {
			$player = BMC_Link::get_linked_player( $order->get_user_id() );
		}

		if ( ! $player ) {

			$player = (string) $order->get_meta( '_minecraft_username' );
		}

		if ( ! $player ) {
			$player = BMC_Link::get_linked_player( $order->get_user_id() );
		}

		$player = sanitize_text_field( trim( $player ) );

		return BMC_Helpers::valid_player_name( $player ) ? $player : '';
	}

	private static function notify_customer( $order, $player ) {
		if ( ! BMC_Settings::bool( 'sms_order_notify', false ) ) {
			return;
		}

		$template = (string) BMC_Settings::get( 'sms_tpl_delivery' );
		if ( ! $template ) {
			return;
		}

		$user_id = $order->get_user_id();
		$mobile  = $user_id ? BMC_Auth::get_user_mobile( $user_id ) : '';

		if ( ! $mobile ) {
			$mobile = BMC_Helpers::normalize_mobile( (string) $order->get_billing_phone() );
		}

		if ( ! $mobile ) {
			return;
		}

		$text = BMC_Helpers::replace_tags(
			$template,
			array(
				'{order}'   => BMC_Helpers::to_persian_digits( $order->get_id() ),
				'{player}'  => $player,
				'{server}'  => (string) BMC_Settings::get( 'server_name' ),
				'{total}'   => BMC_Helpers::format_price( $order->get_total() ),
				'{name}'    => $order->get_billing_first_name(),
			)
		);

		BMC_SMS::send_text( $mobile, $text );
	}

	public static function pending_for_player( $player, $limit = 100 ) {
		global $wpdb;

		$table = BMC_DB::table( 'deliveries' );
		$limit = max( 1, min( 500, (int) $limit ) );
		$now   = current_time( 'mysql' );

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT * FROM {$table}
				 WHERE player = %s
				   AND status = %d
				   AND ( expires_at IS NULL OR expires_at >= %s )
				 ORDER BY id ASC
				 LIMIT {$limit}",
				sanitize_text_field( $player ),
				self::STATUS_PENDING,
				$now
			)
		);

		return $rows ? $rows : array();
	}

	public static function mark_delivered( $id, $player = '' ) {
		global $wpdb;

		$table = BMC_DB::table( 'deliveries' );
		$id    = (int) $id;

		if ( ! $id ) {
			return array(
				'success' => false,
				'message' => 'شناسه نامعتبر است.',
			);
		}

		$data    = array(
			'status'       => self::STATUS_DELIVERED,
			'delivered_at' => current_time( 'mysql' ),
		);
		$formats = array( '%d', '%s' );
		$where   = array(
			'id'     => $id,
			'status' => self::STATUS_PENDING,
		);

		if ( $player ) {
			$where['player'] = sanitize_text_field( $player );
		}

		$updated = $wpdb->update( $table, $data, $where, $formats, array_fill( 0, count( $where ), '%s' ) );

		if ( false === $updated ) {
			return array(
				'success' => false,
				'message' => 'خطا در به‌روزرسانی دیتابیس.',
			);
		}

		if ( 0 === (int) $updated ) {
			return array(
				'success' => false,
				'message' => 'قبلاً تحویل داده شده یا یافت نشد.',
			);
		}

		BMC_Logger::add( 'delivery', sprintf( 'تحویل #%d انجام شد (%s)', $id, $player ), array(), 'success' );

		return array(
			'success' => true,
			'message' => 'تحویل ثبت شد.',
		);
	}

	private static function remove_roles_for_order( $order_id ) {
		if ( ! function_exists( 'wc_get_order' ) ) {
			return;
		}

		$order = wc_get_order( $order_id );
		if ( ! $order || ! $order->get_user_id() ) {
			return;
		}

		$product_role = (array) BMC_Settings::get( 'product_roles', array() );
		$user         = new WP_User( $order->get_user_id() );

		foreach ( $order->get_items() as $item ) {
			if ( ! is_a( $item, 'WC_Order_Item_Product' ) ) {
				continue;
			}

			$key = absint( $item->get_variation_id() ) ? absint( $item->get_variation_id() ) : absint( $item->get_product_id() );

			if ( isset( $product_role[ $key ] ) && $product_role[ $key ] ) {
				$role = sanitize_text_field( $product_role[ $key ] );
				if ( in_array( $role, $user->roles, true ) && 'administrator' !== $role ) {
					$user->remove_role( $role );
				}
			}
		}
	}

	public static function expire_old() {
		global $wpdb;

		$table = BMC_DB::table( 'deliveries' );

		return (int) $wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET status = %d WHERE status = %d AND expires_at IS NOT NULL AND expires_at < %s",
				self::STATUS_EXPIRED,
				self::STATUS_PENDING,
				current_time( 'mysql' )
			)
		);
	}

	public static function stats() {
		global $wpdb;

		$table = BMC_DB::table( 'deliveries' );

		$counts = $wpdb->get_results( "SELECT status, COUNT(*) AS c FROM {$table} GROUP BY status", ARRAY_A );

		$out = array(
			'pending'   => 0,
			'delivered' => 0,
			'expired'   => 0,
			'cancelled' => 0,
			'total'     => 0,
		);

		$map = array(
			self::STATUS_PENDING   => 'pending',
			self::STATUS_DELIVERED => 'delivered',
			self::STATUS_EXPIRED   => 'expired',
			self::STATUS_CANCELLED => 'cancelled',
		);

		foreach ( (array) $counts as $row ) {
			$key = isset( $map[ (int) $row['status'] ] ) ? $map[ (int) $row['status'] ] : '';
			if ( $key ) {
				$out[ $key ] = (int) $row['c'];
			}
			$out['total'] += (int) $row['c'];
		}

		$out['linked_users'] = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT user_id) FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value <> ''",
				BMC_Link::META_PLAYER
			)
		);

		return $out;
	}

	public static function query( array $args = array() ) {
		global $wpdb;

		$table = BMC_DB::table( 'deliveries' );

		$defaults = array(
			'status'   => '',
			'search'   => '',
			'order_id' => 0,
			'paged'    => 1,
			'per_page' => 25,
			'orderby'  => 'id',
			'order'    => 'DESC',
		);

		$args  = wp_parse_args( $args, $defaults );
		$where = array( '1=1' );
		$params = array();

		if ( '' !== $args['status'] && is_numeric( $args['status'] ) ) {
			$where[]  = 'status = %d';
			$params[] = (int) $args['status'];
		}

		if ( $args['order_id'] ) {
			$where[]  = 'order_id = %d';
			$params[] = (int) $args['order_id'];
		}

		if ( $args['search'] ) {
			$like     = '%' . $wpdb->esc_like( $args['search'] ) . '%';
			$where[]  = '( player LIKE %s OR item LIKE %s OR order_id LIKE %s )';
			$params[] = $like;
			$params[] = $like;
			$params[] = $like;
		}

		$orderby = in_array( $args['orderby'], array( 'id', 'order_id', 'player', 'created_at', 'amount' ), true ) ? $args['orderby'] : 'id';
		$order   = 'ASC' === strtoupper( $args['order'] ) ? 'ASC' : 'DESC';

		$per_page = max( 5, min( 100, (int) $args['per_page'] ) );
		$paged    = max( 1, (int) $args['paged'] );
		$offset   = ( $paged - 1 ) * $per_page;

		$where_sql = implode( ' AND ', $where );

		$total = (int) $wpdb->get_var(
			$params ? $wpdb->prepare( "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}", $params ) : "SELECT COUNT(*) FROM {$table} WHERE {$where_sql}"
		);

		$sql = "SELECT * FROM {$table} WHERE {$where_sql} ORDER BY {$orderby} {$order} LIMIT {$per_page} OFFSET {$offset}";

		$items = $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ) ) : $wpdb->get_results( $sql );

		return array(
			'items'    => $items ? $items : array(),
			'total'    => $total,
			'pages'    => (int) ceil( $total / $per_page ),
			'paged'    => $paged,
			'per_page' => $per_page,
		);
	}

	public static function get_row( $id ) {
		global $wpdb;
		$table = BMC_DB::table( 'deliveries' );
		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", (int) $id ) );
	}

	public static function update_row( $id, array $data ) {
		global $wpdb;

		$table   = BMC_DB::table( 'deliveries' );
		$allowed = array( 'player', 'item', 'delivery_key', 'slug', 'sku', 'amount', 'status', 'order_id', 'product_id', 'variation_id', 'note' );
		$clean   = array();
		$formats = array();

		foreach ( $data as $key => $value ) {
			if ( ! in_array( $key, $allowed, true ) ) {
				continue;
			}
			if ( in_array( $key, array( 'amount', 'status', 'order_id', 'product_id', 'variation_id' ), true ) ) {
				$clean[ $key ] = (int) $value;
				$formats[]     = '%d';
			} else {
				$clean[ $key ] = sanitize_text_field( $value );
				$formats[]     = '%s';
			}
		}

		if ( ! $clean ) {
			return false;
		}

		return false !== $wpdb->update( $table, $clean, array( 'id' => (int) $id ), $formats, array( '%d' ) );
	}

	public static function delete_row( $id ) {
		global $wpdb;
		$table = BMC_DB::table( 'deliveries' );
		return false !== $wpdb->delete( $table, array( 'id' => (int) $id ), array( '%d' ) );
	}

	public static function reset_to_pending( $id ) {
		global $wpdb;
		$table = BMC_DB::table( 'deliveries' );
		return false !== $wpdb->update(
			$table,
			array(
				'status'       => self::STATUS_PENDING,
				'delivered_at' => null,
				'note'         => '',
			),
			array( 'id' => (int) $id ),
			array( '%d', '%s', '%s' ),
			array( '%d' )
		);
	}

	public static function status_label( $status ) {
		$labels = array(
			self::STATUS_PENDING   => 'در انتظار تحویل',
			self::STATUS_DELIVERED => 'تحویل شد',
			self::STATUS_EXPIRED   => 'منقضی',
			self::STATUS_CANCELLED => 'لغو شده',
		);

		return isset( $labels[ (int) $status ] ) ? $labels[ (int) $status ] : 'نامشخص';
	}

	public static function status_class( $status ) {
		$map = array(
			self::STATUS_PENDING   => 'is-pending',
			self::STATUS_DELIVERED => 'is-done',
			self::STATUS_EXPIRED   => 'is-expired',
			self::STATUS_CANCELLED => 'is-cancelled',
		);

		return isset( $map[ (int) $status ] ) ? $map[ (int) $status ] : '';
	}

	public static function ajax_admin_action() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی ندارید.' ), 403 );
		}

		check_admin_referer( 'bmc_admin', 'security' );

		$id     = isset( $_POST['id'] ) ? (int) $_POST['id'] : 0;
		$action = isset( $_POST['do'] ) ? sanitize_key( wp_unslash( $_POST['do'] ) ) : '';

		if ( ! $id ) {
			wp_send_json_error( array( 'message' => 'شناسه نامعتبر است.' ), 400 );
		}

		switch ( $action ) {
			case 'delivered':
				global $wpdb;
				$table = BMC_DB::table( 'deliveries' );
				$wpdb->update( $table, array( 'status' => self::STATUS_DELIVERED, 'delivered_at' => current_time( 'mysql' ) ), array( 'id' => $id ), array( '%d', '%s' ), array( '%d' ) );
				wp_send_json_success( array( 'message' => 'به‌عنوان تحویل‌شده ثبت شد.' ) );
				break;

			case 'pending':
				self::reset_to_pending( $id );
				wp_send_json_success( array( 'message' => 'به صف تحویل بازگشت.' ) );
				break;

			case 'delete':
				self::delete_row( $id );
				wp_send_json_success( array( 'message' => 'حذف شد.' ) );
				break;

			default:
				wp_send_json_error( array( 'message' => 'عملیات نامعتبر است.' ), 400 );
		}
	}

	public static function email_meta_fields( $fields, $sent_to_admin, $order ) {
		$player = (string) $order->get_meta( '_bmc_mc_player' );

		if ( ! $player ) {
			$player = self::resolve_player( $order );
		}

		if ( $player ) {
			$fields['bmc_player'] = array(
				'label' => 'بازیکن ماینکرافت',
				'value' => $player,
			);
		}

		return $fields;
	}

	public static function admin_order_box( $order ) {
		$player = (string) $order->get_meta( '_bmc_mc_player' );

		if ( ! $player ) {
			$player = self::resolve_player( $order );
		}

		if ( ! $player ) {
			echo '<p class="form-field"><em>بازیکن ماینکرافت ثبت نشده است.</em></p>';
			return;
		}

		printf(
			'<div style="display:flex;align-items:center;gap:10px;margin:8px 0"><img src="%1$s" width="34" height="34" style="border-radius:6px;image-rendering:pixelated" alt="" /><strong>%2$s</strong></div>',
			esc_url( BMC_Helpers::mc_head( $player, 34 ) ),
			esc_html( $player )
		);
	}
}
