<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BMC_SMS_Melipayamak extends BMC_SMS_Driver {

	const API_BASE = 'https://rest.payamak-panel.com/api/SendSMS/';

	const CONSOLE_SIMPLE_DEFAULT = 'https://console.melipayamak.com/api/send/simple/{API_KEY}';

	const CONSOLE_PATTERN_DEFAULT = 'https://console.melipayamak.com/api/send/shared/{API_KEY}';

	public function get_id() {
		return 'melipayamak';
	}

	public function get_label() {
		return 'ملی‌پیامک';
	}

	public function is_configured() {
		if ( 'api_key' === BMC_Settings::mpm_auth_mode() ) {
			return '' !== trim( (string) BMC_Settings::get( 'sms_mpm_api_key' ) );
		}

		return '' !== (string) BMC_Settings::get( 'sms_mpm_username' )
			&& '' !== (string) BMC_Settings::get( 'sms_mpm_password' );
	}

	private function username() {
		return (string) BMC_Settings::get( 'sms_mpm_username' );
	}

	private function password() {
		return (string) BMC_Settings::get( 'sms_mpm_password' );
	}

	private function api_key() {
		return trim( (string) BMC_Settings::get( 'sms_mpm_api_key' ) );
	}

	private function from() {
		return (string) BMC_Settings::get( 'sms_mpm_from' );
	}

	private function is_console() {
		return 'api_key' === BMC_Settings::mpm_auth_mode();
	}

	public function send_code( $to, $code, array $context = array() ) {
		$to = BMC_Helpers::normalize_mobile( $to );

		if ( ! $to ) {
			return $this->fail( 'شمارهٔ موبایل نامعتبر است.' );
		}

		if ( ! $this->is_configured() ) {
			return $this->is_console()
				? $this->fail( 'کلید API ملی‌پیامک در تنظیمات وارد نشده است.' )
				: $this->fail( 'نام کاربری یا رمز عبور ملی‌پیامک در تنظیمات وارد نشده است.' );
		}

		$method = (string) BMC_Settings::get( 'sms_mpm_method', 'pattern' );

		if ( 'otp' === $method && ! $this->is_console() ) {
			return $this->send_otp_native( $to, $code );
		}

		if ( 'simple' === $method || $this->is_console() && 'otp' === $method ) {
			$template = isset( $context['type'] ) && 'login' === $context['type']
				? (string) BMC_Settings::get( 'sms_tpl_login' )
				: (string) BMC_Settings::get( 'sms_tpl_link' );

			$text = BMC_Helpers::replace_tags(
				$template,
				array_merge(
					$context,
					array(
						'{code}'    => BMC_Helpers::to_persian_digits( $code ),
						'{minutes}' => isset( $context['minutes'] ) ? $context['minutes'] : '۲',
					)
				)
			);

			return $this->send_simple( $to, $text );
		}

		$body_id = (string) BMC_Settings::get( 'sms_mpm_body_id' );

		if ( ! $body_id ) {
			return $this->fail( 'کد الگو (bodyId) در تنظیمات پیامک وارد نشده است. یا روش ارسال را به «متن ساده» تغییر دهید.' );
		}

		return $this->send_pattern( $to, array( $code ), $body_id );
	}

	public function send_text( $to, $text ) {
		return $this->send_simple( $to, $text );
	}

	public function send_otp_native( $to, $code ) {
		if ( ! $this->from() ) {
			return $this->fail( 'شمارهٔ فرستنده (from) در تنظیمات ملی‌پیامک وارد نشده است.' );
		}

		$response = $this->http(
			self::API_BASE . 'SendOtp',
			array(
				'username' => $this->username(),
				'password' => $this->password(),
				'to'       => $to,
				'from'     => $this->from(),
				'code'     => (int) BMC_Helpers::to_latin_digits( $code ),
			)
		);

		return $this->interpret( $response, $to );
	}

	public function send_pattern( $to, $params, $body_id ) {
		$values = is_array( $params ) ? array_values( array_map( 'strval', $params ) ) : array( (string) $params );

		if ( $this->is_console() ) {
			return $this->console_request(
				'pattern',
				$to,
				array(
					'bodyId' => (int) $body_id,
					'to'     => (string) $to,
					'args'   => $values ? $values : array( '' ),
				)
			);
		}

		$response = $this->http(
			self::API_BASE . 'BaseServiceNumber',
			array(
				'username' => $this->username(),
				'password' => $this->password(),
				'to'       => $to,
				'text'     => implode( ';', $values ),
				'bodyId'   => (int) $body_id,
			)
		);

		return $this->interpret( $response, $to );
	}

	public function send_simple( $to, $text ) {
		if ( ! $this->from() ) {
			return $this->fail( 'شمارهٔ فرستنده (from) در تنظیمات ملی‌پیامک وارد نشده است.' );
		}

		if ( $this->is_console() ) {
			return $this->console_request(
				'simple',
				$to,
				array(
					'from' => $this->from(),
					'to'   => (string) $to,
					'text' => (string) $text,
				)
			);
		}

		$response = $this->http(
			self::API_BASE . 'SendSMS',
			array(
				'username' => $this->username(),
				'password' => $this->password(),
				'from'     => $this->from(),
				'to'       => $to,
				'text'     => $text,
				'isflash'  => 'false',
			)
		);

		return $this->interpret( $response, $to );
	}

	private function console_endpoint( $type ) {
		$key      = 'pattern' === $type ? 'sms_mpm_pattern_endpoint' : 'sms_mpm_simple_endpoint';
		$default  = 'pattern' === $type ? self::CONSOLE_PATTERN_DEFAULT : self::CONSOLE_SIMPLE_DEFAULT;
		$endpoint = trim( (string) BMC_Settings::get( $key, $default ) );

		if ( '' === $endpoint ) {
			$endpoint = $default;
		}

		return apply_filters( 'bmc_melipayamak_console_endpoint', $endpoint, $type );
	}

	private function console_request( $type, $to, array $body ) {
		$api_key  = $this->api_key();
		$template = $this->console_endpoint( $type );

		if ( '' === $api_key ) {
			return $this->fail( 'کلید API ملی‌پیامک وارد نشده است.' );
		}

		$has_placeholder = false !== stripos( $template, '{API_KEY}' );
		$endpoint        = str_ireplace( '{API_KEY}', rawurlencode( $api_key ), $template );

		if ( ! filter_var( $endpoint, FILTER_VALIDATE_URL ) || 0 !== strpos( $endpoint, 'https://' ) ) {
			return $this->fail( 'آدرس API ملی‌پیامک معتبر نیست.' );
		}

		$body = apply_filters( 'bmc_melipayamak_console_body', $body, $type, $to );

		$headers = array(
			'Accept'       => 'application/json',
			'Content-Type' => 'application/json; charset=utf-8',
		);

		if ( ! $has_placeholder ) {
			$headers['Authorization'] = 'Bearer ' . $api_key;
			$headers['X-API-Key']     = $api_key;
		}

		$response = $this->http_json( $endpoint, $body, $headers );

		return $this->interpret_console( $response, $to );
	}

	private function interpret_console( array $response, $to ) {
		$http_code = isset( $response['code'] ) ? (int) $response['code'] : 0;
		$raw       = isset( $response['body'] ) ? trim( (string) $response['body'] ) : '';

		if ( empty( $response['ok'] ) ) {
			BMC_Logger::add( 'sms', 'خطای ارتباط با کنسول ملی‌پیامک: ' . $response['error'], array( 'to' => $to ), 'error' );
			return $this->fail( 'ارتباط با سامانهٔ پیامک برقرار نشد. (' . $response['error'] . ')' );
		}

		$parsed = self::parse_console_response( $raw, $http_code );

		BMC_Logger::add(
			'sms',
			sprintf( 'پاسخ کنسول ملی‌پیامک برای %s → HTTP %d / %s', $to, $http_code, $parsed['status'] !== '' ? $parsed['status'] : $raw ),
			array(),
			$parsed['success'] ? 'success' : 'error'
		);

		if ( $parsed['success'] ) {
			return $this->ok( 'پیامک ارسال شد.', $parsed['rec_id'] !== '' ? $parsed['rec_id'] : $raw );
		}

		$status = $parsed['status'];

		if ( ctype_digit( (string) $status ) ) {
			return $this->fail( self::error_text( $status ), $raw );
		}

		return $this->fail( $status !== '' ? 'پیامک ارسال نشد: ' . $status : 'پیامک ارسال نشد.', $raw );
	}

	public static function parse_console_response( $raw, $http_code = 0 ) {
		$raw       = trim( (string) $raw );
		$http_code = (int) $http_code;
		$http_ok   = $http_code >= 200 && $http_code < 300;

		$result = array(
			'success' => false,
			'status'  => '',
			'rec_id'  => '',
			'reason'  => '',
			'raw'     => $raw,
		);

		if ( ! $http_ok ) {
			$result['status'] = $http_code ? 'HTTP ' . $http_code : 'HTTP نامشخص';
			$result['reason'] = 'http_error';
		}

		if ( '' === $raw ) {
			$result['status'] = '' !== $result['status'] ? $result['status'] : 'پاسخ خالی';
			$result['reason'] = '' !== $result['reason'] ? $result['reason'] : 'empty_response';
			return $result;
		}

		$json = json_decode( $raw, true );

		if ( ! is_array( $json ) ) {
			$value = trim( (string) strip_tags( $raw ) );

			if ( ctype_digit( $value ) ) {
				$result['success'] = self::is_success_value( $value );
				$result['rec_id']  = $result['success'] ? $value : '';
				$result['status']  = $result['success'] ? '' : self::error_text( $value );
				return $result;
			}

			$result['status'] = '' !== $result['status'] ? $result['status'] : 'پاسخ JSON معتبر نیست';
			$result['reason'] = '' !== $result['reason'] ? $result['reason'] : 'invalid_json';
			return $result;
		}

		$payload = $json;

		foreach ( array( 'data', 'result' ) as $container ) {
			if ( isset( $json[ $container ] ) && is_array( $json[ $container ] )
				&& null !== self::pick( $json[ $container ], array( 'recId', 'RecId', 'recID', 'rec_id' ) ) ) {
				$payload = $json[ $container ];
				break;
			}
		}

		$rec_id = self::pick( $payload, array( 'recId', 'RecId', 'recID', 'rec_id' ) );

		if ( null === $rec_id ) {
			$rec_id = self::pick( $payload, array( 'Value', 'value' ) );
		}

		if ( is_scalar( $rec_id ) ) {
			$result['rec_id'] = trim( (string) $rec_id );
		}

		$error_value = self::pick( $payload, array( 'error', 'Error' ) );

		if ( null === $error_value ) {
			$error_value = self::pick( $json, array( 'error', 'Error' ) );
		}

		if ( null !== $error_value && '' !== $error_value && false !== $error_value && 0 !== $error_value && '0' !== $error_value ) {
			$result['status'] = is_scalar( $error_value ) ? trim( (string) $error_value ) : wp_json_encode( $error_value );
			$result['reason'] = 'api_error';
			return $result;
		}

		$status_value = self::pick( $payload, array( 'status', 'Status' ) );

		if ( null === $status_value ) {
			$status_value = self::pick( $json, array( 'status', 'Status' ) );
		}

		$status_text = is_scalar( $status_value ) ? self::normalize_status( (string) $status_value ) : '';

		if ( ! self::status_is_success( $status_text ) ) {
			$result['status'] = $status_text;
			$result['reason'] = 'api_status_error';
			return $result;
		}

		if ( '' !== $result['rec_id'] && ( ctype_digit( $result['rec_id'] ) || is_numeric( $result['rec_id'] ) ) ) {
			$result['success'] = (float) $result['rec_id'] > 0;
			$result['status']  = $result['success'] ? '' : 'شناسهٔ ارسال نامعتبر است.';
			return $result;
		}

		if ( '' !== $result['rec_id'] ) {
			$result['success'] = true;
			return $result;
		}

		$result['status'] = 'شناسه ارسال معتبر (recId) در پاسخ وجود ندارد.';
		$result['reason'] = 'missing_rec_id';

		return $result;
	}

	private static function pick( $array, $keys ) {
		if ( ! is_array( $array ) ) {
			return null;
		}

		foreach ( (array) $keys as $key ) {
			if ( array_key_exists( $key, $array ) ) {
				return $array[ $key ];
			}
		}

		return null;
	}

	public static function normalize_status( $value ) {
		$value = trim( (string) $value );

		if ( '' === $value ) {
			return '';
		}

		$value = str_replace( array( "\xE2\x80\x8C", "\xE2\x80\x8F", "\xE2\x80\x8E", "\xC2\xA0" ), ' ', $value );
		$value = str_replace( array( 'ي', 'ى', 'ك' ), array( 'ی', 'ی', 'ک' ), $value );
		$value = preg_replace( '/\s+/u', ' ', $value );

		return trim( (string) $value );
	}

	public static function status_is_success( $status_text ) {
		$status_text = self::normalize_status( $status_text );

		if ( '' === $status_text ) {
			return true;
		}

		$lower = strtolower( $status_text );

		if ( in_array( $lower, array( 'ok', 'success', 'successful', 'sent', 'accepted', 'true' ), true ) ) {
			return true;
		}

		return in_array(
			$status_text,
			array(
				'موفق',
				'عملیات موفق',
				'عملیات موفق است',
				'موفقیت آمیز',
				'موفقیت‌آمیز',
				'ارسال موفق',
				'ارسال موفق بود',
				'ارسال شد',
			),
			true
		);
	}

	private function interpret( array $response, $to ) {
		if ( empty( $response['ok'] ) ) {
			BMC_Logger::add( 'sms', 'خطای ارتباط با ملی‌پیامک: ' . $response['error'], array( 'to' => $to ), 'error' );
			return $this->fail( 'ارتباط با سامانهٔ پیامک برقرار نشد. (' . $response['error'] . ')' );
		}

		$body  = trim( (string) $response['body'] );
		$code  = (int) $response['code'];
		$value = trim( (string) strip_tags( $body ) );

		BMC_Logger::add(
			'sms',
			sprintf( 'پاسخ ملی‌پیامک برای %s → HTTP %d / %s', $to, $code, $value ),
			array(),
			200 === $code && self::is_success_value( $value ) ? 'success' : 'error'
		);

		if ( 200 !== $code ) {
			return $this->fail( 'سامانهٔ پیامک پاسخ غیرمنتظره داد (HTTP ' . $code . ').', $body );
		}

		if ( self::is_success_value( $value ) ) {
			return $this->ok( 'پیامک ارسال شد.', $value );
		}

		return $this->fail( self::error_text( $value ), $body );
	}

	public static function is_success_value( $value ) {
		$value = trim( (string) $value );

		if ( ! ctype_digit( $value ) ) {
			return false;
		}

		return strlen( $value ) >= 10 && (int) $value > 0;
	}

	public static function error_text( $value ) {
		$map = array(
			'-111' => 'IP درخواست‌کننده نامعتبر است.',
			'-110' => 'سامانه الزام کرده از ApiKey به‌جای رمز عبور استفاده کنید (حالت «کلید API» را در تنظیمات فعال کنید).',
			'-109' => 'باید IP سرور خود را در پنل ملی‌پیامک مجاز کنید.',
			'-108' => 'IP به دلیل تلاش‌های ناموفق مسدود شده است.',
			'-10'  => 'در متغیرهای ارسالی لینک وجود دارد.',
			'-7'   => 'خطا در شمارهٔ فرستنده.',
			'-6'   => 'خطای داخلی سامانه.',
			'-5'   => 'متن ارسالی با متغیرهای الگو همخوانی ندارد.',
			'-4'   => 'کد الگو (bodyId) نامعتبر یا تأیید نشده است.',
			'-3'   => 'خط ارسال در سامانه تعریف نشده است.',
			'-2'   => 'فقط یک شماره در هر ارسال مجاز است.',
			'-1'   => 'دسترسی وب‌سرویس غیرفعال است.',
			'0'    => 'نام کاربری یا رمز عبور پنل اشتباه است.',
			'2'    => 'اعتبار پنل پیامکی کافی نیست.',
			'3'    => 'محدودیت ارسال روزانه.',
			'4'    => 'محدودیت حجم ارسال.',
			'5'    => 'شمارهٔ فرستنده معتبر نیست.',
			'6'    => 'سامانه در حال بروزرسانی است.',
			'7'    => 'متن حاوی کلمهٔ فیلترشده است.',
			'9'    => 'ارسال از خطوط عمومی از طریق وب‌سرویس ممکن نیست.',
			'10'   => 'کاربر فعال نیست.',
			'11'   => 'ارسال انجام نشد.',
			'12'   => 'مدارک کاربری کامل نیست.',
			'14'   => 'متن حاوی لینک است.',
			'15'   => 'ارسال به بیش از یک شماره بدون درج «لغو11» ممکن نیست.',
			'16'   => 'شمارهٔ گیرنده یافت نشد.',
			'17'   => 'متن پیامک خالی است.',
			'18'   => 'شمارهٔ گیرنده نامعتبر است.',
			'19'   => 'از محدودیت ساعتی فراتر رفته‌اید.',
			'35'   => 'شمارهٔ گیرنده در لیست سیاه مخابرات است.',
		);

		$value = trim( (string) $value );

		return isset( $map[ $value ] ) ? 'پیامک ارسال نشد: ' . $map[ $value ] : 'پیامک ارسال نشد (کد ' . $value . ').';
	}
}
