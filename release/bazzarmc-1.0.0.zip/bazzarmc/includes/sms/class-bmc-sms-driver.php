<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

abstract class BMC_SMS_Driver {

	abstract public function get_id();

	abstract public function get_label();

	abstract public function is_configured();

	abstract public function send_code( $to, $code, array $context = array() );

	abstract public function send_text( $to, $text );

	protected function http( $url, array $body = array(), $method = 'POST' ) {
		$args = array(
			'timeout'   => 15,
			'method'    => $method,
			'headers'   => array( 'Content-Type' => 'application/x-www-form-urlencoded; charset=UTF-8' ),
			'sslverify' => BMC_Settings::ssl_verify(),
		);

		if ( $body ) {
			$args['body'] = http_build_query( $body );
		}

		$args = apply_filters( 'bmc_sms_http_args', $args, $url, $this->get_id() );

		$response = wp_remote_request( $url, $args );

		if ( is_wp_error( $response ) ) {
			return array(
				'ok'     => false,
				'error'  => $response->get_error_message(),
				'code'   => 0,
				'body'   => '',
			);
		}

		return array(
			'ok'   => true,
			'code' => (int) wp_remote_retrieve_response_code( $response ),
			'body' => (string) wp_remote_retrieve_body( $response ),
		);
	}

	protected function http_json( $url, array $body = array(), array $headers = array() ) {
		$json = wp_json_encode( $body, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES );

		if ( false === $json ) {
			return array(
				'ok'    => false,
				'error' => 'ساخت دادهٔ JSON ناموفق بود.',
				'code'  => 0,
				'body'  => '',
			);
		}

		$args = array(
			'timeout'   => 30,
			'method'    => 'POST',
			'headers'   => $headers,
			'body'      => $json,
			'sslverify' => BMC_Settings::ssl_verify(),
		);

		$args = apply_filters( 'bmc_sms_http_args', $args, $url, $this->get_id() );

		$response = wp_remote_request( $url, $args );

		if ( is_wp_error( $response ) ) {
			return array(
				'ok'    => false,
				'error' => $response->get_error_message(),
				'code'  => 0,
				'body'  => '',
			);
		}

		return array(
			'ok'   => true,
			'code' => (int) wp_remote_retrieve_response_code( $response ),
			'body' => (string) wp_remote_retrieve_body( $response ),
		);
	}

	protected function ok( $message = 'ارسال شد.', $raw = null ) {
		return array(
			'success' => true,
			'message' => $message,
			'raw'     => $raw,
			'driver'  => $this->get_id(),
		);
	}

	protected function fail( $message, $raw = null ) {
		return array(
			'success' => false,
			'message' => $message,
			'raw'     => $raw,
			'driver'  => $this->get_id(),
		);
	}
}
