<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BMC_SMS_EZLogin extends BMC_SMS_Driver {

	public function get_id() {
		return 'ezlogin';
	}

	public function get_label() {
		return 'EZ-Login (ایزی لاگین)';
	}

	public function is_configured() {
		return BMC_EZLogin::is_active()
			&& function_exists( 'ez_send_sms' )
			&& BMC_EZLogin::credentials_ready();
	}

	public function send_code( $to, $code, array $context = array() ) {
		$to = BMC_EZLogin::normalize_phone( $to );

		if ( ! $to ) {
			return $this->fail( 'شمارهٔ موبایل نامعتبر است.' );
		}

		if ( ! $this->is_configured() ) {
			return $this->fail( 'افزونهٔ EZ-Login فعال یا پیکربندی نشده است.' );
		}

		$type = isset( $context['type'] ) ? (string) $context['type'] : 'link';

		switch ( $type ) {
			case 'login':
				$template = (string) BMC_Settings::get( 'sms_tpl_login' );
				break;
			case 'delivery':
				$template = (string) BMC_Settings::get( 'sms_tpl_delivery' );
				break;
			case 'welcome':
				$template = (string) BMC_Settings::get( 'sms_tpl_welcome' );
				break;
			default:
				$template = (string) BMC_Settings::get( 'sms_tpl_link' );
		}

		$ttl      = isset( $context['ttl'] ) ? (int) $context['ttl'] : BMC_EZLogin::otp_ttl();
		$minutes  = BMC_Helpers::to_persian_digits( max( 1, (int) ceil( $ttl / 60 ) ) );

		$text = BMC_Helpers::replace_tags(
			$template,
			array_merge(
				$context,
				array(
					'{code}'    => BMC_Helpers::to_persian_digits( $code ),
					'{minutes}' => isset( $context['minutes'] ) ? $context['minutes'] : $minutes,
				)
			)
		);

		$result = $this->dispatch( $to, $text, (string) $code, false );

		return $result;
	}

	public function send_text( $to, $text ) {
		$to = BMC_EZLogin::normalize_phone( $to );

		if ( ! $to ) {
			return $this->fail( 'شمارهٔ موبایل نامعتبر است.' );
		}

		if ( ! $this->is_configured() ) {
			return $this->fail( 'افزونهٔ EZ-Login فعال یا پیکربندی نشده است.' );
		}

		return $this->dispatch( $to, (string) $text, '', true );
	}

	private function dispatch( $to, $text, $code, $force_text ) {
		try {
			$result = ez_send_sms( $to, $text, $code, (bool) $force_text );
		} catch ( Exception $exception ) {
			BMC_Logger::add( 'sms', 'خطای EZ-Login: ' . $exception->getMessage(), array( 'to' => $to ), 'error' );
			return $this->fail( 'خطا در ارسال پیامک از مسیر EZ-Login.' );
		}

		if ( is_wp_error( $result ) ) {
			$message = $result->get_error_message();

			BMC_Logger::add(
				'sms',
				'EZ-Login → خطا برای ' . $to . ': ' . $message,
				array( 'code' => $result->get_error_code() ),
				'error'
			);

			return $this->fail( $message ? $message : 'ارسال پیامک ناموفق بود.' );
		}

		if ( false === $result || null === $result ) {
			BMC_Logger::add( 'sms', 'EZ-Login → پاسخ ناموفق برای ' . $to, array(), 'error' );
			return $this->fail( 'ارسال پیامک ناموفق بود (EZ-Login).' );
		}

		BMC_Logger::add(
			'sms',
			'EZ-Login → ارسال موفق برای ' . $to,
			array(
				'mode'       => BMC_EZLogin::auth_mode(),
				'send_mode'  => $force_text ? 'text' : BMC_EZLogin::send_mode(),
			),
			'success'
		);

		return $this->ok( 'پیامک از مسیر EZ-Login ارسال شد.', $result );
	}
}
