<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BMC_SMS_Email extends BMC_SMS_Driver {

	public function get_id() {
		return 'email';
	}

	public function get_label() {
		return 'ایمیل (wp_mail)';
	}

	public function is_configured() {
		return BMC_Settings::bool( 'email_enabled', true );
	}

	public function send_code( $to, $code, array $context = array() ) {
		$email = BMC_Helpers::sanitize_email( $to );

		if ( ! $email ) {
			return $this->fail( 'ایمیل نامعتبر است.' );
		}

		$repl = array_merge(
			$context,
			array(
				'{code}'    => $code,
				'{minutes}' => isset( $context['minutes'] ) ? $context['minutes'] : '۵',
				'{player}'  => isset( $context['player'] ) ? $context['player'] : '',
			)
		);

		$subject = BMC_Helpers::replace_tags( (string) BMC_Settings::get( 'email_tpl_subject' ), $repl );
		$body    = BMC_Helpers::replace_tags( (string) BMC_Settings::get( 'email_tpl_body' ), $repl );

		$sent = $this->mail( $email, $subject, $body );

		if ( ! $sent ) {
			BMC_Logger::add( 'sms', 'ارسال ایمیل کد به ' . $email . ' ناموفق بود', array(), 'error' );
			return $this->fail( 'ارسال ایمیل ناموفق بود. تنظیمات SMTP هاست را بررسی کنید.' );
		}

		return $this->ok( 'ایمیل ارسال شد.', $email );
	}

	public function send_text( $to, $text ) {
		$email = BMC_Helpers::sanitize_email( $to );

		if ( ! $email ) {
			return $this->fail( 'ایمیل نامعتبر است.' );
		}

		$site = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$sent = $this->mail( $email, $site, wpautop( $text ) );

		return $sent ? $this->ok( 'ایمیل ارسال شد.' ) : $this->fail( 'ارسال ایمیل ناموفق بود.' );
	}

	private function mail( $to, $subject, $body ) {
		$wrapped = '<div dir="rtl" style="font-family:Tahoma,sans-serif;max-width:560px;margin:0 auto;border:1px solid #e5e7eb;border-radius:14px;overflow:hidden">'
			. '<div style="background:#0f1720;color:#fff;padding:18px 22px;font-size:15px">' . esc_html( wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) ) . '</div>'
			. '<div style="padding:22px;background:#fff;color:#1f2933;font-size:14px;line-height:2">' . wp_kses_post( $body ) . '</div>'
			. '</div>';

		add_filter( 'wp_mail_content_type', array( __CLASS__, 'content_type_html' ) );
		$sent = wp_mail( $to, $subject, $wrapped );
		remove_filter( 'wp_mail_content_type', array( __CLASS__, 'content_type_html' ) );

		return (bool) $sent;
	}

	public static function content_type_html() {
		return 'text/html';
	}
}
