<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Auth {

	const CODE_TYPE = 'otp_login';

	const KNOWN_META_KEYS = array(
		'bmc_mobile',
		'mobile',
		'billing_phone',
		'digits_number',
		'digits_number_no',
		'digcell',
		'digits_mobile',
		'easylogin_mobile',
		'bilacell_mobile',
		'wp_sms_mobile',
		'darvaze_mobile',
		'user_mobile',
		'phone',
	);

	public static function init() {
		add_action( 'wp_ajax_nopriv_bmc_login_request', array( __CLASS__, 'ajax_login_request' ) );
		add_action( 'wp_ajax_bmc_login_request', array( __CLASS__, 'ajax_login_request' ) );
		add_action( 'wp_ajax_nopriv_bmc_login_verify', array( __CLASS__, 'ajax_login_verify' ) );
		add_action( 'wp_ajax_bmc_login_verify', array( __CLASS__, 'ajax_login_verify' ) );
		add_action( 'wp_ajax_nopriv_bmc_login_resend', array( __CLASS__, 'ajax_login_request' ) );
		add_action( 'wp_ajax_bmc_login_resend', array( __CLASS__, 'ajax_login_request' ) );

		add_filter( 'woocommerce_checkout_get_value', array( __CLASS__, 'autofill_billing_phone' ), 10, 2 );
	}

	public static function meta_keys() {
		$configured = (array) BMC_Settings::get( 'mobile_meta_keys', array() );
		$keys       = array_merge( $configured, self::KNOWN_META_KEYS );
		$keys       = array_values( array_unique( array_filter( array_map( 'sanitize_key', $keys ) ) ) );

		return apply_filters( 'bmc_mobile_meta_keys', $keys );
	}

	public static function get_user_mobile( $user_id ) {
		$user_id = (int) $user_id;
		if ( ! $user_id ) {
			return '';
		}

		$own = BMC_Helpers::normalize_mobile( get_user_meta( $user_id, 'bmc_mobile', true ) );
		if ( $own ) {
			return $own;
		}

		foreach ( self::meta_keys() as $key ) {
			$value = get_user_meta( $user_id, $key, true );
			if ( is_array( $value ) ) {
				$value = reset( $value );
			}
			$mobile = BMC_Helpers::normalize_mobile( (string) $value );
			if ( $mobile ) {
				return $mobile;
			}
		}

		if ( function_exists( 'wc_get_orders' ) ) {
			$orders = wc_get_orders(
				array(
					'customer_id' => $user_id,
					'limit'       => 3,
					'orderby'     => 'date',
					'order'       => 'DESC',
					'return'      => 'ids',
				)
			);

			foreach ( (array) $orders as $order_id ) {
				$order = wc_get_order( $order_id );
				if ( $order ) {
					$mobile = BMC_Helpers::normalize_mobile( (string) $order->get_billing_phone() );
					if ( $mobile ) {
						return $mobile;
					}
				}
			}
		}

		return '';
	}

	public static function set_user_mobile( $user_id, $mobile ) {
		$mobile = BMC_Helpers::normalize_mobile( $mobile );
		if ( ! $mobile || ! $user_id ) {
			return false;
		}

		update_user_meta( (int) $user_id, 'bmc_mobile', $mobile );

		if ( ! get_user_meta( (int) $user_id, 'billing_phone', true ) ) {
			update_user_meta( (int) $user_id, 'billing_phone', $mobile );
		}

		return true;
	}

	public static function find_user_by_mobile( $mobile ) {
		global $wpdb;

		$mobile = BMC_Helpers::normalize_mobile( $mobile );
		if ( ! $mobile ) {
			return null;
		}

		$variants = BMC_Helpers::mobile_variants( $mobile );
		$keys     = self::meta_keys();

		if ( ! $variants || ! $keys ) {
			return null;
		}

		$in_keys     = "'" . implode( "','", array_map( 'esc_sql', $keys ) ) . "'";
		$in_variants = "'" . implode( "','", array_map( 'esc_sql', $variants ) ) . "'";

		$user_id = (int) $wpdb->get_var(
			"SELECT user_id FROM {$wpdb->usermeta}
			 WHERE meta_key IN ({$in_keys})
			   AND TRIM(meta_value) IN ({$in_variants})
			 ORDER BY (meta_key = 'bmc_mobile') DESC, user_id ASC
			 LIMIT 1"
		);

		if ( ! $user_id ) {

			$user = get_user_by( 'login', $mobile );
			if ( $user ) {
				return $user;
			}
			$user = get_user_by( 'login', substr( $mobile, 1 ) );
			return $user ? $user : null;
		}

		return get_userdata( $user_id );
	}

	public static function mask_mobile( $mobile ) {
		$mobile = BMC_Helpers::to_latin_digits( (string) $mobile );
		if ( strlen( $mobile ) < 7 ) {
			return $mobile;
		}
		return substr( $mobile, 0, 4 ) . '***' . substr( $mobile, -4 );
	}

	public static function mask_email( $email ) {
		$parts = explode( '@', (string) $email );
		if ( 2 !== count( $parts ) ) {
			return $email;
		}
		$name   = $parts[0];
		$masked = strlen( $name ) > 2 ? substr( $name, 0, 2 ) . '***' : $name . '***';
		return $masked . '@' . $parts[1];
	}

	public static function autofill_billing_phone( $value, $input ) {
		if ( 'billing_phone' === $input && ! $value && is_user_logged_in() && BMC_Settings::bool( 'otp_auto_fill_mobile', true ) ) {
			$mobile = self::get_user_mobile( get_current_user_id() );
			if ( $mobile ) {
				return $mobile;
			}
		}
		return $value;
	}

	public static function detected_integrations() {
		$candidates = array(
			'ایزی‌لاگین (Bigersoft)' => array( 'easylogin/easylogin.php', 'easy-login/easy-login.php', 'bigersoft-easylogin/easylogin.php' ),
			'دیجیتس (Digits)'        => array( 'digits/digits.php' ),
			'دروازه (Kamangir)'      => array( 'darvaze/darvaze.php', 'kamangir-darvaze/darvaze.php' ),
			'WP SMS'                 => array( 'wp-sms/wp-sms.php' ),
			'پیامیتو'                => array( 'payamito/payamito.php', 'payamito-plus/payamito-plus.php' ),
		);

		$active  = (array) get_option( 'active_plugins', array() );
		$network = (array) get_site_option( 'active_sitewide_plugins', array() );
		$all     = array_merge( $active, array_keys( $network ) );

		$found = array();

		foreach ( $candidates as $label => $slugs ) {
			foreach ( $slugs as $slug ) {
				if ( in_array( $slug, $all, true ) ) {
					$found[ $label ] = $slug;
					break;
				}
			}
		}

		return $found;
	}

	public static function should_defer_to_external() {
		$mode = (string) BMC_Settings::get( 'use_external_login', 'auto' );

		if ( 'yes' === $mode ) {
			return true;
		}

		if ( 'no' === $mode ) {
			return false;
		}

		return false;
	}

	public static function login_url() {
		$page_id = (int) BMC_Settings::get( 'page_login', 0 );

		if ( $page_id ) {
			return (string) get_permalink( $page_id );
		}

		if ( function_exists( 'wc_get_page_permalink' ) ) {
			return (string) wc_get_page_permalink( 'myaccount' );
		}

		return wp_login_url();
	}

	public static function request_login_otp( $mobile, $resend = false, $channel = '' ) {
		if ( ! BMC_Settings::bool( 'otp_login', true ) ) {
			return self::error( 'ورود با شماره موبایل توسط مدیر سایت غیرفعال شده است.', 'DISABLED' );
		}

		$mobile = BMC_Helpers::normalize_mobile( $mobile );

		if ( ! $mobile ) {
			return self::error( 'شمارهٔ موبایل را به‌درست وارد کنید (مثال: ۰۹۱۲۳۴۵۶۷۸۹).', 'FORMAT' );
		}

		if ( self::is_locked( $mobile ) ) {
			return self::error( 'به دلیل تلاش‌های ناموفق زیاد، این شماره موقتاً قفل شده است. ۱۰ دقیقه دیگر تلاش کنید.', 'LOCKED' );
		}

		$rl_ip = 'bmc_rl_login_ip_' . BMC_Helpers::ip_hash();
		if ( get_transient( $rl_ip ) ) {
			return self::error( 'تعداد درخواست‌ها از این اتصال زیاد است. کمی صبر کنید.', 'RATE' );
		}

		$user   = self::find_user_by_mobile( $mobile );
		$ttl    = BMC_Settings::int( 'sms_otp_ttl', 120, 30, 900 );
		$exists = (bool) $user;

		if ( ! $user && ! BMC_Settings::bool( 'otp_register_new', true ) ) {
			return self::error( 'حسابی با این شماره در سایت ثبت نشده است.', 'NO_USER' );
		}

		$rl_mobile = 'bmc_rl_login_m_' . md5( $mobile );
		if ( ! $resend && get_transient( $rl_mobile ) ) {

		}

		$active = self::get_active_login_code( $mobile );

		if ( $active && $resend && ( BMC_Helpers::now_timestamp() - strtotime( $active['created_at'] ) ) < 60 ) {
			return self::error( 'کمتر از یک دقیقه از ارسال کد گذشته است.', 'RATE' );
		}

		self::revoke_login_codes( $mobile );

		$code     = BMC_Helpers::random_otp( BMC_Settings::int( 'sms_otp_length', 5, 4, 8 ) );
		$user_id  = $user ? (int) $user->ID : 0;

		$inserted = self::insert_login_code( $mobile, $code, $user_id, $ttl );

		if ( ! $inserted ) {
			return self::error( 'ذخیرهٔ کد ناموفق بود. دوباره تلاش کنید.', 'DB' );
		}

		$sent = BMC_Verify::send(
			'otp_login',
			$mobile,
			$code,
			array(
				'type'    => 'login',
				'user'    => $user,
				'ttl'     => $ttl,
				'minutes' => BMC_Helpers::to_persian_digits( max( 1, (int) ceil( $ttl / 60 ) ) ),
				'email'   => $user ? $user->user_email : '',
			),
			$channel,
			$user_id
		);

		if ( empty( $sent['success'] ) ) {
			self::revoke_login_codes( $mobile );
			BMC_Logger::add( 'auth', 'ارسال کد ورود ناموفق: ' . $sent['message'], array( 'mobile' => self::mask_mobile( $mobile ) ), 'error' );
			return self::error( $sent['message'], isset( $sent['code'] ) ? $sent['code'] : 'SEND_FAIL' );
		}

		set_transient( $rl_ip, 1, BMC_Settings::int( 'sms_rate_limit', 120, 10, 3600 ) );
		set_transient( $rl_mobile, 1, 120 );

		BMC_Logger::add( 'auth', 'کد ورود ارسال شد', array( 'mobile' => self::mask_mobile( $mobile ), 'channel' => $sent['channel'] ), 'info' );

		$channel_labels = BMC_Verify::labels();
		$channel_label  = isset( $channel_labels[ $sent['channel'] ] ) ? $channel_labels[ $sent['channel'] ] : $sent['channel'];

		$response = array(
			'success'    => true,
			'message'    => sprintf( 'کد %d رقمی از راه %s برای %s ارسال شد.', BMC_Settings::int( 'sms_otp_length', 5, 4, 8 ), $channel_label, self::mask_mobile( $mobile ) ),
			'masked'     => self::mask_mobile( $mobile ),
			'expires_in' => $ttl,
			'channel'    => $sent['channel'],
			'is_new'     => ! $exists,
		);

		if ( ! empty( $sent['code'] ) ) {
			$response['code'] = $sent['code'];
		}

		return $response;
	}

	public static function verify_login_otp( $mobile, $code ) {
		$mobile = BMC_Helpers::normalize_mobile( $mobile );
		$code   = BMC_Helpers::to_latin_digits( trim( (string) $code ) );

		if ( ! $mobile ) {
			return self::error( 'شمارهٔ موبایل نامعتبر است.', 'FORMAT' );
		}

		if ( self::is_locked( $mobile ) ) {
			return self::error( 'این شماره به‌دلیل تلاش‌های ناموفق قفل شده است.', 'LOCKED' );
		}

		$active = self::get_active_login_code( $mobile );

		if ( ! $active ) {
			return self::error( 'کد فعالی برای این شماره وجود ندارد. ابتدا کد دریافت کنید.', 'EXPIRED' );
		}

		if ( ! BMC_Helpers::equals( BMC_Helpers::hash_code( $code ), $active['code_hash'] ) ) {
			self::bump_login_attempts( (int) $active['id'] );

			$attempts = (int) $active['attempts'] + 1;
			$limit    = BMC_Settings::int( 'otp_lock_after', 5, 1, 50 );

			if ( $attempts >= $limit ) {
				self::lock_mobile( $mobile );
				self::revoke_login_codes( $mobile );
				return self::error( 'تعداد تلاش‌های ناموفق بیش از حد مجاز شد. ۱۰ دقیقه دیگر تلاش کنید.', 'LOCKED' );
			}

			return self::error(
				sprintf( 'کد واردشده درست نیست. %d تلاش دیگر باقی مانده است.', $limit - $attempts ),
				'INVALID'
			);
		}

		self::consume_login_code( (int) $active['id'] );

		$user = self::find_user_by_mobile( $mobile );

		if ( ! $user ) {
			if ( ! BMC_Settings::bool( 'otp_register_new', true ) ) {
				return self::error( 'حسابی با این شماره وجود ندارد.', 'NO_USER' );
			}

			$user = self::register_user( $mobile );

			if ( is_wp_error( $user ) ) {
				BMC_Logger::add( 'auth', 'ساخت کاربر جدید ناموفق: ' . $user->get_error_message(), array(), 'error' );
				return self::error( 'ساخت حساب کاربری ناموفق بود. با پشتیبانی تماس بگیرید.', 'REGISTER' );
			}
		}

		self::set_user_mobile( $user->ID, $mobile );

		wp_set_current_user( $user->ID );
		wp_set_auth_cookie( $user->ID, true, is_ssl() );

		do_action( 'bmc_otp_login', $user, $mobile );

		BMC_Logger::add( 'auth', sprintf( 'ورود موفق کاربر #%d با موبایل', $user->ID ), array(), 'success' );

		$redirect = self::redirect_after_login();

		return array(
			'success'      => true,
			'message'      => 'ورود موفق بود. در حال انتقال…',
			'redirect'     => $redirect,
			'display_name' => $user->display_name,
		);
	}

	private static function register_user( $mobile ) {
		$base_login = 'user' . substr( (string) $mobile, -7 );
		$login      = $base_login;
		$i          = 1;

		while ( username_exists( $login ) ) {
			$login = $base_login . $i;
			$i++;
			if ( $i > 999 ) {
				return new WP_Error( 'username', 'ساخت نام کاربری ممکن نشد.' );
			}
		}

		$userdata = array(
			'user_login' => $login,
			'user_pass'  => wp_generate_password( 24, true, true ),
			'user_email' => '',
			'role'       => (string) BMC_Settings::get( 'otp_default_role', 'customer' ),
			'first_name' => '',
		);

		$user_id = wp_insert_user( $userdata );

		if ( is_wp_error( $user_id ) ) {

			$userdata['user_email'] = $login . '@' . preg_replace( '/^www\./', '', parse_url( home_url(), PHP_URL_HOST ) );
			$user_id                = wp_insert_user( $userdata );
		}

		if ( is_wp_error( $user_id ) ) {
			return $user_id;
		}

		self::set_user_mobile( $user_id, $mobile );

		do_action( 'bmc_otp_registered', $user_id, $mobile );

		BMC_Logger::add( 'auth', sprintf( 'کاربر جدید #%d با موبایل ثبت شد', $user_id ), array(), 'success' );

		return get_userdata( $user_id );
	}

	public static function redirect_after_login() {
		$custom = (string) BMC_Settings::get( 'otp_login_redirect' );

		if ( $custom ) {
			return esc_url_raw( $custom );
		}

		if ( isset( $_REQUEST['redirect_to'] ) ) {
			$target = esc_url_raw( wp_unslash( $_REQUEST['redirect_to'] ) );
			if ( $target && 0 === strpos( $target, home_url() ) ) {
				return $target;
			}
		}

		if ( function_exists( 'wc_get_page_permalink' ) ) {
			return (string) wc_get_page_permalink( 'myaccount' );
		}

		return home_url( '/' );
	}

	private static function insert_login_code( $mobile, $code, $user_id, $ttl ) {
		global $wpdb;

		$table = BMC_DB::table( 'codes' );

		$ok = $wpdb->insert(
			$table,
			array(
				'type'       => self::CODE_TYPE,
				'user_id'    => (int) $user_id,
				'identifier' => 'mobile:' . $mobile,
				'player'     => '',
				'code_hash'  => BMC_Helpers::hash_code( $code ),
				'attempts'   => 0,
				'status'     => 0,
				'ip_hash'    => BMC_Helpers::ip_hash(),
				'channel'    => 'sms',
				'created_at' => current_time( 'mysql' ),
				'expires_at' => BMC_Helpers::expires_at( $ttl ),
			),
			array( '%s', '%d', '%s', '%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s' )
		);

		if ( false === $ok ) {
			return false;
		}

		return array(
			'id' => (int) $wpdb->insert_id,
		);
	}

	private static function get_active_login_code( $mobile ) {
		global $wpdb;

		$table = BMC_DB::table( 'codes' );
		$now   = current_time( 'mysql' );

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, code_hash, attempts, status, created_at, expires_at FROM {$table}
				 WHERE type = %s AND identifier = %s AND status = 0 AND expires_at >= %s
				 ORDER BY id DESC LIMIT 1",
				self::CODE_TYPE,
				'mobile:' . $mobile,
				$now
			),
			ARRAY_A
		);

		return $row ? $row : null;
	}

	private static function bump_login_attempts( $id ) {
		global $wpdb;
		$table = BMC_DB::table( 'codes' );
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET attempts = attempts + 1 WHERE id = %d", (int) $id ) );
	}

	private static function consume_login_code( $id ) {
		global $wpdb;
		$table = BMC_DB::table( 'codes' );
		$wpdb->update( $table, array( 'status' => 1, 'consumed_at' => current_time( 'mysql' ) ), array( 'id' => (int) $id ), array( '%d', '%s' ), array( '%d' ) );
	}

	private static function revoke_login_codes( $mobile ) {
		global $wpdb;
		$table = BMC_DB::table( 'codes' );
		$wpdb->query(
			$wpdb->prepare( "UPDATE {$table} SET status = 2 WHERE type = %s AND identifier = %s AND status = 0", self::CODE_TYPE, 'mobile:' . $mobile )
		);
	}

	private static function lock_mobile( $mobile ) {
		set_transient( 'bmc_lock_' . md5( $mobile ), 1, 10 * MINUTE_IN_SECONDS );
	}

	public static function is_locked( $mobile ) {
		return (bool) get_transient( 'bmc_lock_' . md5( $mobile ) );
	}

	public static function ajax_login_request() {
		self::check_public_nonce();

		$mobile  = isset( $_POST['mobile'] ) ? sanitize_text_field( wp_unslash( $_POST['mobile'] ) ) : '';
		$resend  = ! empty( $_POST['resend'] );
		$channel = isset( $_POST['channel'] ) ? sanitize_key( wp_unslash( $_POST['channel'] ) ) : '';

		$result = self::request_login_otp( $mobile, $resend, $channel );

		if ( empty( $result['success'] ) ) {
			wp_send_json_error( $result, 400 );
		}

		wp_send_json_success( $result );
	}

	public static function ajax_login_verify() {
		self::check_public_nonce();

		$mobile = isset( $_POST['mobile'] ) ? sanitize_text_field( wp_unslash( $_POST['mobile'] ) ) : '';
		$code   = isset( $_POST['code'] ) ? sanitize_text_field( wp_unslash( $_POST['code'] ) ) : '';

		$result = self::verify_login_otp( $mobile, $code );

		if ( empty( $result['success'] ) ) {
			wp_send_json_error( $result, 400 );
		}

		wp_send_json_success( $result );
	}

	private static function check_public_nonce() {
		$nonce = isset( $_REQUEST['security'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['security'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, 'bmc_public' ) ) {
			wp_send_json_error( array( 'message' => 'نشست نامعتبر است. صفحه را تازه کنید.' ), 403 );
		}
	}

	private static function error( $message, $code = 'ERROR' ) {
		return array(
			'success' => false,
			'message' => $message,
			'code'    => $code,
		);
	}
}
