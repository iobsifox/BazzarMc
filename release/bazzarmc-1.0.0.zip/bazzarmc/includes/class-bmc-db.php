<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_DB {

	public static function table( $name ) {
		global $wpdb;
		$allowed = array( 'deliveries', 'codes', 'logs' );
		if ( ! in_array( $name, $allowed, true ) ) {
			return $wpdb->prefix . 'bmc_deliveries';
		}
		return $wpdb->prefix . 'bmc_' . $name;
	}

	public static function install() {
		global $wpdb;

		$charset = $wpdb->get_charset_collate();
		require_once ABSPATH . 'wp-admin/includes/upgrade.php';

		$deliveries = self::table( 'deliveries' );
		dbDelta(
			"CREATE TABLE {$deliveries} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				order_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				player VARCHAR(32) NOT NULL DEFAULT '',
				player_uuid CHAR(32) NOT NULL DEFAULT '',
				product_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				variation_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				item VARCHAR(190) NOT NULL DEFAULT '',
				delivery_key VARCHAR(190) NOT NULL DEFAULT '',
				slug VARCHAR(190) NOT NULL DEFAULT '',
				sku VARCHAR(64) NOT NULL DEFAULT '',
				amount INT NOT NULL DEFAULT 1,
				status TINYINT NOT NULL DEFAULT 0,
				server VARCHAR(64) NOT NULL DEFAULT '',
				note VARCHAR(255) NOT NULL DEFAULT '',
				delivered_at DATETIME NULL DEFAULT NULL,
				created_at DATETIME NOT NULL,
				expires_at DATETIME NULL DEFAULT NULL,
				PRIMARY KEY  (id),
				KEY order_id (order_id),
				KEY player (player),
				KEY status (status),
				KEY product_id (product_id),
				KEY user_id (user_id),
				KEY delivery_key (delivery_key),
				KEY created_at (created_at)
			) {$charset};"
		);

		$codes = self::table( 'codes' );
		dbDelta(
			"CREATE TABLE {$codes} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				type VARCHAR(20) NOT NULL DEFAULT 'link',
				user_id BIGINT UNSIGNED NOT NULL DEFAULT 0,
				identifier VARCHAR(190) NOT NULL DEFAULT '',
				player VARCHAR(32) NOT NULL DEFAULT '',
				player_uuid CHAR(32) NOT NULL DEFAULT '',
				code_hash CHAR(64) NOT NULL,
				attempts TINYINT UNSIGNED NOT NULL DEFAULT 0,
				status TINYINT NOT NULL DEFAULT 0,
				ip_hash CHAR(32) NOT NULL DEFAULT '',
				channel VARCHAR(20) NOT NULL DEFAULT '',
				created_at DATETIME NOT NULL,
				expires_at DATETIME NOT NULL,
				consumed_at DATETIME NULL DEFAULT NULL,
				PRIMARY KEY  (id),
				UNIQUE KEY code_hash (code_hash),
				KEY type_identifier (type, identifier),
				KEY user_id (user_id),
				KEY status (status),
				KEY expires_at (expires_at)
			) {$charset};"
		);

		$logs = self::table( 'logs' );
		dbDelta(
			"CREATE TABLE {$logs} (
				id BIGINT UNSIGNED NOT NULL AUTO_INCREMENT,
				channel VARCHAR(30) NOT NULL DEFAULT '',
				level VARCHAR(10) NOT NULL DEFAULT 'info',
				message TEXT NULL,
				context TEXT NULL,
				ip_hash CHAR(32) NOT NULL DEFAULT '',
				created_at DATETIME NOT NULL,
				PRIMARY KEY  (id),
				KEY channel (channel),
				KEY created_at (created_at)
			) {$charset};"
		);

		update_option( 'bmc_db_version', BMC_DB_VERSION );
	}

	public static function maybe_upgrade() {
		if ( get_option( 'bmc_db_version' ) !== BMC_DB_VERSION ) {
			self::install();
		}
	}

	public static function table_status() {
		global $wpdb;

		$out = array();

		foreach ( array( 'deliveries', 'codes', 'logs' ) as $name ) {
			$table  = self::table( $name );
			$exists = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) );
			$count  = $exists ? (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" ) : 0;

			$out[ $name ] = array(
				'table'  => $table,
				'exists' => (bool) $exists,
				'rows'   => $count,
			);
		}

		return $out;
	}

	public static function drop_all() {
		global $wpdb;

		foreach ( array( 'deliveries', 'codes', 'logs' ) as $name ) {
			$table = self::table( $name );
			$wpdb->query( "DROP TABLE IF EXISTS {$table}" );
		}
	}

	public static function purge_expired_codes() {
		global $wpdb;
		$table = self::table( 'codes' );
		return (int) $wpdb->query(
			$wpdb->prepare(
				"DELETE FROM {$table} WHERE expires_at < %s OR (status = 1 AND consumed_at < %s)",
				current_time( 'mysql' ),
				BMC_Helpers::local_datetime( BMC_Helpers::now_timestamp() - DAY_IN_SECONDS )
			)
		);
	}
}
