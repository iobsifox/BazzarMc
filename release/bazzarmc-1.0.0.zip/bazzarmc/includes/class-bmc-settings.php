<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Settings {

	const OPTION = 'bmc_settings';

	private static $cache = null;

	public static function defaults() {
		return array(

			'api_token'             => '',
			'server_name'           => 'سرور ماینکرافت',
			'server_ip'             => '',
			'username_policy'       => 'premium',
			'force_link'            => 'yes',
			'default_linked_role'   => '',
			'unlink_allowed'        => 'yes',
			'legacy_compat'         => 'no',
			'debug_log'             => 'yes',
			'ssl_verify'            => 'yes',
			'mojang_check'          => 'yes',
			'cache_exclude'         => 'yes',
			'cf_api_token'          => '',
			'cf_zone_id'            => '',
			'cf_cache_rule'         => 'no',
			'blocks_checkout'       => 'force_classic',

			'link_mode'             => 'both',
			'code_ttl'              => 300,
			'code_length'           => 8,
			'code_alphabet'         => 'safe',
			'code_max_active'       => 1,
			'code_command_hint'     => '/mclink {code}',

			'sync_products'         => array(),
			'product_roles'         => array(),
			'product_key_default'   => 'name',
			'product_keys'          => array(),
			'revoke_roles_on_refund' => 'yes',
			'custom_roles'          => array(),
			'delivery_expiry'       => array(
				'value' => 30,
				'unit'  => 'days',
			),
			'delivery_status'       => array( 'processing', 'completed' ),

			'sms_enabled'           => 'yes',
			'sms_driver'            => 'melipayamak',
			'sms_mpm_auth_mode'     => 'legacy',
			'sms_mpm_api_key'       => '',
			'sms_mpm_simple_endpoint'  => 'https://console.melipayamak.com/api/send/simple/{API_KEY}',
			'sms_mpm_pattern_endpoint' => 'https://console.melipayamak.com/api/send/shared/{API_KEY}',
			'ezlogin_bridge'        => 'auto',
			'ezlogin_reuse_settings' => 'yes',
			'ezlogin_sync_phone'    => 'yes',
			'sms_mpm_username'      => '',
			'sms_mpm_password'      => '',
			'sms_mpm_from'          => '',
			'sms_mpm_body_id'       => '',
			'sms_mpm_method'        => 'pattern',
			'sms_otp_ttl'           => 120,
			'sms_otp_length'        => 5,
			'sms_rate_limit'        => 120,
			'sms_max_attempts'      => 5,
			'sms_resend_limit'      => 3,
			'sms_fallback_email'    => 'yes',
			'sms_order_notify'      => 'no',
			'sms_tpl_link'          => 'کد اتصال ماینکرافت شما در {site}: {code} — معتبر تا {minutes} دقیقه',
			'sms_tpl_login'         => 'کد ورود به {site}: {code} — {minutes} دقیقه اعتبار دارد.',
			'sms_tpl_welcome'       => 'ورود شما به {site} با موفقیت انجام شد.',
			'sms_tpl_delivery'      => 'سفارش {order} پرداخت شد. برای دریافت آیتم وارد سرور {server} شوید.',

			'email_enabled'         => 'yes',
			'email_tpl_subject'     => 'کد اتصال ماینکرافت | {site}',
			'email_tpl_body'        => "<p>سلام {player}،</p>\n<p>کد اتصال شما: <strong style=\"font-size:22px;letter-spacing:2px\">{code}</strong></p>\n<p>این کد تا {minutes} دقیقه اعتبار دارد. آن را در بازی با دستور <code>/mclink {code}</code> وارد کنید.</p>\n<p>— {site}</p>",

			'otp_login'             => 'yes',
			'verify_methods'        => array( 'sms', 'email', 'dashboard' ),
			'verify_default'        => 'sms',
			'otp_dashboard_widget'  => 'yes',
			'otp_dashboard_box'     => 'yes',
			'otp_register_new'      => 'yes',
			'otp_default_role'      => 'customer',
			'otp_lock_after'        => 5,
			'otp_login_redirect'    => '',
			'otp_auto_fill_mobile'  => 'yes',
			'use_external_login'    => 'auto',
			'mobile_meta_keys'      => array( 'bmc_mobile', 'mobile', 'billing_phone', 'digcell', 'digits_mobile', 'easylogin_mobile', 'bilacell_mobile', 'user_mobile', 'phone' ),

			'checkout_mode'         => 'custom',
			'gate_enabled'          => 'yes',
			'gate_only_synced'      => 'yes',
			'gate_product_page'     => 'no',
			'gate_hide_add_to_cart' => 'no',
			'cart_gate'             => 'yes',
			'cart_mode'             => 'wc',
			'persian_fields'        => 'yes',
			'persian_countries'     => 'yes',
			'persian_digits'        => 'no',
			'checkout_theme'        => 'dark',
			'checkout_accent'       => '#3ddc84',
			'checkout_show_coupon'  => 'yes',
			'checkout_show_summary' => 'yes',
			'checkout_gift_allowed' => 'yes',
			'checkout_fields'       => array(
				'first_name' => 1,
				'last_name'  => 1,
				'mobile'     => 1,
				'email'      => 1,
				'address'    => 0,
				'city'       => 0,
				'state'      => 0,
				'postcode'   => 0,
				'country'    => 0,
				'company'    => 0,
				'notes'      => 0,
			),

			'txt_not_linked_title'  => 'اکانت ماینکرافت شما متصل نیست',
			'txt_not_linked_body'   => 'برای ادامهٔ خرید و دریافت آیتم‌ها در بازی، ابتدا اکانت ماینکرافت خود را متصل کنید.',
			'txt_linked_title'      => 'اکانت متصل است',
			'txt_login_title'       => 'ورود با شماره موبایل',
			'txt_link_title'        => 'اتصال اکانت ماینکرافت',
			'txt_cart_blocked'      => 'برای فعال‌شدن دکمهٔ پرداخت، ابتدا اکانت ماینکرافت خود را متصل کنید.',
			'txt_thankyou'          => 'سفارش شما با موفقیت ثبت شد. آیتم‌ها پس از ورود به سرور به‌صورت خودکار تحویل داده می‌شوند.',

			'page_link'             => 0,
			'page_login'            => 0,
			'page_cart'             => 0,
			'page_checkout'         => 0,

			'font_cdn'              => 'yes',
			'purge_on_uninstall'    => 'no',
			'install_notice_seen'   => 'no',
			'smtp_notice_seen'      => 'no',
		);
	}

	public static function all() {
		if ( null === self::$cache ) {
			$stored = get_option( self::OPTION, array() );
			if ( ! is_array( $stored ) ) {
				$stored = array();
			}
			self::$cache = array_merge( self::defaults(), $stored );
		}

		return self::$cache;
	}

	public static function get( $key, $default = null ) {
		$all = self::all();

		if ( array_key_exists( $key, $all ) ) {
			$value = $all[ $key ];
			return ( '' === $value && null !== $default ) ? $default : $value;
		}

		$defaults = self::defaults();

		if ( null !== $default ) {
			return $default;
		}

		return isset( $defaults[ $key ] ) ? $defaults[ $key ] : null;
	}

	public static function bool( $key, $default = false ) {
		$value = self::get( $key, $default );

		if ( is_bool( $value ) ) {
			return $value;
		}

		if ( is_numeric( $value ) ) {
			return (bool) $value;
		}

		return in_array( strtolower( (string) $value ), array( 'yes', 'on', 'true', '1' ), true );
	}

	public static function int( $key, $default = 0, $min = null, $max = null ) {
		$value = (int) self::get( $key, $default );

		if ( null !== $min && $value < $min ) {
			$value = $min;
		}
		if ( null !== $max && $value > $max ) {
			$value = $max;
		}

		return $value;
	}

	public static function set( $key, $value ) {
		return self::save( array( $key => $value ) );
	}

	public static function save( array $values ) {
		$all      = self::all();
		$defaults = self::defaults();

		foreach ( $values as $key => $value ) {
			if ( ! array_key_exists( $key, $defaults ) ) {
				continue;
			}

			$all[ $key ] = self::sanitize_value( $key, $value );
		}

		self::$cache = $all;

		return update_option( self::OPTION, $all, false );
	}

	private static function sanitize_value( $key, $value ) {
		$array_keys = array( 'sync_products', 'product_roles', 'delivery_expiry', 'checkout_fields', 'mobile_meta_keys', 'delivery_status', 'product_keys', 'verify_methods', 'custom_roles' );

		if ( in_array( $key, $array_keys, true ) ) {
			if ( ! is_array( $value ) ) {
				$value = array();
			}

			switch ( $key ) {
				case 'sync_products':
					return array_values( array_unique( array_filter( array_map( 'absint', $value ) ) ) );

				case 'product_roles':
					$clean = array();
					foreach ( $value as $pid => $role ) {
						$pid = absint( $pid );
						if ( $pid ) {
							$clean[ $pid ] = sanitize_text_field( $role );
						}
					}
					return $clean;

				case 'delivery_expiry':
					return array(
						'value' => max( 1, isset( $value['value'] ) ? (int) $value['value'] : 30 ),
						'unit'  => in_array( isset( $value['unit'] ) ? $value['unit'] : 'days', array( 'minutes', 'hours', 'days', 'weeks' ), true ) ? $value['unit'] : 'days',
					);

				case 'delivery_status':
					$allowed = array( 'pending', 'processing', 'completed', 'on-hold' );
					return array_values( array_intersect( array_map( 'sanitize_key', $value ), $allowed ) );

				case 'mobile_meta_keys':
					$clean = array();
					foreach ( $value as $mk ) {
						$mk = sanitize_key( $mk );
						if ( $mk ) {
							$clean[] = $mk;
						}
					}
					return array_values( array_unique( $clean ) );

				case 'checkout_fields':
					$clean = array();
					foreach ( $value as $fk => $fv ) {
						$clean[ sanitize_key( $fk ) ] = (int) (bool) $fv;
					}
					return $clean;

				case 'verify_methods':
					$allowed = array( 'sms', 'email', 'dashboard' );
					$clean   = array_values( array_intersect( array_map( 'sanitize_key', $value ), $allowed ) );
					return $clean ? $clean : array( 'sms' );

				case 'product_keys':
					$clean = array();
					foreach ( $value as $pid => $conf ) {
						$pid = absint( $pid );
						if ( ! $pid || ! is_array( $conf ) ) {
							continue;
						}
						$type = isset( $conf['type'] ) ? sanitize_key( $conf['type'] ) : 'name';
						if ( ! in_array( $type, array( 'name', 'id', 'slug', 'custom', 'sku' ), true ) ) {
							$type = 'name';
						}
						$clean[ $pid ] = array(
							'type'  => $type,
							'value' => sanitize_text_field( isset( $conf['value'] ) ? $conf['value'] : '' ),
						);
					}
					return $clean;

				case 'custom_roles':
					$clean = array();
					foreach ( $value as $pid => $conf ) {
						$pid = absint( $pid );
						if ( ! $pid || ! is_array( $conf ) ) {
							continue;
						}
						$slug = sanitize_key( isset( $conf['slug'] ) ? $conf['slug'] : '' );
						if ( ! $slug ) {
							continue;
						}
						$clean[ $pid ] = array(
							'slug' => $slug,
							'name' => sanitize_text_field( isset( $conf['name'] ) ? $conf['name'] : $slug ),
						);
					}
					return $clean;
			}
		}

		$int_keys = array(
			'code_ttl'         => array( 60, 3600 ),
			'code_length'      => array( 4, 16 ),
			'code_max_active'  => array( 1, 10 ),
			'sms_otp_ttl'      => array( 30, 900 ),
			'sms_otp_length'   => array( 4, 8 ),
			'sms_rate_limit'   => array( 10, 3600 ),
			'sms_max_attempts' => array( 1, 20 ),
			'sms_resend_limit' => array( 1, 20 ),
			'otp_lock_after'   => array( 1, 50 ),
			'page_link'        => array( 0, PHP_INT_MAX ),
			'page_login'       => array( 0, PHP_INT_MAX ),
			'page_cart'        => array( 0, PHP_INT_MAX ),
			'page_checkout'    => array( 0, PHP_INT_MAX ),
		);

		if ( isset( $int_keys[ $key ] ) ) {
			$bound = $int_keys[ $key ];
			return max( $bound[0], min( $bound[1], (int) $value ) );
		}

		$yesno = array(
			'force_link', 'unlink_allowed', 'legacy_compat', 'debug_log', 'sms_enabled',
			'sms_fallback_email', 'email_enabled', 'otp_login', 'otp_register_new',
			'otp_auto_fill_mobile', 'gate_enabled', 'gate_only_synced', 'gate_product_page',
			'gate_hide_add_to_cart', 'checkout_show_coupon', 'checkout_show_summary',
			'checkout_gift_allowed', 'font_cdn', 'install_notice_seen',
			'purge_on_uninstall', 'ssl_verify', 'mojang_check', 'cache_exclude',
			'cf_cache_rule', 'revoke_roles_on_refund', 'ezlogin_sync_phone', 'ezlogin_reuse_settings',
			'otp_dashboard_widget', 'otp_dashboard_box', 'cart_gate', 'persian_fields', 'persian_digits',
			'persian_countries', 'smtp_notice_seen',
		);

		if ( in_array( $key, $yesno, true ) ) {
			return BMC_Settings::normalize_yesno( $value );
		}

		$enums = array(
			'sms_mpm_auth_mode' => array( 'legacy', 'api_key' ),
			'ezlogin_bridge'    => array( 'auto', 'yes', 'no' ),
			'blocks_checkout'   => array( 'force_classic', 'notice', 'register' ),
			'cart_mode'         => array( 'wc', 'custom' ),
			'product_key_default' => array( 'name', 'id', 'slug', 'sku' ),
			'checkout_mode'     => array( 'custom', 'wc' ),
			'checkout_theme'    => array( 'dark', 'light' ),
			'link_mode'         => array( 'panel', 'mc', 'both' ),
			'username_policy'   => array( 'premium', 'any' ),
			'code_alphabet'     => array( 'safe', 'digits', 'full' ),
		);

		if ( isset( $enums[ $key ] ) ) {
			$value = sanitize_key( (string) $value );
			return in_array( $value, $enums[ $key ], true ) ? $value : $enums[ $key ][0];
		}

		if ( 'verify_default' === $key ) {
			$value    = sanitize_key( (string) $value );
			$methods  = (array) self::get( 'verify_methods', array( 'sms' ) );
			return in_array( $value, $methods, true ) ? $value : ( isset( $methods[0] ) ? $methods[0] : 'sms' );
		}

		if ( 'sms_driver' === $key ) {
			$value = sanitize_key( (string) $value );
			return in_array( $value, array( 'melipayamak', 'ezlogin', 'email', 'none' ), true ) ? $value : 'melipayamak';
		}

		if ( in_array( $key, array( 'sms_mpm_simple_endpoint', 'sms_mpm_pattern_endpoint' ), true ) ) {
			$value = trim( (string) $value );
			$value = str_ireplace( '{api_key}', '{API_KEY}', $value );
			return preg_match( '#^https://#i', $value ) ? $value : '';
		}

		if ( in_array( $key, array( 'sms_mpm_api_key', 'cf_api_token' ), true ) ) {
			return preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $value );
		}

		if ( 'cf_zone_id' === $key ) {
			return preg_replace( '/[^A-Za-z0-9]/', '', (string) $value );
		}

		$multiline = array( 'email_tpl_body', 'txt_not_linked_body' );
		if ( in_array( $key, $multiline, true ) ) {
			return wp_kses_post( $value );
		}

		$textarea = array( 'sms_tpl_link', 'sms_tpl_login', 'sms_tpl_welcome', 'sms_tpl_delivery', 'code_command_hint', 'txt_cart_blocked', 'txt_thankyou' );
		if ( in_array( $key, $textarea, true ) ) {
			return sanitize_textarea_field( $value );
		}

		if ( 'api_token' === $key ) {
			return preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $value );
		}

		if ( 'checkout_accent' === $key ) {
			return preg_match( '/^#[0-9a-fA-F]{6}$/', (string) $value ) ? $value : '#3ddc84';
		}

		return sanitize_text_field( $value );
	}

	public static function normalize_yesno( $value ) {
		if ( is_bool( $value ) ) {
			return $value ? 'yes' : 'no';
		}
		return in_array( strtolower( (string) $value ), array( 'yes', 'on', 'true', '1' ), true ) ? 'yes' : 'no';
	}

	public static function api_token() {
		$token = (string) self::get( 'api_token' );

		if ( ! $token ) {
			$token = BMC_Helpers::random_token( 40 );
			self::set( 'api_token', $token );
		}

		return $token;
	}

	public static function regenerate_token() {
		$token = BMC_Helpers::random_token( 40 );
		self::set( 'api_token', $token );
		BMC_Logger::add( 'api', 'توکن API بازسازی شد', array(), 'warning' );
		return $token;
	}

	public static function api_base_url() {
		return esc_url_raw( rest_url( BMC_REST_NS ) );
	}

	public static function panel_code_enabled() {
		return in_array( self::get( 'link_mode' ), array( 'panel', 'both' ), true );
	}

	public static function mc_request_enabled() {
		return in_array( self::get( 'link_mode' ), array( 'mc', 'both' ), true );
	}

	public static function delivery_expiry_seconds() {
		return BMC_Helpers::duration_to_seconds( self::get( 'delivery_expiry' ), 30 * DAY_IN_SECONDS );
	}

	public static function custom_checkout() {
		return 'custom' === self::get( 'checkout_mode' );
	}

	public static function verify_methods() {
		$methods = (array) self::get( 'verify_methods', array( 'sms' ) );
		$methods = array_values( array_intersect( $methods, array( 'sms', 'email', 'dashboard' ) ) );

		return $methods ? $methods : array( 'sms' );
	}

	public static function verify_enabled( $channel ) {
		return in_array( (string) $channel, self::verify_methods(), true );
	}

	public static function verify_default() {
		$default  = (string) self::get( 'verify_default', 'sms' );
		$methods  = self::verify_methods();

		return in_array( $default, $methods, true ) ? $default : $methods[0];
	}

	public static function ssl_verify() {
		return self::bool( 'ssl_verify', true );
	}

	public static function ezlogin_active() {
		return defined( 'EZ_LOGIN_VERSION' )
			|| function_exists( 'ez_login_find_user_by_phone' )
			|| function_exists( 'ez_sms_send_text_message' )
			|| ( function_exists( 'is_plugin_active' ) && is_plugin_active( 'ez-login/ez-login.php' ) );
	}

	public static function use_ezlogin() {
		$mode = (string) self::get( 'ezlogin_bridge', 'auto' );

		if ( 'no' === $mode ) {
			return false;
		}

		if ( ! self::ezlogin_active() ) {
			return false;
		}

		if ( 'yes' === $mode ) {
			return true;
		}

		return function_exists( 'ez_sms_credentials_ready' ) ? (bool) ez_sms_credentials_ready() : true;
	}

	public static function mpm_auth_mode() {
		$mode = (string) self::get( 'sms_mpm_auth_mode', 'legacy' );

		if ( 'api_key' === $mode && '' === trim( (string) self::get( 'sms_mpm_api_key' ) ) ) {
			return 'legacy';
		}

		return in_array( $mode, array( 'legacy', 'api_key' ), true ) ? $mode : 'legacy';
	}

	public static function product_key_conf( $product_id ) {
		$keys = (array) self::get( 'product_keys', array() );
		$pid  = absint( $product_id );

		$default = self::get( 'product_key_default', 'name' );

		if ( ! in_array( $default, array( 'name', 'id', 'slug', 'sku' ), true ) ) {
			$default = 'name';
		}

		if ( isset( $keys[ $pid ] ) && is_array( $keys[ $pid ] ) ) {
			$type  = isset( $keys[ $pid ]['type'] ) ? $keys[ $pid ]['type'] : 'name';
			$value = isset( $keys[ $pid ]['value'] ) ? trim( (string) $keys[ $pid ]['value'] ) : '';

			if ( 'custom' === $type && '' === $value ) {
				$type = $default;
			}

			return array(
				'type'  => $type,
				'value' => $value,
			);
		}

		return array(
			'type'  => $default,
			'value' => '',
		);
	}

	public static function product_key( $product_id, $variation_id = 0 ) {
		$conf      = self::product_key_conf( $product_id );
		$type      = $conf['type'];
		$target_id = $variation_id ? absint( $variation_id ) : absint( $product_id );
		$product   = function_exists( 'wc_get_product' ) ? wc_get_product( $target_id ) : null;

		if ( 'id' === $type ) {
			return (string) $target_id;
		}

		if ( 'slug' === $type ) {
			if ( $product ) {
				return (string) $product->get_slug();
			}
			$post = get_post( $target_id );
			return $post ? (string) $post->post_name : '';
		}

		if ( 'sku' === $type ) {
			if ( $product ) {
				$sku = trim( (string) $product->get_sku() );

				if ( '' !== $sku ) {
					return $sku;
				}
			}
		}

		if ( 'custom' === $type && '' !== trim( $conf['value'] ) ) {
			return trim( $conf['value'] );
		}

		if ( $product ) {
			$name = trim( (string) $product->get_name() );
			return function_exists( 'mb_strtolower' ) ? mb_strtolower( $name ) : strtolower( $name );
		}

		return '';
	}

	public static function cart_gate_enabled() {
		return self::bool( 'gate_enabled', true ) && self::bool( 'cart_gate', true );
	}
}
