<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$field_labels = array(
	'first_name' => 'نام',
	'last_name'  => 'نام خانوادگی',
	'mobile'     => 'شمارهٔ موبایل',
	'email'      => 'ایمیل',
	'address'    => 'آدرس',
	'city'       => 'شهر',
	'state'      => 'استان',
	'postcode'   => 'کد پستی',
	'country'    => 'کشور',
	'company'    => 'شرکت',
	'notes'      => 'توضیحات سفارش',
);

BMC_Admin::form_open( 'checkout' );

BMC_Admin::section_open( 'حالت چک‌اوت', 'در حالت اختصاصی، فرم خرید ووکامرس خاموش می‌شود و فرم طراحی‌شدهٔ افزونه جای آن را می‌گیرد؛ اما سبد خرید و درگاه‌های پرداخت همان ووکامرس هستند.' );

BMC_Admin::row(
	'فرم خرید',
	BMC_Admin::select(
		'checkout_mode',
		$settings['checkout_mode'],
		array(
			'custom' => 'چک‌اوت اختصاصی BazzarMc (پیشنهادی)',
			'wc'     => 'چک‌اوت استاندارد ووکامرس',
		)
	),
	'حتی در حالت اختصاصی، ثبت سفارش از طریق هستهٔ ووکامرس انجام می‌شود؛ بنابراین زرین‌پال، IDPay، سامان و بقیهٔ درگاه‌ها بدون تغییر کار می‌کنند.'
);

BMC_Admin::row(
	'پوسته',
	BMC_Admin::select(
		'checkout_theme',
		$settings['checkout_theme'],
		array(
			'dark'  => 'تیره (گیمینگ)',
			'light' => 'روشن',
		)
	)
);

BMC_Admin::row( 'رنگ تأکید', '<input type="text" name="checkout_accent" value="' . esc_attr( $settings['checkout_accent'] ) . '" class="bmc-color" />' );

BMC_Admin::row( 'بارگذاری فونت وزیرمتن از CDN', BMC_Admin::toggle( 'font_cdn', $settings['font_cdn'], 'فونت فارسی وزیرمتن از jsDelivr بارگذاری شود' ), 'اگر قالب شما فونت فارسی دارد، می‌توانید خاموش کنید.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'گیتِ اتصال اکانت', 'اگر اکانت متصل نباشد، کاربر اجازهٔ ورود به صفحهٔ خرید را ندارد و پیام «هنوز متصل نیستید» نمایش داده می‌شود.' );

BMC_Admin::row( 'فعال‌سازی گیت', BMC_Admin::toggle( 'gate_enabled', $settings['gate_enabled'], 'بدون اتصال اکانت، امکان خرید نباشد' ) );
BMC_Admin::row( 'فقط برای محصولات ماینکرافتی', BMC_Admin::toggle( 'gate_only_synced', $settings['gate_only_synced'], 'گیت فقط وقتی فعال شود که محصول همگام‌شده در سبد باشد' ), 'اگر خاموش کنید، همهٔ خریدها نیازمند اتصال می‌شوند.' );
BMC_Admin::row( 'کنترل صفحهٔ محصول', BMC_Admin::toggle( 'gate_product_page', $settings['gate_product_page'], 'در صفحهٔ محصول همگام‌شده، دکمهٔ خرید برای کاربران متصل‌نشده غیرفعال شود' ) );
BMC_Admin::row( 'نمایش کد تخفیف', BMC_Admin::toggle( 'checkout_show_coupon', $settings['checkout_show_coupon'], 'کادر کد تخفیف در چک‌اوت نمایش داده شود' ) );
BMC_Admin::row( 'خرید هدیه', BMC_Admin::toggle( 'checkout_gift_allowed', $settings['checkout_gift_allowed'], 'کاربر بتواند برای بازیکن دیگری خرید کند' ) );

BMC_Admin::section_close();

BMC_Admin::section_open( 'سبد خرید و گیت پرداخت', 'سبد خرید کامل در صفحهٔ اختصاصی افزونه نمایش داده می‌شود و تا زمانی که اکانت ماینکرافت متصل نباشد، دکمهٔ «ادامهٔ فرآیند خرید / پرداخت» غیرفعال می‌ماند.' );

BMC_Admin::row(
	'صفحهٔ سبد خرید',
	BMC_Admin::select(
		'cart_mode',
		$settings['cart_mode'],
		array(
			'custom' => 'سبد اختصاصی BazzarMc (پیشنهادی)',
			'wc'     => 'سبد پیش‌فرض ووکامرس (فقط گیت اعمال شود)',
		)
	),
	'در حالت اختصاصی، شورت‌کد <code>[bazzarmc_cart]</code> سبد کامل فارسی + کد تخفیف + جمع کل را نشان می‌دهد و پرداخت در همان صفحه انجام می‌شود.'
);

BMC_Admin::row( 'گیت دکمهٔ پرداخت', BMC_Admin::toggle( 'cart_gate', $settings['cart_gate'], 'تا اتصال اکانت، دکمهٔ پرداخت در سبد غیرفعال بماند' ), 'به‌جای دکمه، پیام «هنوز متصل نیستید» + دکمهٔ «اتصال اکانت ماینکرافت» نمایش داده می‌شود.' );
BMC_Admin::row( 'پنهان‌کردن افزودن به سبد', BMC_Admin::toggle( 'gate_hide_add_to_cart', $settings['gate_hide_add_to_cart'], 'برای کاربران متصل‌نشده، دکمهٔ «افزودن به سبد» در صفحهٔ محصول پنهان شود' ), 'کاربر پیش از افزودن به سبد متوجه می‌شود که باید اکانتش را متصل کند.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'فارسی‌سازی فیلدها', 'برچسب و placeholder همهٔ فیلدهای ووکامرس (آدرس، استان، شهر، کد پستی، تلفن و…) به فارسی ترجمه می‌شوند.' );

BMC_Admin::row( 'ترجمهٔ فیلدها', BMC_Admin::toggle( 'persian_fields', $settings['persian_fields'], 'برچسب و placeholder فیلدهای چک‌اوت فارسی شود' ) );
BMC_Admin::row( 'نام کشورها به فارسی', BMC_Admin::toggle( 'persian_countries', $settings['persian_countries'], 'لیست کشورها فارسی نمایش داده شود' ), 'لیست استان‌های ایران همیشه کامل و فارسی است.' );
BMC_Admin::row( 'اعداد فارسی', BMC_Admin::toggle( 'persian_digits', $settings['persian_digits'], 'اعداد قیمت و جمع کل با رقم فارسی نمایش داده شوند' ), 'فقط نمایش؛ مقدار ارسالی به درگاه پرداخت دست‌نخورده می‌ماند.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'فیلدهای فرم خرید', 'فیلدهایی که در چک‌اوت نمایش داده شوند. فیلدهای خاموش، از فرم و از اعتبارسنجی ووکامرس حذف می‌شوند.' );

echo '<div class="bmc-checkbox-grid">';
foreach ( $field_labels as $key => $label ) {
	$checked = ! empty( $settings['checkout_fields'][ $key ] );
	printf(
		'<label class="bmc-check"><input type="checkbox" name="checkout_fields[%1$s]" value="1" %2$s /><span>%3$s</span></label>',
		esc_attr( $key ),
		checked( $checked, true, false ),
		esc_html( $label )
	);
}
echo '</div>';

echo '<p class="bmc-note" style="margin-top:14px">برای فروش آیتم مجازی ماینکرافت، معمولاً فقط «نام»، «نام خانوادگی» و «شمارهٔ موبایل» لازم است.</p>';

BMC_Admin::section_close();

BMC_Admin::form_close();
