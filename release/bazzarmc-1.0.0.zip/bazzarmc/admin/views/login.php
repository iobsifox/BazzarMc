<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$integrations = BMC_Auth::detected_integrations();

BMC_Admin::form_open( 'login' );

BMC_Admin::section_open( 'ورود و عضویت با شمارهٔ موبایل', 'کاربر بدون رمز عبور و فقط با کد یکبارمصرف پیامکی وارد می‌شود.' );

BMC_Admin::row( 'فعال‌سازی ورود با موبایل', BMC_Admin::toggle( 'otp_login', $settings['otp_login'], 'فرم ورود OTP فعال باشد' ) );
BMC_Admin::row( 'عضویت خودکار', BMC_Admin::toggle( 'otp_register_new', $settings['otp_register_new'], 'اگر شماره در سایت نبود، حساب جدید ساخته شود' ) );
BMC_Admin::row( 'نقش کاربران جدید', BMC_Admin::role_select( 'otp_default_role', $settings['otp_default_role'], false ) );
BMC_Admin::row( 'قفل پس از تلاش ناموفق', BMC_Admin::input( 'otp_lock_after', (int) $settings['otp_lock_after'], array( 'type' => 'number', 'min' => 1, 'max' => 50 ) ) . ' <span class="bmc-suffix">بار</span>', 'پس از این تعداد کد اشتباه، شماره به‌مدت ۱۰ دقیقه قفل می‌شود.' );
BMC_Admin::row( 'آدرس بازگشت پس از ورود', BMC_Admin::input( 'otp_login_redirect', $settings['otp_login_redirect'], array( 'dir' => 'ltr', 'placeholder' => home_url( '/' ) ) ), 'خالی بگذارید تا کاربر به حساب کاربری ووکامرس برود.' );
BMC_Admin::row( 'پرکردن خودکار تلفن چک‌اوت', BMC_Admin::toggle( 'otp_auto_fill_mobile', $settings['otp_auto_fill_mobile'], 'شمارهٔ ثبت‌شده در فیلد تلفن صورتحساب قرار گیرد' ) );

BMC_Admin::section_close();

BMC_Admin::section_open( 'هماهنگی با افزونه‌های ورود پیامکی', 'اگر افزونهٔ دیگری مثل ایزی‌لاگین یا دیجیتس نصب دارید، شمارهٔ موبایل کاربران از همان افزونه خوانده می‌شود.' );

if ( $integrations ) {
	echo '<div class="bmc-note bmc-note--ok">افزونه‌های شناسایی‌شده: <strong>' . esc_html( implode( '، ', array_keys( $integrations ) ) ) . '</strong></div>';
} else {
	echo '<div class="bmc-note">افزونهٔ ورود پیامکی دیگری شناسایی نشد. فرم ورود داخلی این افزونه استفاده می‌شود.</div>';
}

BMC_Admin::row(
	'حالت همکاری',
	BMC_Admin::select(
		'use_external_login',
		$settings['use_external_login'],
		array(
			'auto' => 'خودکار (فرم ما فعال بماند + اطلاعیهٔ راهنما)',
			'yes'  => 'ورود را به افزونهٔ خارجی بسپار',
			'no'   => 'فقط از فرم ورود این افزونه استفاده کن',
		)
	)
);

BMC_Admin::row(
	'کلیدهای متای شمارهٔ موبایل',
	'<input class="bmc-input" type="text" name="mobile_meta_keys" value="' . esc_attr( implode( ',', (array) $settings['mobile_meta_keys'] ) ) . '" dir="ltr" />'
		. '<div class="bmc-inline" style="margin-top:8px">'
		. '<button type="button" class="button bmc-action" data-do="detect_mobile_keys" data-target="#bmcDetectedKeys">شناسایی خودکار کلیدها</button>'
		. '<button type="button" class="button bmc-action" data-do="sync_mobiles">یکسان‌سازی شمارهٔ همهٔ کاربران</button>'
		. '</div>'
		. '<div id="bmcDetectedKeys" class="bmc-detect"></div>',
	'با کاما جدا کنید. کلیدهای شناخته‌شده به‌صورت خودکار هم بررسی می‌شوند: <code>digits_number</code>، <code>digcell</code>، <code>easylogin_mobile</code>، <code>billing_phone</code> و…'
);

BMC_Admin::section_close();

BMC_Admin::section_open( 'روش‌های تأیید هویت (سه‌گانه)', 'هر سه روش را می‌توانید همزمان فعال کنید؛ کاربر در فرم ورود روش دلخواه را انتخاب می‌کند. روش «داشبورد» هیچ هزینهٔ پیامکی ندارد.' );

$bmc_verify_methods = (array) $settings['verify_methods'];
?>
<div class="bmc-checklist bmc-checklist--inline">
	<label class="bmc-check"><input type="checkbox" name="verify_methods[]" value="sms" <?php checked( in_array( 'sms', $bmc_verify_methods, true ) ); ?> /> <span>📱 پیامک (OTP)</span></label>
	<label class="bmc-check"><input type="checkbox" name="verify_methods[]" value="email" <?php checked( in_array( 'email', $bmc_verify_methods, true ) ); ?> /> <span>✉️ ایمیل</span></label>
	<label class="bmc-check"><input type="checkbox" name="verify_methods[]" value="dashboard" <?php checked( in_array( 'dashboard', $bmc_verify_methods, true ) ); ?> /> <span>🖥️ داشبورد وردپرس و پنل کاربری (بدون هزینه)</span></label>
</div>
<p class="bmc-hint">حداقل یک روش باید فعال باشد؛ اگر همه را خاموش کنید، «پیامک» به‌صورت خودکار فعال می‌ماند.</p>
<?php

BMC_Admin::row(
	'روش پیش‌فرض',
	BMC_Admin::select(
		'verify_default',
		$settings['verify_default'],
		array(
			'sms'       => '📱 پیامک',
			'email'     => '✉️ ایمیل',
			'dashboard' => '🖥️ داشبورد',
		)
	),
	'اگر روش پیش‌فرض فعال نباشد، افزونه به‌صورت خودکار به «پیامک» برمی‌گردد.'
);

BMC_Admin::row( 'ویجت پیشخوان مدیر', BMC_Admin::toggle( 'otp_dashboard_widget', $settings['otp_dashboard_widget'], 'کدهای فعال در پیشخوان وردپرس نمایش داده شود' ), 'برای پشتیبانی سریع کاربران؛ فقط مدیران و مدیران فروشگاه می‌بینند.' );
BMC_Admin::row( 'جعبهٔ کد در پنل کاربری', BMC_Admin::toggle( 'otp_dashboard_box', $settings['otp_dashboard_box'], 'کد در صفحهٔ ورود و پنل حساب کاربری نمایش داده شود' ), 'وقتی کاربر وارد شده باشد، کد به‌جای پیامک در همان صفحه نشان داده می‌شود و خودکار پر می‌شود.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'صفحه‌های افزونه' );

BMC_Admin::row( 'صفحهٔ اتصال اکانت', BMC_Admin::page_select( 'page_link', (int) $settings['page_link'] ), 'شورت‌کد: <code>[bazzarmc]</code> — در حساب کاربری ووکامرس هم به‌صورت تب «اتصال ماینکرافت» اضافه می‌شود.' );
BMC_Admin::row( 'صفحهٔ ورود', BMC_Admin::page_select( 'page_login', (int) $settings['page_login'] ), 'شورت‌کد: <code>[bazzarmc_login]</code>' );
BMC_Admin::row( 'صفحهٔ سبد خرید', BMC_Admin::page_select( 'page_cart', (int) $settings['page_cart'] ), 'شورت‌کد: <code>[bazzarmc_cart]</code> — سبد کامل فارسی + پرداخت در همان صفحه.' );
BMC_Admin::row( 'صفحهٔ پرداخت', BMC_Admin::page_select( 'page_checkout', (int) $settings['page_checkout'] ), 'شورت‌کد: <code>[bazzarmc_checkout]</code>' );

echo '<div class="bmc-inline" style="margin-top:10px"><button type="button" class="button bmc-action" data-do="create_pages">ساخت خودکار صفحه‌ها</button></div>';

BMC_Admin::section_close();

BMC_Admin::form_close();
