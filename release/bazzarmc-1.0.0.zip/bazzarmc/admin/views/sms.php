<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

BMC_Admin::form_open( 'sms' );

BMC_Admin::section_open( 'سامانهٔ پیامکی', 'در حال حاضر درایور «ملی‌پیامک» به‌صورت کامل پیاده‌سازی شده است. افزودن سامانهٔ دیگر با فیلتر bmc_sms_drivers ممکن است.' );

BMC_Admin::row( 'فعال‌سازی پیامک', BMC_Admin::toggle( 'sms_enabled', $settings['sms_enabled'], 'کدهای تأیید با پیامک ارسال شوند' ) );

BMC_Admin::row(
	'درایور',
	BMC_Admin::select(
		'sms_driver',
		$settings['sms_driver'],
		array(
			'melipayamak' => 'ملی‌پیامک (Melipayamak)',
			'ezlogin'     => 'استفاده از تنظیمات ایزی‌لاگین (EZ-Login)',
			'email'       => 'فقط ایمیل (بدون پیامک)',
			'none'        => 'غیرفعال',
		)
	),
	'وضعیت درایورها: ' . implode(
		' | ',
		array_map(
			function ( $id, $info ) {
				return $info['label'] . ' → ' . ( $info['configured'] ? 'آماده' : 'تنظیم نشده' );
			},
			array_keys( BMC_SMS::status() ),
			BMC_SMS::status()
		)
	)
);

BMC_Admin::row( 'نام کاربری پنل', BMC_Admin::input( 'sms_mpm_username', $settings['sms_mpm_username'], array( 'dir' => 'ltr' ) ), 'نام کاربری سامانهٔ ملی‌پیامک (معمولاً شمارهٔ موبایل).' );
BMC_Admin::row( 'رمز عبور / API Key', '<input class="bmc-input" type="password" name="sms_mpm_password" value="' . esc_attr( $settings['sms_mpm_password'] ) . '" dir="ltr" autocomplete="new-password" />', 'اگر در پنل، استفاده از ApiKey اجباری شده است، همان ApiKey را اینجا وارد کنید.' );
BMC_Admin::row( 'شمارهٔ فرستنده', BMC_Admin::input( 'sms_mpm_from', $settings['sms_mpm_from'], array( 'dir' => 'ltr', 'placeholder' => '5000xxxx' ) ), 'برای متدهای «OTP» و «متن ساده» الزامی است.' );

BMC_Admin::row(
	'روش ارسال',
	BMC_Admin::select(
		'sms_mpm_method',
		$settings['sms_mpm_method'],
		array(
			'pattern' => 'الگو / پترن (خط خدماتی اشتراکی — پیشنهادی)',
			'otp'     => 'متد آمادهٔ SendOtp (متن ثابت سامانه)',
			'simple'  => 'متن ساده از خط اختصاصی (SendSMS)',
		)
	),
	'روش «الگو» به لیست سیاه مخابرات هم ارسال می‌شود و سریع‌تر است. برای آن باید bodyId الگوی تأییدشده را وارد کنید.'
);

BMC_Admin::row( 'کد الگو (bodyId)', BMC_Admin::input( 'sms_mpm_body_id', $settings['sms_mpm_body_id'], array( 'dir' => 'ltr', 'placeholder' => '12345' ) ), 'در پنل ملی‌پیامک → وب‌سرویس → الگوها ساخته می‌شود. الگو باید حداقل یک متغیر برای کد داشته باشد.' );

BMC_Admin::row(
	'تست ارسال',
	'<div class="bmc-inline">'
		. '<input class="bmc-input" type="tel" id="bmcTestMobile" dir="ltr" placeholder="09xxxxxxxxx" style="max-width:200px" />'
		. '<button type="button" class="button button-secondary bmc-action" data-do="test_sms" data-extra="to:#bmcTestMobile">ارسال پیامک تست</button>'
		. '</div>',
	'یک کد نمونه به این شماره ارسال می‌شود تا تنظیمات را بررسی کنید.'
);

BMC_Admin::section_close();

BMC_Admin::section_open( 'روش احراز ملی‌پیامک', 'ملی‌پیامک دو روش دارد: نام کاربری/رمز عبور (پنل قدیمی) و کلید API کنسول جدید (console.melipayamak.com).' );

BMC_Admin::row(
	'روش احراز',
	BMC_Admin::select(
		'sms_mpm_auth_mode',
		$settings['sms_mpm_auth_mode'],
		array(
			'legacy'  => 'نام کاربری + رمز عبور (rest.payamak-panel.com)',
			'api_key' => 'کلید API کنسول (console.melipayamak.com)',
		)
	),
	'اگر از پنل قدیمی استفاده می‌کنید، همان «نام کاربری + رمز عبور» را انتخاب کنید.'
);

BMC_Admin::row( 'کلید API کنسول', BMC_Admin::input( 'sms_mpm_api_key', $settings['sms_mpm_api_key'], array( 'dir' => 'ltr', 'placeholder' => '00000000-0000-0000-0000-000000000000' ) ), 'از کنسول ملی‌پیامک → تنظیمات → کلید API.' );
BMC_Admin::row( 'اندپوینت متن ساده', BMC_Admin::input( 'sms_mpm_simple_endpoint', $settings['sms_mpm_simple_endpoint'], array( 'dir' => 'ltr', 'placeholder' => 'https://console.melipayamak.com/api/send/simple/{API_KEY}' ) ), 'خالی = اندپوینت پیش‌فرض کنسول.' );
BMC_Admin::row( 'اندپوینت الگو (پترن)', BMC_Admin::input( 'sms_mpm_pattern_endpoint', $settings['sms_mpm_pattern_endpoint'], array( 'dir' => 'ltr', 'placeholder' => 'https://console.melipayamak.com/api/send/shared/{API_KEY}' ) ), 'برای خطوط خدماتی اشتراکی؛ بدنهٔ درخواست: bodyId, to, args[].' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'هماهنگی با ایزی‌لاگین (EZ-Login)', 'بدون هیچ دست‌کاری در افزونهٔ ایزی‌لاگین؛ اگر فعال باشد، تنظیمات پیامک، شمارهٔ موبایل کاربران و توابع ارسال آن استفاده می‌شود و سرویس‌های پیامکی جدیدش هم پشتیبانی می‌شوند.' );

$bmc_ez_status = class_exists( 'BMC_EZLogin' ) ? BMC_EZLogin::status() : array();
$bmc_ez_note   = class_exists( 'BMC_EZLogin' ) ? BMC_EZLogin::status_note() : array( 'type' => 'muted', 'text' => '' );
$bmc_ez_active = ! empty( $bmc_ez_status['active'] );

BMC_Admin::row(
	'وضعیت ایزی‌لاگین',
	'<div class="bmc-status-pill ' . ( $bmc_ez_active ? 'is-on' : 'is-off' ) . '">' . ( $bmc_ez_active ? '✅ فعال' : '❌ نصب یا فعال نیست' ) . '</div>',
	esc_html( $bmc_ez_note['text'] )
);

if ( $bmc_ez_active ) {
	BMC_Admin::row(
		'جزئیات شناسایی‌شده',
		'<code>' . esc_html( implode( '</code>, <code>', (array) $bmc_ez_status['meta_keys'] ) ) . '</code>',
		sprintf(
			'روش احراز: %s • حالت ارسال: %s • اعتبارنامه: %s • تابع ارسال: %s • طول کد: %s',
			esc_html( $bmc_ez_status['auth_mode'] ? $bmc_ez_status['auth_mode'] : '—' ),
			esc_html( $bmc_ez_status['send_mode'] ? $bmc_ez_status['send_mode'] : '—' ),
			esc_html( $bmc_ez_status['ready'] ? 'آماده' : 'ناقص' ),
			esc_html( $bmc_ez_status['can_send'] ? 'در دسترس (ez_send_sms)' : 'در دسترس نیست' ),
			esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_ez_status['otp_length'] ) )
		)
	);
}

BMC_Admin::row(
	'پل ارتباطی',
	BMC_Admin::select(
		'ezlogin_bridge',
		$settings['ezlogin_bridge'],
		array(
			'auto' => 'خودکار (اگر فعال بود استفاده شود)',
			'yes'  => 'همیشه استفاده شود',
			'no'   => 'استفاده نشود',
		)
	),
	'در حالت «خودکار» فقط وقتی ایزی‌لاگین فعال باشد، تنظیمات و توابع آن خوانده می‌شود.'
);

BMC_Admin::row( 'خواندن تنظیمات پیامک', BMC_Admin::toggle( 'ezlogin_reuse_settings', $settings['ezlogin_reuse_settings'], 'اعتبارنامه و روش ارسال از ایزی‌لاگین خوانده شود' ), 'با انتخاب درایور «استفاده از تنظیمات ایزی‌لاگین»، ارسال دقیقاً با همان تنظیمات انجام می‌شود.' );
BMC_Admin::row( 'همگام‌سازی شمارهٔ موبایل', BMC_Admin::toggle( 'ezlogin_sync_phone', $settings['ezlogin_sync_phone'], 'شمارهٔ ثبت‌شده در BazzarMc در کلیدهای موبایل ایزی‌لاگین هم نوشته شود' ), 'کاربرانی که از راه BazzarMc ثبت‌نام کرده‌اند، در ایزی‌لاگین هم با همان شماره شناخته می‌شوند.' );
BMC_Admin::row( 'توابع ایزی‌لاگین', '<code>ez_send_sms()</code> • <code>ez_login_normalize_phone()</code> • <code>ez_login_find_user_by_phone()</code> • <code>ez_login_get_otp_length()</code>', 'در صورت وجود، ارسال پیامک از همین توابع انجام می‌شود تا رفتار دو افزونه یکسان بماند.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'قوانین ارسال و امنیت' );

BMC_Admin::row( 'اعتبار کد پیامکی', BMC_Admin::input( 'sms_otp_ttl', (int) $settings['sms_otp_ttl'], array( 'type' => 'number', 'min' => 30, 'max' => 900 ) ) . ' <span class="bmc-suffix">ثانیه</span>', 'پیش‌فرض ۱۲۰ ثانیه.' );
BMC_Admin::row( 'طول کد', BMC_Admin::input( 'sms_otp_length', (int) $settings['sms_otp_length'], array( 'type' => 'number', 'min' => 4, 'max' => 8 ) ), 'تعداد رقم‌های کد یکبارمصرف.' );
BMC_Admin::row( 'فاصلهٔ حداقلی ارسال مجدد', BMC_Admin::input( 'sms_rate_limit', (int) $settings['sms_rate_limit'], array( 'type' => 'number', 'min' => 10, 'max' => 3600 ) ) . ' <span class="bmc-suffix">ثانیه</span>', 'جلوگیری از ارسال پشت‌سرهم برای هر شماره/IP.' );
BMC_Admin::row( 'حداکثر تلاش برای واردکردن کد', BMC_Admin::input( 'sms_max_attempts', (int) $settings['sms_max_attempts'], array( 'type' => 'number', 'min' => 1, 'max' => 20 ) ), 'پس از این تعداد تلاش ناموفق، کد باطل می‌شود.' );
BMC_Admin::row( 'ارسال جایگزین با ایمیل', BMC_Admin::toggle( 'sms_fallback_email', $settings['sms_fallback_email'], 'اگر پیامک ارسال نشد، کد به ایمیل حساب کاربر فرستاده شود' ) );
BMC_Admin::row( 'پیامک اطلاع‌رسانی سفارش', BMC_Admin::toggle( 'sms_order_notify', $settings['sms_order_notify'], 'پس از پرداخت موفق، پیامک تحویل آیتم ارسال شود' ) );

BMC_Admin::section_close();

BMC_Admin::section_open( 'متن پیامک‌ها', 'متغیرها: {code} {site} {minutes} {player} {order} {server} {total}' );

BMC_Admin::row( 'متن الگوی کد اتصال', BMC_Admin::textarea( 'sms_tpl_link', $settings['sms_tpl_link'], 2 ), 'در روش «متن ساده» استفاده می‌شود.' );
BMC_Admin::row( 'متن الگوی کد ورود', BMC_Admin::textarea( 'sms_tpl_login', $settings['sms_tpl_login'], 2 ), 'برای ورود با شمارهٔ موبایل.' );
BMC_Admin::row( 'متن اطلاع‌رسانی سفارش', BMC_Admin::textarea( 'sms_tpl_delivery', $settings['sms_tpl_delivery'], 2 ), 'وقتی «پیامک اطلاع‌رسانی سفارش» روشن باشد.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'ایمیل' );

BMC_Admin::row( 'فعال‌سازی ایمیل', BMC_Admin::toggle( 'email_enabled', $settings['email_enabled'], 'کدها از طریق ایمیل هم قابل ارسال باشند' ) );
BMC_Admin::row( 'موضوع ایمیل', BMC_Admin::input( 'email_tpl_subject', $settings['email_tpl_subject'] ) );
BMC_Admin::row( 'بدنهٔ ایمیل (HTML)', BMC_Admin::textarea( 'email_tpl_body', $settings['email_tpl_body'], 7, 'bmc-code-editor' ) );

BMC_Admin::section_close();

BMC_Admin::form_close();
