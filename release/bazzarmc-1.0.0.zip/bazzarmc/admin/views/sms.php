<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

BMC_Admin::form_open( 'sms' );

BMC_Admin::section_open(
	'کانال پیامک',
	'BazzarMc مستقیماً به هیچ سامانهٔ پیامکی وصل نمی‌شود؛ ارسال کد از مسیر سرویس پیامکی فعال سایت انجام می‌شود: افزونهٔ EZ-Login یا هر سرویس دیگری که فیلتر <code>bmc_sms_send_text</code> را پیاده‌سازی کند.'
);

BMC_Admin::row(
	'فعال‌سازی پیامک',
	BMC_Admin::toggle( 'sms_enabled', $settings['sms_enabled'], 'کدهای تأیید با پیامک ارسال شوند' ),
	'اگر خاموش باشد، کد فقط از راه داشبورد یا ایمیل به کاربر می‌رسد.'
);

BMC_Admin::row(
	'مسیر ارسال',
	BMC_Admin::select(
		'sms_driver',
		$settings['sms_driver'],
		array(
			'ezlogin' => 'سرویس پیامکی فعال سایت (EZ-Login یا فیلتر اختصاصی)',
			'email'   => 'فقط ایمیل (بدون پیامک)',
			'none'    => 'غیرفعال',
		)
	),
	'وضعیت مسیرها: ' . implode(
		' | ',
		array_map(
			function ( $info ) {
				return $info['label'] . ' → ' . ( $info['configured'] ? 'آماده' : 'تنظیم نشده' );
			},
			BMC_SMS::status()
		)
	)
);

$bmc_ez_status = class_exists( 'BMC_EZLogin' ) ? BMC_EZLogin::status() : array();
$bmc_ez_note   = class_exists( 'BMC_EZLogin' ) ? BMC_EZLogin::status_note() : array( 'type' => 'muted', 'text' => '' );
$bmc_ez_active = ! empty( $bmc_ez_status['active'] );
$bmc_filter_on = (bool) has_filter( 'bmc_sms_send_text' );
$bmc_sms_ready = BMC_SMS::is_ready();

BMC_Admin::row(
	'وضعیت سرویس پیامکی',
	'<div class="bmc-status-pill ' . ( $bmc_sms_ready ? 'is-on' : 'is-off' ) . '">'
		. bmc_get_icon( $bmc_sms_ready ? 'check_circle' : 'error', array( 'size' => 16 ) )
		. '<span>' . ( $bmc_sms_ready ? 'آمادهٔ ارسال' : 'در حال حاضر مسیری برای ارسال پیامک وجود ندارد' ) . '</span>'
		. '</div>',
	esc_html( $bmc_ez_note['text'] ) . ( $bmc_filter_on ? ' — یک فیلتر <code>bmc_sms_send_text</code> هم در سایت ثبت شده است.' : '' )
);

BMC_Admin::row(
	'تست ارسال',
	'<div class="bmc-inline">'
		. '<input class="bmc-input" type="tel" id="bmcTestMobile" dir="ltr" placeholder="09xxxxxxxxx" style="max-width:200px" />'
		. '<button type="button" class="button button-secondary bmc-action" data-do="test_sms" data-extra="to:#bmcTestMobile">'
		. bmc_get_icon( 'sms', array( 'size' => 16 ) )
		. '<span>ارسال پیامک تست</span></button>'
		. '</div>',
	'یک کد نمونه به این شماره ارسال می‌شود تا مسیر ارسال را بررسی کنید.'
);

BMC_Admin::section_close();

BMC_Admin::section_open(
	'هماهنگی با EZ-Login',
	'بدون هیچ دست‌کاری در افزونهٔ EZ-Login؛ اگر فعال باشد، کلیدهای موبایل کاربران، تنظیمات سرویس پیامکی و تابع ارسال آن استفاده می‌شود و سرویس‌های پیامکی جدیدش هم به‌صورت خودکار دنبال می‌شوند.'
);

BMC_Admin::row(
	'وضعیت EZ-Login',
	'<div class="bmc-status-pill ' . ( $bmc_ez_active ? 'is-on' : 'is-off' ) . '">'
		. bmc_get_icon( $bmc_ez_active ? 'verified' : 'cancel', array( 'size' => 16 ) )
		. '<span>' . ( $bmc_ez_active ? 'فعال' : 'نصب یا فعال نیست' ) . '</span>'
		. '</div>',
	'برای هماهنگی خودکار، EZ-Login را نصب و فعال کنید؛ در غیر این صورت می‌توانید از فیلتر <code>bmc_sms_send_text</code> استفاده کنید.'
);

if ( $bmc_ez_active ) {
	BMC_Admin::row(
		'جزئیات شناسایی‌شده',
		'<code>' . esc_html( implode( '</code>, <code>', (array) $bmc_ez_status['meta_keys'] ) ) . '</code>',
		sprintf(
			'روش احراز: %s • حالت ارسال: %s • اعتبارنامه: %s • تابع ارسال: %s • طول کد: %s',
			esc_html( $bmc_ez_status['auth_mode'] ? $bmc_ez_status['auth_mode'] : '—' ),
			esc_html( $bmc_ez_status['send_mode'] ? $bmc_ez_status['send_mode'] : '—' ),
			esc_html( $bmc_ez_status['ready'] ? 'آماده' : 'ناقص' ),
			esc_html( $bmc_ez_status['can_send'] ? 'در دسترس (ez_send_sms)' : 'در دسترس نیست' ),
			esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_ez_status['otp_length'] ) )
		)
	);
}

BMC_Admin::row(
	'پل ارتباطی',
	BMC_Admin::select(
		'ezlogin_bridge',
		$settings['ezlogin_bridge'],
		array(
			'auto' => 'خودکار (اگر فعال بود استفاده شود)',
			'yes'  => 'همیشه استفاده شود',
			'no'   => 'استفاده نشود',
		)
	),
	'در حالت «خودکار» فقط وقتی EZ-Login فعال باشد، تنظیمات و توابع آن خوانده می‌شود.'
);

BMC_Admin::row(
	'خواندن تنظیمات پیامک',
	BMC_Admin::toggle( 'ezlogin_reuse_settings', $settings['ezlogin_reuse_settings'], 'اعتبارنامه و روش ارسال از EZ-Login خوانده شود' ),
	'ارسال دقیقاً با همان تنظیماتی انجام می‌شود که در EZ-Login پیکربندی کرده‌اید.'
);

BMC_Admin::row(
	'همگام‌سازی شمارهٔ موبایل',
	BMC_Admin::toggle( 'ezlogin_sync_phone', $settings['ezlogin_sync_phone'], 'شمارهٔ ثبت‌شده در BazzarMc در کلیدهای موبایل EZ-Login هم نوشته شود' ),
	'کاربرانی که از راه BazzarMc ثبت‌نام کرده‌اند، در EZ-Login هم با همان شماره شناخته می‌شوند.'
);

BMC_Admin::row(
	'توابع EZ-Login',
	'<code>ez_send_sms()</code> • <code>ez_login_normalize_phone()</code> • <code>ez_login_find_user_by_phone()</code> • <code>ez_login_get_otp_length()</code>',
	'در صورت وجود، ارسال پیامک از همین توابع انجام می‌شود تا رفتار دو افزونه یکسان بماند.'
);

BMC_Admin::section_close();

BMC_Admin::section_open( 'قوانین ارسال و امنیت' );

BMC_Admin::row( 'اعتبار کد پیامکی', BMC_Admin::input( 'sms_otp_ttl', (int) $settings['sms_otp_ttl'], array( 'type' => 'number', 'min' => 30, 'max' => 900 ) ) . ' <span class="bmc-suffix">ثانیه</span>', 'پیش‌فرض ۱۲۰ ثانیه.' );
BMC_Admin::row( 'طول کد', BMC_Admin::input( 'sms_otp_length', (int) $settings['sms_otp_length'], array( 'type' => 'number', 'min' => 4, 'max' => 8 ) ), 'تعداد رقم‌های کد یکبارمصرف.' );
BMC_Admin::row( 'حداکثر ارسال مجدد', BMC_Admin::input( 'sms_resend_limit', (int) $settings['sms_resend_limit'], array( 'type' => 'number', 'min' => 1, 'max' => 20 ) ), 'برای هر کد، چند بار امکان ارسال مجدد وجود داشته باشد.' );
BMC_Admin::row( 'فاصلهٔ حداقلی ارسال مجدد', BMC_Admin::input( 'sms_rate_limit', (int) $settings['sms_rate_limit'], array( 'type' => 'number', 'min' => 10, 'max' => 3600 ) ) . ' <span class="bmc-suffix">ثانیه</span>', 'جلوگیری از ارسال پشت‌سرهم برای هر شماره/IP.' );
BMC_Admin::row( 'حداکثر تلاش برای واردکردن کد', BMC_Admin::input( 'sms_max_attempts', (int) $settings['sms_max_attempts'], array( 'type' => 'number', 'min' => 1, 'max' => 20 ) ), 'پس از این تعداد تلاش ناموفق، کد باطل می‌شود.' );
BMC_Admin::row( 'ارسال جایگزین با ایمیل', BMC_Admin::toggle( 'sms_fallback_email', $settings['sms_fallback_email'], 'اگر پیامک ارسال نشد، کد به ایمیل حساب کاربر فرستاده شود' ) );
BMC_Admin::row( 'پیامک اطلاع‌رسانی سفارش', BMC_Admin::toggle( 'sms_order_notify', $settings['sms_order_notify'], 'پس از پرداخت موفق، پیامک تحویل آیتم ارسال شود' ) );

BMC_Admin::section_close();

BMC_Admin::section_open( 'متن پیامک‌ها', 'متغیرها: <code>{code}</code> <code>{site}</code> <code>{minutes}</code> <code>{player}</code> <code>{order}</code> <code>{server}</code> <code>{total}</code>' );

BMC_Admin::row( 'متن الگوی کد اتصال', BMC_Admin::textarea( 'sms_tpl_link', $settings['sms_tpl_link'], 2 ), 'برای کد اتصال ۵ دقیقه‌ای اکانت ماینکرافت.' );
BMC_Admin::row( 'متن الگوی کد ورود', BMC_Admin::textarea( 'sms_tpl_login', $settings['sms_tpl_login'], 2 ), 'برای ورود با شمارهٔ موبایل.' );
BMC_Admin::row( 'متن خوش‌آمدگویی', BMC_Admin::textarea( 'sms_tpl_welcome', $settings['sms_tpl_welcome'], 2 ), 'پس از نخستین ورود یا ساخت حساب کاربری.' );
BMC_Admin::row( 'متن اطلاع‌رسانی سفارش', BMC_Admin::textarea( 'sms_tpl_delivery', $settings['sms_tpl_delivery'], 2 ), 'وقتی «پیامک اطلاع‌رسانی سفارش» روشن باشد.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'ایمیل' );

BMC_Admin::row( 'فعال‌سازی ایمیل', BMC_Admin::toggle( 'email_enabled', $settings['email_enabled'], 'کدها از طریق ایمیل هم قابل ارسال باشند' ) );
BMC_Admin::row( 'موضوع ایمیل', BMC_Admin::input( 'email_tpl_subject', $settings['email_tpl_subject'] ) );
BMC_Admin::row( 'بدنهٔ ایمیل (HTML)', BMC_Admin::textarea( 'email_tpl_body', $settings['email_tpl_body'], 7, 'bmc-code-editor' ) );

BMC_Admin::section_close();

BMC_Admin::form_close();
