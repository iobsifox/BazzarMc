<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

BMC_Admin::form_open( 'server' );

BMC_Admin::section_open( 'اتصال سرور ماینکرافت', 'این توکن را در فایل config.yml پلاگین سمت سرور وارد کنید.' );

$api_url = BMC_Settings::api_base_url();

BMC_Admin::row(
	'توکن API',
	'<div class="bmc-inline">'
		. '<code class="bmc-token" id="bmcTokenField">' . esc_html( $settings['api_token'] ) . '</code>'
		. '<button type="button" class="button bmc-copy" data-copy="' . esc_attr( $settings['api_token'] ) . '">کپی</button>'
		. '<button type="button" class="button button-secondary bmc-action" data-do="regenerate_token">ساخت توکن جدید</button>'
		. '</div>',
	'با ساخت توکن جدید، اتصال سرور فعلی قطع می‌شود و باید توکن را در سرور هم به‌روزرسانی کنید.'
);

BMC_Admin::row(
	'آدرس REST API',
	'<div class="bmc-inline"><code class="bmc-token bmc-token--sm" dir="ltr">' . esc_html( $api_url ) . '</code>'
	. '<button type="button" class="button bmc-copy" data-copy="' . esc_attr( $api_url ) . '">کپی</button>'
	. '<button type="button" class="button bmc-action" data-do="ping_api">تست اتصال</button></div>',
	'مسیرهای اصلی: <code>/link/redeem</code>، <code>/link/request</code>، <code>/link/verify</code>، <code>/deliveries</code>، <code>/deliveries/mark</code>، <code>/player</code>، <code>/ping</code>'
);

BMC_Admin::row( 'نام سرور', BMC_Admin::input( 'server_name', $settings['server_name'], array( 'placeholder' => 'سرور ماینکرافت ما' ) ), 'در متن‌ها و صفحهٔ تشکر نمایش داده می‌شود.' );
BMC_Admin::row( 'آدرس سرور (IP)', BMC_Admin::input( 'server_ip', $settings['server_ip'], array( 'dir' => 'ltr', 'placeholder' => 'play.example.ir' ) ), 'فقط برای نمایش به کاربر.' );

BMC_Admin::row(
	'سیاست نام کاربری',
	BMC_Admin::select(
		'username_policy',
		$settings['username_policy'],
		array(
			'premium' => 'فقط اکانت اصلی (پرمیوم موجانگ)',
			'any'     => 'همهٔ نام‌ها (پرمیوم و کرک)',
		)
	),
	'در حالت پرمیوم، نام کاربری از API موجانگ استعلام می‌شود.'
);

BMC_Admin::row(
	'روش اتصال',
	BMC_Admin::select(
		'link_mode',
		$settings['link_mode'],
		array(
			'both'  => 'هر دو روش (پیشنهادی)',
			'panel' => 'فقط کد از پنل کاربری (۵ دقیقه‌ای)',
			'mc'    => 'فقط درخواست از داخل بازی (کد پیامکی/ایمیلی)',
		)
	),
	'روش اول: کاربر در سایت کد می‌سازد و در بازی وارد می‌کند. روش دوم: کاربر در بازی شماره موبایل می‌دهد و کد پیامک می‌شود.'
);

BMC_Admin::section_close();

BMC_Admin::section_open( 'کد اتصال', 'کدی که در پنل کاربری ساخته می‌شود و کاربر آن را در بازی وارد می‌کند.' );

BMC_Admin::row(
	'مدت اعتبار کد',
	BMC_Admin::input( 'code_ttl', (int) $settings['code_ttl'], array( 'type' => 'number', 'min' => 60, 'max' => 3600, 'step' => 30 ) ) . ' <span class="bmc-suffix">ثانیه</span>',
	'پیش‌فرض ۳۰۰ ثانیه (۵ دقیقه).'
);

BMC_Admin::row(
	'طول کد',
	BMC_Admin::input( 'code_length', (int) $settings['code_length'], array( 'type' => 'number', 'min' => 4, 'max' => 16 ) ),
	'بین ۴ تا ۱۶ کاراکتر.'
);

BMC_Admin::row(
	'نوع کاراکترها',
	BMC_Admin::select(
		'code_alphabet',
		$settings['code_alphabet'],
		array(
			'safe'   => 'حروف بزرگ + اعداد (بدون کاراکترهای مبهم مثل O و 0)',
			'digits' => 'فقط عدد',
			'full'   => 'حروف بزرگ و کوچک + اعداد',
		)
	),
	'حالت «فقط عدد» برای ورود با کیبورد عددی در بازی راحت‌تر است.'
);

BMC_Admin::row(
	'الگوی دستور در بازی',
	BMC_Admin::input( 'code_command_hint', $settings['code_command_hint'], array( 'dir' => 'ltr' ) ),
	'متغیرها: <code>{code}</code> و <code>{player}</code>. این متن به کاربر نمایش داده می‌شود.'
);

BMC_Admin::section_close();

BMC_Admin::section_open( 'قوانین اتصال و تحویل' );

BMC_Admin::row( 'اجباری بودن اتصال', BMC_Admin::toggle( 'force_link', $settings['force_link'], 'کاربر بدون اتصال اکانت ماینکرافت نتواند خرید کند' ) );
BMC_Admin::row( 'اجازهٔ قطع اتصال', BMC_Admin::toggle( 'unlink_allowed', $settings['unlink_allowed'], 'کاربر بتواند خودش اتصال را قطع کند' ) );
BMC_Admin::row( 'نقش کاربران متصل', BMC_Admin::role_select( 'default_linked_role', $settings['default_linked_role'] ), 'این نقش به‌صورت خودکار به کاربرانی که اکانتشان متصل می‌شود داده می‌شود.' );

BMC_Admin::row(
	'اعتبار تحویل‌ها',
	BMC_Admin::input( 'delivery_expiry_value', (int) $settings['delivery_expiry']['value'], array( 'type' => 'number', 'min' => 1, 'max' => 365 ) ) . ' '
		. BMC_Admin::select(
			'delivery_expiry_unit',
			$settings['delivery_expiry']['unit'],
			array(
				'minutes' => 'دقیقه',
				'hours'   => 'ساعت',
				'days'    => 'روز',
				'weeks'   => 'هفته',
			)
		),
	'اگر بازیکن در این مدت وارد سرور نشود، تحویل منقضی می‌شود.'
);

$status_options = array(
	'processing' => 'در حال پردازش (processing)',
	'completed'  => 'تکمیل‌شده (completed)',
	'on-hold'    => 'در انتظار بررسی (on-hold)',
	'pending'    => 'در انتظار پرداخت (pending)',
);

$status_html = '<div class="bmc-checkbox-grid">';
foreach ( $status_options as $key => $label ) {
	$checked = in_array( $key, (array) $settings['delivery_status'], true );
	$status_html .= '<label class="bmc-check"><input type="checkbox" name="delivery_status[]" value="' . esc_attr( $key ) . '" ' . checked( $checked, true, false ) . ' /><span>' . esc_html( $label ) . '</span></label>';
}
$status_html .= '</div>';

BMC_Admin::row( 'ثبت تحویل در وضعیت‌های سفارش', $status_html, 'وقتی سفارش به این وضعیت‌ها رسید، آیتم‌ها در صف تحویل قرار می‌گیرند.' );

BMC_Admin::row( 'سازگاری با نسخهٔ قدیمی', BMC_Admin::toggle( 'legacy_compat', $settings['legacy_compat'], 'مسیرهای REST افزونهٔ BazzarMc for MC هم فعال باشد' ), 'اگر پلاگین قدیمی ماینکرافت (WooBazzarMc) را نگه داشته‌اید، این گزینه را روشن کنید. پس از ذخیره، صفحه را رفرش کنید.' );

BMC_Admin::row( 'ثبت لاگ داخلی', BMC_Admin::toggle( 'debug_log', $settings['debug_log'], 'رویدادها در جدول لاگ ذخیره شود' ), 'برای عیب‌یابی توصیه می‌شود روشن باشد.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'اعتبارسنجی و امنیت اتصال', 'این تنظیم‌ها با بخش‌های پیکربندی پلاگین سمت ماینکرافت (config.yml) هماهنگ هستند.' );

BMC_Admin::row( 'اعتبارسنجی گواهی SSL', BMC_Admin::toggle( 'ssl_verify', $settings['ssl_verify'], 'گواهی SSL در درخواست‌های API بررسی شود' ), 'اگر سرور شما گواهی خودامضا دارد، این گزینه را خاموش کنید. در پلاگین ماینکرافت هم کلید <code>api.verify-ssl</code> وجود دارد و باید هماهنگ باشد.' );
BMC_Admin::row( 'بررسی نام کاربری مویانگ', BMC_Admin::toggle( 'mojang_check', $settings['mojang_check'], 'نام کاربری واردشده با سرویس مویانگ بررسی شود' ), 'برای اکانت‌های پریمیوم توصیه می‌شود؛ در حالت «هر نام کاربری» هم می‌تواند روشن بماند.' );

BMC_Admin::row(
	'چک‌اوت بلوکی ووکامرس',
	BMC_Admin::select(
		'blocks_checkout',
		$settings['blocks_checkout'],
		array(
			'force_classic' => 'اجبار به چک‌اوت کلاسیک (پیشنهادی)',
			'register'      => 'تزریق فیلدهای ماینکرافت در چک‌اوت بلوکی',
			'notice'        => 'فقط هشدار به مدیر',
		)
	),
	'اگر قالب شما از «بلوک چک‌اوت» استفاده می‌کند، فرم اختصاصی افزونه جای آن را نمی‌گیرد. با گزینهٔ اول، کاربر به‌صورت خودکار به چک‌اوت کلاسیک هدایت می‌شود.'
);

BMC_Admin::section_close();

BMC_Admin::section_open( 'کش و بهینه‌سازی', 'صفحه‌های سبد، خرید، اتصال و ورود نباید کش شوند؛ در غیر این صورت کدها و وضعیت اتصال به کاربران دیگر نمایش داده می‌شود.' );

$bmc_cache_detected = array();
if ( defined( 'LSCWP_V' ) ) { $bmc_cache_detected[] = 'LiteSpeed Cache'; }
if ( defined( 'WP_ROCKET_VERSION' ) ) { $bmc_cache_detected[] = 'WP Rocket'; }
if ( defined( 'W3TC' ) ) { $bmc_cache_detected[] = 'W3 Total Cache'; }
if ( defined( 'WPFC_EXIST' ) ) { $bmc_cache_detected[] = 'WP Fastest Cache'; }
if ( defined( 'WPCACHEHOME' ) ) { $bmc_cache_detected[] = 'WP Super Cache'; }

BMC_Admin::row( 'افزونه‌های کش شناسایی‌شده', $bmc_cache_detected ? '<strong>' . esc_html( implode( '، ', $bmc_cache_detected ) ) . '</strong>' : 'هیچ افزونهٔ کش شناخته‌شده‌ای پیدا نشد.', 'استثناگذاری به‌صورت خودکار برای LiteSpeed Cache و WP Rocket انجام می‌شود.' );
BMC_Admin::row( 'استثنا از کش', BMC_Admin::toggle( 'cache_exclude', $settings['cache_exclude'], 'صفحه‌های افزونه از کش و بهینه‌سازی مستثنی شوند' ), 'تعریف خودکار <code>DONOTCACHEPAGE</code>، هدرهای no-cache، فیلتر WP Rocket و کنترل LiteSpeed.' );
BMC_Admin::row( 'توکن API کلادفلر', BMC_Admin::input( 'cf_api_token', $settings['cf_api_token'], array( 'dir' => 'ltr', 'placeholder' => 'Cloudflare API Token' ) ), 'اختیاری؛ برای پاک‌سازی کش کلادفلر و ساخت قاعدهٔ «کش نشود» روی صفحه‌های افزونه.' );
BMC_Admin::row( 'شناسهٔ Zone', BMC_Admin::input( 'cf_zone_id', $settings['cf_zone_id'], array( 'dir' => 'ltr', 'placeholder' => 'zone id' ) ), 'از داشبورد کلادفلر → Overview → Zone ID.' );
BMC_Admin::row( 'قاعدهٔ کش کلادفلر', BMC_Admin::toggle( 'cf_cache_rule', $settings['cf_cache_rule'], 'قاعدهٔ Cache Rule به‌صورت خودکار در کلادفلر ساخته/به‌روزرسانی شود' ), 'با دکمهٔ «ساخت قاعدهٔ کش» در تب ابزارها اعمال می‌شود.' );

BMC_Admin::section_close();

BMC_Admin::form_close();
