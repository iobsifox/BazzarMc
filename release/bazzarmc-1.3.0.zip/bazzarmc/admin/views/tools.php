<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tables = BMC_DB::table_status();
$report = BMC_Migrate::migration_report();
$logs   = BMC_Logger::recent( 30 );
?>
<section class="bmc-box">
	<div class="bmc-box__head"><h2>وضعیت جدول‌های دیتابیس</h2></div>
	<div class="bmc-box__body">
		<table class="bmc-table bmc-table--full">
			<thead><tr><th>جدول</th><th>نام کامل</th><th>ردیف‌ها</th><th>وضعیت</th></tr></thead>
			<tbody>
				<?php foreach ( $tables as $name => $info ) : ?>
					<tr>
						<td><?php echo esc_html( $name ); ?></td>
						<td class="bmc-mono" dir="ltr"><?php echo esc_html( $info['table'] ); ?></td>
						<td><?php echo esc_html( BMC_Helpers::to_persian_digits( $info['rows'] ) ); ?></td>
						<td><span class="bmc-pill <?php echo $info['exists'] ? 'is-done' : 'is-cancelled'; ?>"><?php echo $info['exists'] ? 'سالم' : 'موجود نیست'; ?></span></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<div class="bmc-inline" style="margin-top:12px">
			<button type="button" class="button bmc-action" data-do="rebuild_tables">بازسازی/به‌روزرسانی جدول‌ها</button>
			<button type="button" class="button bmc-action" data-do="run_cron">اجرای دستی نگهداری</button>
			<button type="button" class="button bmc-action" data-do="create_pages">ساخت صفحه‌های افزونه</button>
			<button type="button" class="button button-link-delete bmc-action" data-do="clear_logs" data-confirm="1">پاک‌سازی لاگ‌ها</button>
		</div>
	</div>
</section>

<section class="bmc-box">
	<div class="bmc-box__head"><h2>کش و بهینه‌سازی</h2></div>
	<div class="bmc-box__body">
		<?php
		$bmc_cache_status = class_exists( 'BMC_Cache' ) ? BMC_Cache::status() : array();
		?>
		<p>
			استثنای خودکار از کش:
			<span class="bmc-pill <?php echo empty( $bmc_cache_status['enabled'] ) ? 'is-cancelled' : 'is-done'; ?>"><?php echo empty( $bmc_cache_status['enabled'] ) ? 'خاموش' : 'روشن'; ?></span>
			&nbsp;|&nbsp; افزونه‌های شناسایی‌شده:
			<strong><?php echo $bmc_cache_status['detected'] ? esc_html( implode( '، ', (array) $bmc_cache_status['detected'] ) ) : '—'; ?></strong>
			&nbsp;|&nbsp; کلادفلر:
			<span class="bmc-pill <?php echo empty( $bmc_cache_status['cloudflare'] ) ? 'is-cancelled' : 'is-done'; ?>"><?php echo empty( $bmc_cache_status['cloudflare'] ) ? 'تنظیم نشده' : 'آماده'; ?></span>
		</p>
		<div class="bmc-inline" style="margin-top:12px">
			<button type="button" class="button bmc-action" data-do="purge_cache">پاک‌سازی کش (سایت + افزونه‌ها + کلادفلر)</button>
			<button type="button" class="button bmc-action" data-do="cf_cache_rule">ساخت قاعدهٔ «کش نشود» در کلادفلر</button>
		</div>
		<p class="bmc-hint" style="margin-top:10px">صفحه‌های سبد، خرید، اتصال اکانت و ورود همیشه از کش مستثنی می‌شوند تا کد یکبارمصرف یک کاربر به کاربر دیگر نمایش داده نشود.</p>
	</div>
</section>

<section class="bmc-box">
	<div class="bmc-box__head"><h2>یکپارچه‌سازی المنتور</h2></div>
	<div class="bmc-box__body">
		<?php
		$bmc_el_active    = class_exists( 'BMC_Elementor' ) && BMC_Elementor::is_active();
		$bmc_el_version   = class_exists( 'BMC_Elementor' ) ? BMC_Elementor::version() : '';
		$bmc_el_supported = class_exists( 'BMC_Elementor' ) && BMC_Elementor::is_supported();
		$bmc_el_booted    = class_exists( 'BMC_Elementor' ) && BMC_Elementor::booted();
		?>
		<p>
			وضعیت المنتور:
			<span class="bmc-pill <?php echo $bmc_el_active ? 'is-done' : 'is-cancelled'; ?>"><?php echo $bmc_el_active ? 'فعال' : 'نصب یا فعال نیست'; ?></span>
			<?php if ( $bmc_el_version ) : ?>
				&nbsp;|&nbsp; نسخهٔ المنتور: <strong dir="ltr"><?php echo esc_html( $bmc_el_version ); ?></strong>
			<?php endif; ?>
			&nbsp;|&nbsp; ویجت‌های BazzarMc:
			<span class="bmc-pill <?php echo $bmc_el_booted ? 'is-done' : 'is-cancelled'; ?>"><?php echo $bmc_el_booted ? 'ثبت شده (۱۱ ویجت)' : 'ثبت نشده'; ?></span>
		</p>

		<p class="bmc-hint">
			ویجت‌ها در پنل المنتور زیر دستهٔ <strong>«BazzarMc — فروشگاه ماینکرافت»</strong> قرار می‌گیرند:
			کارت حساب کاربری، اتصال اکانت ماینکرافت، وضعیت اتصال، منوی حساب کاربری، محتوای حساب کاربری، سبد خرید اختصاصی، چک‌اوت اختصاصی، تیکت‌های پشتیبانی، گفت‌وگوی تیکت، تحویل‌های من و رنک‌های کاربر.
		</p>

		<?php if ( $bmc_el_active && ! $bmc_el_supported ) : ?>
			<p class="bmc-hint">نسخهٔ المنتور شما قدیمی است؛ برای ثبت ویجت‌ها به المنتور ۳.۱ یا جدیدتر نیاز دارید. افزونه بدون المنتور هم کامل کار می‌کند.</p>
		<?php endif; ?>

		<p class="bmc-hint">
			اگر صفحهٔ «حساب کاربری» را با المنتور می‌سازید و ویجت «کارت حساب کاربری» را در آن گذاشته‌اید، گزینهٔ «نمایش کارت در داشبورد حساب کاربری» را در بخش <strong>تأیید و حساب کاربری</strong> خاموش کنید تا کارت دوبار نمایش داده نشود.
		</p>

		<?php BMC_Admin::form_open( 'tools' ); ?>
		<label class="bmc-check">
			<input type="checkbox" name="elementor_enabled" value="yes" <?php checked( BMC_Settings::bool( 'elementor_enabled', true ) ); ?> />
			<span>ثبت ویجت‌های BazzarMc در المنتور</span>
		</label>
		<p class="bmc-hint">اگر المنتور نصب یا فعال نباشد، افزونه هیچ خطایی نمی‌دهد و همهٔ بخش‌ها با شورت‌کدها و قالب‌های ووکامرس کار می‌کنند.</p>
		<?php BMC_Admin::form_close( 'ذخیرهٔ تنظیمات المنتور' ); ?>
	</div>
</section>

<section class="bmc-box">
	<div class="bmc-box__head"><h2>مهاجرت از BazzarMc for MC (نسخهٔ قدیمی)</h2></div>
	<div class="bmc-box__body">
		<p>
			وضعیت شناسایی:
			<strong><?php echo $report['legacy_plugin'] ? 'افزونهٔ قدیمی نصب است' : 'افزونهٔ قدیمی نصب نیست'; ?></strong> —
			<?php echo esc_html( BMC_Helpers::to_persian_digits( $report['users'] ) ); ?> کاربر دارای متای <code>minecraft_player</code> —
			<?php echo esc_html( BMC_Helpers::to_persian_digits( $report['deliveries'] ) ); ?> رکورد در جدول قدیمی.
		</p>

		<p>با اجرای مهاجرت، موارد زیر منتقل می‌شوند:</p>
		<ul class="bmc-list">
			<li>اکانت‌های متصل (متای <code>minecraft_player</code> → <code>bmc_mc_player</code>) به‌همراه نقش کاربری</li>
			<li>تحویل‌های در انتظار و تحویل‌شده از جدول <code>pending_deliveries</code></li>
			<li>تنظیمات محصولات همگام‌شده، نقش‌ها و سیاست نام کاربری</li>
		</ul>

		<button type="button" class="button button-primary bmc-action" data-do="run_migration" data-confirm="1">اجرای مهاجرت</button>
	</div>
</section>

<section class="bmc-box">
	<div class="bmc-box__head"><h2>نصب پلاگین سمت سرور ماینکرافت</h2></div>
	<div class="bmc-box__body">
		<ol class="bmc-list bmc-list--ordered">
			<li>فایل <code>BazzarMC.jar</code> را در پوشهٔ <code>plugins</code> سرور (Spigot/Paper) قرار دهید.</li>
			<li>سرور را یک‌بار ری‌استارت کنید تا <code>plugins/BazzarMC/config.yml</code> ساخته شود.</li>
			<li>مقدار <code>api.base-url</code> را روی <code dir="ltr"><?php echo esc_html( home_url( '/' ) ); ?></code> و <code>api.token</code> را روی توکن بالا تنظیم کنید.</li>
			<li>در بخش <code>products</code> کلید هر محصول را دقیقاً برابر «نام محصول با حروف کوچک» یا شناسهٔ محصول قرار دهید.</li>
			<li>دستور <code>/bmc reload</code> را با کنسول یا OP اجرا کنید.</li>
		</ol>

		<p class="bmc-note">دستورهای بازی: <code dir="ltr">/mclink &lt;code&gt;</code>، <code dir="ltr">/mclink phone &lt;mobile&gt;</code>، <code dir="ltr">/mclink status</code>، <code dir="ltr">/mclink claim</code></p>
	</div>
</section>

<section class="bmc-box">
	<div class="bmc-box__head"><h2>لاگ‌های اخیر</h2></div>
	<div class="bmc-box__body">
		<?php if ( empty( $logs ) ) : ?>
			<p class="bmc-empty">لاگی ثبت نشده است.</p>
		<?php else : ?>
			<ul class="bmc-loglist">
				<?php foreach ( $logs as $log ) : ?>
					<li class="bmc-log bmc-log--<?php echo esc_attr( $log->level ); ?>">
						<span class="bmc-log__time"><?php echo esc_html( BMC_Jalali::format( $log->created_at ) ); ?></span>
						<span class="bmc-log__channel"><?php echo esc_html( $log->channel ); ?></span>
						<span class="bmc-log__msg"><?php echo esc_html( $log->message ); ?><?php echo $log->context ? ' <small dir="ltr">' . esc_html( $log->context ) . '</small>' : ''; ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
</section>

<section class="bmc-box">
	<div class="bmc-box__head"><h2>پاک‌سازی کامل هنگام حذف افزونه</h2></div>
	<div class="bmc-box__body">
		<form method="post" class="bmc-form">
			<?php wp_nonce_field( 'bmc_save_settings', 'bmc_settings_nonce' ); ?>
			<input type="hidden" name="bmc_tab" value="purge" />

			<div class="bmc-row">
				<div class="bmc-row__label">
					<label>حذف داده‌ها هنگام Uninstall</label>
					<span class="bmc-row__hint">اگر روشن باشد، با حذف افزونه جدول‌ها، تنظیمات و متای اتصال کاربران پاک می‌شود.</span>
				</div>
				<div class="bmc-row__field">
					<?php echo BMC_Admin::toggle( 'purge_on_uninstall', $settings['purge_on_uninstall'], 'جدول‌ها و تنظیمات حذف شوند' ); ?>
				</div>
			</div>

			<div class="bmc-inline" style="margin-top:12px">
				<button type="submit" class="button button-primary">ذخیره</button>
			</div>
		</form>

		<p class="bmc-note bmc-note--warn" style="margin-top:14px">حذف جدول‌ها بازگشت‌پذیر نیست. اگر ممکن است افزونه را دوباره نصب کنید، این گزینه را خاموش بگذارید.</p>
	</div>
</section>
