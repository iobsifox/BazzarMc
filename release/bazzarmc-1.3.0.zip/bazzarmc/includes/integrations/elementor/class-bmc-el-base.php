<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Widget_Base;
use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Plugin;

abstract class BMC_EL_Base extends Widget_Base {

	public function get_categories() {
		return array( BMC_Elementor::CATEGORY );
	}

	public function get_keywords() {
		return array_merge(
			array( 'bazzarmc', 'bmc', 'minecraft', 'woocommerce', 'store', 'mclink', 'account' ),
			$this->extra_keywords()
		);
	}

	public function get_style_depends() {
		return BMC_Elementor::style_depends();
	}

	public function get_script_depends() {
		return array_merge( array( 'bmc-icons' ), $this->extra_scripts() );
	}

	abstract protected function bmc_slug();

	abstract protected function render_inner( $settings );

	protected function extra_keywords() {
		return array();
	}

	protected function extra_scripts() {
		return array();
	}

	protected function content_controls() {}

	protected function style_controls() {}

	protected function register_controls() {
		$this->content_controls();
		$this->common_style_controls();
		$this->style_controls();
	}

	protected function var_selector() {
		return '{{WRAPPER}} .bmc-el .bmc-wrap, {{WRAPPER}} .bmc-el .bmc-acard, {{WRAPPER}} .bmc-el';
	}

	protected function woocommerce_missing() {
		return ! class_exists( 'WooCommerce' );
	}

	protected function notice( $text ) {
		return '<div class="bmc-alert bmc-alert--warn">' . bmc_get_icon( 'warning', array( 'size' => 18 ) ) . ' ' . esc_html( $text ) . '</div>';
	}

	protected function is_editor() {
		if ( ! class_exists( '\Elementor\Plugin' ) || empty( Plugin::$instance->editor ) ) {
			return false;
		}

		return method_exists( Plugin::$instance->editor, 'is_edit_mode' ) && (bool) Plugin::$instance->editor->is_edit_mode();
	}

	protected function editor_placeholder( $text ) {
		if ( ! $this->is_editor() ) {
			return '';
		}

		return '<div class="bmc-el bmc-el--placeholder">'
			. bmc_get_icon( 'build', array( 'size' => 20 ) )
			. '<span>' . esc_html( $text ) . '</span>'
			. '</div>';
	}

	protected function common_style_controls() {
		$this->start_controls_section(
			'bmc_sec_style',
			array(
				'label' => 'ظاهر BazzarMc',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'bmc_theme',
			array(
				'label'   => 'پوستهٔ رنگی',
				'type'    => Controls_Manager::SELECT,
				'default' => 'auto',
				'options' => array(
					'auto'  => 'خودکار (پیش‌فرض افزونه)',
					'light' => 'روشن',
					'dark'  => 'تیره',
				),
			)
		);

		$this->add_control(
			'bmc_frame',
			array(
				'label'       => 'قاب بیرونی',
				'type'        => Controls_Manager::SELECT,
				'default'     => 'boxed',
				'options'     => array(
					'boxed' => 'قاب‌دار (پس‌زمینه، حاشیه و گردی BazzarMc)',
					'bare'  => 'بدون قاب (فقط محتوا — استایل با بخش/ستون المنتور)',
				),
				'description' => 'اگر پس‌زمینه و فاصله‌ها را در خودِ المنتور تنظیم می‌کنید، «بدون قاب» را انتخاب کنید.',
			)
		);

		$this->add_control(
			'bmc_grid_overlay',
			array(
				'label'        => 'حذف الگوی شبکه‌ای پس‌زمینه',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'selectors'    => array(
					'{{WRAPPER}} .bmc-el .bmc-wrap::before' => 'display: none;',
				),
				'condition'    => array(
					'bmc_frame' => 'boxed',
				),
			)
		);

		$this->add_control(
			'bmc_accent',
			array(
				'label'     => 'رنگ تأکیدی',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					$this->var_selector() => '--bmc-accent: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'bmc_accent_2',
			array(
				'label'     => 'رنگ تأکیدی دوم',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					$this->var_selector() => '--bmc-accent-2: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'bmc_accent_soft',
			array(
				'label'     => 'رنگ تأکیدی ملایم (پس‌زمینهٔ چیپ‌ها)',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					$this->var_selector() => '--bmc-accent-soft: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'bmc_bg',
			array(
				'label'     => 'پس‌زمینهٔ اصلی',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					$this->var_selector() => '--bmc-bg: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'bmc_bg_2',
			array(
				'label'     => 'پس‌زمینهٔ دوم',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					$this->var_selector() => '--bmc-bg-2: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'bmc_surface',
			array(
				'label'     => 'پس‌زمینهٔ سطح‌ها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					$this->var_selector() => '--bmc-surface: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'bmc_surface_2',
			array(
				'label'     => 'پس‌زمینهٔ سطح دوم',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					$this->var_selector() => '--bmc-surface-2: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'bmc_text_color',
			array(
				'label'     => 'رنگ متن',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					$this->var_selector() => '--bmc-text: {{VALUE}}; color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'bmc_muted_color',
			array(
				'label'     => 'رنگ متن کم‌رنگ',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					$this->var_selector() => '--bmc-muted: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'bmc_border_color',
			array(
				'label'     => 'رنگ حاشیه‌ها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					$this->var_selector() => '--bmc-border: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'bmc_radius',
			array(
				'label'      => 'گردی گوشه‌ها',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'rem' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 48,
					),
				),
				'selectors'  => array(
					$this->var_selector() => '--bmc-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'bmc_radius_sm',
			array(
				'label'      => 'گردی گوشه‌های کوچک',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'rem' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 32,
					),
				),
				'selectors'  => array(
					$this->var_selector() => '--bmc-radius-sm: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'bmc_no_shadow',
			array(
				'label'        => 'حذف سایه‌ها',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'selectors'    => array(
					'{{WRAPPER}} .bmc-el .bmc-wrap, {{WRAPPER}} .bmc-el .bmc-acard, {{WRAPPER}} .bmc-el .bmc-box, {{WRAPPER}} .bmc-el .bmc-card' => 'box-shadow: none;',
				),
			)
		);

		$this->add_control(
			'bmc_font_family',
			array(
				'label'     => 'قلم',
				'type'      => Controls_Manager::FONT,
				'default'   => '',
				'selectors' => array(
					'{{WRAPPER}} .bmc-el' => '--bmc-font: "{{VALUE}}", Vazirmatn, Vazir, Tahoma, sans-serif; font-family: var(--bmc-font);',
				),
			)
		);

		$this->add_responsive_control(
			'bmc_font_size',
			array(
				'label'      => 'اندازهٔ پایهٔ متن',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'rem' ),
				'range'      => array(
					'px' => array(
						'min' => 10,
						'max' => 24,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el' => 'font-size: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'bmc_padding',
			array(
				'label'      => 'فاصلهٔ داخلی قاب',
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
				'condition'  => array(
					'bmc_frame' => 'boxed',
				),
			)
		);

		$this->add_responsive_control(
			'bmc_max_width',
			array(
				'label'      => 'بیشترین پهنا',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array(
						'min' => 240,
						'max' => 1600,
					),
					'%'  => array(
						'min' => 20,
						'max' => 100,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el' => 'max-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'bmc_align',
			array(
				'label'     => 'چینش',
				'type'      => Controls_Manager::CHOOSE,
				'default'   => '0',
				'options'   => array(
					'0'    => array(
						'title' => 'تمام‌پهنا',
						'icon'  => 'eicon-full-width',
					),
					'auto' => array(
						'title' => 'وسط‌چین',
						'icon'  => 'eicon-h-align-center',
					),
				),
				'selectors' => array(
					'{{WRAPPER}} .bmc-el' => 'margin-inline: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function table_style_controls( $label = 'جدول و فهرست' ) {
		$this->start_controls_section(
			'bmc_sec_table_style',
			array(
				'label' => $label,
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'table_typography',
				'label'    => 'تایپوگرافی جدول',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-table, {{WRAPPER}} .bmc-el table',
			)
		);

		$this->add_control(
			'table_head_bg',
			array(
				'label'     => 'پس‌زمینهٔ سرستون',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-table thead th, {{WRAPPER}} .bmc-el table thead th' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'table_row_bg',
			array(
				'label'     => 'پس‌زمینهٔ ردیف‌ها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-table tbody tr, {{WRAPPER}} .bmc-el table tbody tr' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'table_row_hover_bg',
			array(
				'label'     => 'پس‌زمینهٔ ردیف در هاور',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-table tbody tr:hover, {{WRAPPER}} .bmc-el table tbody tr:hover' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'table_border_color',
			array(
				'label'     => 'رنگ خطوط جدول',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-table th, {{WRAPPER}} .bmc-el .bmc-table td, {{WRAPPER}} .bmc-el table th, {{WRAPPER}} .bmc-el table td' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'table_cell_padding',
			array(
				'label'      => 'فاصلهٔ داخلی سلول‌ها',
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-table th, {{WRAPPER}} .bmc-el .bmc-table td, {{WRAPPER}} .bmc-el table th, {{WRAPPER}} .bmc-el table td' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function button_style_controls( $label = 'دکمه‌ها' ) {
		$this->start_controls_section(
			'bmc_sec_button_style',
			array(
				'label' => $label,
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'button_typography',
				'label'    => 'تایپوگرافی دکمه‌ها',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-btn, {{WRAPPER}} .bmc-el button',
			)
		);

		$this->add_control(
			'button_primary_bg',
			array(
				'label'     => 'پس‌زمینهٔ دکمهٔ اصلی',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-btn-p, {{WRAPPER}} .bmc-el .bmc-btn--block' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_primary_color',
			array(
				'label'     => 'رنگ متن دکمهٔ اصلی',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-btn-p, {{WRAPPER}} .bmc-el .bmc-btn--block' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_outline_color',
			array(
				'label'     => 'رنگ دکمهٔ دوم',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-btn-o, {{WRAPPER}} .bmc-el .bmc-btn--ghost' => 'color: {{VALUE}}; border-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'button_radius',
			array(
				'label'      => 'گردی دکمه‌ها',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-btn, {{WRAPPER}} .bmc-el button' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'button_padding',
			array(
				'label'      => 'فاصلهٔ داخلی دکمه‌ها',
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-btn, {{WRAPPER}} .bmc-el button' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function field_style_controls( $label = 'فیلدها' ) {
		$this->start_controls_section(
			'bmc_sec_field_style',
			array(
				'label' => $label,
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'field_bg',
			array(
				'label'     => 'پس‌زمینهٔ فیلدها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-input, {{WRAPPER}} .bmc-el input[type="text"], {{WRAPPER}} .bmc-el input[type="tel"], {{WRAPPER}} .bmc-el input[type="email"], {{WRAPPER}} .bmc-el input[type="number"], {{WRAPPER}} .bmc-el select, {{WRAPPER}} .bmc-el textarea' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'field_color',
			array(
				'label'     => 'رنگ متن فیلدها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-input, {{WRAPPER}} .bmc-el input, {{WRAPPER}} .bmc-el select, {{WRAPPER}} .bmc-el textarea' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'field_border_color',
			array(
				'label'     => 'رنگ حاشیهٔ فیلدها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-input, {{WRAPPER}} .bmc-el input, {{WRAPPER}} .bmc-el select, {{WRAPPER}} .bmc-el textarea' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'field_radius',
			array(
				'label'      => 'گردی فیلدها',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 30,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-input, {{WRAPPER}} .bmc-el input, {{WRAPPER}} .bmc-el select, {{WRAPPER}} .bmc-el textarea' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'label_typography',
				'label'    => 'تایپوگرافی برچسب‌ها',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-label, {{WRAPPER}} .bmc-el label',
			)
		);

		$this->add_control(
			'label_color',
			array(
				'label'     => 'رنگ برچسب‌ها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-label, {{WRAPPER}} .bmc-el label' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render() {
		$settings = $this->get_settings_for_display();
		$inner    = (string) $this->render_inner( $settings );

		if ( '' === trim( $inner ) ) {
			echo $this->editor_placeholder( 'محتوایی برای نمایش وجود ندارد.' );
			return;
		}

		$classes = array( 'bmc-el', 'bmc-el--' . $this->bmc_slug() );
		$theme   = isset( $settings['bmc_theme'] ) ? (string) $settings['bmc_theme'] : 'auto';
		$frame   = isset( $settings['bmc_frame'] ) ? (string) $settings['bmc_frame'] : 'boxed';

		if ( 'light' === $theme ) {
			$classes[] = 'bmc-el--light';
		} elseif ( 'dark' === $theme ) {
			$classes[] = 'bmc-el--dark';
		}

		if ( 'bare' === $frame ) {
			$classes[] = 'bmc-el--bare';
		}

		printf(
			'<div class="%1$s" data-bmc="%2$s" dir="rtl">',
			esc_attr( implode( ' ', $classes ) ),
			esc_attr( $this->get_id() )
		);

		echo $inner;

		echo '</div>';
	}
}
