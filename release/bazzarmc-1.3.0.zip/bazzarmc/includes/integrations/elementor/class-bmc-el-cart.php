<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class BMC_EL_Cart extends BMC_EL_Base {

	public function get_name() {
		return 'bmc-cart';
	}

	public function get_title() {
		return 'سبد خرید اختصاصی';
	}

	public function get_icon() {
		return 'eicon-cart-medium';
	}

	protected function bmc_slug() {
		return 'cart';
	}

	protected function extra_keywords() {
		return array( 'cart', 'basket', 'سبد', 'خرید' );
	}

	protected function extra_scripts() {
		return array( 'bmc-checkout' );
	}

	protected function content_controls() {
		$this->start_controls_section(
			'bmc_sec_content',
			array(
				'label' => 'سبد خرید',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'bmc_notice',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => 'سبد خرید اختصاصی BazzarMc با خلاصهٔ قیمت، کد تخفیف، ویرایش تعداد و دکمهٔ پرداخت که تا اتصال اکانت ماینکرافت غیرفعال می‌ماند. موتور سبد همان ووکامرس است.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_control(
			'empty_text',
			array(
				'label'   => 'متن سبد خالی',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'shop_url',
			array(
				'label'       => 'پیوند فروشگاه (برای سبد خالی)',
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'description' => 'خالی = صفحهٔ فروشگاه ووکامرس.',
			)
		);

		$this->end_controls_section();
	}

	protected function style_controls() {
		$this->table_style_controls( 'فهرست محصولات' );
		$this->button_style_controls();

		$this->start_controls_section(
			'bmc_sec_cart_style',
			array(
				'label' => 'سبد خرید',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'cart_title_typography',
				'label'    => 'تایپوگرافی عنوان سبد',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-cart-head h2',
			)
		);

		$this->add_control(
			'cart_line_bg',
			array(
				'label'     => 'پس‌زمینهٔ ردیف محصول',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-cart-line, {{WRAPPER}} .bmc-el .bmc-cart-row' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'cart_thumb_size',
			array(
				'label'      => 'اندازهٔ تصویر محصول',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 32,
						'max' => 140,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-cart-thumb, {{WRAPPER}} .bmc-el .bmc-cart-thumb img' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'cart_summary_bg',
			array(
				'label'     => 'پس‌زمینهٔ خلاصهٔ پرداخت',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-cart-side, {{WRAPPER}} .bmc-el .bmc-summary' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'cart_side_width',
			array(
				'label'      => 'پهنای ستون خلاصه',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array(
						'min' => 220,
						'max' => 640,
					),
					'%'  => array(
						'min' => 20,
						'max' => 60,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-cart-side' => 'flex-basis: {{SIZE}}{{UNIT}}; max-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render_inner( $settings ) {
		if ( $this->woocommerce_missing() ) {
			return $this->notice( 'برای نمایش سبد خرید، ووکامرس باید فعال باشد.' );
		}

		$html = (string) BMC_Public::shortcode_cart();

		if ( '' !== trim( (string) $settings['empty_text'] ) && function_exists( 'WC' ) && WC()->cart && WC()->cart->is_empty() ) {
			$shop = '' !== trim( (string) $settings['shop_url'] ) ? (string) $settings['shop_url'] : ( function_exists( 'wc_get_page_permalink' ) ? (string) wc_get_page_permalink( 'shop' ) : home_url( '/' ) );

			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-container"><div class="bmc-empty">'
				. bmc_get_icon( 'shopping_basket', array( 'size' => 44 ) )
				. '<h3>' . esc_html( $settings['empty_text'] ) . '</h3>'
				. '<a class="bmc-btn bmc-btn-p" href="' . esc_url( $shop ) . '">' . bmc_get_icon( 'storefront', array( 'size' => 17 ) ) . ' رفتن به فروشگاه</a>'
				. '</div></div></div>';
		}

		return $html;
	}
}
