<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class BMC_EL_Checkout extends BMC_EL_Base {

	public function get_name() {
		return 'bmc-checkout';
	}

	public function get_title() {
		return 'چک‌اوت اختصاصی';
	}

	public function get_icon() {
		return 'eicon-product-add-to-cart';
	}

	protected function bmc_slug() {
		return 'checkout';
	}

	protected function extra_keywords() {
		return array( 'checkout', 'payment', 'gate', 'چک‌اوت', 'پرداخت' );
	}

	protected function extra_scripts() {
		return array( 'bmc-checkout' );
	}

	protected function content_controls() {
		$this->start_controls_section(
			'bmc_sec_content',
			array(
				'label' => 'چک‌اوت',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'bmc_notice',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => 'فرم چک‌اوت اختصاصی BazzarMc با خلاصهٔ سفارش و درگاه‌های همان ووکامرس. اگر اکانت ماینکرافت متصل نباشد، به‌جای فرم، پیام مسدودسازی نمایش داده می‌شود.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_control(
			'hide_gate',
			array(
				'label'        => 'نمایش فرم حتی بدون اتصال اکانت',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'description'  => 'فقط برای پیش‌نمایش طراحی؛ در زمان ثبت سفارش همچنان بررسی اتصال انجام می‌شود.',
			)
		);

		$this->end_controls_section();
	}

	protected function style_controls() {
		$this->field_style_controls();
		$this->button_style_controls();

		$this->start_controls_section(
			'bmc_sec_checkout_style',
			array(
				'label' => 'چک‌اوت',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'section_typography',
				'label'    => 'تایپوگرافی عنوان بخش‌ها',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-card__title, {{WRAPPER}} .bmc-el h3',
			)
		);

		$this->add_control(
			'section_color',
			array(
				'label'     => 'رنگ عنوان بخش‌ها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-card__title, {{WRAPPER}} .bmc-el h3' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'card_padding',
			array(
				'label'      => 'فاصلهٔ داخلی کارت‌ها',
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'card_bg',
			array(
				'label'     => 'پس‌زمینهٔ کارت‌ها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-card' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'summary_bg',
			array(
				'label'     => 'پس‌زمینهٔ خلاصهٔ سفارش',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-summary, {{WRAPPER}} .bmc-el .bmc-check-side' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'gate_bg',
			array(
				'label'     => 'پس‌زمینهٔ پیام مسدودسازی',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-gate' => 'background: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render_inner( $settings ) {
		if ( $this->woocommerce_missing() ) {
			return $this->notice( 'برای نمایش چک‌اوت، ووکامرس باید فعال باشد.' );
		}

		if ( 'yes' === $settings['hide_gate'] ) {
			BMC_Public::enqueue_base_assets();

			ob_start();
			BMC_Checkout::render_checkout();

			return (string) ob_get_clean();
		}

		return BMC_Public::shortcode_checkout();
	}
}
