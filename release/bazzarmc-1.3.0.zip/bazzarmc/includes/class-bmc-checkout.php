<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Checkout {

	const FIELD_PLAYER = 'bmc_mc_player';
	const FIELD_GIFT   = 'bmc_is_gift';

	public static function init() {

		add_filter( 'woocommerce_checkout_fields', array( __CLASS__, 'filter_checkout_fields' ), 999, 1 );
		add_action( 'woocommerce_checkout_process', array( __CLASS__, 'validate_checkout' ), 5 );
		add_action( 'woocommerce_checkout_update_order_meta', array( __CLASS__, 'save_order_meta' ), 10, 1 );

		add_filter( 'the_content', array( __CLASS__, 'replace_checkout_content' ), 11 );

		add_filter( 'woocommerce_is_purchasable', array( __CLASS__, 'maybe_block_purchasable' ), 10, 2 );
		add_action( 'woocommerce_single_product_summary', array( __CLASS__, 'product_gate_notice' ), 25 );

		add_filter( 'woocommerce_thankyou_order_received_text', array( __CLASS__, 'thankyou_text' ), 10, 2 );

		add_action( 'wp_ajax_bmc_checkout_summary', array( __CLASS__, 'ajax_summary' ) );
		add_action( 'wp_ajax_nopriv_bmc_checkout_summary', array( __CLASS__, 'ajax_summary' ) );
		add_action( 'wp_ajax_bmc_apply_coupon', array( __CLASS__, 'ajax_apply_coupon' ) );
		add_action( 'wp_ajax_nopriv_bmc_apply_coupon', array( __CLASS__, 'ajax_apply_coupon' ) );
		add_action( 'wp_ajax_bmc_remove_coupon', array( __CLASS__, 'ajax_remove_coupon' ) );
		add_action( 'wp_ajax_nopriv_bmc_remove_coupon', array( __CLASS__, 'ajax_remove_coupon' ) );

		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ), 20 );

		remove_action( 'woocommerce_proceed_to_checkout', 'woocommerce_button_proceed_to_checkout', 20 );
		add_action( 'woocommerce_proceed_to_checkout', array( __CLASS__, 'render_cart_button' ), 20 );
		add_action( 'woocommerce_after_cart_totals', array( __CLASS__, 'render_cart_notice' ), 5 );
		add_action( 'woocommerce_after_cart_table', array( __CLASS__, 'render_cart_notice' ), 5 );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_force_classic_checkout' ), 5 );
		add_action( 'admin_notices', array( __CLASS__, 'blocks_admin_notice' ) );
		add_action( 'woocommerce_blocks_loaded', array( __CLASS__, 'register_blocks_fields' ) );
		add_action( 'woocommerce_order_refunded', array( __CLASS__, 'revoke_order_roles' ), 20, 1 );
		add_action( 'woocommerce_order_status_cancelled', array( __CLASS__, 'revoke_order_roles' ), 20, 1 );
		add_action( 'woocommerce_order_status_refunded', array( __CLASS__, 'revoke_order_roles' ), 20, 1 );
	}

	public static function synced_product_ids() {
		return array_map( 'absint', (array) BMC_Settings::get( 'sync_products', array() ) );
	}

	public static function is_synced_product( $product_id ) {
		$synced = self::synced_product_ids();
		return in_array( (int) $product_id, $synced, true );
	}

	public static function cart_has_synced_products() {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return false;
		}

		$synced = self::synced_product_ids();
		if ( ! $synced ) {
			return false;
		}

		foreach ( WC()->cart->get_cart() as $item ) {
			if ( empty( $item['product_id'] ) ) {
				continue;
			}
			if ( in_array( (int) $item['product_id'], $synced, true ) ) {
				return true;
			}
			if ( ! empty( $item['variation_id'] ) && in_array( (int) $item['variation_id'], $synced, true ) ) {
				return true;
			}
		}

		return false;
	}

	public static function cart_needs_link() {
		if ( ! BMC_Settings::bool( 'force_link', true ) || ! BMC_Settings::bool( 'gate_enabled', true ) ) {
			return false;
		}

		if ( BMC_Settings::bool( 'gate_only_synced', true ) ) {
			return self::cart_has_synced_products();
		}

		return function_exists( 'WC' ) && WC()->cart && ! WC()->cart->is_empty();
	}

	public static function gate_status() {
		if ( ! self::cart_needs_link() ) {
			return array(
				'ok'     => true,
				'reason' => '',
				'message' => '',
			);
		}

		if ( ! is_user_logged_in() ) {
			return array(
				'ok'      => false,
				'reason'  => 'guest',
				'message' => 'برای خرید آیتم‌های ماینکرافت ابتدا با شمارهٔ موبایل خود وارد حساب کاربری شوید.',
			);
		}

		if ( BMC_Link::is_linked( get_current_user_id() ) ) {
			return array(
				'ok'      => true,
				'reason'  => 'linked',
				'message' => '',
			);
		}

		return array(
			'ok'      => false,
			'reason'  => 'unlinked',
			'message' => (string) BMC_Settings::get( 'txt_not_linked_body' ),
		);
	}

	public static function filter_checkout_fields( $fields ) {
		if ( ! self::should_customize() ) {
			return $fields;
		}

		$config = (array) BMC_Settings::get( 'checkout_fields', array() );

		$map = array(
			'first_name' => 'billing_first_name',
			'last_name'  => 'billing_last_name',
			'email'      => 'billing_email',
			'mobile'     => 'billing_phone',
			'company'    => 'billing_company',
			'country'    => 'billing_country',
			'address'    => 'billing_address_1',
			'city'       => 'billing_city',
			'state'      => 'billing_state',
			'postcode'   => 'billing_postcode',
			'notes'      => 'order_comments',
		);

		foreach ( $map as $setting_key => $field_key ) {
			if ( empty( $config[ $setting_key ] ) ) {
				if ( isset( $fields['billing'][ $field_key ] ) ) {
					unset( $fields['billing'][ $field_key ] );
				}
				if ( 'address' === $setting_key && isset( $fields['billing']['billing_address_2'] ) ) {
					unset( $fields['billing']['billing_address_2'] );
				}
			}
		}

		if ( self::cart_only_virtual() ) {
			unset( $fields['shipping'] );
		}

		$labels = array(
			'billing_first_name' => 'نام',
			'billing_last_name'  => 'نام خانوادگی',
			'billing_email'      => 'ایمیل (اختیاری)',
			'billing_phone'      => 'شمارهٔ موبایل',
			'billing_company'    => 'شرکت',
			'billing_country'    => 'کشور',
			'billing_address_1'  => 'آدرس',
			'billing_address_2'  => 'آدرس (ادامه)',
			'billing_city'       => 'شهر',
			'billing_state'      => 'استان',
			'billing_postcode'   => 'کد پستی',
			'order_comments'     => 'توضیحات سفارش',
		);

		foreach ( $labels as $key => $label ) {
			if ( isset( $fields['billing'][ $key ] ) ) {
				$fields['billing'][ $key ]['label'] = $label;
				$fields['billing'][ $key ]['class'] = array( 'bmc-field' );

				if ( in_array( $key, array( 'billing_email', 'billing_company', 'billing_address_2' ), true ) ) {
					$fields['billing'][ $key ]['required'] = false;
				}
			}
		}

		if ( isset( $fields['order']['order_comments'] ) ) {
			$fields['order']['order_comments']['label'] = $labels['order_comments'];
		}

		$minecraft = array();

		if ( BMC_Settings::bool( 'checkout_gift_allowed', true ) ) {
			$minecraft[ self::FIELD_GIFT ] = array(
				'label'       => 'این سفارش هدیه است (برای بازیکن دیگری خرید می‌کنم)',
				'type'        => 'checkbox',
				'required'    => false,
				'class'       => array( 'bmc-field bmc-gift' ),
				'priority'    => 5,
			);
		}

		$minecraft[ self::FIELD_PLAYER ] = array(
			'label'       => 'نام کاربری ماینکرافت',
			'type'        => 'text',
			'required'    => false,
			'placeholder' => 'نام کاربری دریافت‌کننده',
			'class'       => array( 'bmc-field bmc-player' ),
			'priority'    => 10,
		);

		$fields['minecraft'] = $minecraft;

		return apply_filters( 'bmc_checkout_fields', $fields );
	}

	private static function should_customize() {
		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
			return false;
		}

		if ( is_checkout_pay_page() ) {
			return false;
		}

		if ( BMC_Settings::bool( 'gate_only_synced', true ) && ! self::cart_has_synced_products() ) {
			return false;
		}

		return true;
	}

	public static function cart_only_virtual() {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return false;
		}

		foreach ( WC()->cart->get_cart() as $item ) {
			if ( empty( $item['data'] ) ) {
				continue;
			}
			$product = $item['data'];
			if ( method_exists( $product, 'needs_shipping' ) && $product->needs_shipping() ) {
				return false;
			}
		}

		return true;
	}

	public static function validate_checkout() {
		$gate = self::gate_status();

		if ( ! $gate['ok'] ) {
			$text = 'guest' === $gate['reason']
				? 'برای تکمیل خرید باید وارد حساب کاربری شوید.'
				: (string) BMC_Settings::get( 'txt_not_linked_body' );

			wc_add_notice( $text, 'error' );
			return;
		}

		$is_gift  = ! empty( $_POST[ self::FIELD_GIFT ] );
		$player   = isset( $_POST[ self::FIELD_PLAYER ] ) ? sanitize_text_field( wp_unslash( $_POST[ self::FIELD_PLAYER ] ) ) : '';

		if ( $is_gift ) {
			if ( ! BMC_Settings::bool( 'checkout_gift_allowed', true ) ) {
				wc_add_notice( 'خرید هدیه در این فروشگاه غیرفعال است.', 'error' );
				return;
			}

			if ( ! BMC_Helpers::valid_player_name( $player ) ) {
				wc_add_notice( 'نام کاربری ماینکرافت دریافت‌کنندهٔ هدیه را درست وارد کنید.', 'error' );
				return;
			}

			if ( 'premium' === BMC_Settings::get( 'username_policy' ) && BMC_Settings::bool( 'mojang_check', true ) ) {
				$check = BMC_Helpers::mojang_check( $player );
				if ( ! $check['ok'] ) {
					wc_add_notice( 'ERR' === $check['reason'] ? 'بررسی نام کاربری ممکن نشد؛ دوباره تلاش کنید.' : 'نام کاربری هدیه باید یک اکانت اصلی (پرمیوم) باشد.', 'error' );
					return;
				}
			}
			return;
		}

		if ( ! is_user_logged_in() ) {
			return;
		}

		$linked = BMC_Link::get_linked_player( get_current_user_id() );

		if ( $linked && $player && strtolower( $player ) !== strtolower( $linked ) ) {
			wc_add_notice( sprintf( 'حساب شما به «%s» متصل است. برای خرید به نام دیگری گزینهٔ هدیه را فعال کنید.', $linked ), 'error' );
		}
	}

	public static function save_order_meta( $order_id ) {
		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;
		if ( ! $order ) {
			return;
		}

		$is_gift = ! empty( $_POST[ self::FIELD_GIFT ] );
		$player  = isset( $_POST[ self::FIELD_PLAYER ] ) ? sanitize_text_field( wp_unslash( $_POST[ self::FIELD_PLAYER ] ) ) : '';

		$target = 'gift';
		if ( ! $is_gift ) {
			$linked = is_user_logged_in() ? BMC_Link::get_linked_player( get_current_user_id() ) : '';
			$player = $linked ? $linked : $player;
			$target = $linked ? 'linked' : 'manual';
		}

		if ( ! BMC_Helpers::valid_player_name( $player ) ) {
			$player = '';
		}

		$order->update_meta_data( '_bmc_target_type', $target );
		$order->update_meta_data( '_bmc_mc_player', $player );
		$order->update_meta_data( '_bmc_is_gift', $is_gift ? 'yes' : 'no' );

		$order->update_meta_data( '_minecraft_username', $player );
		$order->update_meta_data( '_minecraft_gift', $is_gift ? 'yes' : 'no' );

		$order->save();
	}

	public static function replace_checkout_content( $content ) {
		if ( ! BMC_Settings::custom_checkout() ) {
			return $content;
		}

		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
			return $content;
		}

		if ( is_checkout_pay_page() || is_order_received_page() || is_cart() ) {
			return $content;
		}

		if ( ! in_the_loop() || ! is_main_query() ) {
			return $content;
		}

		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return $content;
		}

		if ( WC()->cart->is_empty() ) {
			return $content;
		}

		ob_start();

		$gate = self::gate_status();

		if ( ! $gate['ok'] ) {
			self::render_gate( $gate );
		} else {
			self::render_checkout();
		}

		return (string) ob_get_clean();
	}

	public static function render_checkout() {
		$template = BMC_PATH . 'public/templates/checkout.php';

		if ( file_exists( $template ) ) {
			include $template;
		}
	}

	public static function render_gate( $gate ) {
		$template = BMC_PATH . 'public/templates/gate.php';

		if ( file_exists( $template ) ) {
			include $template;
		}
	}

	public static function maybe_block_purchasable( $purchasable, $product ) {
		if ( ! BMC_Settings::bool( 'gate_product_page', false ) || ! $product ) {
			return $purchasable;
		}

		if ( ! self::is_synced_product( $product->get_id() ) && ! self::is_synced_product( $product->get_parent_id() ) ) {
			return $purchasable;
		}

		if ( ! BMC_Settings::bool( 'force_link', true ) ) {
			return $purchasable;
		}

		if ( is_user_logged_in() && BMC_Link::is_linked( get_current_user_id() ) ) {
			return $purchasable;
		}

		return false;
	}

	public static function product_gate_notice() {
		global $product;

		if ( ! BMC_Settings::bool( 'gate_product_page', false ) || ! $product ) {
			return;
		}

		if ( ! self::is_synced_product( $product->get_id() ) && ! self::is_synced_product( $product->get_parent_id() ) ) {
			return;
		}

		if ( is_user_logged_in() && BMC_Link::is_linked( get_current_user_id() ) ) {
			$player = BMC_Link::get_linked_player( get_current_user_id() );
			echo '<div class="bmc-note bmc-note--ok"><span>' . bmc_get_icon( 'check_circle', array( 'size' => 17 ) ) . '</span> آیتم‌ها به اکانت <strong>' . esc_html( $player ) . '</strong> تحویل داده می‌شود.</div>';
			return;
		}

		$url = BMC_Public::link_page_url();

		echo '<div class="bmc-note bmc-note--warn">'
			. '<span>!</span> برای خرید این محصول ابتدا باید اکانت ماینکرافت خود را متصل کنید. '
			. '<a class="bmc-note__link" href="' . esc_url( $url ) . '">اتصال اکانت</a>'
			. '</div>';
	}

	public static function thankyou_text( $text, $order ) {
		if ( ! $order ) {
			return $text;
		}

		$player = (string) $order->get_meta( '_bmc_mc_player' );

		if ( ! $player ) {
			return $text;
		}

		$server   = (string) BMC_Settings::get( 'server_name' );
		$template = (string) BMC_Settings::get( 'txt_thankyou' );

		$replaced = BMC_Helpers::replace_tags(
			$template,
			array(
				'{player}' => $player,
				'{server}' => $server,
				'{order}'  => $order->get_order_number(),
				'{site}'   => get_bloginfo( 'name' ),
			)
		);

		if ( '' !== trim( $replaced ) ) {
			return wp_kses_post( $replaced );
		}

		return sprintf(
			'سفارش شما با موفقیت ثبت شد. آیتم‌ها در اولین ورود شما به سرور «%s» به اکانت <strong>%s</strong> تحویل داده می‌شود.',
			esc_html( $server ),
			esc_html( $player )
		);
	}

	public static function ajax_summary() {
		self::check_ajax();

		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			wp_send_json_error( array( 'message' => 'سبد خرید در دسترس نیست.' ), 400 );
		}

		WC()->cart->calculate_totals();

		wp_send_json_success( self::summary_data() );
	}

	public static function ajax_apply_coupon() {
		self::check_ajax();

		$code = isset( $_POST['coupon'] ) ? sanitize_text_field( wp_unslash( $_POST['coupon'] ) ) : '';

		if ( ! $code ) {
			wp_send_json_error( array( 'message' => 'کد تخفیف را وارد کنید.' ), 400 );
		}

		if ( WC()->cart->has_discount( $code ) ) {
			wp_send_json_error( array( 'message' => 'این کد قبلاً اعمال شده است.' ), 400 );
		}

		$applied = WC()->cart->apply_coupon( $code );

		if ( ! $applied ) {
			$notices = wc_get_notices( 'error' );
			$message = ! empty( $notices ) ? ( is_array( $notices[0] ) ? $notices[0]['notice'] : $notices[0] ) : 'کد تخفیف معتبر نیست.';
			wc_clear_notices();
			wp_send_json_error( array( 'message' => $message ), 400 );
		}

		wc_clear_notices();
		WC()->cart->calculate_totals();

		wp_send_json_success(
			array_merge(
				self::summary_data(),
				array( 'message' => 'کد تخفیف اعمال شد.' )
			)
		);
	}

	public static function ajax_remove_coupon() {
		self::check_ajax();

		$code = isset( $_POST['coupon'] ) ? sanitize_text_field( wp_unslash( $_POST['coupon'] ) ) : '';

		if ( $code ) {
			WC()->cart->remove_coupon( $code );
		}

		wc_clear_notices();
		WC()->cart->calculate_totals();

		wp_send_json_success( self::summary_data() );
	}

	public static function summary_data() {
		$cart  = WC()->cart;
		$items = array();

		foreach ( $cart->get_cart() as $cart_item ) {
			$product = $cart_item['data'];
			$qty     = (int) $cart_item['quantity'];

			$items[] = array(
				'key'       => $cart_item['key'],
				'name'      => $product->get_name(),
				'qty'       => $qty,
				'price'     => wc_price( $product->get_price() ),
				'total'     => wc_price( $cart_item['line_total'] ),
				'image'     => wp_get_attachment_image_url( $product->get_image_id(), 'thumbnail' ),
				'synced'    => self::is_synced_product( $product->get_id() ) || self::is_synced_product( $product->get_parent_id() ),
			);
		}

		$totals = array(
			array(
				'label' => 'جمع کل',
				'value' => wc_price( $cart->get_subtotal() ),
				'key'   => 'subtotal',
			),
		);

		if ( $cart->get_discount_total() > 0 ) {
			$totals[] = array(
				'label' => 'تخفیف',
				'value' => '-' . wc_price( $cart->get_discount_total() ),
				'key'   => 'discount',
				'class' => 'is-discount',
			);
		}

		if ( $cart->needs_shipping() && $cart->get_shipping_total() > 0 ) {
			$totals[] = array(
				'label' => 'هزینهٔ ارسال',
				'value' => wc_price( $cart->get_shipping_total() ),
				'key'   => 'shipping',
			);
		}

		if ( $cart->get_cart_contents_tax() > 0 || $cart->get_taxes() ) {
			$tax_total = 0;
			foreach ( $cart->get_tax_totals() as $tax ) {
				$tax_total += $tax->amount;
			}
			if ( $tax_total > 0 ) {
				$totals[] = array(
					'label' => 'مالیات',
					'value' => wc_price( $tax_total ),
					'key'   => 'tax',
				);
			}
		}

		return array(
			'items'      => $items,
			'totals'     => $totals,
			'grand_total'=> wc_price( $cart->get_total( 'edit' ) ),
			'total_raw'  => (float) $cart->get_total( 'edit' ),
			'coupons'    => array_keys( (array) $cart->get_coupons() ),
			'item_count' => $cart->get_cart_contents_count(),
		);
	}

	private static function check_ajax() {
		$nonce = isset( $_REQUEST['security'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['security'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, 'bmc_public' ) && ! wp_verify_nonce( $nonce, 'bmc_checkout' ) ) {
			wp_send_json_error( array( 'message' => 'نشست نامعتبر است.' ), 403 );
		}

		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			wp_send_json_error( array( 'message' => 'سبد خرید آماده نیست.' ), 400 );
		}
	}

	public static function enqueue_assets() {
		if ( ! function_exists( 'is_checkout' ) ) {
			return;
		}

		if ( function_exists( 'is_cart' ) && is_cart() ) {
			BMC_Public::enqueue_base_assets();
		}

		if ( ! is_checkout() || ! BMC_Settings::custom_checkout() ) {
			return;
		}

		BMC_Public::enqueue_base_assets();

		$version = defined( 'BMC_VERSION' ) ? BMC_VERSION : '1.1.0';

		wp_enqueue_script(
			'bmc-checkout',
			BMC_URL . 'assets/js/bmc-checkout.js',
			array( 'jquery', 'bmc-icons' ),
			$version,
			true
		);

		wp_localize_script(
			'bmc-checkout',
			'bmcCheckout',
			array(
				'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
				'wcAjaxUrl'    => class_exists( 'WC_AJAX' ) ? WC_AJAX::get_endpoint( '%%endpoint%%' ) : '',
				'nonce'        => wp_create_nonce( 'bmc_public' ),
				'wcNonce'      => wp_create_nonce( 'woocommerce-process_checkout' ),
				'isLinked'     => is_user_logged_in() ? BMC_Link::is_linked( get_current_user_id() ) : false,
				'linkedPlayer' => is_user_logged_in() ? BMC_Link::get_linked_player( get_current_user_id() ) : '',
				'headUrl'      => is_user_logged_in() ? BMC_Helpers::mc_head( BMC_Link::get_linked_player( get_current_user_id() ), 64 ) : '',
				'i18n'         => array(
					'processing' => 'در حال ثبت سفارش…',
					'error'      => 'خطا در ثبت سفارش',
					'fillPlayer' => 'نام کاربری ماینکرافت را وارد کنید.',
				),
			)
		);
	}
	public static function connect_url() {
		$page_id = (int) BMC_Settings::get( 'page_link', 0 );

		if ( $page_id && get_permalink( $page_id ) ) {
			return (string) get_permalink( $page_id );
		}

		if ( is_user_logged_in() && function_exists( 'wc_get_account_endpoint_url' ) ) {
			return (string) wc_get_account_endpoint_url( BMC_Public::ENDPOINT );
		}

		$redirect = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/' );

		return (string) wp_login_url( $redirect );
	}

	public static function render_cart_button() {
		$gate = self::gate_status();

		if ( ! BMC_Settings::cart_gate_enabled() || ! empty( $gate['ok'] ) ) {
			echo '<a href="' . esc_url( function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : home_url( '/' ) ) . '" class="checkout-button button alt wc-forward">';
			echo esc_html( 'ادامهٔ فرآیند خرید' );
			echo '</a>';

			return;
		}

		$message = '' !== trim( (string) $gate['message'] ) ? (string) $gate['message'] : (string) BMC_Settings::get( 'txt_cart_blocked' );
		$label   = 'guest' === $gate['reason'] ? 'ورود و اتصال اکانت' : 'اتصال اکانت ماینکرافت';

		echo '<div class="bmc-cart-blocked">';
		echo '<span class="bmc-cart-lock" aria-hidden="true">' . bmc_get_icon( 'lock', array( 'size' => 22 ) ) . '</span>';
		echo '<div class="bmc-cart-blocked-body">';
		echo '<strong>دکمهٔ پرداخت غیرفعال است</strong>';
		echo '<p>' . esc_html( $message ) . '</p>';
		echo '<a class="button bmc-cart-connect" href="' . esc_url( self::connect_url() ) . '">' . bmc_get_icon( 'link', array( 'size' => 16 ) ) . ' ' . esc_html( $label ) . '</a>';
		echo '</div>';
		echo '<span class="checkout-button button alt wc-forward bmc-disabled" aria-disabled="true" title="' . esc_attr( $message ) . '">ثبت و پرداخت سفارش</span>';
		echo '</div>';
	}

	public static function render_cart_notice() {
		if ( ! BMC_Settings::cart_gate_enabled() ) {
			return;
		}

		$gate = self::gate_status();

		if ( ! empty( $gate['ok'] ) ) {
			$player = is_user_logged_in() ? BMC_Link::get_linked_player( get_current_user_id() ) : '';

			if ( $player ) {
				echo '<div class="bmc-notice bmc-notice-ok">' . bmc_get_icon( 'check_circle', array( 'size' => 17 ) ) . '<div>آیتم‌های این سفارش به بازیکن <strong>' . esc_html( $player ) . '</strong> تحویل داده می‌شود.</div></div>';
			}

			return;
		}

		echo '<div class="bmc-notice bmc-notice-warn">';
		echo '<span>' . bmc_get_icon( 'warning', array( 'size' => 17 ) ) . '</span><div>' . esc_html( '' !== trim( (string) $gate['message'] ) ? $gate['message'] : (string) BMC_Settings::get( 'txt_cart_blocked' ) );
		echo ' <a href="' . esc_url( self::connect_url() ) . '">' . esc_html( 'همین حالا متصل شوید' ) . '</a></div>';
		echo '</div>';
	}

	public static function is_blocks_checkout() {
		if ( ! function_exists( 'is_checkout' ) || ! is_checkout() ) {
			return false;
		}

		$post = get_post();

		if ( ! $post || ! function_exists( 'has_block' ) ) {
			return false;
		}

		return has_block( 'woocommerce/checkout', $post->post_content );
	}

	public static function maybe_force_classic_checkout() {
		if ( 'force_classic' !== (string) BMC_Settings::get( 'blocks_checkout', 'force_classic' ) ) {
			return;
		}

		if ( ! self::is_blocks_checkout() ) {
			return;
		}

		if ( isset( $_GET['bmc_classic'] ) ) {
			return;
		}

		if ( ! self::cart_has_synced_products() && ! self::cart_needs_link() ) {
			return;
		}

		$url = add_query_arg( 'bmc_classic', '1', function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : '' );

		if ( $url ) {
			wp_safe_redirect( $url );
			exit;
		}
	}

	public static function blocks_admin_notice() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		$mode = (string) BMC_Settings::get( 'blocks_checkout', 'force_classic' );

		if ( 'notice' !== $mode ) {
			return;
		}

		$checkout_page = function_exists( 'wc_get_page_id' ) ? (int) wc_get_page_id( 'checkout' ) : 0;

		if ( ! $checkout_page || ! function_exists( 'has_block' ) ) {
			return;
		}

		$post = get_post( $checkout_page );

		if ( ! $post || ! has_block( 'woocommerce/checkout', $post->post_content ) ) {
			return;
		}

		echo '<div class="notice notice-warning"><p><strong>BazzarMc:</strong> برگهٔ پرداخت شما از «چک‌اوت بلوکی» ووکامرس استفاده می‌کند؛ فیلدهای ماینکرافت در آن نمایش داده نمی‌شوند. از تب «چک‌اوت» گزینهٔ «اجبار به چک‌اوت کلاسیک» را انتخاب کنید یا برگهٔ پرداخت اختصاصی افزونه را بسازید.</p></div>';
	}

	public static function register_blocks_fields() {
		if ( 'register' !== (string) BMC_Settings::get( 'blocks_checkout', 'force_classic' ) ) {
			return;
		}

		add_action(
			'woocommerce_blocks_checkout_update_order_from_request',
			array( __CLASS__, 'blocks_update_order_from_request' ),
			10,
			2
		);

		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_blocks_script' ), 30 );
	}

	public static function enqueue_blocks_script() {
		if ( ! self::is_blocks_checkout() ) {
			return;
		}

		wp_enqueue_script(
			'bmc-blocks',
			BMC_URL . 'assets/js/bmc-blocks.js',
			array(),
			BMC_VERSION,
			true
		);

		wp_localize_script(
			'bmc-blocks',
			'bmcBlocks',
			array(
				'playerField' => self::FIELD_PLAYER,
				'giftField'   => self::FIELD_GIFT,
				'player'      => is_user_logged_in() ? BMC_Link::get_linked_player( get_current_user_id() ) : '',
				'labels'      => array(
					'player' => 'نام کاربری ماینکرافت',
					'gift'   => 'این خرید هدیه است',
				),
			)
		);
	}

	public static function blocks_update_order_from_request( $order, $request ) {
		if ( ! $order ) {
			return;
		}

		$values = array();

		if ( $request instanceof \WP_REST_Request ) {
			$extensions = (array) $request->get_param( 'extensions' );

			if ( isset( $extensions['bazzarmc'] ) && is_array( $extensions['bazzarmc'] ) ) {
				$values = $extensions['bazzarmc'];
			}
		}

		if ( ! $values ) {
			$values = array(
				self::FIELD_PLAYER => isset( $_POST[ self::FIELD_PLAYER ] ) ? sanitize_text_field( wp_unslash( $_POST[ self::FIELD_PLAYER ] ) ) : '',
				self::FIELD_GIFT   => ! empty( $_POST[ self::FIELD_GIFT ] ) ? 1 : 0,
			);
		}

		$player = isset( $values[ self::FIELD_PLAYER ] ) ? sanitize_text_field( (string) $values[ self::FIELD_PLAYER ] ) : '';
		$gift   = ! empty( $values[ self::FIELD_GIFT ] );

		if ( '' === $player && is_user_logged_in() ) {
			$player = BMC_Link::get_linked_player( get_current_user_id() );
		}

		$order->update_meta_data( '_bmc_target_type', $gift ? 'gift' : 'self' );
		$order->update_meta_data( '_bmc_mc_player', $player );
		$order->update_meta_data( '_bmc_is_gift', $gift ? 'yes' : 'no' );
		$order->update_meta_data( '_minecraft_username', $player );
		$order->save();
	}

	public static function order_product_roles( $order ) {
		$roles    = array();
		$mapping  = (array) BMC_Settings::get( 'product_roles', array() );
		$default  = (string) BMC_Settings::get( 'default_linked_role' );

		if ( ! $order ) {
			return $roles;
		}

		foreach ( $order->get_items() as $item ) {
			if ( ! is_a( $item, 'WC_Order_Item_Product' ) ) {
				continue;
			}

			$product_id   = absint( $item->get_product_id() );
			$variation_id = absint( $item->get_variation_id() );
			$key          = ( $variation_id && isset( $mapping[ $variation_id ] ) ) ? $variation_id : $product_id;

			if ( isset( $mapping[ $key ] ) && $mapping[ $key ] ) {
				$roles[] = sanitize_text_field( $mapping[ $key ] );
			}
		}

		if ( $default ) {
			$roles[] = $default;
		}

		return array_values( array_unique( array_filter( $roles ) ) );
	}

	public static function revoke_order_roles( $order_id ) {
		if ( ! BMC_Settings::bool( 'revoke_roles_on_refund', true ) ) {
			return;
		}

		$order_id = absint( is_object( $order_id ) && method_exists( $order_id, 'get_id' ) ? $order_id->get_id() : $order_id );
		$order    = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;

		if ( ! $order ) {
			return;
		}

		$user_id = (int) $order->get_user_id();

		if ( ! $user_id ) {
			return;
		}

		$user  = new WP_User( $user_id );
		$owned = self::order_product_roles( $order );

		if ( ! $owned ) {
			return;
		}

		BMC_Roles::revoke_for_order( $order_id );

		$keep = self::roles_from_other_orders( $user_id, $order_id );

		foreach ( $owned as $role ) {
			if ( in_array( $role, $keep, true ) || self::is_protected_role( $role ) ) {
				continue;
			}

			if ( in_array( $role, $user->roles, true ) ) {
				$user->remove_role( $role );
			}
		}

		BMC_Logger::add(
			'delivery',
			sprintf( 'نقش‌های سفارش #%d پس از لغو/بازپرداخت بازبینی شد.', $order_id ),
			array( 'user' => $user_id ),
			'warning'
		);
	}

	public static function roles_from_other_orders( $user_id, $exclude_order_id ) {
		$roles = array();

		if ( ! function_exists( 'wc_get_orders' ) ) {
			return $roles;
		}

		$orders = wc_get_orders(
			array(
				'customer' => (int) $user_id,
				'status'   => array( 'processing', 'completed', 'on-hold' ),
				'limit'    => 200,
				'exclude'  => array( (int) $exclude_order_id ),
			)
		);

		foreach ( $orders as $other ) {
			$roles = array_merge( $roles, self::order_product_roles( $other ) );
		}

		return array_values( array_unique( array_filter( $roles ) ) );
	}

	public static function is_protected_role( $role ) {
		$protected = array( 'administrator', 'shop_manager', 'editor', 'author' );

		return in_array( (string) $role, $protected, true );
	}

	public static function render_cart_page() {
		if ( ! function_exists( 'WC' ) || ! WC()->cart ) {
			return '<div class="bmc-notice bmc-notice-warn">سبد خرید در دسترس نیست.</div>';
		}

		$gate = self::gate_status();

		ob_start();

		include BMC_PATH . 'public/templates/cart.php';

		return (string) ob_get_clean();
	}
}
