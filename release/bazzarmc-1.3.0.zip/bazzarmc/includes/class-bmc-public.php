<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Public {

	const ENDPOINT = 'minecraft';

	public static function init() {
		add_shortcode( 'bazzarmc', array( __CLASS__, 'shortcode_account' ) );
		add_shortcode( 'bazzarmc_account', array( __CLASS__, 'shortcode_account' ) );
		add_shortcode( 'bazzarmc_link', array( __CLASS__, 'shortcode_account' ) );
		add_shortcode( 'bazzarmc_status', array( __CLASS__, 'shortcode_status' ) );
		add_shortcode( 'bazzarmc_checkout', array( __CLASS__, 'shortcode_checkout' ) );
		add_shortcode( 'bazzarmc_cart', array( __CLASS__, 'shortcode_cart' ) );
		add_shortcode( 'bazzarmc_card', array( __CLASS__, 'shortcode_card' ) );
		add_shortcode( 'bazzarmc_nav', array( __CLASS__, 'shortcode_nav' ) );
		add_shortcode( 'bazzarmc_ranks', array( __CLASS__, 'shortcode_ranks' ) );
		add_shortcode( 'bazzarmc_deliveries', array( __CLASS__, 'shortcode_deliveries' ) );

		add_filter( 'woocommerce_account_menu_items', array( __CLASS__, 'my_account_menu' ), 40 );
		add_action( 'init', array( __CLASS__, 'add_my_account_endpoint' ) );
		add_action( 'woocommerce_account_' . self::ENDPOINT . '_endpoint', array( __CLASS__, 'my_account_content' ) );
		add_filter( 'woocommerce_locate_template', array( __CLASS__, 'locate_dashboard_template' ), 20, 3 );

		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ), 15 );
	}

	public static function shortcode_account( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'title' => '',
			),
			$atts,
			'bazzarmc'
		);

		self::enqueue_base_assets();
		self::enqueue_link_assets();

		ob_start();
		$template = BMC_PATH . 'public/templates/link-box.php';

		if ( file_exists( $template ) ) {
			$bmc_atts = $atts;
			include $template;
		}

		return (string) ob_get_clean();
	}


	public static function shortcode_status( $atts = array() ) {
		self::enqueue_base_assets();

		if ( ! is_user_logged_in() ) {
			return '<div class="bmc-badge bmc-badge--warn" dir="rtl">برای مشاهدهٔ وضعیت اتصال وارد حساب شوید.</div>';
		}

		$player = BMC_Link::get_linked_player( get_current_user_id() );

		if ( ! $player ) {
			return '<div class="bmc-badge bmc-badge--warn" dir="rtl">اکانت ماینکرافت متصل نیست — <a href="' . esc_url( self::link_page_url() ) . '">اتصال</a></div>';
		}

		return '<div class="bmc-badge bmc-badge--ok" dir="rtl">'
			. '<img src="' . esc_url( BMC_Helpers::mc_head( $player, 24 ) ) . '" alt="" width="24" height="24" /> '
			. 'متصل به <strong>' . esc_html( $player ) . '</strong>'
			. '</div>';
	}

	public static function shortcode_checkout( $atts = array() ) {
		if ( ! function_exists( 'WC' ) || ! WC()->cart || WC()->cart->is_empty() ) {
			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">سبد خرید شما خالی است.</div></div>';
		}

		self::enqueue_base_assets();

		wp_enqueue_script( 'bmc-checkout', BMC_URL . 'assets/js/bmc-checkout.js', array( 'jquery', 'bmc-icons' ), BMC_VERSION, true );
		wp_localize_script(
			'bmc-checkout',
			'bmcCheckout',
			array(
				'ajaxUrl'   => admin_url( 'admin-ajax.php' ),
				'wcAjaxUrl' => class_exists( 'WC_AJAX' ) ? WC_AJAX::get_endpoint( '%%endpoint%%' ) : '',
				'nonce'     => wp_create_nonce( 'bmc_public' ),
				'wcNonce'   => wp_create_nonce( 'woocommerce-process_checkout' ),
				'isLinked'  => is_user_logged_in() ? BMC_Link::is_linked( get_current_user_id() ) : false,
				'linkedPlayer' => is_user_logged_in() ? BMC_Link::get_linked_player( get_current_user_id() ) : '',
				'headUrl'   => is_user_logged_in() ? BMC_Helpers::mc_head( BMC_Link::get_linked_player( get_current_user_id() ), 64 ) : '',
				'i18n'      => array(
					'processing' => 'در حال ثبت سفارش…',
					'error'      => 'خطا در ثبت سفارش',
					'fillPlayer' => 'نام کاربری ماینکرافت را وارد کنید.',
				),
			)
		);

		ob_start();

		$gate = BMC_Checkout::gate_status();

		if ( ! $gate['ok'] ) {
			BMC_Checkout::render_gate( $gate );
		} else {
			BMC_Checkout::render_checkout();
		}

		return (string) ob_get_clean();
	}

	public static function shortcode_cart( $atts = array() ) {
		if ( ! function_exists( 'WC' ) || ! class_exists( 'WooCommerce' ) ) {
			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">ووکامرس فعال نیست.</div></div>';
		}

		self::enqueue_base_assets();

		wp_enqueue_script( 'bmc-checkout', BMC_URL . 'assets/js/bmc-checkout.js', array( 'jquery', 'bmc-icons' ), BMC_VERSION, true );
		wp_localize_script(
			'bmc-checkout',
			'bmcCheckout',
			array(
				'ajaxUrl'      => admin_url( 'admin-ajax.php' ),
				'wcAjaxUrl'    => class_exists( 'WC_AJAX' ) ? WC_AJAX::get_endpoint( '%%endpoint%%' ) : '',
				'nonce'        => wp_create_nonce( 'bmc_public' ),
				'wcNonce'      => wp_create_nonce( 'woocommerce-process_checkout' ),
				'isLinked'     => is_user_logged_in() ? BMC_Link::is_linked( get_current_user_id() ) : false,
				'linkedPlayer' => is_user_logged_in() ? BMC_Link::get_linked_player( get_current_user_id() ) : '',
				'headUrl'      => is_user_logged_in() ? BMC_Helpers::mc_head( BMC_Link::get_linked_player( get_current_user_id() ), 64 ) : '',
				'i18n'         => array(
					'processing' => 'در حال ثبت سفارش…',
					'error'      => 'خطا در ثبت سفارش',
					'fillPlayer' => 'نام کاربری ماینکرافت را وارد کنید.',
				),
			)
		);

		return BMC_Checkout::render_cart_page();
	}

	public static function add_my_account_endpoint() {
		add_rewrite_endpoint( self::ENDPOINT, EP_ROOT | EP_PAGES );
	}

	public static function my_account_menu( $items ) {
		$new = array();

		foreach ( $items as $key => $label ) {
			$new[ $key ] = $label;

			if ( 'orders' === $key ) {
				$new[ self::ENDPOINT ] = 'اتصال ماینکرافت';
			}
		}

		if ( ! isset( $new[ self::ENDPOINT ] ) ) {
			$new[ self::ENDPOINT ] = 'اتصال ماینکرافت';
		}

		return $new;
	}

	public static function my_account_content() {
		echo self::shortcode_account();
	}

	public static function link_page_url() {
		$page_id = (int) BMC_Settings::get( 'page_link', 0 );

		if ( $page_id ) {
			return (string) get_permalink( $page_id );
		}

		if ( function_exists( 'wc_get_account_endpoint_url' ) ) {
			$url = wc_get_account_endpoint_url( self::ENDPOINT );
			if ( $url && false === strpos( $url, 'wc_get_account_endpoint_url' ) ) {
				return $url;
			}
		}

		return home_url( '/' );
	}

	public static function template( $name, array $vars = array() ) {
		$path = BMC_PATH . 'public/templates/' . $name . '.php';

		if ( ! file_exists( $path ) ) {
			return '';
		}

		ob_start();

		foreach ( $vars as $bmc_key => $bmc_value ) {
			$$bmc_key = $bmc_value;
		}

		include $path;

		return (string) ob_get_clean();
	}

	public static function render_account_card( array $args = array() ) {
		if ( ! is_user_logged_in() ) {
			return self::login_notice( 'برای مشاهدهٔ کارت حساب کاربری وارد حساب شوید.' );
		}

		self::enqueue_base_assets();

		return self::template( 'account-card', array( 'bmc_card' => $args ) );
	}

	public static function render_account_nav( array $args = array() ) {
		if ( ! function_exists( 'wc_get_account_menu_items' ) ) {
			return '<div class="bmc-alert bmc-alert--warn">برای نمایش منوی حساب کاربری، ووکامرس باید فعال باشد.</div>';
		}

		if ( ! is_user_logged_in() ) {
			return self::login_notice( 'برای مشاهدهٔ منوی حساب کاربری وارد حساب شوید.' );
		}

		self::enqueue_base_assets();

		return self::template( 'account-nav', array( 'bmc_nav' => $args ) );
	}

	public static function render_account_content( $endpoint = 'current', array $args = array() ) {
		if ( ! is_user_logged_in() ) {
			return self::login_notice( 'برای مشاهدهٔ این بخش وارد حساب کاربری شوید.' );
		}

		self::enqueue_base_assets();

		$notices = '';

		if ( empty( $args['hide_notices'] ) ) {
			ob_start();
			do_action( 'woocommerce_output_all_notices' );
			$notices = (string) ob_get_clean();
		}

		$endpoint = '' === $endpoint ? 'current' : sanitize_key( (string) $endpoint );

		if ( 'current' === $endpoint ) {
			ob_start();

			if ( function_exists( 'woocommerce_account_content' ) ) {
				woocommerce_account_content();
			} else {
				do_action( 'woocommerce_account_content' );
			}

			return $notices . (string) ob_get_clean();
		}

		if ( 'dashboard' === $endpoint ) {
			ob_start();

			if ( function_exists( 'wc_get_template' ) ) {
				wc_get_template(
					'myaccount/dashboard.php',
					array(
						'current_user' => get_user_by( 'id', get_current_user_id() ),
					)
				);
			} else {
				do_action( 'woocommerce_account_content' );
			}

			return $notices . (string) ob_get_clean();
		}

		$value = get_query_var( $endpoint );

		if ( 'edit-address' === $endpoint && ! empty( $args['address'] ) ) {
			$value = sanitize_key( (string) $args['address'] );
		}

		if ( 'view-order' === $endpoint && ! empty( $args['order_id'] ) ) {
			$value = (int) $args['order_id'];
		}

		if ( has_action( 'woocommerce_account_' . $endpoint . '_endpoint' ) ) {
			ob_start();
			do_action( 'woocommerce_account_' . $endpoint . '_endpoint', $value );

			return $notices . (string) ob_get_clean();
		}

		return $notices . '<div class="bmc-alert bmc-alert--warn">' . bmc_get_icon( 'warning', array( 'size' => 18 ) ) . ' بخش انتخاب‌شده در ووکامرس ثبت نشده است.</div>';
	}

	public static function render_ranks( array $args = array() ) {
		if ( ! is_user_logged_in() ) {
			return self::login_notice( 'برای مشاهدهٔ رنک‌ها وارد حساب کاربری شوید.' );
		}

		self::enqueue_base_assets();

		return self::template( 'ranks', array( 'bmc_ranks' => $args ) );
	}

	public static function render_deliveries( array $args = array() ) {
		if ( ! is_user_logged_in() ) {
			return self::login_notice( 'برای مشاهدهٔ تحویل‌ها وارد حساب کاربری شوید.' );
		}

		self::enqueue_base_assets();

		return self::template( 'deliveries', array( 'bmc_deliveries' => $args ) );
	}

	public static function login_notice( $text = '' ) {
		$login = function_exists( 'wc_get_page_permalink' ) ? (string) wc_get_page_permalink( 'myaccount' ) : (string) wp_login_url();
		$text  = '' === $text ? 'برای مشاهدهٔ این بخش وارد حساب کاربری شوید.' : (string) $text;

		return '<div class="bmc-alert bmc-alert--warn">'
			. bmc_get_icon( 'lock', array( 'size' => 18 ) )
			. ' ' . esc_html( $text )
			. ' <a href="' . esc_url( $login ) . '">ورود / ثبت‌نام</a></div>';
	}

	public static function shortcode_card( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'title'  => '',
				'links'  => '',
				'layout' => '',
			),
			$atts,
			'bazzarmc_card'
		);

		$args = array();

		if ( '' !== trim( (string) $atts['title'] ) ) {
			$args['title'] = (string) $atts['title'];
		}

		if ( '' !== trim( (string) $atts['links'] ) ) {
			$args['link_items'] = array_map( 'sanitize_key', explode( ',', (string) $atts['links'] ) );
		}

		if ( in_array( $atts['layout'], array( 'grid', 'stack' ), true ) ) {
			$args['layout'] = $atts['layout'];
		}

		return '<div class="bmc-wrap bmc-wrap--card" dir="rtl"><div class="bmc-container">' . self::render_account_card( $args ) . '</div></div>';
	}

	public static function shortcode_nav( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'layout' => 'vertical',
				'title'  => '',
			),
			$atts,
			'bazzarmc_nav'
		);

		return '<div class="bmc-wrap bmc-wrap--nav" dir="rtl"><div class="bmc-container bmc-container--narrow">'
			. self::render_account_nav(
				array(
					'layout' => (string) $atts['layout'],
					'title'  => (string) $atts['title'],
				)
			) . '</div></div>';
	}

	public static function shortcode_ranks( $atts = array() ) {
		$atts = shortcode_atts( array( 'title' => '' ), $atts, 'bazzarmc_ranks' );

		return '<div class="bmc-wrap" dir="rtl"><div class="bmc-container">'
			. self::render_ranks( array( 'title' => (string) $atts['title'] ) ) . '</div></div>';
	}

	public static function shortcode_deliveries( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'title'  => '',
				'status' => '',
				'limit'  => 10,
				'layout' => 'list',
			),
			$atts,
			'bazzarmc_deliveries'
		);

		return '<div class="bmc-wrap" dir="rtl"><div class="bmc-container">'
			. self::render_deliveries(
				array(
					'title'  => (string) $atts['title'],
					'status' => (string) $atts['status'],
					'limit'  => (int) $atts['limit'],
					'layout' => (string) $atts['layout'],
				)
			) . '</div></div>';
	}

	public static function enqueue_base_assets() {
		self::ensure_style( 'bmc-public', BMC_URL . 'assets/css/bmc-public.css', BMC_VERSION );
		self::ensure_script( 'bmc-icons', BMC_URL . 'assets/js/bmc-icons.js', array() );

		if ( BMC_Settings::bool( 'font_cdn', true ) ) {
			self::ensure_style( 'bmc-vazir', 'https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css', '33.003' );
		}

		$accent = (string) BMC_Settings::get( 'checkout_accent', '#3ddc84' );
		$theme  = 'light' === BMC_Settings::get( 'checkout_theme' ) ? 'light' : 'dark';

		$inline = '.bmc-wrap,.bmc-acard{--bmc-accent:' . esc_attr( $accent ) . ';}' .
			( 'light' === $theme ? '.bmc-wrap{--bmc-bg:#f6f7fb;--bmc-bg-2:#ffffff;--bmc-surface:#ffffff;--bmc-text:#101828;--bmc-muted:#5b6472;--bmc-border:#e5e7eb;}' : '' );

		if ( did_action( 'wp_head' ) && ! wp_style_is( 'bmc-public', 'enqueued' ) ) {
			echo '<style id="bmc-inline-vars">' . $inline . '</style>';
		} else {
			wp_add_inline_style( 'bmc-public', $inline );
		}
	}

	private static function ensure_style( $handle, $src, $ver ) {
		if ( wp_style_is( $handle, 'done' ) || wp_style_is( $handle, 'enqueued' ) ) {
			return;
		}

		if ( ! did_action( 'wp_head' ) ) {
			wp_enqueue_style( $handle, $src, array(), $ver );
			return;
		}

		printf(
			'<link rel="stylesheet" id="%1$s-css" href="%2$s" media="all" />',
			esc_attr( $handle ),
			esc_url( $src )
		);
	}

	private static function ensure_script( $handle, $src, array $deps = array( 'jquery' ) ) {
		if ( wp_script_is( $handle, 'done' ) || wp_script_is( $handle, 'enqueued' ) ) {
			return;
		}

		if ( ! did_action( 'wp_footer' ) ) {
			wp_enqueue_script( $handle, $src, $deps, BMC_VERSION, true );
			return;
		}

		printf(
			'<script src="%1$s" id="%2$s-js" defer></script>',
			esc_url( $src ),
			esc_attr( $handle )
		);
	}

	public static function enqueue_link_assets() {
		self::ensure_script( 'bmc-link', BMC_URL . 'assets/js/bmc-link.js', array( 'jquery', 'bmc-icons' ) );

		$data = array(
			'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
			'nonce'       => wp_create_nonce( 'bmc_frontend' ),
			'publicNonce' => wp_create_nonce( 'bmc_public' ),
			'loggedIn'    => is_user_logged_in(),
			'headUrl'     => BMC_Helpers::mc_head( '', 64 ),
			'i18n'        => array(
				'copied'        => 'کد کپی شد!',
				'copyError'     => 'کپی نشد؛ کد را دستی انتخاب کنید.',
				'expired'       => 'اعتبار کد تمام شد.',
				'connected'     => 'متصل شد!',
				'waiting'       => 'در انتظار ورود به بازی…',
				'confirmUnlink' => 'مطمئنید می‌خواهید اتصال اکانت ماینکرافت را قطع کنید؟',
			),
		);

		self::localize( 'bmc-link', 'bmcLink', $data );
	}


	private static function localize( $handle, $object, array $data ) {
		unset( $handle );

		$json = wp_json_encode( $data, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT );

		printf(
			'<script>var %1$s = %2$s;</script>',
			esc_js( $object ),
			$json
		);
	}

	public static function enqueue_assets() {
		$page_link  = (int) BMC_Settings::get( 'page_link', 0 );
		$need_link  = ( $page_link && is_page( $page_link ) ) || ( function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( self::ENDPOINT ) );
		$need_card  = function_exists( 'is_account_page' ) && is_account_page() && BMC_Settings::bool( 'myaccount_card', true );

		if ( is_singular() ) {
			$content = (string) get_post_field( 'post_content', get_the_ID() );

			foreach ( array( 'bazzarmc', 'bazzarmc_account', 'bazzarmc_link', 'bazzarmc_status' ) as $sc ) {
				if ( has_shortcode( $content, $sc ) ) {
					$need_link = true;
					break;
				}
			}

			if ( has_shortcode( $content, 'bazzarmc_checkout' ) ) {
				self::enqueue_base_assets();
			}
		}

		if ( $need_link ) {
			self::enqueue_base_assets();
			self::enqueue_link_assets();
		}

		if ( $need_card ) {
			self::enqueue_base_assets();
		}
	}

	public static function locate_dashboard_template( $template, $template_name, $template_path = '' ) {
		if ( 'myaccount/dashboard.php' !== $template_name ) {
			return $template;
		}

		if ( ! BMC_Settings::bool( 'myaccount_card', true ) ) {
			return $template;
		}

		$custom = BMC_PATH . 'public/templates/wc-dashboard.php';

		return file_exists( $custom ) ? $custom : $template;
	}
}
