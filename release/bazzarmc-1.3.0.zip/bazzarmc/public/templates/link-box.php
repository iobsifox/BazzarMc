<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_atts      = isset( $bmc_atts ) ? (array) $bmc_atts : array();
$bmc_title     = ! empty( $bmc_atts['title'] ) ? $bmc_atts['title'] : BMC_Settings::get( 'txt_link_title', 'اتصال اکانت ماینکرافت' );
$bmc_logged_in = is_user_logged_in();
$bmc_user_id   = get_current_user_id();
$bmc_linked    = $bmc_logged_in && BMC_Link::is_linked( $bmc_user_id );
$bmc_player    = $bmc_logged_in ? BMC_Link::get_linked_player( $bmc_user_id ) : '';
$bmc_active    = $bmc_logged_in && ! $bmc_linked ? BMC_Link::get_active_code( $bmc_user_id ) : null;
$bmc_uuid      = $bmc_logged_in ? BMC_Link::get_linked_uuid( $bmc_user_id ) : '';
$bmc_linked_at = $bmc_logged_in ? (int) get_user_meta( $bmc_user_id, BMC_Link::META_LINKED_AT, true ) : 0;
$bmc_policy    = (string) BMC_Settings::get( 'username_policy', 'premium' );
$bmc_cmd_tpl   = (string) BMC_Settings::get( 'code_command_hint', '/mclink {code}' );
$bmc_server    = (string) BMC_Settings::get( 'server_name', 'سرور ماینکرافت' );
$bmc_theme     = 'light' === BMC_Settings::get( 'checkout_theme' ) ? ' bmc-theme-light' : '';
?>
<div class="bmc-wrap<?php echo esc_attr( $bmc_theme ); ?>" id="bmcLinkBox" data-linked="<?php echo $bmc_linked ? '1' : '0'; ?>">
	<div class="bmc-container bmc-container--narrow">

		<div class="bmc-head bmc-card__head" style="border:0;padding:0;margin-bottom:14px">
			<div>
				<span class="bmc-kicker">
					<?php bmc_icon( 'link', array( 'size' => 14 ) ); ?>
					<?php echo esc_html( $bmc_server ); ?>
				</span>
				<h2 class="bmc-title"><?php echo esc_html( $bmc_title ); ?></h2>
			</div>
		</div>

		<?php if ( ! $bmc_logged_in ) : ?>

			<div class="bmc-card bmc-card--center">
				<div class="bmc-avatar bmc-avatar--lg" style="margin:0 auto 16px">
					<img src="<?php echo esc_url( BMC_Helpers::mc_head( 'MHF_Question', 96 ) ); ?>" alt="" />
				</div>
				<h3 class="bmc-title" style="font-size:19px">ابتدا وارد حساب کاربری شوید</h3>
				<p class="bmc-subtitle">برای ساخت کد اتصال و پیوند اکانت ماینکرافت، باید وارد حساب کاربری خود در سایت شوید.</p>
				<div class="bmc-gate__actions">
					<a class="bmc-btn" href="<?php echo esc_url( BMC_Auth::login_url() ); ?>">ورود / عضویت</a>
				</div>
			</div>

		<?php elseif ( $bmc_linked ) : ?>

			<div class="bmc-card bmc-fade" id="bmcLinkedCard">
				<div class="bmc-status">
					<div class="bmc-avatar bmc-avatar--lg">
						<img src="<?php echo esc_url( BMC_Helpers::mc_head( $bmc_player, 96 ) ); ?>" alt="<?php echo esc_attr( $bmc_player ); ?>" />
					</div>
					<div style="flex:1;min-width:200px">
						<span class="bmc-badge bmc-badge--ok"><?php bmc_icon( 'check', array( 'size' => 14 ) ); ?> متصل است</span>
						<h3 class="bmc-player-name"><?php echo esc_html( $bmc_player ); ?></h3>
						<ul class="bmc-meta-list">
							<?php if ( $bmc_linked_at ) : ?>
								<li><?php bmc_icon( 'calendar_month', array( 'size' => 15 ) ); ?> تاریخ اتصال: <?php echo esc_html( BMC_Jalali::format( $bmc_linked_at, false ) ); ?></li>
							<?php endif; ?>
							<?php if ( $bmc_uuid ) : ?>
								<li style="direction:ltr;justify-content:flex-end;font-family:monospace;font-size:11px">UUID: <?php echo esc_html( $bmc_uuid ); ?></li>
							<?php endif; ?>
							<li><?php bmc_icon( 'sports_esports', array( 'size' => 15 ) ); ?> آیتم‌های خریداری‌شده در اولین ورود به سرور تحویل داده می‌شود.</li>
						</ul>
					</div>
				</div>

				<div class="bmc-alert bmc-alert--ok" style="margin-top:18px;margin-bottom:0">
					<span class="bmc-alert__icon"><?php bmc_icon( 'shopping_cart', array( 'size' => 18 ) ); ?></span>
					<div>حساب شما آمادهٔ خرید است. اکنون می‌توانید وارد صفحهٔ خرید شوید و پرداخت را انجام دهید.</div>
				</div>

				<div class="bmc-code-actions" style="margin-top:18px">
					<?php if ( function_exists( 'wc_get_page_permalink' ) ) : ?>
						<a class="bmc-btn" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>">رفتن به فروشگاه</a>
					<?php endif; ?>
					<?php if ( BMC_Settings::bool( 'unlink_allowed', true ) ) : ?>
						<button type="button" class="bmc-btn bmc-btn--danger" id="bmcUnlinkBtn">قطع اتصال</button>
					<?php endif; ?>
				</div>
			</div>

		<?php else : ?>

			<div class="bmc-card">
				<div class="bmc-steps">
					<div class="bmc-step"><strong>۱.</strong> نام کاربری ماینکرافت را وارد کنید و کد بسازید.</div>
					<div class="bmc-step"><strong>۲.</strong> کد را در بازی با دستور <code>/mclink</code> وارد کنید.</div>
					<div class="bmc-step"><strong>۳.</strong> اتصال تأیید می‌شود و می‌توانید خرید کنید.</div>
				</div>

				<div id="bmcLinkAlert"></div>

				<!-- مرحلهٔ واردکردن نام کاربری -->
				<form id="bmcLinkForm" autocomplete="off">
					<div class="bmc-field">
						<label class="bmc-label" for="bmcPlayerInput">
							نام کاربری ماینکرافت <span class="req">*</span>
						</label>
						<div style="display:flex;gap:10px;align-items:center">
							<div class="bmc-avatar bmc-avatar--sm" style="width:48px;height:48px">
								<img id="bmcHeadPreview" src="<?php echo esc_url( BMC_Helpers::mc_head( 'MHF_Question', 48 ) ); ?>" alt="" />
							</div>
							<input class="bmc-input" id="bmcPlayerInput" name="player" type="text" dir="ltr"
								placeholder="Notch" maxlength="16"
								style="text-align:left;font-family:Consolas,monospace;letter-spacing:1px" />
						</div>
						<p class="bmc-hint">
							<?php if ( 'premium' === $bmc_policy ) : ?>
								فقط نام‌های کاربری اصلی (پرمیوم) موجانگ پذیرفته می‌شود.
							<?php else : ?>
								همهٔ نام‌های کاربری (پرمیوم و کرک) پذیرفته می‌شود.
							<?php endif; ?>
						</p>
					</div>

					<button type="submit" class="bmc-btn bmc-btn--block" id="bmcGenerateBtn">
						<span class="bmc-spin"></span>
						<span>ساخت کد اتصال</span>
					</button>
				</form>

				<!-- مرحلهٔ نمایش کد -->
				<div id="bmcCodePanel" class="bmc-code-panel<?php echo $bmc_active ? '' : ' bmc-hidden'; ?>">
					<p class="bmc-subtitle" style="margin:6px 0 14px">این کد را در بازی وارد کنید:</p>

					<div class="bmc-command">
						<span id="bmcCommandText"><code><?php echo esc_html( $bmc_active ? str_replace( '{code}', ( $bmc_active['code_plain'] ? $bmc_active['code_plain'] : 'CODE' ), $bmc_cmd_tpl ) : $bmc_cmd_tpl ); ?></code></span>
					</div>

					<div class="bmc-code" id="bmcCodeValue" style="margin-top:16px">
						<span id="bmcCodeText"><?php echo $bmc_active ? esc_html( $bmc_active['code_plain'] ? $bmc_active['code_plain'] : 'کد فعال' ) : ''; ?></span>
					</div>

					<div class="bmc-code-actions">
						<button type="button" class="bmc-btn bmc-btn--ghost" id="bmcCopyBtn"><?php bmc_icon( 'content_paste', array( 'size' => 16 ) ); ?> کپی کد</button>
						<button type="button" class="bmc-btn bmc-btn--ghost" id="bmcRegenerateBtn"><?php bmc_icon( 'sync', array( 'size' => 16 ) ); ?> کد جدید</button>
					</div>

					<div class="bmc-timer" id="bmcTimer">
						<?php bmc_icon( 'timer', array( 'size' => 15 ) ); ?> <span>اعتبار کد:</span> <strong id="bmcTimerValue">00:00</strong>
					</div>

					<div class="bmc-progress"><span id="bmcProgressBar"></span></div>

					<p class="bmc-hint" style="margin-top:14px">
						به محض واردکردن کد در بازی، این صفحه به‌صورت خودکار به وضعیت «متصل شد» تغییر می‌کند.
					</p>
				</div>
			</div>

			<?php if ( BMC_Settings::mc_request_enabled() && ( BMC_Settings::bool( 'email_enabled', true ) || BMC_Settings::verify_enabled( 'dashboard' ) ) ) : ?>
				<div class="bmc-card">
					<div class="bmc-card__head" style="margin-bottom:12px">
						<h3 class="bmc-card__title"><span class="bmc-dot"></span> روش جایگزین: کد تأیید</h3>
					</div>
					<p class="bmc-subtitle" style="font-size:13px">
						اگر ترجیح می‌دهید، کد تأیید را روی ایمیل ثبت‌شده در حساب خود دریافت کنید (یا همان‌جا در داشبورد ببینید) و آن را در بازی وارد کنید.
					</p>

					<?php $bmc_dashbox = BMC_Verify::panel_box(); ?>
					<?php if ( $bmc_dashbox ) : ?>
						<?php echo $bmc_dashbox; ?>
					<?php endif; ?>

					<form id="bmcOtpLinkForm" autocomplete="off" style="margin-top:14px">
						<div class="bmc-field">
							<label class="bmc-label">نام کاربری ماینکرافت</label>
							<input class="bmc-input" id="bmcOtpPlayer" name="player" type="text" dir="ltr" placeholder="Notch" maxlength="16" />
						</div>

						<div class="bmc-field-row">
							<button type="button" class="bmc-btn bmc-btn--ghost bmc-otp-channel" data-channel="email" data-delivery="email"><?php bmc_icon( 'mail', array( 'size' => 16 ) ); ?> ارسال به ایمیل</button>
							<?php if ( BMC_Settings::verify_enabled( 'dashboard' ) ) : ?>
								<button type="button" class="bmc-btn bmc-btn--ghost bmc-otp-channel" data-channel="auto" data-delivery="dashboard"><?php bmc_icon( 'desktop_windows', array( 'size' => 16 ) ); ?> نمایش کد در داشبورد</button>
							<?php endif; ?>
						</div>

						<div id="bmcOtpCodeField" class="bmc-field bmc-hidden" style="margin-top:14px">
							<label class="bmc-label" for="bmcOtpCode">کد دریافتی</label>
							<input class="bmc-input bmc-input--code" id="bmcOtpCode" name="code" type="text" inputmode="numeric" maxlength="8" placeholder="•••••" />
							<p class="bmc-hint" id="bmcOtpHint"></p>
						</div>

						<button type="submit" class="bmc-btn bmc-btn--block bmc-hidden" id="bmcOtpSubmit" style="margin-top:10px">
							<span class="bmc-spin"></span><span>تأیید و اتصال</span>
						</button>
					</form>

					<div id="bmcOtpAlert"></div>
				</div>
			<?php endif; ?>

		<?php endif; ?>

	</div>
</div>

<script>
	window.bmcLinkState = {
		active: <?php echo $bmc_active ? wp_json_encode( array( 'expires_in' => (int) $bmc_active['expires_in'], 'player' => $bmc_active['player'], 'code_plain' => isset( $bmc_active['code_plain'] ) ? $bmc_active['code_plain'] : '' ) ) : 'null'; ?>,
		commandTemplate: <?php echo wp_json_encode( $bmc_cmd_tpl ); ?>
	};
</script>
