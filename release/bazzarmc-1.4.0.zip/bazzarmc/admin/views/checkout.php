<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$field_labels = array(
	'first_name' => 'نام',
	'last_name'  => 'نام خانوادگی',
	'mobile'     => 'شمارهٔ موبایل',
	'email'      => 'ایمیل',
	'address'    => 'آدرس',
	'city'       => 'شهر',
	'state'      => 'استان',
	'postcode'   => 'کد پستی',
	'country'    => 'کشور',
	'company'    => 'شرکت',
	'notes'      => 'توضیحات سفارش',
);

BMC_Admin::form_open( 'checkout' );

BMC_Admin::section_open( 'حالت چک‌اوت', 'در حالت اختصاصی، فرم خرید ووکامرس خاموش می‌شود و فرم طراحی‌شدهٔ افزونه جای آن را می‌گیرد؛ اما سبد خرید و درگاه‌های پرداخت همان ووکامرس هستند.' );

BMC_Admin::row(
	'فرم خرید',
	BMC_Admin::select(
		'checkout_mode',
		$settings['checkout_mode'],
		array(
			'custom' => 'چک‌اوت اختصاصی BazzarMc (پیشنهادی)',
			'wc'     => 'چک‌اوت استاندارد ووکامرس',
		)
	),
	'حتی در حالت اختصاصی، ثبت سفارش از طریق هستهٔ ووکامرس انجام می‌شود؛ بنابراین زرین‌پال، IDPay، سامان و بقیهٔ درگاه‌ها بدون تغییر کار می‌کنند.'
);

BMC_Admin::row(
	'پوسته',
	BMC_Admin::select(
		'checkout_theme',
		$settings['checkout_theme'],
		array(
			'dark'  => 'تیره (گیمینگ)',
			'light' => 'روشن',
		)
	)
);

BMC_Admin::row( 'رنگ تأکید', '<input type="text" name="checkout_accent" value="' . esc_attr( $settings['checkout_accent'] ) . '" class="bmc-color" />' );

BMC_Admin::row( 'بارگذاری فونت وزیرمتن از CDN', BMC_Admin::toggle( 'font_cdn', $settings['font_cdn'], 'فونت فارسی وزیرمتن از jsDelivr بارگذاری شود' ), 'اگر قالب شما فونت فارسی دارد، می‌توانید خاموش کنید.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'گیتِ اتصال اکانت', 'اگر اکانت متصل نباشد، کاربر اجازهٔ ورود به صفحهٔ خرید را ندارد و پیام «هنوز متصل نیستید» نمایش داده می‌شود.' );

BMC_Admin::row( 'فعال‌سازی گیت', BMC_Admin::toggle( 'gate_enabled', $settings['gate_enabled'], 'بدون اتصال اکانت، امکان خرید نباشد' ) );
BMC_Admin::row( 'فقط برای محصولات ماینکرافتی', BMC_Admin::toggle( 'gate_only_synced', $settings['gate_only_synced'], 'گیت فقط وقتی فعال شود که محصول همگام‌شده در سبد باشد' ), 'اگر خاموش کنید، همهٔ خریدها نیازمند اتصال می‌شوند.' );
BMC_Admin::row( 'کنترل صفحهٔ محصول', BMC_Admin::toggle( 'gate_product_page', $settings['gate_product_page'], 'در صفحهٔ محصول همگام‌شده، دکمهٔ خرید برای کاربران متصل‌نشده غیرفعال شود' ) );
BMC_Admin::row( 'نمایش کد تخفیف', BMC_Admin::toggle( 'checkout_show_coupon', $settings['checkout_show_coupon'], 'کادر کد تخفیف در چک‌اوت نمایش داده شود' ) );
BMC_Admin::row( 'خرید هدیه', BMC_Admin::toggle( 'checkout_gift_allowed', $settings['checkout_gift_allowed'], 'کاربر بتواند برای بازیکن دیگری خرید کند' ) );

BMC_Admin::section_close();

BMC_Admin::section_open( 'سبد خرید و صفحهٔ پرداخت (جدا از هم)', 'صفحهٔ سبد خرید فقط سبد را نشان می‌دهد و صفحهٔ پرداخت فقط فرم خرید و خلاصهٔ سفارش را. دکمهٔ پرداخت کاربر را به صفحهٔ پرداخت می‌برد.' );

BMC_Admin::row(
	'صفحهٔ سبد خرید',
	BMC_Admin::select(
		'cart_mode',
		$settings['cart_mode'],
		array(
			'custom' => 'سبد اختصاصی BazzarMc (پیشنهادی)',
			'wc'     => 'سبد پیش‌فرض ووکامرس (فقط گیت اعمال شود)',
		)
	),
	'در حالت اختصاصی، صفحهٔ سبد ووکامرس با سبد فارسی افزونه جایگزین می‌شود (شورت‌کد <code>[bazzarmc_cart]</code> هم همین خروجی را دارد). پرداخت در صفحهٔ جداگانهٔ خودش انجام می‌شود.'
);

BMC_Admin::row(
	'ادغام چک‌اوت داخل صفحهٔ سبد',
	BMC_Admin::toggle( 'cart_inline_checkout', $settings['cart_inline_checkout'], 'فرم پرداخت زیر سبد خرید هم نمایش داده شود' ),
	'پیش‌فرض خاموش است تا سبد خرید و صفحهٔ پرداخت کاملاً از هم جدا بمانند. اگر روشن کنید، دکمهٔ «ادامه و تکمیل پرداخت» به بخش چک‌اوت در همان صفحه می‌رود.'
);

BMC_Admin::row( 'نوار مرحله‌ها', BMC_Admin::toggle( 'cart_steps_nav', $settings['cart_steps_nav'], 'نمایش «سبد خرید ← پرداخت ← تکمیل سفارش» بالای هر دو صفحه' ) );
BMC_Admin::row( 'لینک بازگشت به سبد', BMC_Admin::toggle( 'checkout_back_to_cart', $settings['checkout_back_to_cart'], 'در صفحهٔ پرداخت لینک «بازگشت به سبد خرید» نمایش داده شود' ) );
BMC_Admin::row( 'متن دکمهٔ پرداخت در سبد', BMC_Admin::input( 'cart_button_text', $settings['cart_button_text'] ) );
BMC_Admin::row( 'متن دکمهٔ ثبت سفارش', BMC_Admin::input( 'checkout_submit_text', $settings['checkout_submit_text'] ) );

BMC_Admin::row( 'گیت دکمهٔ پرداخت', BMC_Admin::toggle( 'cart_gate', $settings['cart_gate'], 'تا اتصال اکانت، دکمهٔ پرداخت در سبد غیرفعال بماند' ), 'به‌جای دکمه، پیام «هنوز متصل نیستید» + دکمهٔ «اتصال اکانت ماینکرافت» نمایش داده می‌شود.' );
BMC_Admin::row( 'پنهان‌کردن افزودن به سبد', BMC_Admin::toggle( 'gate_hide_add_to_cart', $settings['gate_hide_add_to_cart'], 'برای کاربران متصل‌نشده، دکمهٔ «افزودن به سبد» در صفحهٔ محصول پنهان شود' ), 'کاربر پیش از افزودن به سبد متوجه می‌شود که باید اکانتش را متصل کند.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'فارسی‌سازی فیلدها', 'برچسب و placeholder همهٔ فیلدهای ووکامرس (آدرس، استان، شهر، کد پستی، تلفن و…) به فارسی ترجمه می‌شوند.' );

BMC_Admin::row( 'ترجمهٔ فیلدها', BMC_Admin::toggle( 'persian_fields', $settings['persian_fields'], 'برچسب و placeholder فیلدهای چک‌اوت فارسی شود' ) );
BMC_Admin::row( 'نام کشورها به فارسی', BMC_Admin::toggle( 'persian_countries', $settings['persian_countries'], 'لیست کشورها فارسی نمایش داده شود' ), 'لیست استان‌های ایران همیشه کامل و فارسی است.' );
BMC_Admin::row( 'اعداد فارسی', BMC_Admin::toggle( 'persian_digits', $settings['persian_digits'], 'اعداد قیمت و جمع کل با رقم فارسی نمایش داده شوند' ), 'فقط نمایش؛ مقدار ارسالی به درگاه پرداخت دست‌نخورده می‌ماند.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'فرم‌ساز چک‌اوت', 'کارت‌ها و فیلدهای فرم خرید را انتخاب کنید، ترتیب و عنوان و برچسب و عرض هر فیلد را بچینید. مقدارهای خالی یعنی «همان پیش‌فرض ووکامرس/افزونه».' );

$bmc_card_labels = array(
	'mc'      => 'کارت اکانت ماینکرافت',
	'buyer'   => 'کارت اطلاعات خریدار',
	'payment' => 'کارت روش پرداخت',
);
$bmc_cards_on    = (array) $settings['checkout_cards'];
$bmc_card_order  = (array) $settings['checkout_card_order'];
$bmc_titles      = (array) $settings['checkout_titles'];
$bmc_layout      = (array) $settings['checkout_layout'];

BMC_Admin::row(
	'ستون‌بندی فیلدها',
	BMC_Admin::select( 'checkout_columns', $settings['checkout_columns'], array( '2' => 'دو ستونه (پیشنهادی)', '1' => 'یک ستونه (تمام فیلدها تمام‌عرض)' ) )
);

echo '<table class="bmc-table bmc-table--full bmc-layout-table">';
echo '<thead><tr><th>کارت</th><th style="width:70px">نمایش</th><th style="width:90px">ترتیب</th><th>عنوان کارت</th></tr></thead><tbody>';

foreach ( $bmc_card_labels as $bmc_card_key => $bmc_card_label ) {
	printf(
		'<tr><td>%1$s</td><td><label class="bmc-check"><input type="checkbox" name="checkout_card_show[%2$s]" value="1" %3$s /><span></span></label></td>'
		. '<td><input class="bmc-input bmc-input--num" type="number" min="1" max="9" name="checkout_card_order[%2$s]" value="%4$d" /></td>'
		. '<td><input class="bmc-input" type="text" name="checkout_titles[%2$s]" value="%5$s" placeholder="%1$s" /></td></tr>',
		esc_html( $bmc_card_label ),
		esc_attr( $bmc_card_key ),
		checked( in_array( $bmc_card_key, $bmc_cards_on, true ), true, false ),
		isset( $bmc_card_order[ $bmc_card_key ] ) ? (int) $bmc_card_order[ $bmc_card_key ] : 1,
		esc_attr( isset( $bmc_titles[ $bmc_card_key ] ) ? $bmc_titles[ $bmc_card_key ] : '' )
	);
}

printf(
	'<tr><td>کارت خلاصهٔ سفارش (همیشه در ستون کناری)</td><td>—</td><td>—</td><td><input class="bmc-input" type="text" name="checkout_titles[summary]" value="%s" placeholder="خلاصهٔ سفارش" /></td></tr>',
	esc_attr( isset( $bmc_titles['summary'] ) ? $bmc_titles['summary'] : '' )
);

echo '</tbody></table>';

$bmc_wc_fields = array(
	'billing_first_name'  => 'نام',
	'billing_last_name'   => 'نام خانوادگی',
	'billing_phone'       => 'شمارهٔ موبایل',
	'billing_email'       => 'ایمیل',
	'billing_company'     => 'شرکت',
	'billing_country'     => 'کشور',
	'billing_state'       => 'استان',
	'billing_city'        => 'شهر',
	'billing_postcode'    => 'کد پستی',
	'billing_address_1'   => 'آدرس',
	'billing_address_2'   => 'آدرس (ادامه)',
	'order_comments'      => 'توضیحات سفارش',
);

$bmc_width_choices = array(
	0   => 'خودکار',
	100 => 'تمام عرض',
	75  => 'سه‌چهارم',
	66  => 'دو‌سوم',
	50  => 'نصف',
	33  => 'یک‌سوم',
	25  => 'یک‌چهارم',
);

$bmc_required_choices = array(
	-1 => 'پیش‌فرض',
	1  => 'الزامی',
	0  => 'اختیاری',
);

echo '<h3 class="bmc-subhead">فیلدهای فرم خرید</h3>';
echo '<p class="bmc-hint">فیلدهایی که در بخش «فیلدهای فعال» پایین خاموش باشند، در فرم نمایش داده نمی‌شوند. ترتیب کوچک‌تر یعنی بالاتر؛ صفر یعنی ترتیب پیش‌فرض ووکامرس.</p>';

echo '<table class="bmc-table bmc-table--full bmc-layout-table">';
echo '<thead><tr><th>فیلد</th><th style="width:80px">ترتیب</th><th>برچسب دلخواه</th><th>placeholder</th><th style="width:110px">عرض</th><th style="width:100px">الزامی</th></tr></thead><tbody>';

foreach ( $bmc_wc_fields as $bmc_field_key => $bmc_field_label ) {
	$bmc_conf = isset( $bmc_layout[ $bmc_field_key ] ) && is_array( $bmc_layout[ $bmc_field_key ] ) ? $bmc_layout[ $bmc_field_key ] : array();

	printf(
		'<tr><td><strong>%1$s</strong><div class="bmc-dim" dir="ltr"><code>%2$s</code></div></td>'
		. '<td><input class="bmc-input bmc-input--num" type="number" min="0" max="99" name="checkout_layout[%2$s][order]" value="%3$d" /></td>'
		. '<td><input class="bmc-input" type="text" name="checkout_layout[%2$s][label]" value="%4$s" placeholder="%1$s" /></td>'
		. '<td><input class="bmc-input" type="text" name="checkout_layout[%2$s][placeholder]" value="%5$s" /></td>'
		. '<td>%6$s</td><td>%7$s</td></tr>',
		esc_html( $bmc_field_label ),
		esc_attr( $bmc_field_key ),
		isset( $bmc_conf['order'] ) ? (int) $bmc_conf['order'] : 0,
		esc_attr( isset( $bmc_conf['label'] ) ? $bmc_conf['label'] : '' ),
		esc_attr( isset( $bmc_conf['placeholder'] ) ? $bmc_conf['placeholder'] : '' ),
		BMC_Admin::select( 'checkout_layout[' . $bmc_field_key . '][width]', isset( $bmc_conf['width'] ) ? (int) $bmc_conf['width'] : 0, $bmc_width_choices ),
		BMC_Admin::select( 'checkout_layout[' . $bmc_field_key . '][required]', isset( $bmc_conf['required'] ) ? (int) $bmc_conf['required'] : -1, $bmc_required_choices )
	);
}

echo '</tbody></table>';

BMC_Admin::section_close();

BMC_Admin::section_open( 'فیلدهای فعال فرم خرید', 'فیلدهایی که در چک‌اوت نمایش داده شوند. فیلدهای خاموش، از فرم و از اعتبارسنجی ووکامرس حذف می‌شوند.' );

echo '<div class="bmc-checkbox-grid">';
foreach ( $field_labels as $key => $label ) {
	$checked = ! empty( $settings['checkout_fields'][ $key ] );
	printf(
		'<label class="bmc-check"><input type="checkbox" name="checkout_fields[%1$s]" value="1" %2$s /><span>%3$s</span></label>',
		esc_attr( $key ),
		checked( $checked, true, false ),
		esc_html( $label )
	);
}
echo '</div>';

echo '<p class="bmc-note" style="margin-top:14px">برای فروش آیتم مجازی ماینکرافت، معمولاً فقط «نام»، «نام خانوادگی» و «شمارهٔ موبایل» لازم است.</p>';

BMC_Admin::section_close();

BMC_Admin::form_close();
