(function ($) {
	'use strict';

	if (typeof bmcAdmin === 'undefined') {
		return;
	}

	function toast(message, type) {
		$('.bmc-toast').remove();
		var $t = $('<div class="bmc-toast"></div>').addClass(type ? 'is-' + type : '').text(message);
		$('body').append($t);
		setTimeout(function () { $t.fadeOut(220, function () { $t.remove(); }); }, 4200);
	}

	$(document).on('click', '.bmc-copy', function () {
		var text = $(this).data('copy');
		var $btn = $(this);
		var original = $btn.text();

		var done = function () {
			$btn.text(bmcAdmin.i18n.copied);
			setTimeout(function () { $btn.text(original); }, 1600);
		};

		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(String(text)).then(done).catch(function () { fallback(text, done); });
		} else {
			fallback(text, done);
		}
	});

	function fallback(text, cb) {
		var $tmp = $('<textarea>').val(text).css({ position: 'fixed', top: '-1000px', opacity: 0 }).appendTo('body');
		$tmp[0].select();
		try {
			document.execCommand('copy');
			cb();
		} catch (e) {
			toast('کپی ناموفق بود.', 'error');
		}
		$tmp.remove();
	}

	$(document).on('click', '.bmc-action', function (e) {
		e.preventDefault();

		var $btn = $(this);
		var action = $btn.data('do');

		if ($btn.data('confirm') && !window.confirm(bmcAdmin.i18n.confirm)) {
			return;
		}

		var data = { action: 'bmc_admin_action', security: bmcAdmin.nonce, 'do': action };

		if ($btn.data('id')) {
			data.id = $btn.data('id');
		}

		if ($btn.data('status')) {
			data.status = $btn.data('status');
		}

		var extra = $btn.data('extra');
		if (extra) {
			$.each(String(extra).split(','), function (i, pair) {
				var parts = pair.split(':');
				if (parts.length === 2) {
					data[parts[0]] = $(parts[1]).val();
				}
			});
		}

		var original = $btn.html();
		$btn.prop('disabled', true).html(bmcAdmin.i18n.working);

		$.post(bmcAdmin.ajaxUrl, data)
			.done(function (res) {
				if (res && res.success) {
					toast(res.data.message || bmcAdmin.i18n.done, 'ok');
					handleSpecial(action, res.data);

					if ($btn.data('remove-row')) {
						$btn.closest('tr').fadeOut(200, function () { $(this).remove(); });
					} else if ($btn.data('reload')) {
						setTimeout(function () { window.location.reload(); }, 700);
					}
				} else {
					toast((res && res.data && res.data.message) ? res.data.message : bmcAdmin.i18n.error, 'error');
				}
			})
			.fail(function (xhr) {
				var msg = (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ? xhr.responseJSON.data.message : bmcAdmin.i18n.error;
				toast(msg, 'error');
			})
			.always(function () {
				$btn.prop('disabled', false).html(original);
			});
	});

	function handleSpecial(action, data) {
		if (action === 'regenerate_token' && data.token) {
			$('#bmcTokenValue, #bmcTokenField').text(data.token);
			$('.bmc-copy[data-copy]').each(function () {
				if ($(this).data('copy').length === data.token.length) {
					$(this).attr('data-copy', data.token);
				}
			});
		}

		if (action === 'run_health' && data.checks) {
			renderHealth(data.checks);
		}

		if (action === 'detect_mobile_keys' && data.keys) {
			var $target = $('#bmcDetectedKeys');
			$target.empty();

			if (!data.keys.length) {
				$target.append('<div class="bmc-note">کلیدی با مقدار شبیه شمارهٔ موبایل پیدا نشد.</div>');
				return;
			}

			$.each(data.keys, function (i, row) {
				$target.append(
					'<div class="bmc-key-row"><code>' + row.meta_key + '</code><span>' + row.c + ' کاربر</span>' +
					'<button type="button" class="button button-small bmc-add-key" data-key="' + row.meta_key + '">افزودن به لیست</button></div>'
				);
			});
		}
	}

	function renderHealth(checks) {
		var $box = $('#bmcHealthResult');

		if (!$box.length) {
			return;
		}

		var labels = { ok: 'سالم', warn: 'هشدار', fail: 'نیازمند اقدام', info: 'اطلاع' };
		var html = '<table class="bmc-table bmc-table--full"><thead><tr><th style="width:190px">بررسی</th><th style="width:120px">نتیجه</th><th>جزئیات</th></tr></thead><tbody>';

		$.each(checks, function (i, row) {
			html += '<tr class="bmc-health-' + row.status + '">' +
				'<td><strong>' + $('<span>').text(row.label).html() + '</strong></td>' +
				'<td><span class="bmc-pill is-' + (row.status === 'ok' ? 'done' : (row.status === 'fail' ? 'expired' : (row.status === 'warn' ? 'pending' : 'info'))) + '">' + (labels[row.status] || row.status) + '</span></td>' +
				'<td>' + row.detail + '</td></tr>';
		});

		html += '</tbody></table>';
		$box.html(html).slideDown(160);
	}

	function bmcSvg(name) {
		return (typeof window.bmcIcon === 'function') ? window.bmcIcon(name, '', 15) : '';
	}

	var bmcFieldCounter = $('#bmcFieldBuilder tbody tr.bmc-builder__row').length;

	function builderMeta() {
		try {
			return JSON.parse($('#bmcFieldTemplate').text() || '{}');
		} catch (e) {
			return { types: {}, widths: {} };
		}
	}

	function optionsHtml(name) {
		var meta = builderMeta();
		var html = '<select class="bmc-input bmc-select" name="' + name + '">';

		$.each(meta.types || {}, function (value, label) {
			html += '<option value="' + value + '">' + label + '</option>';
		});

		return html + '</select>';
	}

	function widthsHtml(name) {
		var meta = builderMeta();
		var html = '<select class="bmc-input bmc-select" name="' + name + '">';

		$.each(meta.widths || {}, function (value, label) {
			html += '<option value="' + value + '">' + label + '</option>';
		});

		return html + '</select>';
	}

	function syncOrder() {
		var $box = $('#bmcOrderBox').empty();
		var order = [];

		$('#bmcFieldBuilder tbody tr.bmc-builder__row').each(function () {
			order.push($(this).data('row'));
		});

		$.each(order, function (i, rowIndex) {
			$box.append($('<input type="hidden" name="bmc_form_order[]">').val(rowIndex));
		});

		$('#bmcFieldBuilder tbody tr.bmc-builder__row').each(function (i) {
			$(this).find('.bmc-builder__num').text((i + 1).toLocaleString('fa-IR'));
		});
	}

	$(document).on('click', '#bmcAddField', function () {
		var index = bmcFieldCounter++;
		var base = 'bmc_form_fields[' + index + ']';
		var $row = $(
			'<tr class="bmc-builder__row" data-row="' + index + '">' +
			'<td class="bmc-builder__order"><span class="bmc-builder__num">' + (index + 1) + '</span></td>' +
			'<td><input class="bmc-input" type="text" name="' + base + '[label]" placeholder="برچسب فیلد" />' +
			'<input class="bmc-input bmc-builder__sub" type="text" name="' + base + '[placeholder]" placeholder="placeholder" /></td>' +
			'<td>' + optionsHtml(base + '[type]') + '</td>' +
			'<td><input class="bmc-input" type="text" dir="ltr" name="' + base + '[id]" value="field_' + (index + 1) + '" /></td>' +
			'<td>' + widthsHtml(base + '[width]') + '</td>' +
			'<td><label class="bmc-check"><input type="checkbox" name="' + base + '[required]" value="1" /><span></span></label></td>' +
			'<td><div class="bmc-builder__tools">' +
			'<button type="button" class="button button-small bmc-row-up">' + bmcSvg('keyboard_arrow_up') + '</button>' +
			'<button type="button" class="button button-small bmc-row-down">' + bmcSvg('keyboard_arrow_down') + '</button>' +
			'<button type="button" class="button button-small bmc-row-adv">' + bmcSvg('tune') + '</button>' +
			'<button type="button" class="button button-small button-link-delete bmc-row-del">' + bmcSvg('delete') + '</button>' +
			'</div></td></tr>'
		);

		var $adv = $(
			'<tr class="bmc-builder__adv-row" data-adv-for="' + index + '" style="display:none"><td colspan="7"><div class="bmc-builder__adv">' +
			'<div class="bmc-formgrid">' +
			'<label class="bmc-advfield">راهنمای زیر فیلد<input class="bmc-input" type="text" name="' + base + '[help]" /></label>' +
			'<label class="bmc-advfield">مقدار پیش‌فرض<input class="bmc-input" type="text" name="' + base + '[default]" /></label>' +
			'<label class="bmc-advfield">حداقل<input class="bmc-input" type="number" min="0" name="' + base + '[min]" value="0" /></label>' +
			'<label class="bmc-advfield">حداکثر<input class="bmc-input" type="number" min="0" name="' + base + '[max]" value="0" /></label>' +
			'<label class="bmc-advfield">الگوی اعتبارسنجی<input class="bmc-input" type="text" dir="ltr" name="' + base + '[pattern]" /></label>' +
			'<label class="bmc-advfield">پیام خطای دلخواه<input class="bmc-input" type="text" name="' + base + '[message]" /></label>' +
			'<label class="bmc-advfield">تعداد سطر<input class="bmc-input" type="number" min="2" max="20" name="' + base + '[rows]" value="4" /></label>' +
			'<label class="bmc-advfield">پسوند فایل مجاز<input class="bmc-input" type="text" dir="ltr" name="' + base + '[accept]" placeholder="jpg,png,pdf" /></label>' +
			'</div>' +
			'<label class="bmc-check"><input type="checkbox" name="' + base + '[iran_phone]" value="1" /><span>شمارهٔ موبایل ایرانی اعتبارسنجی شود</span></label>' +
			'<label class="bmc-advfield">گزینه‌ها (هر خط: value|برچسب)<textarea class="bmc-input bmc-textarea" rows="4" name="' + base + '[options]"></textarea></label>' +
			'</div></td></tr>'
		);

		var $last = $('#bmcFieldBuilder tbody tr').last();

		if ($last.length) {
			$last.after($row).after($adv);
		} else {
			$('#bmcFieldBuilder tbody').append($row).append($adv);
		}

		syncOrder();
		$row.find('input[name$="[label]"]').trigger('focus');
	});

	$(document).on('click', '.bmc-row-del', function () {
		if (!window.confirm(bmcAdmin.i18n.confirm)) {
			return;
		}

		var $row = $(this).closest('tr');
		var index = $row.data('row');

		$row.remove();
		$('tr.bmc-builder__adv-row[data-adv-for="' + index + '"]').remove();
		syncOrder();
	});

	$(document).on('click', '.bmc-row-up', function () {
		var $row = $(this).closest('tr');
		var index = $row.data('row');
		var $adv = $('tr.bmc-builder__adv-row[data-adv-for="' + index + '"]');
		var $prev = $row.prevAll('tr.bmc-builder__row').first();

		if (!$prev.length) {
			return;
		}

		var $prevAdv = $('tr.bmc-builder__adv-row[data-adv-for="' + $prev.data('row') + '"]');

		$row.insertBefore($prev);
		$adv.insertAfter($row);
		$prev.insertAfter($adv);
		$prevAdv.insertAfter($prev);
		syncOrder();
	});

	$(document).on('click', '.bmc-row-down', function () {
		var $row = $(this).closest('tr');
		var index = $row.data('row');
		var $adv = $('tr.bmc-builder__adv-row[data-adv-for="' + index + '"]');
		var $next = $row.nextAll('tr.bmc-builder__row').first();

		if (!$next.length) {
			return;
		}

		var $nextAdv = $('tr.bmc-builder__adv-row[data-adv-for="' + $next.data('row') + '"]');

		$next.insertBefore($row);
		$nextAdv.insertAfter($next);
		$row.insertAfter($nextAdv);
		$adv.insertAfter($row);
		syncOrder();
	});

	$(document).on('click', '.bmc-row-adv', function () {
		var index = $(this).closest('tr').data('row');
		$('tr.bmc-builder__adv-row[data-adv-for="' + index + '"]').toggle();
	});

	$(document).on('click', '.bmc-add-key', function () {
		var key = $(this).data('key');
		var $input = $('input[name="mobile_meta_keys"]');
		var current = ($input.val() || '').split(',').map(function (v) { return v.trim(); }).filter(Boolean);

		if (current.indexOf(key) === -1) {
			current.push(key);
			$input.val(current.join(','));
			toast('کلید «' + key + '» اضافه شد. فرم را ذخیره کنید.', 'ok');
		}
	});

	$(document).on('click', '.bmc-delivery-action', function () {
		var $btn = $(this);
		var action = $btn.data('do');

		if (action === 'delete' && !window.confirm(bmcAdmin.i18n.confirm)) {
			return;
		}

		$btn.prop('disabled', true);

		$.post(bmcAdmin.ajaxUrl, {
			action: 'bmc_admin_delivery_action',
			security: bmcAdmin.nonce,
			id: $btn.data('id'),
			'do': action
		}).done(function (res) {
			if (res && res.success) {
				toast(res.data.message, 'ok');
				var $row = $btn.closest('tr');
				if (action === 'delete') {
					$row.fadeOut(200, function () { $row.remove(); });
				} else {
					setTimeout(function () { window.location.reload(); }, 700);
				}
			} else {
				toast((res && res.data && res.data.message) ? res.data.message : bmcAdmin.i18n.error, 'error');
				$btn.prop('disabled', false);
			}
		}).fail(function () {
			toast(bmcAdmin.i18n.error, 'error');
			$btn.prop('disabled', false);
		});
	});

	$(document).on('input', '#bmcProductSearch', function () {
		var q = $(this).val().trim().toLowerCase();

		$('.bmc-product').each(function () {
			var title = $(this).data('title') || '';
			var match = !q || String(title).indexOf(q) !== -1;
			$(this).toggle(match);
		});

		$('.bmc-variations').each(function () {
			var anyVisible = $(this).find('.bmc-product:visible').length > 0;
			$(this).toggle(anyVisible);
		});
	});

	function updateCount() {
		var count = $('input[name="sync_products[]"]:checked').length;
		$('#bmcSelectedCount').text(count.toLocaleString('fa-IR'));
	}

	$(document).on('change', 'input[name="sync_products[]"]', function () {
		$(this).closest('.bmc-product').toggleClass('is-checked', this.checked);
		updateCount();
	});

	if ($.fn.wpColorPicker) {
		$('.bmc-color').wpColorPicker();
	}

	syncOrder();
	updateCount();
})(jQuery);
