<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_view      = isset( $_GET['view'] ) ? sanitize_key( wp_unslash( $_GET['view'] ) ) : 'list'; // phpcs:ignore WordPress.Security.NonceVerification
$bmc_form_id   = isset( $_GET['form'] ) ? absint( wp_unslash( $_GET['form'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
$bmc_entry_id  = isset( $_GET['entry'] ) ? absint( wp_unslash( $_GET['entry'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
$bmc_base_url  = admin_url( 'admin.php?page=bazzarmc&tab=forms' );
$bmc_types     = BMC_Forms::field_types();
$bmc_widths    = BMC_Forms::widths();
$bmc_statuses  = BMC_Forms::entry_statuses();

if ( isset( $_GET['bmc_form_msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
	echo '<div class="bmc-notice bmc-notice--ok">' . bmc_get_icon( 'check_circle', array( 'size' => 17 ) )
		. '<span>' . esc_html( sanitize_text_field( rawurldecode( wp_unslash( $_GET['bmc_form_msg'] ) ) ) ) . '</span></div>'; // phpcs:ignore WordPress.Security.NonceVerification
}

if ( isset( $_GET['bmc_safe_done'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
	echo '<div class="bmc-notice bmc-notice--ok">' . bmc_get_icon( 'check_circle', array( 'size' => 17 ) )
		. '<span>عملیات محافظ پایداری انجام شد.</span></div>';
}

if ( 'edit' === $bmc_view ) :

	$bmc_form = $bmc_form_id ? BMC_Forms::get( $bmc_form_id ) : null;
	$bmc_cfg  = $bmc_form ? $bmc_form : BMC_Forms::normalize_config( array( 'title' => 'فرم تماس', 'fields' => array() ) );

	if ( $bmc_form_id && ! $bmc_form ) {
		echo '<div class="bmc-notice bmc-notice--warn">' . bmc_get_icon( 'warning', array( 'size' => 17 ) ) . '<span>فرم پیدا نشد.</span></div>';
	}
	?>

	<?php BMC_Admin::form_open( 'forms' ); ?>
	<input type="hidden" name="bmc_form_id" value="<?php echo esc_attr( $bmc_form_id ); ?>" />
	<input type="hidden" name="bmc_form_builder" value="1" />

	<section class="bmc-box">
		<div class="bmc-box__head">
			<h2><?php bmc_icon( 'dynamic_form', array( 'size' => 18 ) ); ?> <?php echo $bmc_form_id ? 'ویرایش فرم' : 'ساخت فرم جدید'; ?></h2>
			<div class="bmc-inline">
				<a class="button" href="<?php echo esc_url( $bmc_base_url ); ?>"><?php bmc_icon( 'keyboard_arrow_right', array( 'size' => 16 ) ); ?> بازگشت به فهرست فرم‌ها</a>
				<?php if ( $bmc_form_id ) : ?>
					<a class="button" href="<?php echo esc_url( add_query_arg( array( 'bmc_form_preview' => $bmc_form_id ), home_url( '/' ) ) ); ?>" target="_blank" rel="noopener"><?php bmc_icon( 'visibility', array( 'size' => 15 ) ); ?> پیش‌نمایش</a>
				<?php endif; ?>
			</div>
		</div>

		<div class="bmc-box__body">
			<div class="bmc-formgrid">
				<?php BMC_Admin::row( 'عنوان فرم', BMC_Admin::input( 'bmc_form_title', $bmc_cfg['title'], array( 'placeholder' => 'فرم پشتیبانی' ) ) ); ?>
				<?php BMC_Admin::row( 'نامک (slug)', BMC_Admin::input( 'bmc_form_slug', isset( $bmc_cfg['slug'] ) ? $bmc_cfg['slug'] : '', array( 'dir' => 'ltr', 'placeholder' => 'contact' ) ), 'برای فراخوانی با <code>[bazzarmc_form slug="..."]</code>. خالی بگذارید تا خودکار ساخته شود.' ); ?>
			</div>

			<?php BMC_Admin::row( 'توضیح بالای فرم', BMC_Admin::textarea( 'bmc_form_description', $bmc_cfg['description'], 2 ) ); ?>

			<div class="bmc-formgrid">
				<?php
				BMC_Admin::row(
					'وضعیت',
					BMC_Admin::select(
						'bmc_form_status',
						$bmc_cfg['status'],
						array(
							'active' => 'فعال',
							'paused' => 'غیرفعال (موقت)',
						)
					)
				);
				BMC_Admin::row( 'متن دکمهٔ ارسال', BMC_Admin::input( 'bmc_form_submit_text', $bmc_cfg['submit_text'] ) );
				BMC_Admin::row( 'پیام موفقیت', BMC_Admin::input( 'bmc_form_success', $bmc_cfg['success_message'] ) );
				BMC_Admin::row( 'پیام خطا', BMC_Admin::input( 'bmc_form_error', $bmc_cfg['error_message'] ) );
				BMC_Admin::row(
					'جای برچسب فیلدها',
					BMC_Admin::select( 'bmc_form_labels', $bmc_cfg['labels_position'], array( 'top' => 'بالای فیلد', 'inside' => 'داخل فیلد (placeholder)' ) )
				);
				BMC_Admin::row(
					'پوسته',
					BMC_Admin::select( 'bmc_form_theme', $bmc_cfg['theme'], array( 'inherit' => 'همان تنظیمات چک‌اوت', 'dark' => 'تیره', 'light' => 'روشن' ) )
				);
				BMC_Admin::row( 'رنگ تأکید', '<input type="text" name="bmc_form_accent" value="' . esc_attr( $bmc_cfg['accent'] ) . '" class="bmc-color" />', 'خالی = رنگ تأکید عمومی افزونه.' );
				BMC_Admin::row( 'فاصلهٔ بین فیلدها (پیکسل)', BMC_Admin::input( 'bmc_form_gap', $bmc_cfg['gap'], array( 'type' => 'number', 'min' => 4, 'max' => 48 ) ) );
				?>
			</div>

			<div class="bmc-checkbox-grid">
				<label class="bmc-check"><input type="checkbox" name="bmc_form_show_title" value="1" <?php checked( ! empty( $bmc_cfg['show_title'] ) ); ?> /><span>نمایش عنوان و توضیح</span></label>
				<label class="bmc-check"><input type="checkbox" name="bmc_form_bordered" value="1" <?php checked( ! empty( $bmc_cfg['bordered'] ) ); ?> /><span>کارت قاب‌دار</span></label>
				<label class="bmc-check"><input type="checkbox" name="bmc_form_save" value="1" <?php checked( ! empty( $bmc_cfg['save_entries'] ) ); ?> /><span>ذخیرهٔ ارسال‌ها در سایت</span></label>
				<label class="bmc-check"><input type="checkbox" name="bmc_form_honeypot" value="1" <?php checked( ! empty( $bmc_cfg['honeypot'] ) ); ?> /><span>تلهٔ ضدربات (honeypot)</span></label>
				<label class="bmc-check"><input type="checkbox" name="bmc_form_login" value="1" <?php checked( ! empty( $bmc_cfg['login_required'] ) ); ?> /><span>فقط کاربران واردشده بتوانند ارسال کنند</span></label>
				<label class="bmc-check"><input type="checkbox" name="bmc_form_files" value="1" <?php checked( ! empty( $bmc_cfg['allow_files'] ) ); ?> /><span>اجازهٔ بارگذاری فایل</span></label>
			</div>
		</div>
	</section>

	<section class="bmc-box">
		<div class="bmc-box__head">
			<h2><?php bmc_icon( 'checklist', array( 'size' => 18 ) ); ?> فیلدهای فرم</h2>
			<div class="bmc-inline">
				<button type="button" class="button button-primary" id="bmcAddField"><?php bmc_icon( 'add', array( 'size' => 16 ) ); ?> افزودن فیلد</button>
			</div>
		</div>

		<div class="bmc-box__body">
			<p class="bmc-hint">با دکمه‌های بالا و پایین ترتیب فیلدها را عوض کنید. فیلدهای «لیست بازشو»، «رادیویی» و «چند انتخابی» گزینه‌های خود را از کادر «گزینه‌ها» می‌گیرند (هر خط یک گزینه، به شکل <code>value|برچسب</code>).</p>

			<table class="bmc-table bmc-table--full bmc-builder" id="bmcFieldBuilder">
				<thead>
					<tr>
						<th style="width:34px">#</th>
						<th>برچسب</th>
						<th style="width:150px">نوع</th>
						<th style="width:130px">شناسه</th>
						<th style="width:110px">عرض</th>
						<th style="width:70px">الزامی</th>
						<th style="width:112px">ابزار</th>
					</tr>
				</thead>
				<tbody>
					<?php
					$bmc_index = 0;

					foreach ( $bmc_cfg['fields'] as $bmc_field ) {
						$bmc_options_text = '';

						foreach ( (array) $bmc_field['options'] as $bmc_option ) {
							$bmc_options_text .= $bmc_option['value'] . '|' . $bmc_option['label'] . "\n";
						}
						?>
						<tr class="bmc-builder__row" data-row="<?php echo esc_attr( $bmc_index ); ?>">
							<td class="bmc-builder__order"><span class="bmc-builder__num"><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_index + 1 ) ); ?></span></td>
							<td>
								<input class="bmc-input" type="text" name="bmc_form_fields[<?php echo esc_attr( $bmc_index ); ?>][label]" value="<?php echo esc_attr( $bmc_field['label'] ); ?>" placeholder="برچسب فیلد" />
								<input class="bmc-input bmc-builder__sub" type="text" name="bmc_form_fields[<?php echo esc_attr( $bmc_index ); ?>][placeholder]" value="<?php echo esc_attr( $bmc_field['placeholder'] ); ?>" placeholder="placeholder" />
							</td>
							<td><?php echo BMC_Admin::select( 'bmc_form_fields[' . $bmc_index . '][type]', $bmc_field['type'], $bmc_types ); ?></td>
							<td><input class="bmc-input" type="text" dir="ltr" name="bmc_form_fields[<?php echo esc_attr( $bmc_index ); ?>][id]" value="<?php echo esc_attr( $bmc_field['id'] ); ?>" /></td>
							<td><?php echo BMC_Admin::select( 'bmc_form_fields[' . $bmc_index . '][width]', $bmc_field['width'], $bmc_widths ); ?></td>
							<td><label class="bmc-check"><input type="checkbox" name="bmc_form_fields[<?php echo esc_attr( $bmc_index ); ?>][required]" value="1" <?php checked( ! empty( $bmc_field['required'] ) ); ?> /><span></span></label></td>
							<td>
								<div class="bmc-builder__tools">
									<button type="button" class="button button-small bmc-row-up" title="بالا"><?php bmc_icon( 'keyboard_arrow_up', array( 'size' => 15 ) ); ?></button>
									<button type="button" class="button button-small bmc-row-down" title="پایین"><?php bmc_icon( 'keyboard_arrow_down', array( 'size' => 15 ) ); ?></button>
									<button type="button" class="button button-small bmc-row-adv" title="تنظیمات پیشرفته"><?php bmc_icon( 'tune', array( 'size' => 15 ) ); ?></button>
									<button type="button" class="button button-small button-link-delete bmc-row-del" title="حذف"><?php bmc_icon( 'delete', array( 'size' => 15 ) ); ?></button>
								</div>
							</td>
						</tr>
						<tr class="bmc-builder__adv-row" data-adv-for="<?php echo esc_attr( $bmc_index ); ?>" style="display:none">
							<td colspan="7">
								<div class="bmc-builder__adv">
									<div class="bmc-formgrid">
										<label class="bmc-advfield">راهنمای زیر فیلد
											<input class="bmc-input" type="text" name="bmc_form_fields[<?php echo esc_attr( $bmc_index ); ?>][help]" value="<?php echo esc_attr( wp_strip_all_tags( $bmc_field['help'] ) ); ?>" />
										</label>
										<label class="bmc-advfield">مقدار پیش‌فرض
											<input class="bmc-input" type="text" name="bmc_form_fields[<?php echo esc_attr( $bmc_index ); ?>][default]" value="<?php echo esc_attr( $bmc_field['default'] ); ?>" />
										</label>
										<label class="bmc-advfield">حداقل (نویسه/عدد)
											<input class="bmc-input" type="number" min="0" name="bmc_form_fields[<?php echo esc_attr( $bmc_index ); ?>][min]" value="<?php echo esc_attr( $bmc_field['min'] ); ?>" />
										</label>
										<label class="bmc-advfield">حداکثر (نویسه/عدد)
											<input class="bmc-input" type="number" min="0" name="bmc_form_fields[<?php echo esc_attr( $bmc_index ); ?>][max]" value="<?php echo esc_attr( $bmc_field['max'] ); ?>" />
										</label>
										<label class="bmc-advfield">الگوی اعتبارسنجی (RegExp)
											<input class="bmc-input" type="text" dir="ltr" name="bmc_form_fields[<?php echo esc_attr( $bmc_index ); ?>][pattern]" value="<?php echo esc_attr( $bmc_field['pattern'] ); ?>" />
										</label>
										<label class="bmc-advfield">پیام خطای دلخواه
											<input class="bmc-input" type="text" name="bmc_form_fields[<?php echo esc_attr( $bmc_index ); ?>][message]" value="<?php echo esc_attr( $bmc_field['message'] ); ?>" />
										</label>
										<label class="bmc-advfield">تعداد سطر (متن بلند)
											<input class="bmc-input" type="number" min="2" max="20" name="bmc_form_fields[<?php echo esc_attr( $bmc_index ); ?>][rows]" value="<?php echo esc_attr( $bmc_field['rows'] ); ?>" />
										</label>
										<label class="bmc-advfield">پسوند فایل مجاز
											<input class="bmc-input" type="text" dir="ltr" name="bmc_form_fields[<?php echo esc_attr( $bmc_index ); ?>][accept]" value="<?php echo esc_attr( $bmc_field['accept'] ); ?>" placeholder="jpg,png,pdf" />
										</label>
									</div>
									<label class="bmc-check"><input type="checkbox" name="bmc_form_fields[<?php echo esc_attr( $bmc_index ); ?>][iran_phone]" value="1" <?php checked( ! empty( $bmc_field['iran_phone'] ) ); ?> /><span>شمارهٔ موبایل ایرانی اعتبارسنجی و یکسان‌سازی شود</span></label>
									<label class="bmc-advfield">گزینه‌ها (هر خط: <code dir="ltr">value|برچسب</code>)
										<textarea class="bmc-input bmc-textarea" rows="4" dir="rtl" name="bmc_form_fields[<?php echo esc_attr( $bmc_index ); ?>][options]"><?php echo esc_textarea( $bmc_options_text ); ?></textarea>
									</label>
								</div>
							</td>
						</tr>
						<?php
						$bmc_index++;
					}
					?>
				</tbody>
			</table>

			<div id="bmcFieldTemplate" style="display:none"><?php echo esc_html( wp_json_encode( array( 'types' => $bmc_types, 'widths' => $bmc_widths ) ) ); ?></div>

			<p class="bmc-hint">ترتیب فعلی فیلدها در ورودی پنهان زیر نگه داشته می‌شود و هنگام ذخیره اعمال می‌شود.</p>
			<div id="bmcOrderBox">
				<?php for ( $bmc_i = 0; $bmc_i < $bmc_index; $bmc_i++ ) : ?>
					<input type="hidden" name="bmc_form_order[]" value="<?php echo esc_attr( $bmc_i ); ?>" />
				<?php endfor; ?>
			</div>
		</div>
	</section>

	<section class="bmc-box">
		<div class="bmc-box__head"><h2><?php bmc_icon( 'bolt', array( 'size' => 18 ) ); ?> کارهای پس از ارسال</h2></div>
		<div class="bmc-box__body">
			<div class="bmc-formgrid">
				<label class="bmc-check"><input type="checkbox" name="bmc_form_email_on" value="1" <?php checked( ! empty( $bmc_cfg['email_enabled'] ) ); ?> /><span>ارسال ایمیل به مدیر</span></label>
				<label class="bmc-check"><input type="checkbox" name="bmc_form_webhook_on" value="1" <?php checked( ! empty( $bmc_cfg['webhook_enabled'] ) ); ?> /><span>فراخوانی وب‌هوک</span></label>
				<label class="bmc-check"><input type="checkbox" name="bmc_form_ticket_on" value="1" <?php checked( ! empty( $bmc_cfg['ticket_enabled'] ) ); ?> /><span>ساخت تیکت پشتیبانی (برای کاربران واردشده)</span></label>
			</div>

			<?php BMC_Admin::row( 'گیرنده‌های ایمیل', BMC_Admin::input( 'bmc_form_email_to', $bmc_cfg['email_to'], array( 'dir' => 'ltr', 'placeholder' => 'shop@example.com, support@example.com' ) ), 'چند ایمیل را با کاما جدا کنید. خالی = ایمیل مدیر سایت.' ); ?>
			<?php BMC_Admin::row( 'موضوع ایمیل', BMC_Admin::input( 'bmc_form_email_subject', $bmc_cfg['email_subject'] ), 'برچسب‌ها: <code>{form}</code> <code>{id}</code> <code>{date}</code> <code>{user}</code> و <code>{شناسهٔ فیلد}</code>.' ); ?>
			<?php BMC_Admin::row( 'آدرس وب‌هوک', BMC_Admin::input( 'bmc_form_webhook_url', $bmc_cfg['webhook_url'], array( 'dir' => 'ltr', 'placeholder' => 'https://example.com/hook' ) ), 'با متد POST و بدنهٔ JSON فراخوانی می‌شود (مهلت ۸ ثانیه؛ خطای آن سایت را متوقف نمی‌کند).' ); ?>
			<?php BMC_Admin::row( 'آدرس انتقال پس از ارسال', BMC_Admin::input( 'bmc_form_redirect', $bmc_cfg['redirect_url'], array( 'dir' => 'ltr' ) ), 'خالی = نمایش پیام موفقیت در همان صفحه.' ); ?>

			<div class="bmc-formgrid">
				<?php
				BMC_Admin::row(
					'دستهٔ تیکت',
					BMC_Admin::select( 'bmc_form_ticket_category', $bmc_cfg['ticket_category'], BMC_Forms::ticket_categories() )
				);
				BMC_Admin::row(
					'اولویت تیکت',
					BMC_Admin::select( 'bmc_form_ticket_priority', $bmc_cfg['ticket_priority'], BMC_Forms::ticket_priorities() )
				);
				$bmc_field_choices = array( '' => '— انتخاب نشده —' );

				foreach ( $bmc_cfg['fields'] as $bmc_field ) {
					$bmc_field_choices[ $bmc_field['id'] ] = ( $bmc_field['label'] ? $bmc_field['label'] : $bmc_field['id'] ) . ' (' . $bmc_field['id'] . ')';
				}

				BMC_Admin::row( 'فیلد موضوع تیکت', BMC_Admin::select( 'bmc_form_ticket_subject', $bmc_cfg['ticket_subject_field'], $bmc_field_choices ) );
				BMC_Admin::row( 'فیلد متن تیکت', BMC_Admin::select( 'bmc_form_ticket_body', $bmc_cfg['ticket_body_field'], $bmc_field_choices ) );
				?>
			</div>
		</div>
	</section>

	<section class="bmc-box">
		<div class="bmc-box__head"><h2><?php bmc_icon( 'description', array( 'size' => 18 ) ); ?> نحوهٔ استفاده</h2></div>
		<div class="bmc-box__body">
			<p>در هر صفحه یا نوشته:</p>
			<p><code class="bmc-token" dir="ltr">[bazzarmc_form id="<?php echo esc_attr( $bmc_form_id ? $bmc_form_id : '۱' ); ?>"]</code></p>
			<?php if ( $bmc_form_id && ! empty( $bmc_cfg['slug'] ) ) : ?>
				<p><code class="bmc-token" dir="ltr">[bazzarmc_form slug="<?php echo esc_html( $bmc_cfg['slug'] ); ?>"]</code></p>
			<?php endif; ?>
			<p>در المنتور: ویجت <strong>«فرم سفارشی»</strong> از دستهٔ «BazzarMc — فروشگاه ماینکرافت» را اضافه کنید و همین فرم را انتخاب کنید (یا فرم را داخل همان ویجت بسازید).</p>
		</div>
	</section>

	<?php BMC_Admin::form_close( $bmc_form_id ? 'ذخیرهٔ فرم' : 'ساخت فرم' ); ?>

<?php elseif ( 'entries' === $bmc_view || 'entry' === $bmc_view ) :

	$bmc_form = $bmc_form_id ? BMC_Forms::get( $bmc_form_id ) : null;

	if ( ! $bmc_form ) {
		echo '<div class="bmc-notice bmc-notice--warn">' . bmc_get_icon( 'warning', array( 'size' => 17 ) ) . '<span>فرم پیدا نشد.</span></div>';
		$bmc_view = 'list';
	} else {
		$bmc_counts = BMC_Forms::counts( $bmc_form_id );

		if ( 'entry' === $bmc_view && $bmc_entry_id ) :
			$bmc_entry = BMC_Forms::entry( $bmc_entry_id );

			if ( ! $bmc_entry || (int) $bmc_entry->form_id !== (int) $bmc_form_id ) :
				echo '<div class="bmc-notice bmc-notice--warn">' . bmc_get_icon( 'warning', array( 'size' => 17 ) ) . '<span>ارسال پیدا نشد.</span></div>';
			else :
				BMC_Forms::set_entry_status( (int) $bmc_entry->id, BMC_Forms::STATUS_READ );
				$bmc_user = $bmc_entry->user_id ? get_userdata( (int) $bmc_entry->user_id ) : null;
				?>
				<section class="bmc-box">
					<div class="bmc-box__head">
						<h2><?php bmc_icon( 'inbox', array( 'size' => 18 ) ); ?> ارسال #<?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_entry->id ) ); ?> — <?php echo esc_html( $bmc_form['title'] ); ?></h2>
						<div class="bmc-inline">
							<a class="button" href="<?php echo esc_url( add_query_arg( array( 'view' => 'entries', 'form' => $bmc_form_id ), $bmc_base_url ) ); ?>"><?php bmc_icon( 'keyboard_arrow_right', array( 'size' => 16 ) ); ?> بازگشت</a>
							<button type="button" class="button bmc-action" data-do="delete_entry" data-id="<?php echo esc_attr( (int) $bmc_entry->id ); ?>" data-confirm="1" data-reload="1"><?php bmc_icon( 'delete', array( 'size' => 15 ) ); ?> حذف</button>
						</div>
					</div>
					<div class="bmc-box__body">
						<table class="bmc-table bmc-table--full">
							<tbody>
								<?php foreach ( $bmc_form['fields'] as $bmc_field ) : ?>
									<?php if ( in_array( $bmc_field['type'], array( 'html', 'hidden' ), true ) ) : ?>
										<?php continue; ?>
									<?php endif; ?>
									<tr>
										<th style="width:220px"><?php echo esc_html( $bmc_field['label'] ? $bmc_field['label'] : $bmc_field['id'] ); ?></th>
										<td>
											<?php
											$bmc_value = isset( $bmc_entry->data[ $bmc_field['id'] ] ) ? $bmc_entry->data[ $bmc_field['id'] ] : '';

											if ( 'file' === $bmc_field['type'] && isset( $bmc_entry->files[ $bmc_field['id'] ] ) ) {
												$bmc_value = $bmc_entry->files[ $bmc_field['id'] ]['url'];
											}

											echo wp_kses_post( BMC_Forms::display_value( $bmc_form, $bmc_field['id'], $bmc_value ) );
											?>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>

						<div class="bmc-entry-meta">
							<span class="bmc-dim"><?php bmc_icon( 'calendar_month', array( 'size' => 14 ) ); ?> <?php echo esc_html( BMC_Jalali::format( $bmc_entry->created_at ) ); ?></span>
							<span class="bmc-dim"><?php bmc_icon( 'person', array( 'size' => 14 ) ); ?> <?php echo $bmc_user ? esc_html( $bmc_user->display_name ) . ' (#' . (int) $bmc_entry->user_id . ')' : 'مهمان'; ?></span>
							<span class="bmc-dim" dir="ltr"><?php bmc_icon( 'fingerprint', array( 'size' => 14 ) ); ?> IP: <?php echo esc_html( substr( (string) $bmc_entry->ip_hash, 0, 12 ) ); ?>…</span>
							<?php if ( $bmc_entry->referer ) : ?>
								<span class="bmc-dim"><?php bmc_icon( 'link', array( 'size' => 14 ) ); ?> از: <code dir="ltr"><?php echo esc_html( $bmc_entry->referer ); ?></code></span>
							<?php endif; ?>
							<span class="bmc-pill <?php echo BMC_Forms::STATUS_NEW === $bmc_entry->status ? 'is-info' : 'is-done'; ?>"><?php echo esc_html( isset( $bmc_statuses[ $bmc_entry->status ] ) ? $bmc_statuses[ $bmc_entry->status ] : $bmc_entry->status ); ?></span>
						</div>
					</div>
				</section>
			<?php endif; ?>

		<?php else : ?>

			<section class="bmc-box">
				<div class="bmc-box__head">
					<h2><?php bmc_icon( 'inbox', array( 'size' => 18 ) ); ?> ارسال‌های «<?php echo esc_html( $bmc_form['title'] ); ?>»</h2>
					<div class="bmc-inline">
						<a class="button" href="<?php echo esc_url( $bmc_base_url ); ?>"><?php bmc_icon( 'keyboard_arrow_right', array( 'size' => 16 ) ); ?> فرم‌ها</a>
						<a class="button" href="<?php echo esc_url( add_query_arg( array( 'view' => 'edit', 'form' => $bmc_form_id ), $bmc_base_url ) ); ?>"><?php bmc_icon( 'tune', array( 'size' => 15 ) ); ?> ویرایش فرم</a>
						<a class="button" href="<?php echo esc_url( wp_nonce_url( add_query_arg( array( 'bmc_export' => 'forms', 'bmc_form' => $bmc_form_id ), admin_url( 'admin.php' ) ), 'bmc_export', 'bmc_nonce' ) ); ?>"><?php bmc_icon( 'download', array( 'size' => 15 ) ); ?> خروجی CSV</a>
						<button type="button" class="button button-link-delete bmc-action" data-do="clear_entries" data-id="<?php echo esc_attr( $bmc_form_id ); ?>" data-confirm="1" data-reload="1">حذف همهٔ ارسال‌ها</button>
					</div>
				</div>

				<div class="bmc-box__body">
					<p>
						مجموع: <strong><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_counts['total'] ) ); ?></strong>
						&nbsp;|&nbsp; خوانده‌نشده: <span class="bmc-pill is-info"><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_counts['new'] ) ); ?></span>
						&nbsp; خوانده‌شده: <span class="bmc-pill is-done"><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_counts['read'] ) ); ?></span>
						&nbsp; بایگانی: <span class="bmc-pill is-cancelled"><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_counts['archive'] ) ); ?></span>
						&nbsp; هرزنامه: <span class="bmc-pill is-expired"><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_counts['spam'] ) ); ?></span>
					</p>

					<?php
					$bmc_status_filter = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
					$bmc_search        = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
					$bmc_paged         = isset( $_GET['paged'] ) ? max( 1, absint( $_GET['paged'] ) ) : 1; // phpcs:ignore WordPress.Security.NonceVerification
					$bmc_result        = BMC_Forms::entries_query( $bmc_form_id, array( 'per_page' => 20, 'paged' => $bmc_paged, 'status' => $bmc_status_filter, 'search' => $bmc_search ) );
					?>

					<form method="get" class="bmc-filterbar">
						<input type="hidden" name="page" value="bazzarmc" />
						<input type="hidden" name="tab" value="forms" />
						<input type="hidden" name="view" value="entries" />
						<input type="hidden" name="form" value="<?php echo esc_attr( $bmc_form_id ); ?>" />
						<?php echo BMC_Admin::select( 'status', $bmc_status_filter, array_merge( array( '' => 'همهٔ وضعیت‌ها' ), $bmc_statuses ) ); ?>
						<input class="bmc-input" type="text" name="s" value="<?php echo esc_attr( $bmc_search ); ?>" placeholder="جست‌وجو در مقدارهای ارسالی" />
						<button type="submit" class="button"><?php bmc_icon( 'search', array( 'size' => 15 ) ); ?> اعمال</button>
					</form>

					<?php if ( ! $bmc_result['items'] ) : ?>
						<p class="bmc-empty">هنوز ارسالی ثبت نشده است.</p>
					<?php else : ?>
						<table class="bmc-table bmc-table--full">
							<thead><tr><th style="width:70px">#</th><th style="width:170px">تاریخ</th><th>خلاصه</th><th style="width:120px">کاربر</th><th style="width:110px">وضعیت</th><th style="width:210px">عملیات</th></tr></thead>
							<tbody>
								<?php foreach ( $bmc_result['items'] as $bmc_row ) : ?>
									<?php
									$bmc_data    = json_decode( (string) $bmc_row->data, true );
									$bmc_data    = is_array( $bmc_data ) ? $bmc_data : array();
									$bmc_preview = array();

									foreach ( $bmc_form['fields'] as $bmc_field ) {
										if ( in_array( $bmc_field['type'], array( 'html', 'hidden' ), true ) || ! isset( $bmc_data[ $bmc_field['id'] ] ) || '' === (string) ( is_array( $bmc_data[ $bmc_field['id'] ] ) ? implode( '', $bmc_data[ $bmc_field['id'] ] ) : $bmc_data[ $bmc_field['id'] ] ) ) {
											continue;
										}

										$bmc_preview[] = ( $bmc_field['label'] ? $bmc_field['label'] : $bmc_field['id'] ) . ': ' . wp_strip_all_tags( BMC_Forms::display_value( $bmc_form, $bmc_field['id'], $bmc_data[ $bmc_field['id'] ] ) );

										if ( count( $bmc_preview ) >= 3 ) {
											break;
										}
									}
									?>
									<tr class="<?php echo BMC_Forms::STATUS_NEW === $bmc_row->status ? 'is-unread' : ''; ?>">
										<td><?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_row->id ) ); ?></td>
										<td><?php echo esc_html( BMC_Jalali::format( $bmc_row->created_at ) ); ?></td>
										<td><?php echo esc_html( implode( ' — ', $bmc_preview ) ); ?></td>
										<td><?php echo $bmc_row->user_id ? '#' . esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_row->user_id ) ) : 'مهمان'; ?></td>
										<td><span class="bmc-pill <?php echo BMC_Forms::STATUS_NEW === $bmc_row->status ? 'is-info' : 'is-done'; ?>"><?php echo esc_html( isset( $bmc_statuses[ $bmc_row->status ] ) ? $bmc_statuses[ $bmc_row->status ] : $bmc_row->status ); ?></span></td>
										<td>
											<div class="bmc-inline">
												<a class="button button-small" href="<?php echo esc_url( add_query_arg( array( 'view' => 'entry', 'form' => $bmc_form_id, 'entry' => (int) $bmc_row->id ), $bmc_base_url ) ); ?>">مشاهده</a>
												<button type="button" class="button button-small bmc-action" data-do="entry_status" data-id="<?php echo esc_attr( (int) $bmc_row->id ); ?>" data-status="<?php echo BMC_Forms::STATUS_NEW === $bmc_row->status ? esc_attr( BMC_Forms::STATUS_ARCHIVE ) : esc_attr( BMC_Forms::STATUS_NEW ); ?>" data-reload="1"><?php echo BMC_Forms::STATUS_NEW === $bmc_row->status ? 'بایگانی' : 'خوانده‌نشده'; ?></button>
												<button type="button" class="button button-small bmc-action" data-do="entry_status" data-id="<?php echo esc_attr( (int) $bmc_row->id ); ?>" data-status="spam" data-reload="1">هرزنامه</button>
												<button type="button" class="button button-small button-link-delete bmc-action" data-do="delete_entry" data-id="<?php echo esc_attr( (int) $bmc_row->id ); ?>" data-confirm="1" data-remove-row="1">حذف</button>
											</div>
										</td>
									</tr>
								<?php endforeach; ?>
							</tbody>
						</table>

						<?php if ( $bmc_result['pages'] > 1 ) : ?>
							<div class="bmc-pager">
								<?php for ( $bmc_p = 1; $bmc_p <= $bmc_result['pages']; $bmc_p++ ) : ?>
									<a class="button button-small <?php echo $bmc_p === (int) $bmc_result['paged'] ? 'button-primary' : ''; ?>" href="<?php echo esc_url( add_query_arg( array( 'view' => 'entries', 'form' => $bmc_form_id, 'status' => $bmc_status_filter, 's' => $bmc_search, 'paged' => $bmc_p ), $bmc_base_url ) ); ?>"><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_p ) ); ?></a>
								<?php endfor; ?>
							</div>
						<?php endif; ?>
					<?php endif; ?>
				</div>
			</section>

		<?php endif; ?>
	<?php } ?>

<?php endif; ?>

<?php if ( 'list' === $bmc_view ) : ?>

	<section class="bmc-box">
		<div class="bmc-box__head">
			<h2><?php bmc_icon( 'dynamic_form', array( 'size' => 18 ) ); ?> فرم‌های سفارشی</h2>
			<div class="bmc-inline">
				<a class="button button-primary" href="<?php echo esc_url( add_query_arg( array( 'view' => 'edit', 'form' => 0 ), $bmc_base_url ) ); ?>"><?php bmc_icon( 'add', array( 'size' => 16 ) ); ?> ساخت فرم جدید</a>
			</div>
		</div>

		<div class="bmc-box__body">
			<p class="bmc-hint">فرم دلخواه خود را بسازید و با شورت‌کد یا ویجت المنتور «فرم سفارشی» هر جای سایت نمایش دهید. ارسال‌ها در سایت ذخیره می‌شوند و می‌توانید خروجی CSV بگیرید، ایمیل دریافت کنید، وب‌هوک بزنید یا از همان ارسال یک تیکت پشتیبانی بسازید.</p>

			<?php $bmc_forms = BMC_Forms::all(); ?>

			<?php if ( ! $bmc_forms ) : ?>
				<p class="bmc-empty">هنوز فرمی ساخته نشده است.</p>
			<?php else : ?>
				<table class="bmc-table bmc-table--full">
					<thead><tr><th>فرم</th><th style="width:130px">فیلدها</th><th style="width:150px">ارسال‌ها</th><th style="width:110px">وضعیت</th><th style="width:270px">شورت‌کد و عملیات</th></tr></thead>
					<tbody>
						<?php foreach ( $bmc_forms as $bmc_row ) : ?>
							<?php
							$bmc_cfg    = BMC_Forms::hydrate( $bmc_row );
							$bmc_counts = BMC_Forms::counts( (int) $bmc_row->id );
							$bmc_code   = '[bazzarmc_form id="' . (int) $bmc_row->id . '"]';
							?>
							<tr>
								<td>
									<strong><?php echo esc_html( $bmc_row->title ); ?></strong>
									<div class="bmc-dim" dir="ltr"><code><?php echo esc_html( $bmc_row->slug ); ?></code></div>
								</td>
								<td><?php echo esc_html( BMC_Helpers::to_persian_digits( count( $bmc_cfg['fields'] ) ) ); ?></td>
								<td>
									<a href="<?php echo esc_url( add_query_arg( array( 'view' => 'entries', 'form' => (int) $bmc_row->id ), $bmc_base_url ) ); ?>">
										<?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_counts['total'] ) ); ?> ارسال
									</a>
									<?php if ( $bmc_counts['new'] ) : ?>
										<span class="bmc-pill is-info"><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_counts['new'] ) ); ?> جدید</span>
									<?php endif; ?>
								</td>
								<td>
									<span class="bmc-pill <?php echo 'active' === $bmc_row->status ? 'is-done' : 'is-cancelled'; ?>">
										<?php echo 'active' === $bmc_row->status ? 'فعال' : ( 'inline' === $bmc_row->status ? 'ویجت المنتور' : 'غیرفعال' ); ?>
									</span>
								</td>
								<td>
									<div class="bmc-inline">
										<code class="bmc-token bmc-token--sm bmc-copy" data-copy="<?php echo esc_attr( $bmc_code ); ?>" dir="ltr" title="کلیک = کپی"><?php echo esc_html( $bmc_code ); ?></code>
										<a class="button button-small" href="<?php echo esc_url( add_query_arg( array( 'view' => 'edit', 'form' => (int) $bmc_row->id ), $bmc_base_url ) ); ?>">ویرایش</a>
										<button type="button" class="button button-small bmc-action" data-do="duplicate_form" data-id="<?php echo esc_attr( (int) $bmc_row->id ); ?>" data-reload="1">کپی</button>
										<button type="button" class="button button-small button-link-delete bmc-action" data-do="delete_form" data-id="<?php echo esc_attr( (int) $bmc_row->id ); ?>" data-confirm="1" data-reload="1">حذف</button>
									</div>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
	</section>

	<?php BMC_Admin::form_open( 'forms' ); ?>
	<input type="hidden" name="bmc_form_settings" value="1" />

	<section class="bmc-box">
		<div class="bmc-box__head"><h2><?php bmc_icon( 'tune', array( 'size' => 18 ) ); ?> تنظیمات عمومی فرم‌ها</h2></div>
		<div class="bmc-box__body">
			<?php BMC_Admin::row( 'سامانهٔ فرم‌ها', BMC_Admin::toggle( 'forms_enabled', $settings['forms_enabled'], 'فرم‌های سفارشی فعال باشند' ), 'اگر خاموش شود، شورت‌کد و ویجت فرم چیزی نمایش نمی‌دهند و هیچ خطایی رخ نمی‌دهد.' ); ?>
			<?php BMC_Admin::row( 'حداقل فاصلهٔ دو ارسال (ثانیه)', BMC_Admin::input( 'forms_rate_limit', $settings['forms_rate_limit'], array( 'type' => 'number', 'min' => 5, 'max' => 3600 ) ) ); ?>
			<?php BMC_Admin::row( 'سقف ارسال روزانهٔ هر IP', BMC_Admin::input( 'forms_max_per_day', $settings['forms_max_per_day'], array( 'type' => 'number', 'min' => 0, 'max' => 1000 ) ), 'صفر = بدون محدودیت.' ); ?>
			<?php BMC_Admin::row( 'تلهٔ ضدربات', BMC_Admin::toggle( 'forms_honeypot', $settings['forms_honeypot'], 'فیلد پنهان برای شناسایی ربات‌ها' ) ); ?>
			<?php BMC_Admin::row( 'اجازهٔ بارگذاری فایل', BMC_Admin::toggle( 'forms_allow_files', $settings['forms_allow_files'], 'فرم‌ها بتوانند فایل دریافت کنند' ), 'فایل‌ها در <code dir="ltr">wp-content/uploads/bazzarmc-forms</code> ذخیره می‌شوند و اجرای اسکریپت در آن پوشه غیرفعال است.' ); ?>
			<?php BMC_Admin::row( 'حداکثر حجم فایل (مگابایت)', BMC_Admin::input( 'forms_max_file_size', $settings['forms_max_file_size'], array( 'type' => 'number', 'min' => 1, 'max' => 25 ) ) ); ?>
			<?php BMC_Admin::row( 'ایمیل اطلاع‌رسانی عمومی', BMC_Admin::input( 'forms_notice_email', $settings['forms_notice_email'], array( 'dir' => 'ltr', 'placeholder' => 'shop@example.com' ) ), 'برای فرم‌هایی که ایمیل اختصاصی ندارند استفاده می‌شود.' ); ?>
			<?php BMC_Admin::row( 'پیام موفقیت پیش‌فرض', BMC_Admin::textarea( 'forms_success_message', $settings['forms_success_message'], 2 ) ); ?>
			<?php BMC_Admin::row( 'پیام خطای پیش‌فرض', BMC_Admin::textarea( 'forms_error_message', $settings['forms_error_message'], 2 ) ); ?>
		</div>
	</section>

	<?php BMC_Admin::form_close( 'ذخیرهٔ تنظیمات فرم‌ها' ); ?>

<?php endif; ?>
