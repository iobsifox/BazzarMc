<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$field_labels = array(
	'first_name' => 'نام',
	'last_name'  => 'نام خانوادگی',
	'mobile'     => 'شمارهٔ موبایل',
	'email'      => 'ایمیل',
	'address'    => 'آدرس',
	'city'       => 'شهر',
	'state'      => 'استان',
	'postcode'   => 'کد پستی',
	'country'    => 'کشور',
	'company'    => 'شرکت',
	'notes'      => 'توضیحات سفارش',
);

BMC_Admin::form_open( 'checkout' );

BMC_Admin::section_open( 'حالت چک‌اوت', 'در حالت اختصاصی، فرم خرید ووکامرس خاموش می‌شود و فرم طراحی‌شدهٔ افزونه جای آن را می‌گیرد؛ اما سبد خرید و درگاه‌های پرداخت همان ووکامرس هستند.' );

BMC_Admin::row(
	'فرم خرید',
	BMC_Admin::select(
		'checkout_mode',
		$settings['checkout_mode'],
		array(
			'custom' => 'چک‌اوت اختصاصی BazzarMc (پیشنهادی)',
			'wc'     => 'چک‌اوت استاندارد ووکامرس',
		)
	),
	'حتی در حالت اختصاصی، ثبت سفارش از طریق هستهٔ ووکامرس انجام می‌شود؛ بنابراین زرین‌پال، IDPay، سامان و بقیهٔ درگاه‌ها بدون تغییر کار می‌کنند.'
);

BMC_Admin::row(
	'پوسته',
	BMC_Admin::select(
		'checkout_theme',
		$settings['checkout_theme'],
		array(
			'dark'  => 'تیره (گیمینگ)',
			'light' => 'روشن',
		)
	)
);

BMC_Admin::row( 'رنگ تأکید', '<input type="text" name="checkout_accent" value="' . esc_attr( $settings['checkout_accent'] ) . '" class="bmc-color" />' );

BMC_Admin::row( 'بارگذاری فونت وزیرمتن از CDN', BMC_Admin::toggle( 'font_cdn', $settings['font_cdn'], 'فونت فارسی وزیرمتن از jsDelivr بارگذاری شود' ), 'اگر قالب شما فونت فارسی دارد، می‌توانید خاموش کنید.', 'advanced' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'گیتِ اتصال اکانت', 'اگر اکانت متصل نباشد، کاربر اجازهٔ ورود به صفحهٔ خرید را ندارد و پیام «هنوز متصل نیستید» نمایش داده می‌شود.' );

BMC_Admin::row( 'فعال‌سازی گیت', BMC_Admin::toggle( 'gate_enabled', $settings['gate_enabled'], 'بدون اتصال اکانت، امکان خرید نباشد' ) );
BMC_Admin::row( 'فقط برای محصولات ماینکرافتی', BMC_Admin::toggle( 'gate_only_synced', $settings['gate_only_synced'], 'گیت فقط وقتی فعال شود که محصول همگام‌شده در سبد باشد' ), 'اگر خاموش کنید، همهٔ خریدها نیازمند اتصال می‌شوند.' );
BMC_Admin::row( 'کنترل صفحهٔ محصول', BMC_Admin::toggle( 'gate_product_page', $settings['gate_product_page'], 'در صفحهٔ محصول همگام‌شده، دکمهٔ خرید برای کاربران متصل‌نشده غیرفعال شود' ) );
BMC_Admin::row( 'نمایش کد تخفیف', BMC_Admin::toggle( 'checkout_show_coupon', $settings['checkout_show_coupon'], 'کادر کد تخفیف در چک‌اوت نمایش داده شود' ) );
BMC_Admin::row( 'خرید هدیه', BMC_Admin::toggle( 'checkout_gift_allowed', $settings['checkout_gift_allowed'], 'کاربر بتواند برای بازیکن دیگری خرید کند' ) );

BMC_Admin::section_close();

BMC_Admin::section_open( 'سبد خرید و صفحهٔ پرداخت (جدا از هم)', 'صفحهٔ سبد خرید فقط سبد را نشان می‌دهد و صفحهٔ پرداخت فقط فرم خرید و خلاصهٔ سفارش را. دکمهٔ پرداخت کاربر را به صفحهٔ پرداخت می‌برد.' );

BMC_Admin::row(
	'صفحهٔ سبد خرید',
	BMC_Admin::select(
		'cart_mode',
		$settings['cart_mode'],
		array(
			'custom' => 'سبد اختصاصی BazzarMc (پیشنهادی)',
			'wc'     => 'سبد پیش‌فرض ووکامرس (فقط گیت اعمال شود)',
		)
	),
	'در حالت اختصاصی، صفحهٔ سبد ووکامرس با سبد فارسی افزونه جایگزین می‌شود (شورت‌کد <code>[bazzarmc_cart]</code> هم همین خروجی را دارد). پرداخت در صفحهٔ جداگانهٔ خودش انجام می‌شود.'
);

BMC_Admin::row(
	'ادغام چک‌اوت داخل صفحهٔ سبد',
	BMC_Admin::toggle( 'cart_inline_checkout', $settings['cart_inline_checkout'], 'فرم پرداخت زیر سبد خرید هم نمایش داده شود' ),
	'پیش‌فرض خاموش است تا سبد خرید و صفحهٔ پرداخت کاملاً از هم جدا بمانند. اگر روشن کنید، دکمهٔ «ادامه و تکمیل پرداخت» به بخش چک‌اوت در همان صفحه می‌رود.',
	'advanced'
);


BMC_Admin::row( 'نوار مرحله‌ها', BMC_Admin::toggle( 'cart_steps_nav', $settings['cart_steps_nav'], 'نمایش «سبد خرید ← پرداخت ← تکمیل سفارش» بالای هر دو صفحه' ) );
BMC_Admin::row( 'لینک بازگشت به سبد', BMC_Admin::toggle( 'checkout_back_to_cart', $settings['checkout_back_to_cart'], 'در صفحهٔ پرداخت لینک «بازگشت به سبد خرید» نمایش داده شود' ) );
BMC_Admin::row( 'متن دکمهٔ پرداخت در سبد', BMC_Admin::input( 'cart_button_text', $settings['cart_button_text'] ) );
BMC_Admin::row( 'متن دکمهٔ ثبت سفارش', BMC_Admin::input( 'checkout_submit_text', $settings['checkout_submit_text'] ) );

BMC_Admin::row( 'گیت دکمهٔ پرداخت', BMC_Admin::toggle( 'cart_gate', $settings['cart_gate'], 'تا اتصال اکانت، دکمهٔ پرداخت در سبد غیرفعال بماند' ), 'به‌جای دکمه، پیام «هنوز متصل نیستید» + دکمهٔ «اتصال اکانت ماینکرافت» نمایش داده می‌شود.' );
BMC_Admin::row( 'پنهان‌کردن افزودن به سبد', BMC_Admin::toggle( 'gate_hide_add_to_cart', $settings['gate_hide_add_to_cart'], 'برای کاربران متصل‌نشده، دکمهٔ «افزودن به سبد» در صفحهٔ محصول پنهان شود' ), 'کاربر پیش از افزودن به سبد متوجه می‌شود که باید اکانتش را متصل کند.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'فارسی‌سازی فیلدها', 'برچسب و placeholder همهٔ فیلدهای ووکامرس (آدرس، استان، شهر، کد پستی، تلفن و…) به فارسی ترجمه می‌شوند.', 'advanced' );

BMC_Admin::row( 'ترجمهٔ فیلدها', BMC_Admin::toggle( 'persian_fields', $settings['persian_fields'], 'برچسب و placeholder فیلدهای چک‌اوت فارسی شود' ) );
BMC_Admin::row( 'نام کشورها به فارسی', BMC_Admin::toggle( 'persian_countries', $settings['persian_countries'], 'لیست کشورها فارسی نمایش داده شود' ), 'لیست استان‌های ایران همیشه کامل و فارسی است.' );
BMC_Admin::row( 'اعداد فارسی', BMC_Admin::toggle( 'persian_digits', $settings['persian_digits'], 'اعداد قیمت و جمع کل با رقم فارسی نمایش داده شوند' ), 'فقط نمایش؛ مقدار ارسالی به درگاه پرداخت دست‌نخورده می‌ماند.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'فرم‌ساز چک‌اوت', 'کارت‌ها و فیلدهای فرم خرید را انتخاب کنید، ترتیب و عنوان و برچسب و عرض هر فیلد را بچینید. مقدارهای خالی یعنی «همان پیش‌فرض ووکامرس/افزونه».', 'advanced' );

$bmc_card_labels = array(
	'mc'      => 'کارت اکانت ماینکرافت',
	'buyer'   => 'کارت اطلاعات خریدار',
	'payment' => 'کارت روش پرداخت',
	'extra'   => 'کارت اطلاعات تکمیلی',
);
$bmc_cards_on    = (array) $settings['checkout_cards'];
$bmc_card_order  = (array) $settings['checkout_card_order'];
$bmc_titles      = (array) $settings['checkout_titles'];
$bmc_layout      = (array) $settings['checkout_layout'];
$bmc_cf_list     = class_exists( 'BMC_Checkout_Fields' ) ? BMC_Checkout_Fields::custom_fields() : array();
$bmc_cf_meta     = class_exists( 'BMC_Checkout_Fields' ) ? BMC_Checkout_Fields::builder_meta() : array();
$bmc_cf_types    = isset( $bmc_cf_meta['types'] ) ? (array) $bmc_cf_meta['types'] : array();
$bmc_cf_sections = isset( $bmc_cf_meta['sections'] ) ? (array) $bmc_cf_meta['sections'] : array();
$bmc_cf_audience = isset( $bmc_cf_meta['audiences'] ) ? (array) $bmc_cf_meta['audiences'] : array();
$bmc_cf_conds    = isset( $bmc_cf_meta['conditions'] ) ? (array) $bmc_cf_meta['conditions'] : array();

BMC_Admin::row(
	'ستون‌بندی فیلدها',
	BMC_Admin::select( 'checkout_columns', $settings['checkout_columns'], array( '2' => 'دو ستونه (پیشنهادی)', '1' => 'یک ستونه (تمام فیلدها تمام‌عرض)' ) )
);

echo '<table class="bmc-table bmc-table--full bmc-layout-table">';
echo '<thead><tr><th>کارت</th><th style="width:70px">نمایش</th><th style="width:90px">ترتیب</th><th>عنوان کارت</th></tr></thead><tbody>';

foreach ( $bmc_card_labels as $bmc_card_key => $bmc_card_label ) {
	printf(
		'<tr><td>%1$s</td><td><label class="bmc-check"><input type="checkbox" name="checkout_card_show[%2$s]" value="1" %3$s /><span></span></label></td>'
		. '<td><input class="bmc-input bmc-input--num" type="number" min="1" max="9" name="checkout_card_order[%2$s]" value="%4$d" /></td>'
		. '<td><input class="bmc-input" type="text" name="checkout_titles[%2$s]" value="%5$s" placeholder="%1$s" /></td></tr>',
		esc_html( $bmc_card_label ),
		esc_attr( $bmc_card_key ),
		checked( in_array( $bmc_card_key, $bmc_cards_on, true ), true, false ),
		isset( $bmc_card_order[ $bmc_card_key ] ) ? (int) $bmc_card_order[ $bmc_card_key ] : 1,
		esc_attr( isset( $bmc_titles[ $bmc_card_key ] ) ? $bmc_titles[ $bmc_card_key ] : '' )
	);
}

printf(
	'<tr><td>کارت خلاصهٔ سفارش (همیشه در ستون کناری)</td><td>—</td><td>—</td><td><input class="bmc-input" type="text" name="checkout_titles[summary]" value="%s" placeholder="خلاصهٔ سفارش" /></td></tr>',
	esc_attr( isset( $bmc_titles['summary'] ) ? $bmc_titles['summary'] : '' )
);

echo '</tbody></table>';

$bmc_wc_fields = array(
	'billing_first_name'  => array( 'label' => 'نام', 'group' => 'اطلاعات خریدار' ),
	'billing_last_name'   => array( 'label' => 'نام خانوادگی', 'group' => 'اطلاعات خریدار' ),
	'billing_phone'       => array( 'label' => 'شمارهٔ موبایل', 'group' => 'اطلاعات خریدار' ),
	'billing_email'       => array( 'label' => 'ایمیل', 'group' => 'اطلاعات خریدار' ),
	'billing_company'     => array( 'label' => 'شرکت', 'group' => 'اطلاعات خریدار' ),
	'billing_country'     => array( 'label' => 'کشور', 'group' => 'اطلاعات خریدار' ),
	'billing_state'       => array( 'label' => 'استان', 'group' => 'اطلاعات خریدار' ),
	'billing_city'        => array( 'label' => 'شهر', 'group' => 'اطلاعات خریدار' ),
	'billing_postcode'    => array( 'label' => 'کد پستی', 'group' => 'اطلاعات خریدار' ),
	'billing_address_1'   => array( 'label' => 'آدرس', 'group' => 'اطلاعات خریدار' ),
	'billing_address_2'   => array( 'label' => 'آدرس (ادامه)', 'group' => 'اطلاعات خریدار' ),
	'order_comments'      => array( 'label' => 'توضیحات سفارش', 'group' => 'سفارش' ),
	'shipping_first_name' => array( 'label' => 'نام گیرنده', 'group' => 'ارسال' ),
	'shipping_last_name'  => array( 'label' => 'نام خانوادگی گیرنده', 'group' => 'ارسال' ),
	'shipping_phone'      => array( 'label' => 'تلفن گیرنده', 'group' => 'ارسال' ),
	'shipping_country'    => array( 'label' => 'کشور مقصد', 'group' => 'ارسال' ),
	'shipping_state'      => array( 'label' => 'استان مقصد', 'group' => 'ارسال' ),
	'shipping_city'       => array( 'label' => 'شهر مقصد', 'group' => 'ارسال' ),
	'shipping_postcode'   => array( 'label' => 'کد پستی مقصد', 'group' => 'ارسال' ),
	'shipping_address_1'  => array( 'label' => 'آدرس مقصد', 'group' => 'ارسال' ),
	'shipping_address_2'  => array( 'label' => 'آدرس مقصد (ادامه)', 'group' => 'ارسال' ),
);

$bmc_width_choices = array(
	0   => 'خودکار',
	100 => 'تمام عرض',
	75  => 'سه‌چهارم',
	66  => 'دو‌سوم',
	50  => 'نصف',
	33  => 'یک‌سوم',
	25  => 'یک‌چهارم',
);

$bmc_required_choices = array(
	-1 => 'پیش‌فرض',
	1  => 'الزامی',
	0  => 'اختیاری',
);

$bmc_state_choices  = array(
	-1 => 'پیش‌فرض',
	1  => 'نمایش',
	0  => 'پنهان',
);

$bmc_section_choices = array( '' => 'پیش‌فرض' );

foreach ( $bmc_cf_sections as $bmc_section_key => $bmc_section_label ) {
	$bmc_section_choices[ $bmc_section_key ] = $bmc_section_label;
}

echo '<h3 class="bmc-subhead">فیلدهای آمادهٔ فرم خرید</h3>';
echo '<p class="bmc-hint">برای هر فیلد می‌توانید نمایش/پنهان، کارت مقصد، ترتیب، برچسب، placeholder، راهنما، عرض و الزامی‌بودن را تعیین کنید. «پیش‌فرض» یعنی همان رفتار قبلی افزونه/ووکامرس.</p>';

echo '<table class="bmc-table bmc-table--full bmc-layout-table">';
echo '<thead><tr><th>فیلد</th><th style="width:96px">نمایش</th><th style="width:170px">کارت / بخش</th><th style="width:74px">ترتیب</th><th>برچسب و راهنما</th><th>placeholder</th><th style="width:104px">عرض</th><th style="width:96px">الزامی</th></tr></thead><tbody>';

foreach ( $bmc_wc_fields as $bmc_field_key => $bmc_field_meta ) {
	$bmc_conf = isset( $bmc_layout[ $bmc_field_key ] ) && is_array( $bmc_layout[ $bmc_field_key ] ) ? $bmc_layout[ $bmc_field_key ] : array();

	printf(
		'<tr><td><strong>%1$s</strong><div class="bmc-dim">%5$s · <code dir="ltr">%2$s</code></div></td>'
		. '<td>%6$s</td><td>%7$s</td>'
		. '<td><input class="bmc-input bmc-input--num" type="number" min="0" max="999" name="checkout_layout[%2$s][order]" value="%3$d" /></td>'
		. '<td><input class="bmc-input" type="text" name="checkout_layout[%2$s][label]" value="%4$s" placeholder="%1$s" />'
		. '<input class="bmc-input bmc-builder__sub" type="text" name="checkout_layout[%2$s][help]" value="%8$s" placeholder="راهنمای زیر فیلد" /></td>'
		. '<td><input class="bmc-input" type="text" name="checkout_layout[%2$s][placeholder]" value="%9$s" /></td>'
		. '<td>%10$s</td><td>%11$s</td></tr>',
		esc_html( $bmc_field_meta['label'] ),
		esc_attr( $bmc_field_key ),
		isset( $bmc_conf['order'] ) ? (int) $bmc_conf['order'] : 0,
		esc_attr( isset( $bmc_conf['label'] ) ? $bmc_conf['label'] : '' ),
		esc_html( $bmc_field_meta['group'] ),
		BMC_Admin::select( 'checkout_layout[' . $bmc_field_key . '][enabled]', isset( $bmc_conf['enabled'] ) ? (int) $bmc_conf['enabled'] : -1, $bmc_state_choices ),
		BMC_Admin::select( 'checkout_layout[' . $bmc_field_key . '][section]', isset( $bmc_conf['section'] ) ? $bmc_conf['section'] : '', $bmc_section_choices ),
		esc_attr( isset( $bmc_conf['help'] ) ? $bmc_conf['help'] : '' ),
		esc_attr( isset( $bmc_conf['placeholder'] ) ? $bmc_conf['placeholder'] : '' ),
		BMC_Admin::select( 'checkout_layout[' . $bmc_field_key . '][width]', isset( $bmc_conf['width'] ) ? (int) $bmc_conf['width'] : 0, $bmc_width_choices ),
		BMC_Admin::select( 'checkout_layout[' . $bmc_field_key . '][required]', isset( $bmc_conf['required'] ) ? (int) $bmc_conf['required'] : -1, $bmc_required_choices )
	);
}

echo '</tbody></table>';

BMC_Admin::section_close();

BMC_Admin::section_open( 'فیلدهای دلخواه فرم خرید', 'هر فیلدی که مشتری باید هنگام تصفیهٔ حساب پر کند بسازید: کد ملی، نام کاربری دیسکورد، سرور مقصد، فیش واریز، پرسشنامهٔ کوتاه و… . مقدارها اعتبارسنجی شده و در سفارش (پیشخوان، ایمیل و صفحهٔ تشکر) ذخیره و نمایش داده می‌شوند.' );

BMC_Admin::row(
	'فعال‌سازی فیلدهای دلخواه',
	BMC_Admin::toggle( 'checkout_custom_enabled', $settings['checkout_custom_enabled'], 'فیلدهای دلخواه در فرم خرید نمایش داده شوند' ),
	'با خاموش‌کردن این کلید، همهٔ فیلدهای دلخواه موقتاً از فرم حذف می‌شوند اما تنظیماتشان پاک نمی‌شود.'
);

echo '<div class="bmc-builder__bar">';
echo '<span class="bmc-dim">تعداد فیلدها: <strong id="bmcCheckoutCount">' . esc_html( BMC_Helpers::to_persian_digits( count( $bmc_cf_list ) ) ) . '</strong> (حداکثر ۴۰)</span>';
echo '<button type="button" class="button button-primary" id="bmcAddCheckoutField">' . ( function_exists( 'bmc_icon' ) ? '' : '' ) . 'افزودن فیلد دلخواه</button>';
echo '</div>';

echo '<table class="bmc-table bmc-table--full bmc-builder" id="bmcCheckoutBuilder" data-prefix="checkout_custom_fields" data-cols="9" data-template="#bmcCheckoutTemplate" data-order-box="#bmcCheckoutOrderBox" data-order-name="checkout_custom_order[]">';
echo '<thead><tr>'
	. '<th style="width:34px">#</th>'
	. '<th>برچسب و راهنما</th>'
	. '<th style="width:150px">نوع</th>'
	. '<th style="width:120px">شناسه</th>'
	. '<th style="width:160px">کارت / بخش</th>'
	. '<th style="width:104px">عرض</th>'
	. '<th style="width:64px">الزامی</th>'
	. '<th style="width:64px">نمایش</th>'
	. '<th style="width:112px">ابزار</th>'
	. '</tr></thead><tbody>';

$bmc_cf_index = 0;

foreach ( $bmc_cf_list as $bmc_cf ) {
	$bmc_cf_options_text = '';

	foreach ( (array) $bmc_cf['options'] as $bmc_cf_option ) {
		$bmc_cf_options_text .= $bmc_cf_option['value'] . '|' . $bmc_cf_option['label'] . "\n";
	}

	$bmc_cf_name = 'checkout_custom_fields[' . $bmc_cf_index . ']';
	?>
	<tr class="bmc-builder__row" data-row="<?php echo esc_attr( $bmc_cf_index ); ?>">
		<td class="bmc-builder__order"><span class="bmc-builder__num"><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_cf_index + 1 ) ); ?></span></td>
		<td>
			<input class="bmc-input" type="text" name="<?php echo esc_attr( $bmc_cf_name ); ?>[label]" value="<?php echo esc_attr( $bmc_cf['label'] ); ?>" placeholder="برچسب فیلد" />
			<input class="bmc-input bmc-builder__sub" type="text" name="<?php echo esc_attr( $bmc_cf_name ); ?>[placeholder]" value="<?php echo esc_attr( $bmc_cf['placeholder'] ); ?>" placeholder="placeholder" />
		</td>
		<td><?php echo BMC_Admin::select( $bmc_cf_name . '[type]', $bmc_cf['type'], $bmc_cf_types ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
		<td><input class="bmc-input" type="text" dir="ltr" name="<?php echo esc_attr( $bmc_cf_name ); ?>[id]" value="<?php echo esc_attr( $bmc_cf['id'] ); ?>" /></td>
		<td><?php echo BMC_Admin::select( $bmc_cf_name . '[section]', $bmc_cf['section'], $bmc_cf_sections ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
		<td><?php echo BMC_Admin::select( $bmc_cf_name . '[width]', $bmc_cf['width'], (array) $bmc_cf_meta['widths'] ); // phpcs:ignore WordPress.Security.EscapeOutput ?></td>
		<td><label class="bmc-check"><input type="checkbox" name="<?php echo esc_attr( $bmc_cf_name ); ?>[required]" value="1" <?php checked( ! empty( $bmc_cf['required'] ) ); ?> /><span></span></label></td>
		<td>
			<input type="hidden" name="<?php echo esc_attr( $bmc_cf_name ); ?>[enabled]" value="0" />
			<label class="bmc-check"><input type="checkbox" name="<?php echo esc_attr( $bmc_cf_name ); ?>[enabled]" value="1" <?php checked( ! empty( $bmc_cf['enabled'] ) ); ?> /><span></span></label>
		</td>
		<td>
			<div class="bmc-builder__tools">
				<button type="button" class="button button-small bmc-cf-up" title="بالا"><?php bmc_icon( 'keyboard_arrow_up', array( 'size' => 15 ) ); ?></button>
				<button type="button" class="button button-small bmc-cf-down" title="پایین"><?php bmc_icon( 'keyboard_arrow_down', array( 'size' => 15 ) ); ?></button>
				<button type="button" class="button button-small bmc-cf-adv" title="تنظیمات پیشرفته"><?php bmc_icon( 'tune', array( 'size' => 15 ) ); ?></button>
				<button type="button" class="button button-small button-link-delete bmc-cf-del" title="حذف"><?php bmc_icon( 'delete', array( 'size' => 15 ) ); ?></button>
			</div>
		</td>
	</tr>
	<tr class="bmc-builder__adv-row" data-adv-for="<?php echo esc_attr( $bmc_cf_index ); ?>" style="display:none">
		<td colspan="9">
			<div class="bmc-builder__adv">
				<div class="bmc-formgrid">
					<label class="bmc-advfield">راهنمای زیر فیلد<input class="bmc-input" type="text" name="<?php echo esc_attr( $bmc_cf_name ); ?>[help]" value="<?php echo esc_attr( wp_strip_all_tags( $bmc_cf['help'] ) ); ?>" /></label>
					<label class="bmc-advfield">مقدار پیش‌فرض<input class="bmc-input" type="text" name="<?php echo esc_attr( $bmc_cf_name ); ?>[default]" value="<?php echo esc_attr( $bmc_cf['default'] ); ?>" /></label>
					<label class="bmc-advfield">ترتیب در فرم (۰ = خودکار)<input class="bmc-input bmc-input--num" type="number" min="0" max="999" name="<?php echo esc_attr( $bmc_cf_name ); ?>[order]" value="<?php echo esc_attr( $bmc_cf['order'] ); ?>" /></label>
					<label class="bmc-advfield">حداقل<input class="bmc-input bmc-input--num" type="number" min="0" name="<?php echo esc_attr( $bmc_cf_name ); ?>[min]" value="<?php echo esc_attr( $bmc_cf['min'] ); ?>" /></label>
					<label class="bmc-advfield">حداکثر<input class="bmc-input bmc-input--num" type="number" min="0" name="<?php echo esc_attr( $bmc_cf_name ); ?>[max]" value="<?php echo esc_attr( $bmc_cf['max'] ); ?>" /></label>
					<label class="bmc-advfield">الگوی اعتبارسنجی (RegExp)<input class="bmc-input" type="text" dir="ltr" name="<?php echo esc_attr( $bmc_cf_name ); ?>[pattern]" value="<?php echo esc_attr( $bmc_cf['pattern'] ); ?>" /></label>
					<label class="bmc-advfield">پیام خطای دلخواه<input class="bmc-input" type="text" name="<?php echo esc_attr( $bmc_cf_name ); ?>[message]" value="<?php echo esc_attr( $bmc_cf['message'] ); ?>" /></label>
					<label class="bmc-advfield">تعداد سطر (متن بلند)<input class="bmc-input bmc-input--num" type="number" min="2" max="20" name="<?php echo esc_attr( $bmc_cf_name ); ?>[rows]" value="<?php echo esc_attr( $bmc_cf['rows'] ); ?>" /></label>
					<label class="bmc-advfield">پسوند فایل مجاز<input class="bmc-input" type="text" dir="ltr" name="<?php echo esc_attr( $bmc_cf_name ); ?>[accept]" value="<?php echo esc_attr( $bmc_cf['accept'] ); ?>" placeholder="jpg,png,pdf" /></label>
					<label class="bmc-advfield">نمایش برای<?php echo BMC_Admin::select( $bmc_cf_name . '[audience]', $bmc_cf['audience'], $bmc_cf_audience ); // phpcs:ignore WordPress.Security.EscapeOutput ?></label>
					<label class="bmc-advfield">نمایش مشروط به فیلد<?php echo BMC_Admin::select( $bmc_cf_name . '[show_if]', $bmc_cf['show_if'], $bmc_cf_conds ); // phpcs:ignore WordPress.Security.EscapeOutput ?></label>
					<label class="bmc-advfield">مقدار برابر با (خالی = فقط پر بودن)<input class="bmc-input" type="text" name="<?php echo esc_attr( $bmc_cf_name ); ?>[show_if_is]" value="<?php echo esc_attr( $bmc_cf['show_if_is'] ); ?>" /></label>
				</div>
				<label class="bmc-advfield">گزینه‌ها (هر خط: value|برچسب)<textarea class="bmc-input bmc-textarea" rows="4" dir="rtl" name="<?php echo esc_attr( $bmc_cf_name ); ?>[options]"><?php echo esc_textarea( $bmc_cf_options_text ); ?></textarea></label>
				<div class="bmc-builder__checks">
					<label class="bmc-check"><input type="checkbox" name="<?php echo esc_attr( $bmc_cf_name ); ?>[iran_phone]" value="1" <?php checked( ! empty( $bmc_cf['iran_phone'] ) ); ?> /><span>شمارهٔ موبایل ایرانی اعتبارسنجی و یکسان‌سازی شود</span></label>
					<label class="bmc-check"><input type="checkbox" name="<?php echo esc_attr( $bmc_cf_name ); ?>[only_synced]" value="1" <?php checked( ! empty( $bmc_cf['only_synced'] ) ); ?> /><span>فقط وقتی آیتم ماینکرافت در سبد است</span></label>
					<input type="hidden" name="<?php echo esc_attr( $bmc_cf_name ); ?>[admin_show]" value="0" />
					<label class="bmc-check"><input type="checkbox" name="<?php echo esc_attr( $bmc_cf_name ); ?>[admin_show]" value="1" <?php checked( ! empty( $bmc_cf['admin_show'] ) ); ?> /><span>در صفحهٔ سفارش (پیشخوان) نمایش داده شود</span></label>
					<input type="hidden" name="<?php echo esc_attr( $bmc_cf_name ); ?>[email_show]" value="0" />
					<label class="bmc-check"><input type="checkbox" name="<?php echo esc_attr( $bmc_cf_name ); ?>[email_show]" value="1" <?php checked( ! empty( $bmc_cf['email_show'] ) ); ?> /><span>در ایمیل‌های سفارش نمایش داده شود</span></label>
					<input type="hidden" name="<?php echo esc_attr( $bmc_cf_name ); ?>[save_meta]" value="0" />
					<label class="bmc-check"><input type="checkbox" name="<?php echo esc_attr( $bmc_cf_name ); ?>[save_meta]" value="1" <?php checked( ! empty( $bmc_cf['save_meta'] ) ); ?> /><span>به‌صورت متادیتا در سفارش ذخیره شود</span></label>
				</div>
			</div>
		</td>
	</tr>
	<?php
	$bmc_cf_index++;
}

echo '</tbody></table>';

echo '<div id="bmcCheckoutTemplate" style="display:none">' . esc_html( wp_json_encode( $bmc_cf_meta ) ) . '</div>';
echo '<div id="bmcCheckoutOrderBox" style="display:none">';

for ( $bmc_i = 0; $bmc_i < count( $bmc_cf_list ); $bmc_i++ ) {
	echo '<input type="hidden" name="checkout_custom_order[]" value="' . esc_attr( $bmc_i ) . '" />';
}

echo '</div>';

echo '<p class="bmc-note" style="margin-top:12px">شناسهٔ هر فیلد فقط حروف انگلیسی، رقم و خط زیرین باشد؛ مقدار فیلد با کلید <code dir="ltr">_bmc_cf_شناسه</code> در سفارش ذخیره می‌شود و در REST/وب‌هوک هم قابل خواندن است.</p>';

BMC_Admin::section_close();

BMC_Admin::section_open( 'فیلدهای فعال فرم خرید', 'فیلدهایی که در چک‌اوت نمایش داده شوند. فیلدهای خاموش، از فرم و از اعتبارسنجی ووکامرس حذف می‌شوند.' );

echo '<div class="bmc-checkbox-grid">';
foreach ( $field_labels as $key => $label ) {
	$checked = ! empty( $settings['checkout_fields'][ $key ] );
	printf(
		'<label class="bmc-check"><input type="checkbox" name="checkout_fields[%1$s]" value="1" %2$s /><span>%3$s</span></label>',
		esc_attr( $key ),
		checked( $checked, true, false ),
		esc_html( $label )
	);
}
echo '</div>';

echo '<p class="bmc-note" style="margin-top:14px">برای فروش آیتم مجازی ماینکرافت، معمولاً فقط «نام»، «نام خانوادگی» و «شمارهٔ موبایل» لازم است.</p>';

BMC_Admin::section_close();

BMC_Admin::form_close();
