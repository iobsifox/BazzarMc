<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Fields {

	public static function init() {
		if ( ! BMC_Settings::bool( 'persian_fields', true ) ) {
			return;
		}

		add_filter( 'woocommerce_default_address_fields', array( __CLASS__, 'address_fields' ), 900 );
		add_filter( 'woocommerce_checkout_fields', array( __CLASS__, 'checkout_fields' ), 900 );
		add_filter( 'woocommerce_billing_fields', array( __CLASS__, 'billing_fields' ), 900 );
		add_filter( 'woocommerce_shipping_fields', array( __CLASS__, 'shipping_fields' ), 900 );
		add_filter( 'woocommerce_get_country_address_formats', array( __CLASS__, 'address_formats' ), 10, 1 );
		add_filter( 'woocommerce_localisation_address_formats', array( __CLASS__, 'address_formats' ), 10, 1 );
		add_filter( 'woocommerce_countries_allowed_countries', array( __CLASS__, 'allowed_countries' ), 20 );
		add_filter( 'woocommerce_countries', array( __CLASS__, 'country_names' ), 20 );
		add_filter( 'woocommerce_states', array( __CLASS__, 'iran_states' ), 20 );
		add_filter( 'woocommerce_countries_country_currency', array( __CLASS__, 'country_currency' ), 20, 2 );
		add_filter( 'woocommerce_order_button_html', array( __CLASS__, 'order_button' ), 20 );
		add_filter( 'woocommerce_checkout_coupon_message', array( __CLASS__, 'coupon_message' ), 20 );
		add_filter( 'woocommerce_checkout_login_message', array( __CLASS__, 'login_message' ), 20 );
		add_filter( 'woocommerce_no_available_payment_methods_message', array( __CLASS__, 'no_gateway_message' ), 20 );
		add_filter( 'woocommerce_cart_shipping_method_full_label', array( __CLASS__, 'shipping_label' ), 20, 2 );
		add_filter( 'woocommerce_cart_totals_order_total_html', array( __CLASS__, 'persian_amount' ), 20 );
		add_filter( 'woocommerce_cart_totals_subtotal_html', array( __CLASS__, 'persian_amount' ), 20 );
	}

	public static function labels() {
		return array(
			'first_name'    => 'نام',
			'last_name'     => 'نام خانوادگی',
			'company'       => 'نام شرکت (اختیاری)',
			'country'       => 'کشور',
			'address_1'     => 'آدرس',
			'address_2'     => 'واحد، پلاک (اختیاری)',
			'city'          => 'شهر',
			'state'         => 'استان',
			'postcode'      => 'کد پستی',
			'phone'         => 'شمارهٔ موبایل',
			'email'         => 'ایمیل',
			'phone_required' => 'شمارهٔ موبایل',
			'mobile'        => 'شمارهٔ موبایل',
		);
	}

	public static function placeholders() {
		return array(
			'first_name' => 'مثلاً علی',
			'last_name'  => 'مثلاً رضایی',
			'company'    => 'نام شرکت',
			'country'    => 'انتخاب کشور',
			'address_1'  => 'خیابان، کوچه، پلاک',
			'address_2'  => 'واحد، طبقه',
			'city'       => 'مثلاً تهران',
			'state'      => 'انتخاب استان',
			'postcode'   => 'مثلاً ۱۲۳۴۵۶۷۸۹۰',
			'phone'      => '۰۹۱۲۳۴۵۶۷۸۹',
			'email'      => 'name@example.com',
			'mobile'     => '۰۹۱۲۳۴۵۶۷۸۹',
		);
	}

	public static function address_fields( $fields ) {
		$labels       = self::labels();
		$placeholders = self::placeholders();

		foreach ( $fields as $key => $field ) {
			if ( isset( $labels[ $key ] ) ) {
				$fields[ $key ]['label'] = $labels[ $key ];
			}

			if ( isset( $placeholders[ $key ] ) ) {
				$fields[ $key ]['placeholder'] = $placeholders[ $key ];
			}
		}

		return $fields;
	}

	public static function checkout_fields( $fields ) {
		$labels       = self::labels();
		$placeholders = self::placeholders();

		foreach ( $fields as $group => $group_fields ) {
			if ( ! is_array( $group_fields ) ) {
				continue;
			}

			foreach ( $group_fields as $key => $field ) {
				$short = str_replace( array( 'billing_', 'shipping_', 'order_' ), '', $key );

				if ( isset( $labels[ $short ] ) ) {
					$fields[ $group ][ $key ]['label'] = $labels[ $short ];
				}

				if ( isset( $placeholders[ $short ] ) ) {
					$fields[ $group ][ $key ]['placeholder'] = $placeholders[ $short ];
				}

				if ( 'billing_phone' === $key ) {
					$fields[ $group ][ $key ]['type']     = 'tel';
					$fields[ $group ][ $key ]['inputmask'] = true;
					$fields[ $group ][ $key ]['validate']  = array( 'phone' );
				}

				if ( 'order_comments' === $key ) {
					$fields[ $group ][ $key ]['label']       = 'توضیحات سفارش (اختیاری)';
					$fields[ $group ][ $key ]['placeholder'] = 'اگر نکتهٔ خاصی دربارهٔ سفارش دارید بنویسید…';
				}
			}
		}

		if ( isset( $fields['billing']['billing_country'] ) ) {
			$fields['billing']['billing_country']['type'] = 'select';
		}

		return $fields;
	}

	public static function billing_fields( $fields ) {
		$labels       = self::labels();
		$placeholders = self::placeholders();

		foreach ( $fields as $key => $field ) {
			$short = str_replace( 'billing_', '', $key );

			if ( isset( $labels[ $short ] ) ) {
				$fields[ $key ]['label'] = $labels[ $short ];
			}

			if ( isset( $placeholders[ $short ] ) ) {
				$fields[ $key ]['placeholder'] = $placeholders[ $short ];
			}
		}

		return $fields;
	}

	public static function shipping_fields( $fields ) {
		return self::billing_fields( $fields );
	}

	public static function address_formats( $formats ) {
		$formats['IR'] = "{name}\n{company}\n{address_1}\n{address_2}\n{city}\n{state}\n{postcode}\n{country}\n{phone}";

		return $formats;
	}

	public static function iran_states( $all_states ) {
		$states = array(
			'THR' => 'تهران',
			'ALB' => 'البرز',
			'QOM' => 'قم',
			'MRK' => 'مرکزی',
			'QZV' => 'قزوین',
			'ZJN' => 'زنجان',
			'EAZ' => 'آذربایجان شرقی',
			'WAZ' => 'آذربایجان غربی',
			'KRD' => 'کردستان',
			'KRM' => 'کرمانشاه',
			'ILM' => 'ایلام',
			'LRS' => 'لرستان',
			'KHZ' => 'خوزستان',
			'CHM' => 'چهارمحال و بختیاری',
			'KBA' => 'کهگیلویه و بویراحمد',
			'FSH' => 'فارس',
			'BSH' => 'بوشهر',
			'HDM' => 'همدان',
			'SMN' => 'سمنان',
			'YZD' => 'یزد',
			'ESF' => 'اصفهان',
			'HRM' => 'هرمزگان',
			'KRN' => 'کرمان',
			'SBN' => 'سیستان و بلوچستان',
			'RKH' => 'خراسان جنوبی',
			'RKV' => 'خراسان رضوی',
			'RKS' => 'خراسان شمالی',
			'GZN' => 'گلستان',
			'MZD' => 'مازندران',
			'GIL' => 'گیلان',
			'ARD' => 'اردبیل',
		);

		if ( ! is_array( $all_states ) ) {
			$all_states = array();
		}

		$all_states['IR'] = $states;

		return $all_states;
	}

	public static function country_names( $countries ) {
		if ( ! is_array( $countries ) ) {
			return $countries;
		}

		$persian = array(
			'IR' => 'ایران',
			'AF' => 'افغانستان',
			'TR' => 'ترکیه',
			'AE' => 'امارات متحدهٔ عربی',
			'DE' => 'آلمان',
			'GB' => 'بریتانیا',
			'US' => 'ایالات متحدهٔ آمریکا',
			'CA' => 'کانادا',
			'FR' => 'فرانسه',
			'NL' => 'هلند',
			'SE' => 'سوئد',
			'NO' => 'نروژ',
			'DK' => 'دانمارک',
			'FI' => 'فنلاند',
			'ES' => 'اسپانیا',
			'IT' => 'ایتالیا',
			'RU' => 'روسیه',
			'CN' => 'چین',
			'JP' => 'ژاپن',
			'IQ' => 'عراق',
			'PK' => 'پاکستان',
			'AZ' => 'جمهوری آذربایجان',
			'AM' => 'ارمنستان',
			'GE' => 'گرجستان',
			'QA' => 'قطر',
			'KW' => 'کویت',
			'OM' => 'عمان',
			'BH' => 'بحرین',
			'SA' => 'عربستان سعودی',
			'MY' => 'مالزی',
			'IN' => 'هند',
			'AU' => 'استرالیا',
		);

		foreach ( $persian as $code => $name ) {
			if ( isset( $countries[ $code ] ) ) {
				$countries[ $code ] = $name;
			}
		}

		return $countries;
	}

	public static function allowed_countries( $countries ) {
		if ( ! is_array( $countries ) || ! $countries ) {
			return $countries;
		}

		return $countries;
	}

	public static function country_currency( $currency, $country ) {
		if ( 'IR' === $country && ! $currency ) {
			return 'IRR';
		}

		return $currency;
	}

	public static function order_button( $html ) {
		$replacements = array(
			'Place order'      => 'ثبت و پرداخت سفارش',
			'Proceed to PayPal' => 'پرداخت و ثبت سفارش',
		);

		foreach ( $replacements as $from => $to ) {
			$html = str_replace( $from, $to, $html );
		}

		return $html;
	}

	public static function coupon_message( $message ) {
		return 'کد تخفیف دارید؟ <a href="#" class="showcoupon">اینجا وارد کنید</a>';
	}

	public static function login_message( $message ) {
		return 'قبلاً حساب ساخته‌اید؟ <a href="' . esc_url( wp_login_url( wc_get_page_permalink( 'checkout' ) ) ) . '" class="showlogin">وارد شوید</a>';
	}

	public static function no_gateway_message( $message ) {
		return 'متأسفانه هیچ درگاه پرداختی فعال نیست. لطفاً با پشتیبانی تماس بگیرید.';
	}

	public static function shipping_label( $label, $method ) {
		if ( is_string( $label ) ) {
			$label = str_replace( array( 'Free shipping', 'Flat rate', 'Local pickup' ), array( 'ارسال رایگان', 'نرخ ثابت', 'تحویل حضوری' ), $label );
		}

		return $label;
	}

	public static function persian_amount( $html ) {
		if ( ! BMC_Helpers::is_persian_digits_enabled() ) {
			return $html;
		}

		return preg_replace_callback(
			'/(\d[\d,\.]*)/',
			static function ( $matches ) {
				return BMC_Helpers::to_persian_digits( $matches[1] );
			},
			$html
		);
	}
}
