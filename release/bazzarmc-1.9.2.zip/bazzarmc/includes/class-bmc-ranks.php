<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Ranks {

	public static function init() {
		if ( ! BMC_Settings::bool( 'rank_guard', true ) ) {
			return;
		}

		add_filter( 'woocommerce_add_to_cart_validation', array( __CLASS__, 'validate_add_to_cart' ), 20, 4 );
		add_action( 'woocommerce_after_checkout_validation', array( __CLASS__, 'validate_checkout' ), 20, 2 );
		add_filter( 'woocommerce_product_is_visible', array( __CLASS__, 'product_visible' ), 20, 2 );
		add_filter( 'woocommerce_is_purchasable', array( __CLASS__, 'is_purchasable' ), 20, 2 );
		add_action( 'woocommerce_before_add_to_cart_button', array( __CLASS__, 'single_product_notice' ) );
		add_action( 'woocommerce_after_cart_item_name', array( __CLASS__, 'cart_item_notice' ), 10, 2 );
		add_action( 'woocommerce_before_cart', array( __CLASS__, 'cart_notice' ) );
		add_action( 'woocommerce_before_checkout_form', array( __CLASS__, 'checkout_notice' ), 5 );
	}

	public static function enabled() {
		return (bool) BMC_Settings::bool( 'rank_guard', true );
	}

	public static function hide_lower() {
		return (bool) BMC_Settings::bool( 'rank_hide_lower', true );
	}

	public static function definitions() {
		$defs = (array) BMC_Settings::get( 'mc_ranks', array() );
		$out  = array();

		foreach ( $defs as $def ) {
			if ( ! is_array( $def ) ) {
				continue;
			}

			$out[] = array(
				'key'   => isset( $def['key'] ) ? (string) $def['key'] : '',
				'name'  => isset( $def['name'] ) ? (string) $def['name'] : '',
				'level' => isset( $def['level'] ) ? (int) $def['level'] : 0,
				'role'  => isset( $def['role'] ) ? (string) $def['role'] : '',
				'days'  => isset( $def['days'] ) ? (int) $def['days'] : 0,
			);
		}

		return $out;
	}

	public static function rank_for_product( $product_id, $variation_id = 0 ) {
		$product_id   = absint( $product_id );
		$variation_id = absint( $variation_id );

		if ( ! $product_id && ! $variation_id ) {
			return null;
		}

		$manual = (array) BMC_Settings::get( 'rank_levels', array() );
		$mc     = self::match_definition( $product_id, $variation_id );

		$manual_level = 0;

		if ( $variation_id && isset( $manual[ $variation_id ] ) && '' !== $manual[ $variation_id ] ) {
			$manual_level = (int) $manual[ $variation_id ];
		} elseif ( $product_id && isset( $manual[ $product_id ] ) && '' !== $manual[ $product_id ] ) {
			$manual_level = (int) $manual[ $product_id ];
		}

		$level = $manual_level > 0 ? $manual_level : ( $mc ? (int) $mc['level'] : 0 );

		if ( $level <= 0 ) {
			return null;
		}

		return array(
			'level'  => $level,
			'name'   => $mc && '' !== $mc['name'] ? $mc['name'] : self::product_title( $product_id, $variation_id ),
			'role'   => $mc ? (string) $mc['role'] : '',
			'days'   => $mc ? (int) $mc['days'] : 0,
			'key'    => $mc ? (string) $mc['key'] : '',
			'source' => $mc ? 'minecraft' : 'manual',
		);
	}

	public static function level_for_product( $product_id, $variation_id = 0 ) {
		$rank = self::rank_for_product( $product_id, $variation_id );

		return $rank ? (int) $rank['level'] : 0;
	}

	private static function match_definition( $product_id, $variation_id ) {
		$defs = self::definitions();

		if ( ! $defs ) {
			return null;
		}

		$product = function_exists( 'wc_get_product' ) ? wc_get_product( $variation_id ? $variation_id : $product_id ) : null;

		$ids = array();

		if ( $product ) {
			$title = trim( (string) $product->get_name() );
			$ids[] = function_exists( 'mb_strtolower' ) ? mb_strtolower( $title ) : strtolower( $title );
			$ids[] = (string) $product->get_slug();

			$sku = trim( (string) $product->get_sku() );

			if ( '' !== $sku ) {
				$ids[] = $sku;
			}
		}

		if ( $variation_id ) {
			$ids[] = (string) $variation_id;
		}

		if ( $product_id ) {
			$ids[] = (string) $product_id;
		}

		$key = trim( (string) BMC_Settings::product_key( $product_id, $variation_id ) );

		if ( '' !== $key ) {
			array_unshift( $ids, function_exists( 'mb_strtolower' ) ? mb_strtolower( $key ) : strtolower( $key ) );
		}

		$ids = array_values( array_unique( array_filter( array_map( 'strval', $ids ) ) ) );

		if ( ! $ids ) {
			return null;
		}

		foreach ( $defs as $def ) {
			$needle = function_exists( 'mb_strtolower' ) ? mb_strtolower( trim( (string) $def['key'] ) ) : strtolower( trim( (string) $def['key'] ) );

			if ( '' === $needle ) {
				continue;
			}

			if ( in_array( $needle, $ids, true ) ) {
				return $def;
			}
		}

		return null;
	}

	public static function product_title( $product_id, $variation_id = 0 ) {
		if ( ! function_exists( 'wc_get_product' ) ) {
			return '';
		}

		$product = wc_get_product( $variation_id ? absint( $variation_id ) : absint( $product_id ) );

		return $product ? (string) $product->get_name() : '';
	}

	public static function user_top( $user_id ) {
		$user_id = absint( $user_id );
		$top     = array(
			'level' => 0,
			'name'  => '',
			'role'  => '',
			'grant' => null,
		);

		if ( ! $user_id ) {
			return $top;
		}

		foreach ( BMC_Roles::active_grants( $user_id ) as $grant ) {
			$level = isset( $grant['level'] ) ? (int) $grant['level'] : 0;

			if ( $level <= 0 ) {
				$level = self::level_for_product(
					isset( $grant['product_id'] ) ? $grant['product_id'] : 0,
					isset( $grant['variation_id'] ) ? $grant['variation_id'] : 0
				);
			}

			if ( $level > (int) $top['level'] ) {
				$top = array(
					'level' => $level,
					'name'  => isset( $grant['label'] ) ? (string) $grant['label'] : '',
					'role'  => isset( $grant['role'] ) ? (string) $grant['role'] : '',
					'grant' => $grant,
				);
			}
		}

		return $top;
	}

	public static function user_top_level( $user_id ) {
		$top = self::user_top( $user_id );

		return (int) $top['level'];
	}

	public static function is_downgrade( $user_id, $product_id, $variation_id = 0 ) {
		if ( ! self::enabled() || ! is_user_logged_in() ) {
			return false;
		}

		$level = self::level_for_product( $product_id, $variation_id );

		if ( $level <= 0 ) {
			return false;
		}

		$top = self::user_top_level( $user_id );

		return $top > 0 && $level < $top;
	}

	public static function blocked_message( $user_id, $product_id, $variation_id = 0 ) {
		$top   = self::user_top( $user_id );
		$level = self::level_for_product( $product_id, $variation_id );
		$name  = self::product_title( $product_id, $variation_id );

		return sprintf(
			'شما هم‌اکنون رنک «%s» (سطح %s) را دارید و امکان خرید رنک پایین‌تر «%s» (سطح %s) وجود ندارد. برای ارتقا، رنک بالاتر را انتخاب کنید.',
			'' !== $top['name'] ? $top['name'] : self::label_for_level( (int) $top['level'] ),
			BMC_Helpers::to_persian_digits( (int) $top['level'] ),
			'' !== $name ? $name : self::label_for_level( $level ),
			BMC_Helpers::to_persian_digits( $level )
		);
	}

	public static function label_for_level( $level ) {
		$best = '';

		foreach ( self::definitions() as $def ) {
			if ( (int) $def['level'] === (int) $level && '' !== $def['name'] ) {
				$best = $def['name'];
				break;
			}
		}

		return '' !== $best ? $best : 'سطح ' . BMC_Helpers::to_persian_digits( (int) $level );
	}

	public static function validate_add_to_cart( $pass, $product_id, $quantity, $variation_arg = 0 ) {
		$product_id = absint( $product_id );
		$variation  = absint( $variation_arg );

		if ( ! $variation && isset( $_POST['variation_id'] ) ) {
			$variation = absint( wp_unslash( $_POST['variation_id'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		}

		if ( ! self::is_downgrade( get_current_user_id(), $product_id, $variation ) ) {
			return $pass;
		}

		if ( function_exists( 'wc_add_notice' ) ) {
			wc_add_notice( self::blocked_message( get_current_user_id(), $product_id, $variation ), 'error' );
		}

		BMC_Logger::add(
			'rank',
			sprintf( 'از افزودن رنک پایین‌تر به سبد جلوگیری شد (کاربر #%d، محصول #%d).', get_current_user_id(), $product_id ),
			array(),
			'warning'
		);

		return false;
	}

	public static function validate_checkout( $data, $errors ) {
		$blocked = self::cart_blocked_items();

		if ( ! $blocked ) {
			return;
		}

		$messages = array();

		foreach ( $blocked as $item ) {
			$messages[] = $item['message'];
		}

		if ( is_wp_error( $errors ) ) {
			$errors->add( 'bmc_rank_downgrade', implode( ' ', array_unique( $messages ) ) );
		} elseif ( function_exists( 'wc_add_notice' ) ) {
			wc_add_notice( implode( ' ', array_unique( $messages ) ), 'error' );
		}
	}

	public static function cart_blocked_items() {
		$out = array();

		if ( ! self::enabled() || ! is_user_logged_in() || ! function_exists( 'WC' ) || ! isset( WC()->cart ) || WC()->cart->is_empty() ) {
			return $out;
		}

		$user_id = get_current_user_id();

		foreach ( WC()->cart->get_cart() as $cart_key => $item ) {
			$product_id   = isset( $item['product_id'] ) ? absint( $item['product_id'] ) : 0;
			$variation_id = isset( $item['variation_id'] ) ? absint( $item['variation_id'] ) : 0;

			if ( ! self::is_downgrade( $user_id, $product_id, $variation_id ) ) {
				continue;
			}

			$out[] = array(
				'key'      => $cart_key,
				'name'     => self::product_title( $product_id, $variation_id ),
				'product'  => $product_id,
				'variation' => $variation_id,
				'message'  => self::blocked_message( $user_id, $product_id, $variation_id ),
			);
		}

		return $out;
	}

	public static function product_visible( $visible, $product_id ) {
		if ( ! self::hide_lower() || ! $visible || ! is_user_logged_in() ) {
			return $visible;
		}

		return ! self::is_downgrade( get_current_user_id(), absint( $product_id ), 0 );
	}

	public static function is_purchasable( $purchasable, $product ) {
		if ( ! self::enabled() || ! $purchasable || ! is_user_logged_in() || ! is_object( $product ) ) {
			return $purchasable;
		}

		$product_id = method_exists( $product, 'get_id' ) ? (int) $product->get_id() : 0;

		if ( ! $product_id ) {
			return $purchasable;
		}

		$variation_id = 0;

		if ( $product instanceof WC_Product_Variation ) {
			$variation_id = $product_id;
			$product_id   = (int) $product->get_parent_id();
		}

		return self::is_downgrade( get_current_user_id(), $product_id, $variation_id ) ? false : $purchasable;
	}

	public static function single_product_notice() {
		if ( ! function_exists( 'is_product' ) || ! is_product() || ! is_user_logged_in() ) {
			return;
		}

		$product = function_exists( 'wc_get_product' ) ? wc_get_product( get_the_ID() ) : null;

		if ( ! $product ) {
			return;
		}

		$product_id = (int) $product->get_id();

		if ( ! self::is_downgrade( get_current_user_id(), $product_id, 0 ) ) {
			return;
		}

		printf(
			'<div class="bmc-rank-block">%s<div>%s</div></div>',
			bmc_get_icon( 'lock', array( 'size' => 18 ) ),
			esc_html( self::blocked_message( get_current_user_id(), $product_id, 0 ) )
		);
	}

	public static function cart_item_notice( $item_data, $cart_item ) {
		if ( ! is_array( $cart_item ) || ! is_user_logged_in() ) {
			return;
		}

		$product_id   = isset( $cart_item['product_id'] ) ? absint( $cart_item['product_id'] ) : 0;
		$variation_id = isset( $cart_item['variation_id'] ) ? absint( $cart_item['variation_id'] ) : 0;

		if ( ! self::is_downgrade( get_current_user_id(), $product_id, $variation_id ) ) {
			return;
		}

		printf(
			'<div class="bmc-rank-tag">%s رنک پایین‌تر — قابل پرداخت نیست</div>',
			bmc_get_icon( 'warning', array( 'size' => 13 ) )
		);
	}

	public static function cart_notice() {
		self::render_blocked_notice( 'woocommerce_before_cart' );
	}

	public static function checkout_notice() {
		self::render_blocked_notice( 'woocommerce_before_checkout_form' );
	}

	private static function render_blocked_notice( $context ) {
		$blocked = self::cart_blocked_items();

		if ( ! $blocked ) {
			return;
		}

		echo '<div class="bmc-notice bmc-notice-error bmc-rank-notice">';
		echo '<span>' . bmc_get_icon( 'lock', array( 'size' => 18 ) ) . '</span>';
		echo '<div><strong>پرداخت این سبد ممکن نیست</strong><ul>';

		foreach ( $blocked as $item ) {
			echo '<li>' . esc_html( $item['message'] ) . '</li>';
		}

		echo '</ul>';

		if ( function_exists( 'wc_get_cart_url' ) ) {
			printf(
				'<a class="bmc-rank-fix" href="%s">%s بازگردانی سبد</a>',
				esc_url( (string) wc_get_cart_url() ),
				bmc_get_icon( 'shopping_cart', array( 'size' => 15 ) )
			);
		}

		echo '</div></div>';
	}

	public static function sync_definitions( array $ranks ) {
		$clean = array();

		foreach ( $ranks as $rank ) {
			if ( ! is_array( $rank ) ) {
				continue;
			}

			$key = sanitize_text_field( isset( $rank['key'] ) ? (string) $rank['key'] : '' );

			if ( '' === $key ) {
				continue;
			}

			$clean[] = array(
				'key'   => $key,
				'name'  => sanitize_text_field( isset( $rank['name'] ) ? (string) $rank['name'] : '' ),
				'level' => max( 0, (int) ( isset( $rank['level'] ) ? $rank['level'] : 0 ) ),
				'role'  => sanitize_text_field( isset( $rank['role'] ) ? (string) $rank['role'] : '' ),
				'days'  => max( 0, (int) ( isset( $rank['days'] ) ? $rank['days'] : 0 ) ),
			);
		}

		BMC_Settings::set( 'mc_ranks', $clean );
		BMC_Settings::set( 'mc_ranks_synced_at', BMC_Helpers::now_timestamp() );

		BMC_Logger::add( 'rank', sprintf( 'تعریف %d رنک از پلاگین ماینکرافت دریافت شد.', count( $clean ) ), array(), 'info' );

		return count( $clean );
	}

	public static function apply_report( $player, $uuid, array $ranks, $full = true ) {
		$player = sanitize_text_field( (string) $player );
		$user   = '' !== $player ? BMC_Link::find_user_by_player( $player ) : null;

		if ( ! $user ) {
			return array(
				'success' => false,
				'error'   => 'بازیکن متصل یافت نشد.',
			);
		}

		$user_id   = (int) $user->ID;
		$keep_keys = array();
		$updated   = 0;

		foreach ( $ranks as $rank ) {
			if ( ! is_array( $rank ) ) {
				continue;
			}

			$key = sanitize_text_field( isset( $rank['key'] ) ? (string) $rank['key'] : '' );

			if ( '' === $key ) {
				continue;
			}

			$keep_keys[] = $key;

			$role = sanitize_text_field( isset( $rank['role'] ) ? (string) $rank['role'] : '' );

			if ( '' === $role ) {
				$def  = self::definition_by_key( $key );
				$role = $def ? (string) $def['role'] : '';
			}

			BMC_Roles::upsert_external(
				$user_id,
				array(
					'key'        => $key,
					'name'       => sanitize_text_field( isset( $rank['name'] ) ? (string) $rank['name'] : '' ),
					'role'       => $role,
					'level'      => (int) ( isset( $rank['level'] ) ? $rank['level'] : 0 ),
					'days_left'  => (int) ( isset( $rank['days_left'] ) ? $rank['days_left'] : 0 ),
					'permanent'  => ! empty( $rank['permanent'] ),
					'product_id' => absint( isset( $rank['product_id'] ) ? $rank['product_id'] : 0 ),
				)
			);

			$updated++;
		}

		$pruned = 0;

		if ( $full ) {
			$pruned = BMC_Roles::prune_external( $user_id, $keep_keys );
		}

		BMC_Settings::set( 'mc_ranks_reported_at', BMC_Helpers::now_timestamp() );

		BMC_Logger::add(
			'rank',
			sprintf( 'گزارش رنک از ماینکرافت برای %s: %d رنک به‌روز شد%s', $player, $updated, $pruned ? ' و ' . $pruned . ' مورد بازپس گرفته شد' : '' ),
			array( 'user' => $user_id ),
			'info'
		);

		return array(
			'success' => true,
			'user_id' => $user_id,
			'updated' => $updated,
			'pruned'  => $pruned,
		);
	}

	public static function definition_by_key( $key ) {
		$key = function_exists( 'mb_strtolower' ) ? mb_strtolower( trim( (string) $key ) ) : strtolower( trim( (string) $key ) );

		foreach ( self::definitions() as $def ) {
			$needle = function_exists( 'mb_strtolower' ) ? mb_strtolower( trim( (string) $def['key'] ) ) : strtolower( trim( (string) $def['key'] ) );

			if ( $needle === $key ) {
				return $def;
			}
		}

		return null;
	}

	public static function status() {
		return array(
			'enabled'      => self::enabled(),
			'hide_lower'   => self::hide_lower(),
			'definitions'  => count( self::definitions() ),
			'manual'       => count( array_filter( (array) BMC_Settings::get( 'rank_levels', array() ) ) ),
			'synced_at'    => (int) BMC_Settings::get( 'mc_ranks_synced_at', 0 ),
			'reported_at'  => (int) BMC_Settings::get( 'mc_ranks_reported_at', 0 ),
		);
	}

	public static function save_manual_levels( array $levels ) {
		$clean = array();

		foreach ( $levels as $pid => $level ) {
			$pid = absint( $pid );

			if ( ! $pid || '' === trim( (string) $level ) ) {
				continue;
			}

			$level = (int) $level;

			if ( $level <= 0 ) {
				continue;
			}

			$clean[ $pid ] = min( 9999, $level );
		}

		return $clean;
	}
}
