<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

class BMC_Checkout_Fields {

	const NAME_PREFIX = 'bmc_cf_';
	const META_PREFIX = '_bmc_cf_';
	const SUMMARY_KEY = '_bmc_custom_fields';
	const SESSION_KEY = 'bmc_checkout_custom';
	const MAX_FIELDS  = 40;

	private static $cache = null;

	public static function init() {
		add_action( 'woocommerce_checkout_process', array( __CLASS__, 'validate' ), 20 );
		add_action( 'woocommerce_checkout_create_order', array( __CLASS__, 'save' ), 20, 2 );
		add_action( 'woocommerce_admin_order_data_after_billing_address', array( __CLASS__, 'render_admin' ) );
		add_filter( 'woocommerce_email_order_meta_fields', array( __CLASS__, 'email_fields' ), 10, 3 );
		add_action( 'woocommerce_thankyou', array( __CLASS__, 'render_thankyou' ), 5 );
		add_filter( 'bmc_checkout_field_plan', array( __CLASS__, 'inject_plan' ), 10, 3 );
	}

	public static function enabled() {
		if ( class_exists( 'BMC_Safe' ) && BMC_Safe::safe_mode() ) {
			return false;
		}

		if ( ! BMC_Settings::bool( 'checkout_custom_enabled', true ) ) {
			return false;
		}

		return (bool) self::custom_fields();
	}

	public static function field_types() {
		$types = class_exists( 'BMC_Forms' )
			? BMC_Forms::field_types()
			: array(
				'text'           => 'متن کوتاه',
				'textarea'       => 'متن بلند',
				'email'          => 'ایمیل',
				'tel'            => 'شمارهٔ تماس',
				'number'         => 'عدد',
				'url'            => 'آدرس وب',
				'date'           => 'تاریخ',
				'select'         => 'لیست بازشو',
				'radio'          => 'گزینه‌های رادیویی',
				'checkbox'       => 'تأیید (یک چک‌باکس)',
				'checkbox_group' => 'چند انتخابی',
				'mc_username'    => 'نام کاربری ماینکرافت',
				'file'           => 'آپلود فایل',
				'hidden'         => 'فیلد پنهان',
				'html'           => 'متن یا HTML ثابت',
			);

		$out = array();

		foreach ( $types as $key => $label ) {
			$out[ $key ] = $label;

			if ( 'tel' === $key ) {
				$out['national_code'] = 'کد ملی';
				$out['postal_code']   = 'کد پستی';
			}
		}

		if ( ! isset( $out['national_code'] ) ) {
			$out['national_code'] = 'کد ملی';
			$out['postal_code']   = 'کد پستی';
		}

		unset( $out['file'] );

		if ( self::files_allowed() ) {
			$out['file'] = 'آپلود فایل';
		}

		return apply_filters( 'bmc_checkout_field_types', $out );
	}

	public static function files_allowed() {
		return class_exists( 'BMC_Forms' ) && BMC_Settings::bool( 'forms_allow_files', false );
	}

	public static function widths() {
		return class_exists( 'BMC_Forms' )
			? BMC_Forms::widths()
			: array(
				100 => 'تمام عرض',
				75  => 'سه‌چهارم',
				66  => 'دو‌سوم',
				50  => 'نصف',
				33  => 'یک‌سوم',
				25  => 'یک‌چهارم',
			);
	}

	public static function sections() {
		return array(
			'mc'       => 'کارت اکانت ماینکرافت',
			'buyer'    => 'کارت اطلاعات خریدار',
			'shipping' => 'بخش ارسال (داخل کارت خریدار)',
			'order'    => 'بخش توضیحات سفارش',
			'payment'  => 'کارت روش پرداخت',
			'extra'    => 'کارت اطلاعات تکمیلی',
		);
	}

	public static function audiences() {
		return array(
			'all'   => 'همه',
			'guest' => 'فقط کاربر مهمان',
			'user'  => 'فقط کاربر واردشده',
		);
	}

	public static function label( $field ) {
		$label = isset( $field['label'] ) ? trim( (string) $field['label'] ) : '';

		return '' !== $label ? $label : ( isset( $field['id'] ) ? (string) $field['id'] : '' );
	}

	public static function field_name( $id ) {
		return self::NAME_PREFIX . sanitize_key( (string) $id );
	}

	public static function meta_key( $id ) {
		return self::META_PREFIX . sanitize_key( (string) $id );
	}

	public static function normalize_field( $raw, $index = 0 ) {
		$raw   = is_array( $raw ) ? $raw : array();
		$field = class_exists( 'BMC_Forms' ) ? BMC_Forms::normalize_field( $raw, $index ) : array( 'id' => 'field_' . ( $index + 1 ), 'type' => 'text' );

		$type = isset( $raw['type'] ) ? sanitize_key( (string) $raw['type'] ) : 'text';

		if ( in_array( $type, array( 'national_code', 'postal_code' ), true ) ) {
			$field['type'] = $type;
		} elseif ( 'file' === $type && ! self::files_allowed() ) {
			$field['type'] = 'text';
		} elseif ( ! array_key_exists( $field['type'], self::field_types() ) ) {
			$field['type'] = 'text';
		}

		if ( ! isset( $field['id'] ) || '' === $field['id'] ) {
			$field['id'] = 'field_' . ( $index + 1 );
		}

		$section = isset( $raw['section'] ) ? sanitize_key( (string) $raw['section'] ) : 'buyer';

		$field['section']  = array_key_exists( $section, self::sections() ) ? $section : 'buyer';
		$field['audience'] = isset( $raw['audience'] ) && array_key_exists( $raw['audience'], self::audiences() ) ? $raw['audience'] : 'all';

		$field['enabled']     = isset( $raw['enabled'] ) && '0' === (string) $raw['enabled'] ? 0 : 1;
		$field['only_synced'] = empty( $raw['only_synced'] ) ? 0 : 1;
		$field['admin_show']  = isset( $raw['admin_show'] ) && '0' === (string) $raw['admin_show'] ? 0 : 1;
		$field['email_show']  = isset( $raw['email_show'] ) && '0' === (string) $raw['email_show'] ? 0 : 1;
		$field['save_meta']   = isset( $raw['save_meta'] ) && '0' === (string) $raw['save_meta'] ? 0 : 1;

		$field['show_if']    = isset( $raw['show_if'] ) ? preg_replace( '/[^A-Za-z0-9_\-]/', '', (string) $raw['show_if'] ) : '';
		$field['show_if_is'] = isset( $raw['show_if_is'] ) ? sanitize_text_field( (string) $raw['show_if_is'] ) : '';

		$field['order'] = isset( $raw['order'] ) ? max( 0, min( 999, (int) $raw['order'] ) ) : 0;

		if ( in_array( $field['type'], array( 'hidden', 'html' ), true ) ) {
			$field['width'] = 100;
		}

		if ( 'html' === $field['type'] && '' === trim( (string) $field['label'] ) ) {
			$field['label'] = '';
		}

		return apply_filters( 'bmc_checkout_field', $field, $raw );
	}

	public static function normalize_list( $raw, $order = array() ) {
		$raw = is_array( $raw ) ? $raw : array();

		if ( $order && is_array( $order ) ) {
			$sorted = array();
			$seen   = array();

			foreach ( $order as $position ) {
				$position = absint( $position );

				if ( isset( $raw[ $position ] ) && ! isset( $seen[ $position ] ) ) {
					$sorted[]          = $raw[ $position ];
					$seen[ $position ] = true;
				}
			}

			foreach ( $raw as $position => $item ) {
				if ( ! isset( $seen[ absint( $position ) ] ) ) {
					$sorted[] = $item;
				}
			}

			$raw = $sorted;
		}

		$out  = array();
		$used = array();
		$i    = 0;

		foreach ( $raw as $item ) {
			$field = self::normalize_field( $item, $i );
			$i++;

			if ( ! in_array( $field['type'], array( 'hidden', 'html' ), true ) && '' === trim( (string) $field['label'] ) ) {
				continue;
			}

			if ( isset( $used[ $field['id'] ] ) ) {
				$field['id'] = $field['id'] . '_' . $i;
			}

			$used[ $field['id'] ] = true;
			$out[]                = $field;

			if ( count( $out ) >= self::MAX_FIELDS ) {
				break;
			}
		}

		return $out;
	}

	public static function custom_fields() {
		if ( null !== self::$cache ) {
			return self::$cache;
		}

		$raw = (array) BMC_Settings::get( 'checkout_custom_fields', array() );

		self::$cache = self::normalize_list( $raw );

		return self::$cache;
	}

	public static function reset_cache() {
		self::$cache = null;
	}

	public static function find( $id ) {
		$id = sanitize_key( (string) $id );

		foreach ( self::custom_fields() as $field ) {
			if ( $field['id'] === $id ) {
				return $field;
			}
		}

		return null;
	}

	public static function audience_ok( $field ) {
		$audience = isset( $field['audience'] ) ? (string) $field['audience'] : 'all';

		if ( 'guest' === $audience && function_exists( 'is_user_logged_in' ) && is_user_logged_in() ) {
			return false;
		}

		if ( 'user' === $audience && function_exists( 'is_user_logged_in' ) && ! is_user_logged_in() ) {
			return false;
		}

		if ( ! empty( $field['only_synced'] ) && class_exists( 'BMC_Checkout' ) && ! BMC_Checkout::cart_has_synced_products() ) {
			return false;
		}

		return true;
	}

	public static function active_fields() {
		$out = array();

		foreach ( self::custom_fields() as $field ) {
			if ( empty( $field['enabled'] ) ) {
				continue;
			}

			if ( ! self::audience_ok( $field ) ) {
				continue;
			}

			$out[] = $field;
		}

		return $out;
	}

	public static function condition_ok( $field ) {
		$key = isset( $field['show_if'] ) ? (string) $field['show_if'] : '';

		if ( '' === $key ) {
			return true;
		}

		$expected = isset( $field['show_if_is'] ) ? trim( (string) $field['show_if_is'] ) : '';
		$actual   = '';

		foreach ( array( $key, self::NAME_PREFIX . $key ) as $candidate ) {
			if ( isset( $_POST[ $candidate ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				$raw = wp_unslash( $_POST[ $candidate ] ); // phpcs:ignore WordPress.Security.NonceVerification

				if ( is_array( $raw ) ) {
					$actual = implode( ',', array_map( 'sanitize_text_field', $raw ) );
				} else {
					$actual = sanitize_text_field( (string) $raw );
				}

				break;
			}
		}

		if ( '' === $expected ) {
			return '' !== trim( $actual );
		}

		return strtolower( trim( $actual ) ) === strtolower( $expected );
	}

	public static function raw_value( $field ) {
		$name = self::field_name( $field['id'] );

		if ( 'checkbox_group' === $field['type'] ) {
			if ( ! isset( $_POST[ $name ] ) || ! is_array( $_POST[ $name ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
				return array();
			}

			return array_map( 'sanitize_text_field', wp_unslash( $_POST[ $name ] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		}

		if ( ! isset( $_POST[ $name ] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return 'checkbox' === $field['type'] ? '' : null;
		}

		$raw = wp_unslash( $_POST[ $name ] ); // phpcs:ignore WordPress.Security.NonceVerification

		return is_array( $raw ) ? array_map( 'sanitize_text_field', $raw ) : $raw;
	}

	public static function field_defaults() {
		$defaults = class_exists( 'BMC_Forms' ) ? BMC_Forms::default_field() : array();

		return array_merge(
			$defaults,
			array(
				'id'          => '',
				'type'        => 'text',
				'label'       => '',
				'section'     => 'buyer',
				'audience'    => 'all',
				'enabled'     => 1,
				'only_synced' => 0,
				'admin_show'  => 1,
				'email_show'  => 1,
				'save_meta'   => 1,
				'show_if'     => '',
				'show_if_is'  => '',
				'order'       => 0,
			)
		);
	}

	public static function valid_national_code( $value ) {
		$value = preg_replace( '/[^0-9]/', '', (string) $value );

		if ( 10 !== strlen( $value ) ) {
			return false;
		}

		if ( preg_match( '/^(\d)\1{9}$/', $value ) ) {
			return false;
		}

		$sum = 0;

		for ( $i = 0; $i < 9; $i++ ) {
			$sum += (int) $value[ $i ] * ( 10 - $i );
		}

		$rest = $sum % 11;
		$last = (int) $value[9];

		return ( $rest < 2 && $last === $rest ) || ( $rest >= 2 && $last === 11 - $rest );
	}

	public static function to_latin_digits( $value ) {
		if ( is_array( $value ) ) {
			return array_map( array( __CLASS__, 'to_latin_digits' ), $value );
		}

		return str_replace(
			array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹', '٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩' ),
			array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9', '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' ),
			(string) $value
		);
	}

	public static function validate_field( $field, $value ) {
		$field  = array_merge( self::field_defaults(), is_array( $field ) ? $field : array() );
		$type   = isset( $field['type'] ) ? (string) $field['type'] : 'text';
		$custom = isset( $field['message'] ) ? (string) $field['message'] : '';

		if ( in_array( $type, array( 'national_code', 'postal_code', 'number', 'tel' ), true ) ) {
			$value = self::to_latin_digits( $value );
		}

		if ( 'national_code' === $type ) {
			$clean = preg_replace( '/[^0-9]/', '', self::to_latin_digits( $value ) );
			$empty = '' === $clean;

			if ( $empty ) {
				if ( ! empty( $field['required'] ) ) {
					return array(
						'value' => '',
						'error' => $custom ? $custom : 'کد ملی الزامی است.',
					);
				}

				return array(
					'value' => '',
					'error' => '',
				);
			}

			if ( ! self::valid_national_code( $clean ) ) {
				return array(
					'value' => '',
					'error' => $custom ? $custom : 'کد ملی معتبر نیست (۱۰ رقم).',
				);
			}

			return array(
				'value' => $clean,
				'error' => '',
			);
		}

		if ( 'postal_code' === $type ) {
			$clean = preg_replace( '/[^0-9]/', '', self::to_latin_digits( $value ) );
			$empty = '' === $clean;

			if ( $empty ) {
				if ( ! empty( $field['required'] ) ) {
					return array(
						'value' => '',
						'error' => $custom ? $custom : 'کد پستی الزامی است.',
					);
				}

				return array(
					'value' => '',
					'error' => '',
				);
			}

			if ( strlen( $clean ) < 5 || strlen( $clean ) > 10 ) {
				return array(
					'value' => '',
					'error' => $custom ? $custom : 'کد پستی باید ۵ تا ۱۰ رقم باشد.',
				);
			}

			return array(
				'value' => $clean,
				'error' => '',
			);
		}

		if ( class_exists( 'BMC_Forms' ) ) {
			return BMC_Forms::validate_field( $field, $value );
		}

		return array(
			'value' => is_array( $value ) ? $value : sanitize_text_field( (string) $value ),
			'error' => '',
		);
	}

	public static function session_values() {
		if ( ! function_exists( 'WC' ) || ! WC()->session ) {
			return array();
		}

		$values = WC()->session->get( self::SESSION_KEY, array() );

		return is_array( $values ) ? $values : array();
	}

	public static function validate() {
		if ( ! self::enabled() ) {
			return;
		}

		$values = array();
		$ok     = true;

		foreach ( self::active_fields() as $field ) {
			if ( ! self::condition_ok( $field ) ) {
				continue;
			}

			$type = (string) $field['type'];

			if ( 'html' === $type ) {
				continue;
			}

			if ( 'file' === $type ) {
				$name  = self::field_name( $field['id'] );
				$has   = ! empty( $_FILES[ $name ]['name'] ); // phpcs:ignore WordPress.Security.NonceVerification

				if ( ! $has && ! empty( $field['required'] ) ) {
					wc_add_notice( self::label( $field ) . ' — بارگذاری فایل الزامی است.', 'error' );
					$ok = false;
				}

				continue;
			}

			$result = self::validate_field( $field, self::raw_value( $field ) );

			$values[ $field['id'] ] = is_array( $result['value'] ) ? $result['value'] : (string) $result['value'];

			if ( '' !== $result['error'] ) {
				wc_add_notice( self::label( $field ) . ' — ' . $result['error'], 'error' );
				$ok = false;
			}
		}

		if ( function_exists( 'WC' ) && WC()->session ) {
			WC()->session->set( self::SESSION_KEY, $values );
		}

		do_action( 'bmc_checkout_fields_validated', $ok, $values );
	}

	public static function store_upload( $field ) {
		$name = self::field_name( $field['id'] );

		if ( empty( $_FILES[ $name ]['name'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return null;
		}

		if ( ! class_exists( 'BMC_Forms' ) ) {
			return null;
		}

		$stored = BMC_Forms::store_file(
			array(
				'name'     => isset( $_FILES[ $name ]['name'] ) ? sanitize_file_name( (string) $_FILES[ $name ]['name'] ) : '', // phpcs:ignore WordPress.Security.NonceVerification
				'type'     => isset( $_FILES[ $name ]['type'] ) ? (string) $_FILES[ $name ]['type'] : '', // phpcs:ignore WordPress.Security.NonceVerification
				'tmp_name' => isset( $_FILES[ $name ]['tmp_name'] ) ? (string) $_FILES[ $name ]['tmp_name'] : '', // phpcs:ignore WordPress.Security.NonceVerification
				'error'    => isset( $_FILES[ $name ]['error'] ) ? (int) $_FILES[ $name ]['error'] : 0, // phpcs:ignore WordPress.Security.NonceVerification
				'size'     => isset( $_FILES[ $name ]['size'] ) ? (int) $_FILES[ $name ]['size'] : 0, // phpcs:ignore WordPress.Security.NonceVerification
			),
			isset( $field['accept'] ) ? (string) $field['accept'] : ''
		);

		if ( is_wp_error( $stored ) ) {
			return null;
		}

		return $stored;
	}

	public static function save( $order, $posted = array() ) {
		if ( ! self::enabled() || ! is_object( $order ) || ! method_exists( $order, 'update_meta_data' ) ) {
			return;
		}

		$summary = array();

		foreach ( self::active_fields() as $field ) {
			$type = (string) $field['type'];

			if ( 'html' === $type ) {
				continue;
			}

			if ( ! self::condition_ok( $field ) ) {
				continue;
			}

			if ( 'file' === $type ) {
				$stored = self::store_upload( $field );

				if ( $stored && ! empty( $stored['url'] ) ) {
					if ( ! empty( $field['save_meta'] ) ) {
						$order->update_meta_data( self::meta_key( $field['id'] ), (string) $stored['url'] );
					}

					$summary[] = array(
						'id'    => (string) $field['id'],
						'label' => self::label( $field ),
						'value' => (string) $stored['name'],
						'url'   => (string) $stored['url'],
					);
				}

				continue;
			}

			$result = self::validate_field( $field, self::raw_value( $field ) );
			$value  = $result['value'];

			if ( is_array( $value ) ) {
				$value = implode( '، ', array_filter( array_map( 'sanitize_text_field', $value ), 'strlen' ) );
			}

			$value = is_scalar( $value ) ? (string) $value : '';

			if ( ! empty( $field['save_meta'] ) ) {
				$order->update_meta_data( self::meta_key( $field['id'] ), $value );
			}

			if ( '' !== $value ) {
				$summary[] = array(
					'id'    => (string) $field['id'],
					'label' => self::label( $field ),
					'value' => $value,
				);
			}
		}

		$order->update_meta_data( self::SUMMARY_KEY, $summary );

		if ( function_exists( 'WC' ) && WC()->session ) {
			WC()->session->__unset( self::SESSION_KEY );
		}

		self::reset_cache();
	}

	public static function values_from_order( $order ) {
		if ( ! is_object( $order ) || ! method_exists( $order, 'get_meta' ) ) {
			return array();
		}

		$summary = $order->get_meta( self::SUMMARY_KEY, true );

		if ( is_array( $summary ) && $summary ) {
			return $summary;
		}

		$out = array();

		foreach ( self::custom_fields() as $field ) {
			$value = $order->get_meta( self::meta_key( $field['id'] ), true );

			if ( '' === $value || null === $value ) {
				continue;
			}

			$row = array(
				'id'    => (string) $field['id'],
				'label' => self::label( $field ),
				'value' => (string) $value,
			);

			if ( 'file' === $field['type'] ) {
				$row['url'] = (string) $value;
			}

			$out[] = $row;
		}

		return $out;
	}

	public static function render_admin( $order ) {
		$rows = self::values_from_order( $order );

		if ( ! $rows ) {
			return;
		}

		echo '<div class="bmc-order-custom"><h3>' . esc_html__( 'اطلاعات تکمیلی خرید (BazzarMc)', 'bazzarmc' ) . '</h3>';
		echo '<table class="widefat striped bmc-order-custom__table"><tbody>';

		foreach ( $rows as $row ) {
			if ( empty( $row['label'] ) ) {
				continue;
			}

			$field = ! empty( $row['id'] ) ? self::find( $row['id'] ) : null;

			if ( $field && empty( $field['admin_show'] ) ) {
				continue;
			}

			echo '<tr><th style="width:35%">' . esc_html( (string) $row['label'] ) . '</th><td>';

			if ( ! empty( $row['url'] ) ) {
				echo '<a href="' . esc_url( (string) $row['url'] ) . '" target="_blank" rel="noopener">' . esc_html( (string) $row['value'] ) . '</a>';
			} else {
				echo esc_html( (string) $row['value'] );
			}

			echo '</td></tr>';
		}

		echo '</tbody></table></div>';
	}

	public static function email_fields( $fields, $sent_to_admin = false, $order = null ) {
		if ( ! is_array( $fields ) ) {
			$fields = array();
		}

		$rows = self::values_from_order( $order );

		foreach ( $rows as $index => $row ) {
			$field = isset( $row['id'] ) ? self::find( $row['id'] ) : null;

			if ( $field && empty( $field['email_show'] ) ) {
				continue;
			}

			$fields[ 'bmc_custom_' . $index ] = array(
				'label' => (string) $row['label'],
				'value' => (string) $row['value'],
			);
		}

		return $fields;
	}

	public static function render_thankyou( $order_id ) {
		$order = function_exists( 'wc_get_order' ) ? wc_get_order( $order_id ) : null;

		if ( ! $order ) {
			return;
		}

		$rows = self::values_from_order( $order );

		if ( ! $rows ) {
			return;
		}

		echo '<section class="bmc-card bmc-card--custom bmc-thankyou-custom"><div class="bmc-card__head"><h3 class="bmc-card__title"><span class="bmc-dot"></span> اطلاعات تکمیلی سفارش</h3></div><ul class="bmc-custom-list">';

		foreach ( $rows as $row ) {
			$field = ! empty( $row['id'] ) ? self::find( $row['id'] ) : null;

			if ( $field && empty( $field['admin_show'] ) ) {
				continue;
			}

			echo '<li><span>' . esc_html( (string) $row['label'] ) . '</span><strong>';

			if ( ! empty( $row['url'] ) ) {
				echo '<a href="' . esc_url( (string) $row['url'] ) . '" target="_blank" rel="noopener">' . esc_html( (string) $row['value'] ) . '</a>';
			} else {
				echo esc_html( (string) $row['value'] );
			}

			echo '</strong></li>';
		}

		echo '</ul></section>';
	}

	public static function inject_plan( $plan, $fields = array(), $layout = array() ) {
		if ( ! self::enabled() ) {
			return $plan;
		}

		if ( ! is_array( $plan ) ) {
			$plan = array();
		}

		$columns = isset( $layout['columns'] ) ? (int) $layout['columns'] : 2;
		$session = self::session_values();

		foreach ( self::active_fields() as $index => $field ) {
			$section = isset( $plan[ $field['section'] ] ) ? $field['section'] : 'buyer';

			if ( ! isset( $plan[ $section ] ) || ! is_array( $plan[ $section ] ) ) {
				$plan[ $section ] = array();
			}

			$width = 1 === $columns ? 100 : (int) $field['width'];

			if ( in_array( $field['type'], array( 'hidden', 'html' ), true ) ) {
				$width = 100;
			}

			$value = isset( $session[ $field['id'] ] ) ? $session[ $field['id'] ] : (string) $field['default'];
			$order = (int) $field['order'] > 0 ? (int) $field['order'] : 600 + $index;

			$plan[ $section ][] = array(
				'key'    => self::field_name( $field['id'] ),
				'field'  => array(
					'label'    => (string) $field['label'],
					'type'     => (string) $field['type'],
					'required' => (bool) $field['required'],
				),
				'width'  => $width,
				'order'  => $order,
				'group'  => 'bmc',
				'custom' => true,
				'cf'     => $field,
				'value'  => $value,
			);
		}

		foreach ( $plan as $section => $rows ) {
			if ( ! is_array( $rows ) ) {
				continue;
			}

			usort(
				$plan[ $section ],
				function ( $a, $b ) {
					$oa = isset( $a['order'] ) ? (int) $a['order'] : 500;
					$ob = isset( $b['order'] ) ? (int) $b['order'] : 500;

					return $oa <=> $ob;
				}
			);
		}

		return $plan;
	}

	public static function render_field_row( $field, $value = '', $width = 100, $error = '' ) {
		$id       = isset( $field['id'] ) ? (string) $field['id'] : '';
		$name     = self::field_name( $id );
		$type     = isset( $field['type'] ) ? (string) $field['type'] : 'text';
		$label    = self::label( $field );
		$required = ! empty( $field['required'] );
		$help     = isset( $field['help'] ) ? (string) $field['help'] : '';
		$holder   = isset( $field['placeholder'] ) ? (string) $field['placeholder'] : ( 'html' === $type || 'hidden' === $type ? '' : $label );
		$width    = (int) $width > 0 ? (int) $width : 100;
		$attrs    = '';

		if ( ! empty( $field['show_if'] ) ) {
			$attrs .= ' data-bmc-show-if="' . esc_attr( (string) $field['show_if'] ) . '"';
			$attrs .= ' data-bmc-show-is="' . esc_attr( (string) $field['show_if_is'] ) . '"';
		}

		if ( 'hidden' === $type ) {
			printf( '<input type="hidden" name="%1$s" value="%2$s" />', esc_attr( $name ), esc_attr( isset( $field['default'] ) ? (string) $field['default'] : '' ) );
			return;
		}

		if ( $required && ! in_array( $type, array( 'hidden', 'html' ), true ) ) {
			$attrs .= ' data-bmc-required="1"';
		}

		echo '<div class="bmc-col-' . esc_attr( $width ) . ' bmc-cf" data-bmc-cf="' . esc_attr( $id ) . '" data-bmc-type="' . esc_attr( $type ) . '"' . $attrs . '>'; // phpcs:ignore WordPress.Security.EscapeOutput

		if ( 'html' === $type ) {
			echo '<div class="bmc-html">';

			if ( '' !== $label ) {
				echo '<strong>' . wp_kses_post( $label ) . '</strong>';
			}

			echo wp_kses_post( $help ? $help : ( isset( $field['default'] ) ? (string) $field['default'] : '' ) );
			echo '</div></div>';
			return;
		}

		if ( 'checkbox' === $type ) {
			echo '<label class="bmc-check bmc-cf__check' . ( $required ? ' is-required' : '' ) . '">';
			printf( '<input type="checkbox" name="%1$s" id="%1$s" value="1" %2$s />', esc_attr( $name ), checked( ! empty( $value ), true, false ) );
			echo '<span>' . esc_html( $label ) . ( $required ? ' <em class="req">*</em>' : '' ) . '</span>';
			echo '</label>';

			if ( $help ) {
				echo '<p class="bmc-hint">' . wp_kses_post( $help ) . '</p>';
			}

			if ( $error ) {
				echo '<p class="bmc-error">' . esc_html( $error ) . '</p>';
			}

			echo '</div>';
			return;
		}

		echo '<div class="bmc-field">';

		if ( '' !== $label ) {
			printf(
				'<label class="bmc-label" for="%1$s">%2$s%3$s</label>',
				esc_attr( $name ),
				esc_html( $label ),
				$required ? ' <span class="req">*</span>' : ''
			);
		}

		switch ( $type ) {
			case 'textarea':
				printf(
					'<textarea class="bmc-input bmc-textarea" name="%1$s" id="%1$s" rows="%2$d" placeholder="%3$s"%4$s>%5$s</textarea>',
					esc_attr( $name ),
					isset( $field['rows'] ) ? max( 2, (int) $field['rows'] ) : 4,
					esc_attr( $holder ),
					$required ? 'required' : '',
					esc_textarea( is_array( $value ) ? implode( '، ', $value ) : (string) $value )
				);
				break;

			case 'select':
				echo '<select class="bmc-input bmc-select" name="' . esc_attr( $name ) . '" id="' . esc_attr( $name ) . '"' . ( $required ? ' required' : '' ) . '>';

				if ( ! $required ) {
					echo '<option value="">' . esc_html( $holder ? $holder : 'انتخاب کنید…' ) . '</option>';
				}

				foreach ( (array) $field['options'] as $option ) {
					printf(
						'<option value="%1$s"%2$s>%3$s</option>',
						esc_attr( (string) $option['value'] ),
						selected( (string) $value, (string) $option['value'], false ),
						esc_html( (string) $option['label'] )
					);
				}

				echo '</select>';
				break;

			case 'radio':
				echo '<div class="bmc-radios">';

				foreach ( (array) $field['options'] as $option ) {
					echo '<label class="bmc-radio">';
					printf(
						'<input type="radio" name="%1$s" value="%2$s"%3$s />',
						esc_attr( $name ),
						esc_attr( (string) $option['value'] ),
						checked( (string) $value, (string) $option['value'], false )
					);
					echo '<span>' . esc_html( (string) $option['label'] ) . '</span></label>';
				}

				echo '</div>';
				break;

			case 'checkbox_group':
				$checked_values = is_array( $value ) ? array_map( 'strval', $value ) : array_filter( array_map( 'trim', explode( '،', (string) $value ) ), 'strlen' );

				echo '<div class="bmc-checks">';

				foreach ( (array) $field['options'] as $option ) {
					echo '<label class="bmc-check">';
					printf(
						'<input type="checkbox" name="%1$s[]" value="%2$s"%3$s />',
						esc_attr( $name ),
						esc_attr( (string) $option['value'] ),
						checked( in_array( (string) $option['value'], $checked_values, true ), true, false )
					);
					echo '<span>' . esc_html( (string) $option['label'] ) . '</span></label>';
				}

				echo '</div>';
				break;

			case 'file':
				printf(
					'<input class="bmc-input bmc-file" type="file" name="%1$s" id="%1$s" accept="%2$s"%3$s />',
					esc_attr( $name ),
					esc_attr( isset( $field['accept'] ) ? (string) $field['accept'] : '' ),
					$required ? 'required' : ''
				);
				break;

			default:
				$input_type = 'text';
				$extra      = '';

				if ( in_array( $type, array( 'email', 'tel', 'number', 'url', 'date' ), true ) ) {
					$input_type = $type;
				}

				if ( in_array( $type, array( 'mc_username', 'national_code', 'postal_code', 'url', 'email' ), true ) ) {
					$extra .= ' dir="ltr" style="text-align:left"';
				}

				if ( 'mc_username' === $type ) {
					$extra .= ' maxlength="16" autocomplete="off" spellcheck="false"';
				}

				if ( 'national_code' === $type ) {
					$extra .= ' maxlength="10" inputmode="numeric"';
				}

				if ( 'postal_code' === $type ) {
					$extra .= ' maxlength="10" inputmode="numeric"';
				}

				if ( 'number' === $type ) {
					if ( ! empty( $field['min'] ) ) {
						$extra .= ' min="' . esc_attr( (string) $field['min'] ) . '"';
					}

					if ( ! empty( $field['max'] ) ) {
						$extra .= ' max="' . esc_attr( (string) $field['max'] ) . '"';
					}
				}

				if ( ! empty( $field['pattern'] ) ) {
					$extra .= ' pattern="' . esc_attr( (string) $field['pattern'] ) . '"';
				}

				printf(
					'<input class="bmc-input" type="%1$s" name="%2$s" id="%2$s" placeholder="%3$s" value="%4$s"%5$s%6$s />',
					esc_attr( $input_type ),
					esc_attr( $name ),
					esc_attr( $holder ),
					esc_attr( is_array( $value ) ? implode( '، ', $value ) : (string) $value ),
					$required ? 'required' : '',
					$extra // phpcs:ignore WordPress.Security.EscapeOutput
				);
				break;
		}

		if ( $help ) {
			echo '<p class="bmc-hint">' . wp_kses_post( $help ) . '</p>';
		}

		if ( $error ) {
			echo '<p class="bmc-error">' . esc_html( $error ) . '</p>';
		}

		echo '</div></div>';
	}

	public static function builder_meta() {
		$conditions = array( '' => '— بدون شرط —' );

		$conditions['billing_first_name'] = 'نام (ووکامرس)';
		$conditions['billing_last_name']  = 'نام خانوادگی (ووکامرس)';
		$conditions['billing_phone']      = 'شمارهٔ موبایل (ووکامرس)';
		$conditions['billing_email']      = 'ایمیل (ووکامرس)';
		$conditions['billing_city']       = 'شهر (ووکامرس)';
		$conditions['billing_state']      = 'استان (ووکامرس)';
		$conditions['billing_postcode']   = 'کد پستی (ووکامرس)';
		$conditions['billing_address_1']  = 'آدرس (ووکامرس)';
		$conditions['billing_company']    = 'شرکت (ووکامرس)';
		$conditions['order_comments']     = 'توضیحات سفارش (ووکامرس)';

		if ( class_exists( 'BMC_Checkout' ) ) {
			$conditions[ BMC_Checkout::FIELD_GIFT ]   = 'خرید هدیه (ماینکرافت)';
			$conditions[ BMC_Checkout::FIELD_PLAYER ] = 'نام کاربری ماینکرافت';
		}

		foreach ( self::custom_fields() as $field ) {
			$conditions[ $field['id'] ] = self::label( $field ) . ' (فیلد دلخواه)';
		}

		return array(
			'types'      => self::field_types(),
			'widths'     => self::widths(),
			'sections'   => self::sections(),
			'audiences'  => self::audiences(),
			'conditions' => $conditions,
			'prefix'     => 'checkout_custom_fields',
			'order'      => 'checkout_custom_order',
			'maxSize'    => (int) BMC_Settings::int( 'forms_max_file_size', 4, 1, 64 ),
		);
	}
}
