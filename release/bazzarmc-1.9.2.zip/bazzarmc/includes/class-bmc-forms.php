<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Forms {

	const STATUS_NEW     = 'new';
	const STATUS_READ    = 'read';
	const STATUS_ARCHIVE = 'archive';
	const STATUS_SPAM    = 'spam';

	public static $redirect = array();

	private static $inline_done = array();
	private static $dir_hooked  = false;

	public static function init() {
		add_action( 'wp_ajax_bmc_form_submit', array( __CLASS__, 'handle_ajax' ) );
		add_action( 'wp_ajax_nopriv_bmc_form_submit', array( __CLASS__, 'handle_ajax' ) );
		add_action( 'admin_post_bmc_form_submit', array( __CLASS__, 'handle_classic_post' ) );
		add_action( 'admin_post_nopriv_bmc_form_submit', array( __CLASS__, 'handle_classic_post' ) );
		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ), 6 );
	}

	public static function enabled() {
		return class_exists( 'BMC_Settings' ) && BMC_Settings::bool( 'forms_enabled', true );
	}

	public static function front_enabled() {
		if ( ! self::enabled() ) {
			return false;
		}

		if ( class_exists( 'BMC_Safe' ) && BMC_Safe::safe_mode() ) {
			return false;
		}

		return true;
	}

	public static function table() {
		return BMC_DB::table( 'forms' );
	}

	public static function entries_table() {
		return BMC_DB::table( 'form_entries' );
	}

	public static function field_types() {
		return array(
			'text'           => 'متن کوتاه',
			'textarea'       => 'متن بلند',
			'email'          => 'ایمیل',
			'tel'            => 'شمارهٔ تماس',
			'number'         => 'عدد',
			'url'            => 'آدرس وب',
			'date'           => 'تاریخ',
			'select'         => 'لیست بازشو',
			'radio'          => 'گزینه‌های رادیویی',
			'checkbox'       => 'تأیید (یک چک‌باکس)',
			'checkbox_group' => 'چند انتخابی',
			'mc_username'    => 'نام کاربری ماینکرافت',
			'file'           => 'آپلود فایل',
			'hidden'         => 'فیلد پنهان',
			'html'           => 'متن یا HTML ثابت',
		);
	}

	public static function widths() {
		return array(
			100 => 'تمام عرض',
			75  => 'سه‌چهارم',
			66  => 'دو‌سوم',
			50  => 'نصف',
			33  => 'یک‌سوم',
			25  => 'یک‌چهارم',
		);
	}

	public static function entry_statuses() {
		return array(
			self::STATUS_NEW     => 'خوانده‌نشده',
			self::STATUS_READ    => 'خوانده‌شده',
			self::STATUS_ARCHIVE => 'بایگانی',
			self::STATUS_SPAM    => 'هرزنامه',
		);
	}

	public static function allowed_mimes() {
		return array(
			'jpg|jpeg'  => 'image/jpeg',
			'png'       => 'image/png',
			'gif'       => 'image/gif',
			'webp'      => 'image/webp',
			'pdf'       => 'application/pdf',
			'zip'       => 'application/zip',
			'rar'       => 'application/x-rar-compressed',
			'doc|docx'  => 'application/msword',
			'xls|xlsx'  => 'application/vnd.ms-excel',
			'txt|csv'   => 'text/plain',
			'mp3'       => 'audio/mpeg',
			'mp4'       => 'video/mp4',
		);
	}

	public static function default_field( $index = 0, $type = 'text' ) {
		return array(
			'id'          => 'field_' . ( $index + 1 ),
			'type'        => $type,
			'label'       => '',
			'placeholder' => '',
			'help'        => '',
			'default'     => '',
			'required'    => 0,
			'width'       => 100,
			'options'     => array(),
			'min'         => 0,
			'max'         => 0,
			'rows'        => 4,
			'pattern'     => '',
			'message'     => '',
			'accept'      => '',
			'iran_phone'  => 0,
		);
	}

	public static function normalize_field( $raw, $index = 0 ) {
		$raw   = is_array( $raw ) ? $raw : array();
		$field = self::default_field( $index );

		$id = isset( $raw['id'] ) ? sanitize_key( (string) $raw['id'] ) : '';

		if ( ! $id ) {
			$id = isset( $raw['label'] ) ? sanitize_key( str_replace( '_', '-', (string) $raw['label'] ) ) : '';
		}

		$field['id'] = $id ? $id : 'field_' . ( $index + 1 );

		$type          = isset( $raw['type'] ) ? sanitize_key( (string) $raw['type'] ) : 'text';
		$field['type'] = array_key_exists( $type, self::field_types() ) ? $type : 'text';

		$field['label']       = isset( $raw['label'] ) ? sanitize_text_field( (string) $raw['label'] ) : '';
		$field['placeholder'] = isset( $raw['placeholder'] ) ? sanitize_text_field( (string) $raw['placeholder'] ) : '';
		$field['help']        = isset( $raw['help'] ) ? wp_kses_post( (string) $raw['help'] ) : '';
		$field['default']     = isset( $raw['default'] ) ? sanitize_textarea_field( (string) $raw['default'] ) : '';
		$field['required']    = empty( $raw['required'] ) ? 0 : 1;
		$field['iran_phone']  = empty( $raw['iran_phone'] ) ? 0 : 1;
		$field['message']     = isset( $raw['message'] ) ? sanitize_text_field( (string) $raw['message'] ) : '';
		$field['accept']      = isset( $raw['accept'] ) ? preg_replace( '/[^a-z0-9,\.|\s]/', '', strtolower( (string) $raw['accept'] ) ) : '';

		$width = isset( $raw['width'] ) ? (int) $raw['width'] : 100;

		if ( ! array_key_exists( $width, self::widths() ) ) {
			$width = 100;
		}

		$field['width'] = in_array( $field['type'], array( 'hidden', 'html' ), true ) ? 100 : $width;
		$field['min']   = isset( $raw['min'] ) ? max( 0, (int) $raw['min'] ) : 0;
		$field['max']   = isset( $raw['max'] ) ? max( 0, (int) $raw['max'] ) : 0;
		$field['rows']  = isset( $raw['rows'] ) ? max( 2, min( 20, (int) $raw['rows'] ) ) : 4;

		$pattern = isset( $raw['pattern'] ) ? (string) $raw['pattern'] : '';

		if ( '' !== trim( $pattern ) ) {
			$pattern = preg_replace( '/[^A-Za-z0-9_\-\|\s\.\*\+\?\^\$\(\)\[\]\{\}\\\/:@=,;!=<>%#&]/u', '', $pattern );
			$test    = @preg_match( '/' . str_replace( '/', '\/', $pattern ) . '/u', '' );

			if ( false === $test ) {
				$pattern = '';
			}
		}

		$field['pattern'] = $pattern;
		$field['options'] = self::normalize_options( isset( $raw['options'] ) ? $raw['options'] : array() );

		if ( in_array( $field['type'], array( 'select', 'radio', 'checkbox_group' ), true ) && ! $field['options'] ) {
			$field['options'] = array( array( 'value' => '1', 'label' => 'گزینهٔ ۱' ) );
		}

		if ( 'hidden' === $field['type'] ) {
			$field['required'] = 0;
			$field['label']    = $field['label'] ? $field['label'] : $field['id'];
		}

		if ( 'html' === $field['type'] ) {
			$field['required'] = 0;
			$field['help']     = isset( $raw['help'] ) ? wp_kses_post( (string) $raw['help'] ) : '';
		}

		return apply_filters( 'bmc_form_field', $field, $raw );
	}

	public static function normalize_options( $raw ) {
		if ( is_string( $raw ) ) {
			$raw = preg_split( '/\r\n|\r|\n/', $raw );
		}

		$out = array();

		foreach ( (array) $raw as $item ) {
			if ( is_array( $item ) ) {
				$value = isset( $item['value'] ) ? sanitize_text_field( (string) $item['value'] ) : '';
				$label = isset( $item['label'] ) ? sanitize_text_field( (string) $item['label'] ) : $value;
			} else {
				$line = trim( (string) $item );

				if ( '' === $line ) {
					continue;
				}

				if ( false !== strpos( $line, '|' ) ) {
					list( $value, $label ) = array_map( 'trim', explode( '|', $line, 2 ) );
				} else {
					$value = $line;
					$label = $line;
				}

				$value = sanitize_text_field( $value );
				$label = sanitize_text_field( $label );
			}

			if ( '' === $value && '' === $label ) {
				continue;
			}

			$out[] = array(
				'value' => $value,
				'label' => $label ? $label : $value,
			);
		}

		return array_slice( $out, 0, 60 );
	}

	public static function default_config() {
		return array(
			'title'               => '',
			'slug'                => '',
			'description'         => '',
			'fields'              => array(),
			'submit_text'         => 'ارسال',
			'success_message'     => (string) BMC_Settings::get( 'forms_success_message' ),
			'error_message'       => (string) BMC_Settings::get( 'forms_error_message' ),
			'labels_position'     => 'top',
			'gap'                 => 16,
			'theme'               => 'inherit',
			'accent'              => '',
			'bordered'            => 1,
			'show_title'          => 1,
			'login_required'      => 0,
			'honeypot'            => BMC_Settings::bool( 'forms_honeypot', true ) ? 1 : 0,
			'save_entries'        => 1,
			'allow_files'         => 0,
			'email_enabled'       => 0,
			'email_to'            => '',
			'email_subject'       => '',
			'webhook_enabled'     => 0,
			'webhook_url'         => '',
			'ticket_enabled'      => 0,
			'ticket_category'     => 'other',
			'ticket_priority'     => 'normal',
			'ticket_subject_field' => '',
			'ticket_body_field'   => '',
			'redirect_url'        => '',
			'status'              => 'active',
		);
	}

	public static function normalize_config( $config ) {
		$config = is_array( $config ) ? $config : array();
		$out    = self::default_config();

		foreach ( $config as $key => $value ) {
			if ( ! array_key_exists( $key, $out ) ) {
				continue;
			}

			$out[ $key ] = $value;
		}

		$out['title']       = sanitize_text_field( (string) $out['title'] );
		$out['description'] = wp_kses_post( (string) $out['description'] );
		$out['submit_text'] = sanitize_text_field( (string) $out['submit_text'] );

		if ( '' === trim( $out['submit_text'] ) ) {
			$out['submit_text'] = 'ارسال';
		}

		$out['success_message'] = sanitize_textarea_field( (string) $out['success_message'] );
		$out['error_message']   = sanitize_textarea_field( (string) $out['error_message'] );
		$out['labels_position'] = in_array( $out['labels_position'], array( 'top', 'inside' ), true ) ? $out['labels_position'] : 'top';
		$out['gap']             = max( 4, min( 48, (int) $out['gap'] ) );
		$out['theme']           = in_array( $out['theme'], array( 'inherit', 'dark', 'light' ), true ) ? $out['theme'] : 'inherit';
		$out['accent']          = preg_match( '/^#[0-9a-fA-F]{6}$/', (string) $out['accent'] ) ? $out['accent'] : '';
		$out['email_subject']   = sanitize_text_field( (string) $out['email_subject'] );
		$out['redirect_url']    = esc_url_raw( (string) $out['redirect_url'] );
		$out['webhook_url']     = esc_url_raw( (string) $out['webhook_url'] );
		$out['status']          = in_array( $out['status'], array( 'active', 'paused', 'inline' ), true ) ? $out['status'] : 'active';

		if ( ! in_array( $out['ticket_category'], array_keys( self::ticket_categories() ), true ) ) {
			$out['ticket_category'] = 'other';
		}

		if ( ! in_array( $out['ticket_priority'], array_keys( self::ticket_priorities() ), true ) ) {
			$out['ticket_priority'] = 'normal';
		}

		foreach ( array( 'bordered', 'show_title', 'login_required', 'honeypot', 'save_entries', 'allow_files', 'email_enabled', 'webhook_enabled', 'ticket_enabled' ) as $flag ) {
			$out[ $flag ] = empty( $out[ $flag ] ) ? 0 : 1;
		}

		$fields = array();
		$used   = array();

		foreach ( (array) $out['fields'] as $index => $raw ) {
			$field = self::normalize_field( $raw, $index );

			while ( isset( $used[ $field['id'] ] ) ) {
				$field['id'] .= '_2';
			}

			$used[ $field['id'] ] = true;
			$fields[]             = $field;
		}

		$out['fields'] = array_slice( $fields, 0, 60 );

		if ( ! $out['allow_files'] ) {
			$out['allow_files'] = BMC_Settings::bool( 'forms_allow_files', false ) ? 0 : 0;
		}

		return $out;
	}

	public static function ticket_categories() {
		return class_exists( 'BMC_Tickets' ) ? BMC_Tickets::categories() : array( 'other' => 'سایر' );
	}

	public static function ticket_priorities() {
		return class_exists( 'BMC_Tickets' ) ? BMC_Tickets::priorities() : array( 'normal' => 'عادی' );
	}

	public static function all( $status = '' ) {
		global $wpdb;

		$table = self::table();
		$sql   = "SELECT * FROM {$table}";

		if ( $status ) {
			$sql .= $wpdb->prepare( ' WHERE status = %s', $status );
		}

		$rows = $wpdb->get_results( $sql . ' ORDER BY id DESC' );

		return $rows ? $rows : array();
	}

	public static function choices( $include_inline = false ) {
		$out = array();

		foreach ( self::all() as $row ) {
			if ( ! $include_inline && 'inline' === $row->status ) {
				continue;
			}

			$out[ (int) $row->id ] = $row->title . ' (#' . $row->id . ')';
		}

		return $out;
	}

	public static function get( $id_or_slug ) {
		global $wpdb;

		$table = self::table();

		if ( is_numeric( $id_or_slug ) ) {
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", absint( $id_or_slug ) ) );
		} else {
			$row = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE slug = %s", sanitize_title( (string) $id_or_slug ) ) );
		}

		if ( ! $row ) {
			return null;
		}

		return self::hydrate( $row );
	}

	public static function hydrate( $row ) {
		$config = json_decode( (string) $row->config, true );

		$form = self::normalize_config( is_array( $config ) ? $config : array() );

		$form['id']         = (int) $row->id;
		$form['slug']       = (string) $row->slug;
		$form['status']     = (string) $row->status;
		$form['entries']    = (int) $row->entries;
		$form['created_at'] = (string) $row->created_at;
		$form['updated_at'] = (string) $row->updated_at;

		if ( '' === $form['title'] ) {
			$form['title'] = 'فرم #' . $form['id'];
		}

		return $form;
	}

	public static function unique_slug( $title, $exclude_id = 0 ) {
		global $wpdb;

		$table = self::table();
		$base  = sanitize_title( $title );

		if ( ! $base ) {
			$base = 'form';
		}

		$slug = $base;
		$n    = 2;

		while ( true ) {
			$exists = $wpdb->get_var( $wpdb->prepare( "SELECT id FROM {$table} WHERE slug = %s AND id != %d", $slug, absint( $exclude_id ) ) );

			if ( ! $exists ) {
				return $slug;
			}

			$slug = $base . '-' . $n;
			$n++;

			if ( $n > 200 ) {
				return $base . '-' . wp_generate_password( 4, false );
			}
		}
	}

	public static function create( array $args ) {
		global $wpdb;

		$config = self::normalize_config( $args );
		$title  = $config['title'] ? $config['title'] : 'فرم بدون نام';
		$slug   = self::unique_slug( $config['slug'] ? $config['slug'] : $title );
		$now    = BMC_Helpers::local_datetime();

		$inserted = $wpdb->insert(
			self::table(),
			array(
				'title'      => $title,
				'slug'       => $slug,
				'config'     => wp_json_encode( $config, JSON_UNESCAPED_UNICODE ),
				'status'     => $config['status'],
				'entries'    => 0,
				'created_at' => $now,
				'updated_at' => $now,
			),
			array( '%s', '%s', '%s', '%s', '%d', '%s', '%s' )
		);

		if ( false === $inserted ) {
			return new WP_Error( 'db', 'ثبت فرم ناموفق بود.' );
		}

		$id = (int) $wpdb->insert_id;

		do_action( 'bmc_form_created', $id, $config );

		return $id;
	}

	public static function update( $id, array $args ) {
		global $wpdb;

		$id   = absint( $id );
		$form = self::get( $id );

		if ( ! $form ) {
			return new WP_Error( 'missing', 'فرم پیدا نشد.' );
		}

		$config   = self::normalize_config( array_merge( $form, $args ) );
		$title    = $config['title'] ? $config['title'] : $form['title'];
		$slug     = isset( $args['slug'] ) && $args['slug'] ? self::unique_slug( $args['slug'], $id ) : $form['slug'];
		$status   = isset( $args['status'] ) && in_array( $args['status'], array( 'active', 'paused', 'inline' ), true ) ? $args['status'] : $config['status'];
		$config['slug']   = $slug;
		$config['status'] = $status;
		$config['title']  = $title;

		$updated = $wpdb->update(
			self::table(),
			array(
				'title'      => $title,
				'slug'       => $slug,
				'config'     => wp_json_encode( $config, JSON_UNESCAPED_UNICODE ),
				'status'     => $status,
				'updated_at' => BMC_Helpers::local_datetime(),
			),
			array( 'id' => $id ),
			array( '%s', '%s', '%s', '%s', '%s' ),
			array( '%d' )
		);

		if ( false === $updated ) {
			return new WP_Error( 'db', 'به‌روزرسانی فرم ناموفق بود.' );
		}

		do_action( 'bmc_form_updated', $id, $config );

		return $id;
	}

	public static function delete( $id ) {
		global $wpdb;

		$id = absint( $id );

		if ( ! $id ) {
			return 0;
		}

		$wpdb->delete( self::entries_table(), array( 'form_id' => $id ), array( '%d' ) );

		$deleted = $wpdb->delete( self::table(), array( 'id' => $id ), array( '%d' ) );

		do_action( 'bmc_form_deleted', $id );

		return (int) $deleted;
	}

	public static function duplicate( $id ) {
		$form = self::get( $id );

		if ( ! $form ) {
			return new WP_Error( 'missing', 'فرم پیدا نشد.' );
		}

		$copy             = $form;
		$copy['title']    = $form['title'] . ' (کپی)';
		$copy['slug']     = '';
		$copy['status']   = 'paused';
		$copy['entries']  = 0;

		unset( $copy['id'], $copy['created_at'], $copy['updated_at'] );

		return self::create( $copy );
	}

	public static function ensure_inline( array $config ) {
		$config  = self::normalize_config( $config );
		$payload = wp_json_encode( $config['fields'], JSON_UNESCAPED_UNICODE ) . '|' . $config['title'] . '|' . $config['submit_text'];
		$key     = 'inline-' . substr( md5( $payload . wp_salt( 'auth' ) ), 0, 14 );

		if ( isset( self::$inline_done[ $key ] ) ) {
			return self::$inline_done[ $key ];
		}

		$existing = self::get( $key );

		if ( $existing ) {
			self::update( $existing['id'], $config );
			self::$inline_done[ $key ] = $existing['id'];

			return $existing['id'];
		}

		$config['slug']   = $key;
		$config['status'] = 'inline';

		if ( ! $config['title'] ) {
			$config['title'] = 'فرم ویجت المنتور';
		}

		$id = self::create( $config );

		if ( is_wp_error( $id ) ) {
			return 0;
		}

		self::$inline_done[ $key ] = (int) $id;

		return (int) $id;
	}

	public static function register_assets() {
		if ( wp_script_is( 'bmc-form', 'registered' ) ) {
			return;
		}

		wp_register_script( 'bmc-form', BMC_URL . 'assets/js/bmc-form.js', array( 'jquery' ), BMC_VERSION, true );
	}

	public static function enqueue_assets() {
		if ( class_exists( 'BMC_Public' ) ) {
			BMC_Public::enqueue_base_assets();
		}

		self::register_assets();

		wp_enqueue_script( 'bmc-form' );

		wp_localize_script(
			'bmc-form',
			'bmcForm',
			array(
				'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
				'postUrl'  => admin_url( 'admin-post.php' ),
				'i18n'     => array(
					'required'   => 'این فیلد الزامی است.',
					'email'      => 'ایمیل معتبر وارد کنید.',
					'tel'        => 'شمارهٔ تماس معتبر وارد کنید.',
					'number'     => 'عدد معتبر وارد کنید.',
					'url'        => 'آدرس وب معتبر وارد کنید.',
					'min'        => 'حداقل طول مجاز رعایت نشده است.',
					'max'        => 'حداکثر طول مجاز رعایت نشده است.',
					'pattern'    => 'مقدار واردشده با الگوی خواسته‌شده مطابقت ندارد.',
					'player'     => 'نام کاربری ماینکرافت معتبر نیست (۳ تا ۱۶ نویسهٔ لاتین).',
					'sending'    => 'در حال ارسال…',
					'error'      => 'ارسال ناموفق بود. دوباره تلاش کنید.',
					'filelarge'  => 'حجم فایل بیش از حد مجاز است.',
					'select'     => 'یک گزینه انتخاب کنید.',
				),
				'maxSize'  => max( 1, (int) BMC_Settings::get( 'forms_max_file_size', 4 ) ) * 1048576,
			)
		);
	}

	public static function nonce( $form_id ) {
		return wp_create_nonce( 'bmc_form_' . absint( $form_id ) );
	}

	public static function render_field( $field, $values = array(), $errors = array() ) {
		$id      = (string) $field['id'];
		$name    = 'bmc_f[' . $id . ']';
		$type    = (string) $field['type'];
		$classes = array( 'bmc-form__field', 'bmc-form__field--' . $type, 'bmc-col-' . (int) $field['width'] );
		$error   = isset( $errors[ $id ] ) ? (string) $errors[ $id ] : '';
		$current = isset( $values[ $id ] ) ? $values[ $id ] : $field['default'];

		if ( $error ) {
			$classes[] = 'has-error';
		}

		if ( 'hidden' === $type ) {
			return '<input type="hidden" name="' . esc_attr( $name ) . '" value="' . esc_attr( (string) $field['default'] ) . '" />';
		}

		$html = '<div class="' . esc_attr( implode( ' ', $classes ) ) . '" data-field="' . esc_attr( $id ) . '">';

		if ( 'html' === $type ) {
			$html .= '<div class="bmc-form__static">' . wp_kses_post( $field['help'] ? $field['help'] : $field['label'] ) . '</div>';

			return $html . '</div>';
		}

		$show_label = 'inside' !== ( isset( $field['labels_position'] ) ? $field['labels_position'] : 'top' ) && '' !== $field['label'];

		if ( $show_label ) {
			$html .= '<label class="bmc-label" for="bmcf-' . esc_attr( $id ) . '">' . esc_html( $field['label'] );

			if ( ! empty( $field['required'] ) ) {
				$html .= ' <span class="req">*</span>';
			}

			$html .= '</label>';
		}

		$attrs  = ' id="bmcf-' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '"';
		$attrs .= $field['placeholder'] ? ' placeholder="' . esc_attr( $field['placeholder'] ) . '"' : '';
		$attrs .= ! empty( $field['required'] ) ? ' required="required"' : '';

		switch ( $type ) {
			case 'textarea':
				$attrs .= ' rows="' . (int) $field['rows'] . '"';

				if ( $field['max'] ) {
					$attrs .= ' maxlength="' . (int) $field['max'] . '"';
				}

				$html .= '<textarea class="bmc-input bmc-textarea"' . $attrs . '>' . esc_textarea( (string) $current ) . '</textarea>';

				if ( $field['max'] ) {
					$html .= '<span class="bmc-form__count" data-count-for="bmcf-' . esc_attr( $id ) . '">' . (int) self::mb_strlen( (string) $current ) . '/' . (int) $field['max'] . '</span>';
				}
				break;

			case 'select':
				$html .= '<select class="bmc-input bmc-select"' . $attrs . '>';
				$html .= '<option value="">' . esc_html( $field['placeholder'] ? $field['placeholder'] : '— انتخاب کنید —' ) . '</option>';

				foreach ( $field['options'] as $option ) {
					$html .= '<option value="' . esc_attr( $option['value'] ) . '" ' . selected( (string) $current, (string) $option['value'], false ) . '>' . esc_html( $option['label'] ) . '</option>';
				}

				$html .= '</select>';
				break;

			case 'radio':
				$html .= '<div class="bmc-form__choices">';

				foreach ( $field['options'] as $index => $option ) {
					$oid = 'bmcf-' . $id . '-' . $index;

					$html .= '<label class="bmc-check" for="' . esc_attr( $oid ) . '">'
						. '<input type="radio" id="' . esc_attr( $oid ) . '" name="' . esc_attr( $name ) . '" value="' . esc_attr( $option['value'] ) . '" ' . checked( (string) $current, (string) $option['value'], false ) . ' />'
						. '<span>' . esc_html( $option['label'] ) . '</span></label>';
				}

				$html .= '</div>';
				break;

			case 'checkbox':
				$html .= '<label class="bmc-check bmc-check--single" for="bmcf-' . esc_attr( $id ) . '">'
					. '<input type="checkbox" id="bmcf-' . esc_attr( $id ) . '" name="' . esc_attr( $name ) . '" value="1" ' . checked( ! empty( $current ), true, false ) . ' />'
					. '<span>' . esc_html( $field['label'] ? $field['label'] : 'تأیید می‌کنم' ) . '</span></label>';
				break;

			case 'checkbox_group':
				$current_group = is_array( $current ) ? array_map( 'strval', $current ) : array();
				$html         .= '<div class="bmc-form__choices">';

				foreach ( $field['options'] as $index => $option ) {
					$oid = 'bmcf-' . $id . '-' . $index;

					$html .= '<label class="bmc-check" for="' . esc_attr( $oid ) . '">'
						. '<input type="checkbox" id="' . esc_attr( $oid ) . '" name="' . esc_attr( $name ) . '[]" value="' . esc_attr( $option['value'] ) . '" ' . checked( in_array( (string) $option['value'], $current_group, true ), true, false ) . ' />'
						. '<span>' . esc_html( $option['label'] ) . '</span></label>';
				}

				$html .= '</div>';
				break;

			case 'file':
				$html .= '<label class="bmc-form__file" for="bmcf-' . esc_attr( $id ) . '">'
					. '<span class="bmc-form__fileicon">' . bmc_get_icon( 'upload_file', array( 'size' => 20 ) ) . '</span>'
					. '<span class="bmc-form__filetext">' . esc_html( $field['placeholder'] ? $field['placeholder'] : 'انتخاب فایل' ) . '</span>'
					. '<input type="file" id="bmcf-' . esc_attr( $id ) . '" name="bmc_files[' . esc_attr( $id ) . ']"'
					. ( $field['accept'] ? ' accept="' . esc_attr( $field['accept'] ) . '"' : '' )
					. ( ! empty( $field['required'] ) ? ' required="required"' : '' ) . ' />'
					. '</label>';
				break;

			case 'mc_username':
				$html .= '<div class="bmc-form__player">'
					. '<span class="bmc-avatar bmc-avatar--sm"><img data-bmc-head-for="bmcf-' . esc_attr( $id ) . '" src="' . esc_url( BMC_Helpers::mc_head( 'MHF_Question', 48 ) ) . '" alt="" /></span>'
					. '<input class="bmc-input" type="text" dir="ltr" style="text-align:left;font-family:Consolas,monospace" maxlength="16"' . $attrs . ' value="' . esc_attr( (string) $current ) . '" />'
					. '</div>';
				break;

			case 'date':
				$html .= '<input class="bmc-input" type="date"' . $attrs . ' value="' . esc_attr( (string) $current ) . '" />';
				break;

			case 'number':
				$extra = '';

				if ( $field['min'] ) {
					$extra .= ' min="' . (int) $field['min'] . '"';
				}

				if ( $field['max'] ) {
					$extra .= ' max="' . (int) $field['max'] . '"';
				}

				$html .= '<input class="bmc-input" type="number" inputmode="numeric"' . $extra . $attrs . ' value="' . esc_attr( (string) $current ) . '" />';
				break;

			case 'tel':
				$html .= '<input class="bmc-input" type="tel" dir="ltr" inputmode="tel" style="text-align:left"' . $attrs . ' value="' . esc_attr( (string) $current ) . '" />';
				break;

			case 'email':
				$html .= '<input class="bmc-input" type="email" dir="ltr" style="text-align:left"' . $attrs . ' value="' . esc_attr( (string) $current ) . '" />';
				break;

			case 'url':
				$html .= '<input class="bmc-input" type="url" dir="ltr" style="text-align:left"' . $attrs . ' value="' . esc_attr( (string) $current ) . '" />';
				break;

			default:
				$extra = '';

				if ( $field['max'] ) {
					$extra .= ' maxlength="' . (int) $field['max'] . '"';
				}

				$html .= '<input class="bmc-input" type="text"' . $extra . $attrs . ' value="' . esc_attr( (string) $current ) . '" />';
				break;
		}

		if ( $field['help'] && 'html' !== $type ) {
			$html .= '<p class="bmc-hint">' . wp_kses_post( $field['help'] ) . '</p>';
		}

		$html .= '<p class="bmc-form__error" data-error-for="' . esc_attr( $id ) . '"' . ( $error ? '' : ' style="display:none"' ) . '>' . esc_html( $error ) . '</p>';

		return $html . '</div>';
	}

	public static function mb_strlen( $string ) {
		return function_exists( 'mb_strlen' ) ? mb_strlen( (string) $string ) : strlen( (string) $string );
	}

	public static function render( $form, array $overrides = array() ) {
		if ( ! self::front_enabled() ) {
			return class_exists( 'BMC_Safe' ) ? BMC_Safe::blocked_box( 'فرم‌های BazzarMc موقتاً غیرفعال است' ) : '';
		}

		if ( is_numeric( $form ) || is_string( $form ) ) {
			$form = self::get( $form );
		}

		if ( is_array( $form ) && empty( $form['id'] ) ) {
			$id   = self::ensure_inline( $form );
			$form = $id ? self::get( $id ) : null;
		}

		if ( ! $form || ! is_array( $form ) ) {
			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">فرم موردنظر پیدا نشد.</div></div>';
		}

		if ( 'paused' === $form['status'] && ! ( function_exists( 'current_user_can' ) && current_user_can( 'manage_woocommerce' ) ) ) {
			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">این فرم موقتاً غیرفعال است.</div></div>';
		}

		if ( $overrides ) {
			$form = self::normalize_config( array_merge( $form, $overrides ) );
			$form['id']     = isset( $overrides['id'] ) ? (int) $overrides['id'] : 0;
			$form['status'] = 'active';
		}

		self::enqueue_assets();

		ob_start();

		$bmc_form = $form;

		include BMC_PATH . 'public/templates/form.php';

		return (string) ob_get_clean();
	}

	public static function shortcode( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'id'      => 0,
				'slug'    => '',
				'title'   => '',
				'submit'  => '',
				'theme'   => '',
				'accent'  => '',
			),
			$atts,
			'bazzarmc_form'
		);

		$overrides = array();

		if ( $atts['title'] ) {
			$overrides['title'] = $atts['title'];
		}

		if ( $atts['submit'] ) {
			$overrides['submit_text'] = $atts['submit'];
		}

		if ( in_array( $atts['theme'], array( 'dark', 'light' ), true ) ) {
			$overrides['theme'] = $atts['theme'];
		}

		if ( preg_match( '/^#[0-9a-fA-F]{6}$/', (string) $atts['accent'] ) ) {
			$overrides['accent'] = $atts['accent'];
		}

		$target = $atts['id'] ? (int) $atts['id'] : ( $atts['slug'] ? $atts['slug'] : 0 );

		if ( ! $target ) {
			$forms = self::all( 'active' );
			$target = $forms ? (int) $forms[0]->id : 0;
		}

		if ( ! $target ) {
			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">هیچ فرمی ساخته نشده است. از پیشخوان ← BazzarMc ← فرم‌ها یک فرم بسازید.</div></div>';
		}

		return self::render( $target, $overrides );
	}

	public static function validate_field( $field, $value ) {
		$field   = array_merge( self::default_field(), is_array( $field ) ? $field : array() );
		$type    = (string) $field['type'];
		$error   = '';
		$custom  = (string) $field['message'];

		if ( is_array( $value ) && 'checkbox_group' !== $type ) {
			$value = implode( ', ', array_filter( array_map( 'sanitize_text_field', $value ), 'strlen' ) );
		}
		$empty   = ( is_array( $value ) ? ! array_filter( $value, 'strlen' ) : '' === trim( (string) $value ) );

		if ( in_array( $type, array( 'html', 'hidden' ), true ) ) {
			return array( 'value' => (string) $field['default'], 'error' => '' );
		}

		if ( $empty ) {
			if ( ! empty( $field['required'] ) ) {
				$error = $custom ? $custom : ( 'checkbox' === $type ? 'این گزینه باید تأیید شود.' : 'این فیلد الزامی است.' );
			}

			return array( 'value' => '', 'error' => $error );
		}

		switch ( $type ) {
			case 'email':
				$value = sanitize_email( (string) $value );

				if ( ! is_email( $value ) ) {
					$error = $custom ? $custom : 'ایمیل معتبر وارد کنید.';
					$value = '';
				}
				break;

			case 'tel':
				$raw = preg_replace( '/[^0-9+\-\s]/', '', (string) $value );

				if ( ! empty( $field['iran_phone'] ) ) {
					$normalized = BMC_Helpers::normalize_mobile( $raw );

					if ( ! $normalized ) {
						$error = $custom ? $custom : 'شمارهٔ موبایل ایرانی معتبر وارد کنید (مثل ۰۹۱۲۳۴۵۶۷۸۹).';
						$value = '';
						break;
					}

					$value = $normalized;
					break;
				}

				if ( self::mb_strlen( $raw ) < 6 || self::mb_strlen( $raw ) > 20 ) {
					$error = $custom ? $custom : 'شمارهٔ تماس معتبر وارد کنید.';
					$value = '';
					break;
				}

				$value = $raw;
				break;

			case 'number':
				if ( ! is_numeric( $value ) ) {
					$error = $custom ? $custom : 'عدد معتبر وارد کنید.';
					$value = '';
					break;
				}

				$number = (float) $value;

				if ( $field['min'] && $number < (float) $field['min'] ) {
					$error = 'مقدار نباید کمتر از ' . BMC_Helpers::to_persian_digits( $field['min'] ) . ' باشد.';
				}

				if ( $field['max'] && $number > (float) $field['max'] ) {
					$error = 'مقدار نباید بیشتر از ' . BMC_Helpers::to_persian_digits( $field['max'] ) . ' باشد.';
				}

				$value = $error ? '' : (string) $number;
				break;

			case 'url':
				$value = esc_url_raw( (string) $value );

				if ( ! preg_match( '~^https?://~i', (string) $value ) ) {
					$error = $custom ? $custom : 'آدرس وب معتبر وارد کنید.';
					$value = '';
				}
				break;

			case 'date':
				$value = sanitize_text_field( (string) $value );

				if ( ! preg_match( '/^\d{4}-\d{2}-\d{2}$/', $value ) ) {
					$error = $custom ? $custom : 'تاریخ را به شکل معتبر وارد کنید.';
					$value = '';
				}
				break;

			case 'select':
			case 'radio':
				$value   = sanitize_text_field( is_array( $value ) ? implode( ', ', $value ) : (string) $value );
				$allowed = wp_list_pluck( (array) $field['options'], 'value' );

				if ( ! in_array( $value, $allowed, true ) ) {
					$error = $custom ? $custom : 'گزینهٔ معتبر انتخاب کنید.';
					$value = '';
				}
				break;

			case 'checkbox_group':
				$allowed = wp_list_pluck( (array) $field['options'], 'value' );
				$clean   = array();

				foreach ( (array) $value as $item ) {
					$item = sanitize_text_field( (string) $item );

					if ( in_array( $item, $allowed, true ) && ! in_array( $item, $clean, true ) ) {
						$clean[] = $item;
					}
				}

				if ( $field['min'] && count( $clean ) < (int) $field['min'] ) {
					$error = 'حداقل ' . BMC_Helpers::to_persian_digits( $field['min'] ) . ' گزینه را انتخاب کنید.';
				}

				if ( $field['max'] && count( $clean ) > (int) $field['max'] ) {
					$error = 'حداکثر ' . BMC_Helpers::to_persian_digits( $field['max'] ) . ' گزینه انتخاب کنید.';
				}

				$value = $clean;
				break;

			case 'checkbox':
				$value = empty( $value ) ? '' : '1';
				break;

			case 'mc_username':
				$value = sanitize_text_field( (string) $value );

				if ( ! BMC_Helpers::valid_player_name( $value ) ) {
					$error = $custom ? $custom : 'نام کاربری ماینکرافت معتبر نیست (۳ تا ۱۶ نویسهٔ لاتین، عدد و _).';
					$value = '';
				}
				break;

			case 'textarea':
				$value = sanitize_textarea_field( (string) $value );

				if ( $field['max'] && self::mb_strlen( $value ) > (int) $field['max'] ) {
					$error = 'متن طولانی است (حداکثر ' . BMC_Helpers::to_persian_digits( $field['max'] ) . ' نویسه).';
					$value = '';
					break;
				}

				if ( $field['min'] && self::mb_strlen( $value ) < (int) $field['min'] ) {
					$error = 'متن کوتاه است (حداقل ' . BMC_Helpers::to_persian_digits( $field['min'] ) . ' نویسه).';
					$value = '';
					break;
				}
				break;

			default:
				$value = sanitize_text_field( (string) $value );

				if ( $field['max'] && self::mb_strlen( $value ) > (int) $field['max'] ) {
					$error = 'حداکثر طول مجاز ' . BMC_Helpers::to_persian_digits( $field['max'] ) . ' نویسه است.';
					$value = '';
					break;
				}

				if ( $field['min'] && self::mb_strlen( $value ) < (int) $field['min'] ) {
					$error = 'حداقل طول مجاز ' . BMC_Helpers::to_persian_digits( $field['min'] ) . ' نویسه است.';
					$value = '';
					break;
				}
				break;
		}

		if ( ! $error && ! empty( $field['pattern'] ) && ! is_array( $value ) && '' !== (string) $value ) {
			$delimiter = '/' . str_replace( '/', '\/', (string) $field['pattern'] ) . '/u';
			$matched   = @preg_match( $delimiter, (string) $value );

			if ( false !== $matched && ! $matched ) {
				$error = $custom ? $custom : 'مقدار واردشده با الگوی خواسته‌شده مطابقت ندارد.';
				$value = '';
			}
		}

		return array( 'value' => $value, 'error' => $error );
	}

	public static function rate_limit_ok( $form_id ) {
		$interval = max( 5, (int) BMC_Settings::get( 'forms_rate_limit', 60 ) );
		$ip_key   = 'bmc_form_rl_' . absint( $form_id ) . '_' . md5( BMC_Helpers::client_ip() );

		if ( get_transient( $ip_key ) ) {
			return array( 'ok' => false, 'message' => 'خیلی سریع ارسال کردید. کمی صبر کنید و دوباره تلاش کنید.' );
		}

		$per_day = (int) BMC_Settings::get( 'forms_max_per_day', 25 );

		if ( $per_day > 0 ) {
			$day_key = 'bmc_form_day_' . absint( $form_id ) . '_' . md5( BMC_Helpers::client_ip() ) . '_' . gmdate( 'Ymd' );
			$hits    = (int) get_transient( $day_key );

			if ( $hits >= $per_day ) {
				return array( 'ok' => false, 'message' => 'سقف ارسال روزانهٔ این فرم برای شما پر شده است.' );
			}

			set_transient( $day_key, $hits + 1, DAY_IN_SECONDS );
		}

		set_transient( $ip_key, time(), $interval );

		return array( 'ok' => true, 'message' => '' );
	}

	public static function handle_files( $form, array $files ) {
		$uploaded = array();
		$errors   = array();

		if ( empty( $files ) || empty( $_FILES['bmc_files'] ) || empty( $form['allow_files'] ) ) {
			return array( 'files' => $uploaded, 'errors' => $errors );
		}

		$max_mb   = max( 1, (int) BMC_Settings::get( 'forms_max_file_size', 4 ) );
		$max_size = $max_mb * 1048576;

		foreach ( $form['fields'] as $field ) {
			if ( 'file' !== $field['type'] ) {
				continue;
			}

			$id = (string) $field['id'];

			if ( empty( $files['name'][ $id ] ) ) {
				if ( ! empty( $field['required'] ) ) {
					$errors[ $id ] = 'بارگذاری فایل الزامی است.';
				}

				continue;
			}

			if ( (int) $files['size'][ $id ] > $max_size ) {
				$errors[ $id ] = 'حجم فایل بیشتر از ' . BMC_Helpers::to_persian_digits( $max_mb ) . ' مگابایت است.';
				continue;
			}

			if ( ! empty( $files['error'][ $id ] ) ) {
				$errors[ $id ] = 'بارگذاری فایل ناموفق بود (کد ' . (int) $files['error'][ $id ] . ').';
				continue;
			}

			$file = array(
				'name'     => (string) $files['name'][ $id ],
				'type'     => (string) $files['type'][ $id ],
				'tmp_name' => (string) $files['tmp_name'][ $id ],
				'error'    => (int) $files['error'][ $id ],
				'size'     => (int) $files['size'][ $id ],
			);

			$result = self::store_file( $file, (string) $field['accept'] );

			if ( is_wp_error( $result ) ) {
				$errors[ $id ] = $result->get_error_message();
				continue;
			}

			$uploaded[ $id ] = $result;
		}

		return array( 'files' => $uploaded, 'errors' => $errors );
	}

	public static function store_file( array $file, $accept = '' ) {
		if ( ! function_exists( 'wp_handle_upload' ) ) {
			require_once ABSPATH . 'wp-admin/includes/file.php';
		}

		if ( ! function_exists( 'wp_handle_upload' ) ) {
			return new WP_Error( 'files', 'بارگذاری فایل در این سرور ممکن نیست.' );
		}

		$dir = self::upload_dir();

		if ( is_wp_error( $dir ) ) {
			return $dir;
		}

		$mimes = self::allowed_mimes();

		if ( $accept ) {
			$wanted = array_filter( array_map( 'trim', preg_split( '/[,\s|]+/', strtolower( (string) $accept ) ) ) );
			$mimes  = array();

			foreach ( self::allowed_mimes() as $exts => $mime ) {
				foreach ( explode( '|', $exts ) as $ext ) {
					if ( in_array( '.' . $ext, $wanted, true ) || in_array( $ext, $wanted, true ) || in_array( $mime, $wanted, true ) ) {
						$mimes[ $exts ] = $mime;
						break;
					}
				}
			}

			if ( ! $mimes ) {
				$mimes = self::allowed_mimes();
			}
		}

		self::$dir_hooked = true;
		add_filter( 'upload_dir', array( __CLASS__, 'filter_upload_dir' ), 20 );

		$stored = wp_handle_upload( $file, array( 'test_form' => false, 'mimes' => $mimes, 'unique_filename_callback' => array( __CLASS__, 'unique_filename' ) ) );

		remove_filter( 'upload_dir', array( __CLASS__, 'filter_upload_dir' ), 20 );
		self::$dir_hooked = false;

		if ( isset( $stored['error'] ) ) {
			return new WP_Error( 'upload', (string) $stored['error'] );
		}

		return array(
			'name' => isset( $stored['file'] ) ? basename( (string) $stored['file'] ) : (string) $file['name'],
			'url'  => isset( $stored['url'] ) ? (string) $stored['url'] : '',
			'type' => isset( $stored['type'] ) ? (string) $stored['type'] : '',
			'size' => (int) $file['size'],
		);
	}

	public static function upload_dir() {
		$uploads = function_exists( 'wp_upload_dir' ) ? wp_upload_dir() : array();

		if ( empty( $uploads['basedir'] ) ) {
			return new WP_Error( 'uploads', 'پوشهٔ بارگذاری در دسترس نیست.' );
		}

		$dir = trailingslashit( $uploads['basedir'] ) . 'bazzarmc-forms';

		if ( ! file_exists( $dir ) && ! wp_mkdir_p( $dir ) ) {
			return new WP_Error( 'uploads', 'ساخت پوشهٔ bazzarmc-forms ناموفق بود (مجوز نوشتن ندارید).' );
		}

		$htaccess = $dir . '/.htaccess';

		if ( ! file_exists( $htaccess ) ) {
			$rules = "Options -Indexes -ExecCGI\n<FilesMatch \"\\.(php|php3|php4|php5|phtml|pl|py|cgi|sh)$\">\n\tRequire all denied\n</FilesMatch>\n";

			if ( false === @file_put_contents( $htaccess, $rules ) ) {
				@file_put_contents( $dir . '/index.html', '' );
			}
		}

		return $dir;
	}

	public static function filter_upload_dir( $uploads ) {
		if ( empty( $uploads['basedir'] ) ) {
			return $uploads;
		}

		$base = trailingslashit( $uploads['basedir'] ) . 'bazzarmc-forms';
		$url  = trailingslashit( $uploads['baseurl'] ) . 'bazzarmc-forms';

		$uploads['path']   = $base;
		$uploads['url']    = $url;
		$uploads['subdir'] = '';

		return $uploads;
	}

	public static function unique_filename( $dir, $name, $ext ) {
		$name = sanitize_file_name( $name );
		$file = $dir . '/' . $name . $ext;
		$n    = 2;

		while ( file_exists( $file ) ) {
			$file = $dir . '/' . $name . '-' . $n . $ext;
			$n++;

			if ( $n > 500 ) {
				$file = $dir . '/' . $name . '-' . wp_generate_password( 6, false ) . $ext;
				break;
			}
		}

		return basename( $file );
	}

	public static function validate( $form, array $raw ) {
		$data   = array();
		$errors = array();

		foreach ( $form['fields'] as $field ) {
			$id  = (string) $field['id'];
			$raw_value = isset( $raw[ $id ] ) ? wp_unslash( $raw[ $id ] ) : '';

			$result = self::validate_field( $field, $raw_value );

			$data[ $id ] = $result['value'];

			if ( $result['error'] ) {
				$errors[ $id ] = $result['error'];
			}
		}

		return array( 'data' => $data, 'errors' => $errors );
	}

	public static function process_submission( $form, array $raw, array $files = array() ) {
		if ( ! self::front_enabled() ) {
			return array( 'success' => false, 'message' => 'ارسال فرم موقتاً غیرفعال است.', 'errors' => array() );
		}

		if ( 'active' !== $form['status'] && 'inline' !== $form['status'] ) {
			return array( 'success' => false, 'message' => 'این فرم غیرفعال است.', 'errors' => array() );
		}

		if ( ! empty( $form['login_required'] ) && ! is_user_logged_in() ) {
			return array(
				'success' => false,
				'message' => 'برای ارسال این فرم ابتدا وارد حساب کاربری شوید.',
				'errors'  => array(),
			);
		}

		$limit = self::rate_limit_ok( $form['id'] );

		if ( empty( $limit['ok'] ) ) {
			return array( 'success' => false, 'message' => $limit['message'], 'errors' => array() );
		}

		if ( ! empty( $form['honeypot'] ) && isset( $raw['__hp'] ) && '' !== trim( (string) $raw['__hp'] ) ) {
			return array(
				'success' => true,
				'message' => (string) $form['success_message'],
				'errors'  => array(),
				'silent'  => true,
			);
		}

		$result = self::validate( $form, $raw );
		$data   = $result['data'];
		$errors = $result['errors'];

		if ( $files ) {
			$handled = self::handle_files( $form, $files );
			$errors  = array_merge( $errors, $handled['errors'] );

			foreach ( $handled['files'] as $id => $info ) {
				$data[ $id ] = isset( $info['url'] ) ? $info['url'] : '';
			}

			$files = $handled['files'];
		}

		if ( $errors ) {
			return array(
				'success' => false,
				'message' => $form['error_message'] ? $form['error_message'] : 'لطفاً خطاهای مشخص‌شده را اصلاح کنید.',
				'errors'  => $errors,
				'data'    => $data,
			);
		}

		$entry_id = 0;

		if ( ! empty( $form['save_entries'] ) ) {
			$entry_id = self::save_entry( $form, $data, $files );
		}

		self::run_actions( $form, $entry_id, $data, $files );

		do_action( 'bmc_form_submitted', $form, $entry_id, $data, $files );

		return array(
			'success'  => true,
			'message'  => $form['success_message'] ? $form['success_message'] : 'ارسال شد.',
			'errors'   => array(),
			'entry_id' => $entry_id,
			'redirect' => $form['redirect_url'] ? $form['redirect_url'] : '',
		);
	}

	public static function handle_ajax() {
		$form_id = isset( $_POST['bmc_form_id'] ) ? absint( $_POST['bmc_form_id'] ) : 0;

		if ( ! $form_id ) {
			wp_send_json_error( array( 'message' => 'فرم نامعتبر است.' ), 400 );
		}

		check_ajax_referer( 'bmc_form_' . $form_id, 'bmc_form_nonce' );

		$form = self::get( $form_id );

		if ( ! $form ) {
			wp_send_json_error( array( 'message' => 'فرم پیدا نشد.' ), 404 );
		}

		$raw = isset( $_POST['bmc_f'] ) && is_array( $_POST['bmc_f'] ) ? (array) $_POST['bmc_f'] : array();

		if ( isset( $_POST['bmc_hp'] ) ) {
			$raw['__hp'] = sanitize_text_field( wp_unslash( $_POST['bmc_hp'] ) );
		}

		$result = BMC_Safe::guard(
			'forms:ajax',
			function () use ( $form, $raw ) {
				return self::process_submission( $form, $raw, isset( $_FILES['bmc_files'] ) ? (array) $_FILES['bmc_files'] : array() );
			},
			array( 'success' => false, 'message' => 'خطای غیرمنتظره در پردازش فرم.', 'errors' => array() )
		);

		if ( empty( $result['success'] ) ) {
			wp_send_json_error(
				array(
					'message' => isset( $result['message'] ) ? $result['message'] : 'ارسال ناموفق بود.',
					'errors'  => isset( $result['errors'] ) ? $result['errors'] : array(),
				),
				400
			);
		}

		wp_send_json_success(
			array(
				'message'  => $result['message'],
				'redirect' => isset( $result['redirect'] ) ? $result['redirect'] : '',
				'entry_id' => isset( $result['entry_id'] ) ? (int) $result['entry_id'] : 0,
			)
		);
	}

	public static function handle_classic_post() {
		$form_id = isset( $_POST['bmc_form_id'] ) ? absint( $_POST['bmc_form_id'] ) : 0;
		$form    = $form_id ? self::get( $form_id ) : null;
		$back    = isset( $_POST['bmc_form_back'] ) ? esc_url_raw( wp_unslash( $_POST['bmc_form_back'] ) ) : wp_get_referer();

		if ( ! $back ) {
			$back = home_url( '/' );
		}

		if ( ! $form ) {
			wp_safe_redirect( add_query_arg( array( 'bmc_form' => 'missing' ), $back ) );
			exit;
		}

		if ( ! isset( $_POST['bmc_form_nonce'] ) || ! wp_verify_nonce( sanitize_text_field( wp_unslash( $_POST['bmc_form_nonce'] ) ), 'bmc_form_' . $form_id ) ) {
			wp_safe_redirect( add_query_arg( array( 'bmc_form' => $form_id, 'bmc_form_error' => rawurlencode( 'نشست شما منقضی شده است. دوباره تلاش کنید.' ) ), $back ) );
			exit;
		}

		$raw = isset( $_POST['bmc_f'] ) && is_array( $_POST['bmc_f'] ) ? (array) $_POST['bmc_f'] : array();

		if ( isset( $_POST['bmc_hp'] ) ) {
			$raw['__hp'] = sanitize_text_field( wp_unslash( $_POST['bmc_hp'] ) );
		}

		$result = BMC_Safe::guard(
			'forms:post',
			function () use ( $form, $raw ) {
				return self::process_submission( $form, $raw, isset( $_FILES['bmc_files'] ) ? (array) $_FILES['bmc_files'] : array() );
			},
			array( 'success' => false, 'message' => 'خطای غیرمنتظره در پردازش فرم.', 'errors' => array() )
		);

		if ( ! empty( $result['redirect'] ) ) {
			wp_safe_redirect( $result['redirect'] );
			exit;
		}

		if ( empty( $result['success'] ) ) {
			wp_safe_redirect(
				add_query_arg(
					array(
						'bmc_form'       => $form_id,
						'bmc_form_error' => rawurlencode( (string) $result['message'] ),
					),
					$back
				)
			);
			exit;
		}

		wp_safe_redirect(
			add_query_arg(
				array(
					'bmc_form'    => $form_id,
					'bmc_form_ok' => rawurlencode( (string) $result['message'] ),
				),
				$back
			)
		);
		exit;
	}

	public static function save_entry( $form, array $data, array $files = array() ) {
		global $wpdb;

		$inserted = $wpdb->insert(
			self::entries_table(),
			array(
				'form_id'    => (int) $form['id'],
				'user_id'    => get_current_user_id(),
				'data'       => wp_json_encode( $data, JSON_UNESCAPED_UNICODE ),
				'files'      => $files ? wp_json_encode( $files, JSON_UNESCAPED_UNICODE ) : '',
				'ip_hash'    => BMC_Helpers::ip_hash(),
				'agent'      => substr( BMC_Helpers::user_agent(), 0, 190 ),
				'referer'    => substr( (string) ( isset( $_SERVER['HTTP_REFERER'] ) ? sanitize_text_field( wp_unslash( $_SERVER['HTTP_REFERER'] ) ) : '' ), 0, 255 ),
				'status'     => self::STATUS_NEW,
				'created_at' => BMC_Helpers::local_datetime(),
			),
			array( '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%s', '%s' )
		);

		if ( false === $inserted ) {
			return 0;
		}

		$id = (int) $wpdb->insert_id;

		$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::table() . ' SET entries = entries + 1 WHERE id = %d', (int) $form['id'] ) );

		return $id;
	}

	public static function run_actions( $form, $entry_id, array $data, array $files = array() ) {
		$done = array();

		if ( ! empty( $form['email_enabled'] ) ) {
			$done['email'] = self::send_email( $form, $entry_id, $data, $files );
		}

		if ( ! empty( $form['webhook_enabled'] ) && $form['webhook_url'] ) {
			$done['webhook'] = self::send_webhook( $form, $entry_id, $data, $files );
		}

		if ( ! empty( $form['ticket_enabled'] ) ) {
			$done['ticket'] = self::create_ticket( $form, $entry_id, $data );
		}

		$notice = (string) BMC_Settings::get( 'forms_notice_email', '' );

		if ( $notice && empty( $form['email_enabled'] ) ) {
			$done['notice'] = self::send_email( $form, $entry_id, $data, $files, $notice );
		}

		return $done;
	}

	public static function tags( $form, $entry_id, array $data ) {
		$tags = array(
			'{form}'  => (string) $form['title'],
			'{id}'    => (string) $entry_id,
			'{date}'  => class_exists( 'BMC_Jalali' ) ? BMC_Jalali::format( time(), false ) : BMC_Helpers::local_datetime(),
			'{site}'  => (string) get_bloginfo( 'name' ),
			'{user}'  => is_user_logged_in() ? wp_get_current_user()->display_name : 'مهمان',
			'{email}' => is_user_logged_in() ? wp_get_current_user()->user_email : '',
			'{ip}'    => BMC_Helpers::client_ip(),
			'{url}'   => (string) ( isset( $_SERVER['REQUEST_URI'] ) ? home_url( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) ) : home_url( '/' ) ),
		);

		foreach ( $form['fields'] as $field ) {
			$id    = (string) $field['id'];
			$value = isset( $data[ $id ] ) ? $data[ $id ] : '';

			if ( is_array( $value ) ) {
				$value = implode( '، ', array_map( 'sanitize_text_field', $value ) );
			}

			$tags[ '{' . $id . '}' ]       = (string) $value;
			$tags[ '{field_' . $id . '}' ] = (string) $value;
		}

		return $tags;
	}

	public static function send_email( $form, $entry_id, array $data, array $files = array(), $to_override = '' ) {
		$to = $to_override ? $to_override : (string) $form['email_to'];

		if ( ! $to ) {
			$to = (string) BMC_Settings::get( 'forms_notice_email', '' );
		}

		if ( ! $to ) {
			$to = (string) get_option( 'admin_email' );
		}

		$recipients = array_filter( array_map( 'trim', preg_split( '/[\s,;]+/', (string) $to ) ) );

		if ( ! $recipients ) {
			return false;
		}

		$tags    = self::tags( $form, $entry_id, $data );
		$subject = $form['email_subject'] ? $form['email_subject'] : 'ارسال جدید از فرم «{form}»';
		$subject = strtr( $subject, $tags );

		$rows = '';

		foreach ( $form['fields'] as $field ) {
			$id = (string) $field['id'];

			if ( in_array( $field['type'], array( 'hidden', 'html' ), true ) ) {
				continue;
			}

			$value = isset( $data[ $id ] ) ? $data[ $id ] : '';

			if ( is_array( $value ) ) {
				$value = implode( '، ', $value );
			}

			if ( 'file' === $field['type'] && isset( $files[ $id ]['url'] ) ) {
				$value = $files[ $id ]['url'];
			}

			if ( '' === (string) $value ) {
				$value = '—';
			}

			$rows .= '<tr><td style="padding:8px 10px;border:1px solid #e5e7eb;background:#f8fafc;font-weight:700;white-space:nowrap">'
				. esc_html( $field['label'] ? $field['label'] : $id )
				. '</td><td style="padding:8px 10px;border:1px solid #e5e7eb">'
				. ( 'url' === $field['type'] || 'file' === $field['type'] ? '<a href="' . esc_url( (string) $value ) . '">' . esc_html( (string) $value ) . '</a>' : nl2br( esc_html( (string) $value ) ) )
				. '</td></tr>';
		}

		$body = '<div dir="rtl" style="font-family:Tahoma,sans-serif">'
			. '<h3 style="margin:0 0 12px">' . esc_html( (string) $form['title'] ) . '</h3>'
			. '<table style="border-collapse:collapse;width:100%;max-width:640px;font-size:13px">' . $rows . '</table>'
			. '<p style="margin-top:14px;color:#64748b;font-size:12px">شناسهٔ ارسال: ' . (int) $entry_id . ' | کاربر: ' . esc_html( $tags['{user}'] ) . ' | IP: ' . esc_html( $tags['{ip}'] ) . '</p>'
			. '</div>';

		$headers = array( 'Content-Type: text/html; charset=UTF-8' );

		$from = (string) BMC_Settings::get( 'forms_notice_email', '' );

		if ( ! $from && ! empty( $data ) ) {
			foreach ( $form['fields'] as $field ) {
				if ( 'email' === $field['type'] && ! empty( $data[ $field['id'] ] ) ) {
					$headers[] = 'Reply-To: ' . sanitize_email( (string) $data[ $field['id'] ] );
					break;
				}
			}
		}

		$body = apply_filters( 'bmc_form_email_body', $body, $form, $entry_id, $data, $files );

		foreach ( $recipients as $recipient ) {
			wp_mail( sanitize_email( $recipient ), $subject, $body, $headers );
		}

		return true;
	}

	public static function send_webhook( $form, $entry_id, array $data, array $files = array() ) {
		$payload = array(
			'event'   => 'bazzarmc.form.submitted',
			'form'    => array(
				'id'    => (int) $form['id'],
				'title' => (string) $form['title'],
				'slug'  => (string) $form['slug'],
			),
			'entry'   => (int) $entry_id,
			'date'    => BMC_Helpers::local_datetime(),
			'user'    => array(
				'id'    => get_current_user_id(),
				'email' => is_user_logged_in() ? wp_get_current_user()->user_email : '',
			),
			'ip'      => BMC_Helpers::client_ip(),
			'data'    => $data,
			'files'   => $files,
		);

		$response = wp_remote_post(
			(string) $form['webhook_url'],
			array(
				'timeout'     => 8,
				'headers'     => array( 'Content-Type' => 'application/json' ),
				'body'        => wp_json_encode( apply_filters( 'bmc_form_webhook_payload', $payload, $form, $data ), JSON_UNESCAPED_UNICODE ),
				'sslverify'   => BMC_Settings::bool( 'ssl_verify', true ),
			)
		);

		if ( is_wp_error( $response ) ) {
			BMC_Logger::add( 'forms', 'وب‌هوک فرم «' . $form['title'] . '» ناموفق بود: ' . $response->get_error_message(), array( 'form' => (int) $form['id'] ), 'warning' );

			return false;
		}

		return true;
	}

	public static function create_ticket( $form, $entry_id, array $data ) {
		if ( ! class_exists( 'BMC_Tickets' ) || ! BMC_Tickets::enabled() ) {
			return false;
		}

		if ( ! is_user_logged_in() ) {
			BMC_Logger::add( 'forms', 'ساخت تیکت از فرم «' . $form['title'] . '» نیازمند ورود کاربر است.', array( 'form' => (int) $form['id'] ), 'info' );

			return false;
		}

		$subject = '';
		$body    = '';

		if ( $form['ticket_subject_field'] && ! empty( $data[ $form['ticket_subject_field'] ] ) ) {
			$subject = (string) $data[ $form['ticket_subject_field'] ];
		}

		if ( $form['ticket_body_field'] && ! empty( $data[ $form['ticket_body_field'] ] ) ) {
			$value = $data[ $form['ticket_body_field'] ];
			$body  = is_array( $value ) ? implode( "\n", $value ) : (string) $value;
		}

		if ( ! $subject ) {
			$subject = 'فرم ' . $form['title'];
		}

		if ( self::mb_strlen( $subject ) < 4 ) {
			$subject = 'درخواست از فرم «' . $form['title'] . '»';
		}

		$summary = '';

		foreach ( $form['fields'] as $field ) {
			$id = (string) $field['id'];

			if ( in_array( $field['type'], array( 'hidden', 'html' ), true ) || empty( $data[ $id ] ) ) {
				continue;
			}

			$value = is_array( $data[ $id ] ) ? implode( '، ', $data[ $id ] ) : $data[ $id ];
			$summary .= ( $field['label'] ? $field['label'] : $id ) . ': ' . $value . "\n";
		}

		$body = trim( $body . ( $summary ? "\n\n" . $summary : '' ) );

		if ( self::mb_strlen( $body ) < 10 ) {
			$body = $body . "\n" . 'ارسال از فرم «' . $form['title'] . '» — شناسهٔ ' . (int) $entry_id;
		}

		$ticket = BMC_Tickets::create(
			array(
				'user_id'  => get_current_user_id(),
				'subject'  => $subject,
				'body'     => $body,
				'category' => (string) $form['ticket_category'],
			)
		);

		if ( is_wp_error( $ticket ) ) {
			BMC_Logger::add( 'forms', 'ساخت تیکت از فرم ناموفق بود: ' . $ticket->get_error_message(), array( 'form' => (int) $form['id'] ), 'warning' );

			return false;
		}

		if ( $form['ticket_priority'] && 'normal' !== $form['ticket_priority'] ) {
			BMC_Tickets::set_priority( $ticket, $form['ticket_priority'] );
		}

		return (int) $ticket;
	}

	public static function entries_query( $form_id, array $args = array() ) {
		global $wpdb;

		$table    = self::entries_table();
		$form_id  = absint( $form_id );
		$per_page = isset( $args['per_page'] ) ? max( 1, min( 200, (int) $args['per_page'] ) ) : 20;
		$paged    = isset( $args['paged'] ) ? max( 1, (int) $args['paged'] ) : 1;
		$status   = isset( $args['status'] ) ? sanitize_key( (string) $args['status'] ) : '';
		$search   = isset( $args['search'] ) ? sanitize_text_field( (string) $args['search'] ) : '';
		$offset   = ( $paged - 1 ) * $per_page;

		$where  = $form_id ? $wpdb->prepare( ' WHERE form_id = %d', $form_id ) : '';
		$params = array();

		if ( $status ) {
			$where .= ( $where ? ' AND' : ' WHERE' ) . ' status = %s';
			$params[] = $status;
		}

		if ( $search ) {
			$where   .= ( $where ? ' AND' : ' WHERE' ) . ' data LIKE %s';
			$params[] = '%' . $wpdb->esc_like( $search ) . '%';
		}

		$sql = "SELECT * FROM {$table}{$where} ORDER BY id DESC LIMIT {$per_page} OFFSET {$offset}";

		if ( $params ) {
			$sql = $wpdb->prepare( $sql, $params );
		}

		$rows = $wpdb->get_results( $sql );

		$count_sql = "SELECT COUNT(*) FROM {$table}{$where}";

		if ( $params ) {
			$count_sql = $wpdb->prepare( $count_sql, $params );
		}

		$total = (int) $wpdb->get_var( $count_sql );

		return array(
			'items'    => $rows ? $rows : array(),
			'total'    => $total,
			'pages'    => (int) ceil( $total / $per_page ),
			'paged'    => $paged,
			'per_page' => $per_page,
		);
	}

	public static function entry( $id ) {
		global $wpdb;

		$table = self::entries_table();
		$row   = $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", absint( $id ) ) );

		if ( ! $row ) {
			return null;
		}

		$row->data  = json_decode( (string) $row->data, true );
		$row->files = $row->files ? json_decode( (string) $row->files, true ) : array();

		if ( ! is_array( $row->data ) ) {
			$row->data = array();
		}

		if ( ! is_array( $row->files ) ) {
			$row->files = array();
		}

		return $row;
	}

	public static function set_entry_status( $id, $status ) {
		global $wpdb;

		if ( ! array_key_exists( $status, self::entry_statuses() ) ) {
			return false;
		}

		$fields = array( 'status' => $status );

		if ( self::STATUS_READ === $status ) {
			$fields['read_at'] = BMC_Helpers::local_datetime();
		}

		return false !== $wpdb->update( self::entries_table(), $fields, array( 'id' => absint( $id ) ) );
	}

	public static function delete_entry( $id ) {
		global $wpdb;

		$id   = absint( $id );
		$row  = $wpdb->get_row( $wpdb->prepare( 'SELECT form_id FROM ' . self::entries_table() . ' WHERE id = %d', $id ) );
		$done = $wpdb->delete( self::entries_table(), array( 'id' => $id ), array( '%d' ) );

		if ( $done && $row ) {
			$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::table() . ' SET entries = GREATEST(entries - 1, 0) WHERE id = %d', (int) $row->form_id ) );
		}

		return (int) $done;
	}

	public static function delete_entries( $form_id, $status = '' ) {
		global $wpdb;

		$form_id = absint( $form_id );
		$table   = self::entries_table();

		if ( $status && array_key_exists( $status, self::entry_statuses() ) ) {
			$count = (int) $wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE form_id = %d AND status = %s", $form_id, $status ) );
		} else {
			$count = (int) $wpdb->query( $wpdb->prepare( "DELETE FROM {$table} WHERE form_id = %d", $form_id ) );
		}

		$wpdb->query( $wpdb->prepare( 'UPDATE ' . self::table() . ' SET entries = 0 WHERE id = %d', $form_id ) );

		return $count;
	}

	public static function counts( $form_id = 0 ) {
		global $wpdb;

		$table = self::entries_table();
		$where = $form_id ? $wpdb->prepare( ' WHERE form_id = %d', absint( $form_id ) ) : '';
		$out   = array(
			'total'   => 0,
			'new'     => 0,
			'read'    => 0,
			'archive' => 0,
			'spam'    => 0,
		);

		$rows = $wpdb->get_results( "SELECT status, COUNT(*) AS c FROM {$table}{$where} GROUP BY status" );

		foreach ( (array) $rows as $row ) {
			$key = (string) $row->status;

			if ( array_key_exists( $key, $out ) ) {
				$out[ $key ] = (int) $row->c;
			}

			$out['total'] += (int) $row->c;
		}

		return $out;
	}

	public static function display_value( $form, $field_id, $value ) {
		foreach ( $form['fields'] as $field ) {
			if ( (string) $field['id'] !== (string) $field_id ) {
				continue;
			}

			if ( is_array( $value ) ) {
				$labels = array();

				foreach ( $value as $item ) {
					$labels[] = self::option_label( $field, (string) $item );
				}

				return implode( '، ', $labels );
			}

			if ( 'checkbox' === $field['type'] ) {
				return $value ? 'بله' : 'خیر';
			}

			if ( 'file' === $field['type'] && $value ) {
				return '<a href="' . esc_url( (string) $value ) . '" target="_blank" rel="noopener">دانلود فایل</a>';
			}

			if ( 'url' === $field['type'] && $value ) {
				return '<a href="' . esc_url( (string) $value ) . '" target="_blank" rel="noopener" dir="ltr">' . esc_html( (string) $value ) . '</a>';
			}

			if ( 'email' === $field['type'] && $value ) {
				return '<a href="mailto:' . esc_attr( (string) $value ) . '" dir="ltr">' . esc_html( (string) $value ) . '</a>';
			}

			return esc_html( self::option_label( $field, (string) $value ) );
		}

		return esc_html( is_array( $value ) ? implode( '، ', $value ) : (string) $value );
	}

	public static function option_label( $field, $value ) {
		foreach ( (array) $field['options'] as $option ) {
			if ( (string) $option['value'] === (string) $value ) {
				return (string) $option['label'];
			}
		}

		return (string) $value;
	}

	public static function export_rows( $form_id ) {
		$form  = self::get( $form_id );
		$all   = array();
		$paged = 1;

		if ( ! $form ) {
			return array( array(), array() );
		}

		do {
			$result = self::entries_query( $form_id, array( 'per_page' => 100, 'paged' => $paged ) );
			$all    = array_merge( $all, $result['items'] );
			$paged++;
		} while ( $paged <= min( 50, (int) $result['pages'] ) );

		$head = array( 'شناسه', 'تاریخ', 'کاربر', 'وضعیت' );

		foreach ( $form['fields'] as $field ) {
			if ( 'html' === $field['type'] ) {
				continue;
			}

			$head[] = $field['label'] ? $field['label'] : $field['id'];
		}

		$rows = array();

		foreach ( $all as $row ) {
			$data   = json_decode( (string) $row->data, true );
			$data   = is_array( $data ) ? $data : array();
			$line   = array(
				(int) $row->id,
				(string) $row->created_at,
				$row->user_id ? ( '#' . (int) $row->user_id ) : 'مهمان',
				isset( self::entry_statuses()[ $row->status ] ) ? self::entry_statuses()[ $row->status ] : (string) $row->status,
			);

			foreach ( $form['fields'] as $field ) {
				if ( 'html' === $field['type'] ) {
					continue;
				}

				$value = isset( $data[ $field['id'] ] ) ? $data[ $field['id'] ] : '';

				if ( 'file' === $field['type'] ) {
					$files = json_decode( (string) $row->files, true );

					if ( is_array( $files ) && isset( $files[ $field['id'] ]['url'] ) ) {
						$value = $files[ $field['id'] ]['url'];
					}
				}

				$line[] = is_array( $value ) ? implode( ' | ', $value ) : (string) $value;
			}

			$rows[] = $line;
		}

		return array( $head, $rows );
	}

	public static function save_from_post( array $post ) {
		$id     = isset( $post['bmc_form_id'] ) ? absint( $post['bmc_form_id'] ) : 0;
		$fields = isset( $post['bmc_form_fields'] ) && is_array( $post['bmc_form_fields'] ) ? $post['bmc_form_fields'] : array();
		$order  = isset( $post['bmc_form_order'] ) && is_array( $post['bmc_form_order'] ) ? array_map( 'absint', $post['bmc_form_order'] ) : array();

		$ordered = array();

		foreach ( $order as $index ) {
			if ( isset( $fields[ $index ] ) ) {
				$ordered[] = $fields[ $index ];
			}
		}

		foreach ( $fields as $index => $field ) {
			if ( ! in_array( (int) $index, $order, true ) ) {
				$ordered[] = $field;
			}
		}

		$clean_fields = array();

		foreach ( $ordered as $index => $raw ) {
			$type = isset( $raw['type'] ) ? sanitize_key( (string) $raw['type'] ) : 'text';

			if ( 'html' === $type && empty( $raw['help'] ) && empty( $raw['label'] ) ) {
				continue;
			}

			if ( 'html' !== $type && 'hidden' !== $type && '' === trim( (string) ( isset( $raw['label'] ) ? $raw['label'] : '' ) ) ) {
				continue;
			}

			$clean_fields[] = self::normalize_field( $raw, $index );
		}

		$config = array(
			'title'                => isset( $post['bmc_form_title'] ) ? sanitize_text_field( wp_unslash( $post['bmc_form_title'] ) ) : '',
			'slug'                 => isset( $post['bmc_form_slug'] ) ? sanitize_title( wp_unslash( $post['bmc_form_slug'] ) ) : '',
			'description'          => isset( $post['bmc_form_description'] ) ? wp_kses_post( wp_unslash( $post['bmc_form_description'] ) ) : '',
			'fields'               => $clean_fields,
			'submit_text'          => isset( $post['bmc_form_submit_text'] ) ? sanitize_text_field( wp_unslash( $post['bmc_form_submit_text'] ) ) : 'ارسال',
			'success_message'      => isset( $post['bmc_form_success'] ) ? sanitize_textarea_field( wp_unslash( $post['bmc_form_success'] ) ) : '',
			'error_message'        => isset( $post['bmc_form_error'] ) ? sanitize_textarea_field( wp_unslash( $post['bmc_form_error'] ) ) : '',
			'labels_position'      => isset( $post['bmc_form_labels'] ) ? sanitize_key( $post['bmc_form_labels'] ) : 'top',
			'gap'                  => isset( $post['bmc_form_gap'] ) ? (int) $post['bmc_form_gap'] : 16,
			'theme'                => isset( $post['bmc_form_theme'] ) ? sanitize_key( $post['bmc_form_theme'] ) : 'inherit',
			'accent'               => isset( $post['bmc_form_accent'] ) ? sanitize_text_field( wp_unslash( $post['bmc_form_accent'] ) ) : '',
			'bordered'             => empty( $post['bmc_form_bordered'] ) ? 0 : 1,
			'show_title'           => empty( $post['bmc_form_show_title'] ) ? 0 : 1,
			'login_required'       => empty( $post['bmc_form_login'] ) ? 0 : 1,
			'honeypot'             => empty( $post['bmc_form_honeypot'] ) ? 0 : 1,
			'save_entries'         => empty( $post['bmc_form_save'] ) ? 0 : 1,
			'allow_files'          => empty( $post['bmc_form_files'] ) ? 0 : 1,
			'email_enabled'        => empty( $post['bmc_form_email_on'] ) ? 0 : 1,
			'email_to'             => isset( $post['bmc_form_email_to'] ) ? sanitize_text_field( wp_unslash( $post['bmc_form_email_to'] ) ) : '',
			'email_subject'        => isset( $post['bmc_form_email_subject'] ) ? sanitize_text_field( wp_unslash( $post['bmc_form_email_subject'] ) ) : '',
			'webhook_enabled'      => empty( $post['bmc_form_webhook_on'] ) ? 0 : 1,
			'webhook_url'          => isset( $post['bmc_form_webhook_url'] ) ? esc_url_raw( wp_unslash( $post['bmc_form_webhook_url'] ) ) : '',
			'ticket_enabled'       => empty( $post['bmc_form_ticket_on'] ) ? 0 : 1,
			'ticket_category'      => isset( $post['bmc_form_ticket_category'] ) ? sanitize_key( $post['bmc_form_ticket_category'] ) : 'other',
			'ticket_priority'      => isset( $post['bmc_form_ticket_priority'] ) ? sanitize_key( $post['bmc_form_ticket_priority'] ) : 'normal',
			'ticket_subject_field' => isset( $post['bmc_form_ticket_subject'] ) ? sanitize_key( $post['bmc_form_ticket_subject'] ) : '',
			'ticket_body_field'    => isset( $post['bmc_form_ticket_body'] ) ? sanitize_key( $post['bmc_form_ticket_body'] ) : '',
			'redirect_url'         => isset( $post['bmc_form_redirect'] ) ? esc_url_raw( wp_unslash( $post['bmc_form_redirect'] ) ) : '',
			'status'               => isset( $post['bmc_form_status'] ) ? sanitize_key( $post['bmc_form_status'] ) : 'active',
		);

		if ( ! $config['fields'] ) {
			self::$redirect = array( 'bmc_form_msg' => rawurlencode( 'حداقل یک فیلد برای فرم اضافه کنید.' ) );

			return 0;
		}

		if ( '' === trim( (string) $config['title'] ) ) {
			self::$redirect = array( 'bmc_form_msg' => rawurlencode( 'عنوان فرم را وارد کنید.' ) );

			return 0;
		}

		if ( $id ) {
			$result = self::update( $id, $config );
		} else {
			$result = self::create( $config );
		}

		if ( is_wp_error( $result ) ) {
			self::$redirect = array( 'bmc_form_msg' => rawurlencode( $result->get_error_message() ) );

			return 0;
		}

		self::$redirect = array(
			'view'         => 'edit',
			'id'           => (int) $result,
			'bmc_form_msg' => rawurlencode( $id ? 'فرم به‌روزرسانی شد.' : 'فرم ساخته شد.' ),
		);

		return (int) $result;
	}

	public static function admin_url( array $args = array() ) {
		$base = array( 'page' => 'bazzarmc', 'tab' => 'forms' );

		return admin_url( 'admin.php?' . http_build_query( array_merge( $base, $args ) ) );
	}

	public static function needs_attention() {
		$counts = self::counts();

		return (int) $counts['new'];
	}
}
