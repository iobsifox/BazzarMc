<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Cron {

	const HOOK = 'bmc_hourly_maintenance';

	public static function schedule() {
		if ( ! wp_next_scheduled( self::HOOK ) ) {
			wp_schedule_event( time() + 60, 'hourly', self::HOOK );
		}

		add_action( self::HOOK, array( __CLASS__, 'run' ) );
	}

	public static function unschedule() {
		$timestamp = wp_next_scheduled( self::HOOK );
		if ( $timestamp ) {
			wp_unschedule_event( $timestamp, self::HOOK );
		}
	}

	public static function run() {
		$expired_deliveries = BMC_Deliveries::expire_old();
		$purged_codes       = BMC_DB::purge_expired_codes();

		if ( $expired_deliveries || $purged_codes ) {
			BMC_Logger::add(
				'cron',
				sprintf( 'نگهداری: %d تحویل منقضی و %d کد پاک شد', $expired_deliveries, $purged_codes ),
				array(),
				'info'
			);
		}

		do_action( 'bmc_maintenance' );
	}

	public static function run_now() {
		$deliveries = BMC_Deliveries::expire_old();
		$codes      = BMC_DB::purge_expired_codes();

		return array(
			'deliveries' => $deliveries,
			'codes'      => $codes,
		);
	}
}
