<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Catalog {

	private static $seq           = 0;
	private static $modal         = false;
	private static $modal_product = 0;
	private static $modal_cfg     = array();
	private static $modal_printed = false;
	private static $assets        = false;
	private static $force_404     = false;
	private static $rank_ids      = array();
	private static $base_url      = '';

	public static function init() {
		add_shortcode( 'bazzarmc_shop', array( __CLASS__, 'shortcode_shop' ) );
		add_shortcode( 'bazzarmc_products', array( __CLASS__, 'shortcode_shop' ) );
		add_shortcode( 'bazzarmc_product_card', array( __CLASS__, 'shortcode_card' ) );
		add_shortcode( 'bazzarmc_product_filter', array( __CLASS__, 'shortcode_filter' ) );

		add_action( 'wp_ajax_bmc_shop_filter', array( __CLASS__, 'ajax_filter' ) );
		add_action( 'wp_ajax_nopriv_bmc_shop_filter', array( __CLASS__, 'ajax_filter' ) );
		add_action( 'wp_ajax_bmc_shop_more', array( __CLASS__, 'ajax_more' ) );
		add_action( 'wp_ajax_nopriv_bmc_shop_more', array( __CLASS__, 'ajax_more' ) );
		add_action( 'wp_ajax_bmc_quick_view', array( __CLASS__, 'ajax_quick_view' ) );
		add_action( 'wp_ajax_nopriv_bmc_quick_view', array( __CLASS__, 'ajax_quick_view' ) );

		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'register_assets' ), 5 );
		add_action( 'template_redirect', array( __CLASS__, 'maybe_prefill_modal' ), 4 );
		add_action( 'template_redirect', array( __CLASS__, 'single_product_gate' ), 5 );
		add_filter( 'template_include', array( __CLASS__, 'single_product_template' ), 99 );
		add_action( 'wp_footer', array( __CLASS__, 'print_modal' ), 15 );
		add_filter( 'woocommerce_add_to_cart_redirect', array( __CLASS__, 'buy_now_redirect' ) );
	}

	public static function enabled() {
		return (bool) BMC_Settings::bool( 'shop_enabled', true );
	}

	public static function quick_view_enabled() {
		return (bool) BMC_Settings::bool( 'qv_enabled', true );
	}

	public static function single_mode() {
		$mode = (string) BMC_Settings::get( 'single_product_mode', 'enabled' );

		return in_array( $mode, array( 'enabled', 'disabled', 'redirect' ), true ) ? $mode : 'enabled';
	}

	public static function single_enabled() {
		return 'enabled' === self::single_mode();
	}

	public static function config_keys() {
		return array(
			'shop_source', 'shop_source_tag', 'shop_categories', 'shop_category_depth', 'shop_hide_empty_cats',
			'shop_include', 'shop_exclude', 'shop_per_page', 'shop_columns', 'shop_columns_tablet', 'shop_columns_mobile',
			'shop_gap', 'shop_pagination', 'shop_load_more_text', 'shop_empty_text', 'shop_heading', 'shop_heading_icon',
			'shop_show_count', 'shop_count_text', 'shop_ajax',
			'filter_enabled', 'filter_style', 'filter_position', 'filter_title', 'filter_icon', 'filter_show_all',
			'filter_all_label', 'filter_show_counts', 'filter_show_thumb', 'filter_show_sort', 'filter_sort_label',
			'filter_sort_options', 'filter_default_sort', 'filter_show_search', 'filter_search_placeholder',
			'filter_search_min', 'filter_show_reset', 'filter_reset_text', 'filter_sticky',
			'card_show_image', 'card_image_ratio', 'card_show_category', 'card_show_price', 'card_show_excerpt',
			'card_excerpt_words', 'card_show_rating', 'card_show_sale_badge', 'card_sale_badge_text',
			'card_show_rank_badge', 'card_show_stock', 'card_show_meta', 'card_button_text', 'card_button_text_variable',
			'card_button_text_soldout', 'card_button_icon', 'card_buy_now', 'card_buy_now_text', 'card_align',
			'card_hover', 'card_click', 'card_radius', 'card_qv_hint',
			'qv_enabled', 'qv_width', 'qv_title_text', 'qv_show_image', 'qv_show_price', 'qv_show_meta', 'qv_show_excerpt',
			'qv_show_description', 'qv_show_attributes', 'qv_show_rank', 'qv_show_add_to_cart', 'qv_show_single_link',
			'qv_single_link_text', 'qv_close_text', 'qv_loading_text', 'qv_error_text',
		);
	}

	public static function config( array $overrides = array() ) {
		$cfg = array();

		foreach ( self::config_keys() as $key ) {
			$cfg[ $key ] = BMC_Settings::get( $key );
		}

		foreach ( $overrides as $key => $value ) {
			if ( null === $value || '' === $value || ! array_key_exists( $key, $cfg ) ) {
				continue;
			}

			$cfg[ $key ] = $value;
		}

		return self::sanitize_config( $cfg );
	}

	public static function sanitize_config( array $cfg ) {
		$defaults = BMC_Settings::defaults();
		$clean    = array();

		foreach ( self::config_keys() as $key ) {
			$value   = array_key_exists( $key, $cfg ) ? $cfg[ $key ] : ( array_key_exists( $key, $defaults ) ? $defaults[ $key ] : '' );
			$default = array_key_exists( $key, $defaults ) ? $defaults[ $key ] : '';

			if ( is_array( $default ) ) {
				if ( 'shop_categories' === $key ) {
					$value = array_values( array_unique( array_filter( array_map( 'absint', (array) $value ) ) ) );
				} else {
					$allowed = array_keys( BMC_Settings::sort_options() );
					$value   = array_values( array_intersect( array_map( 'sanitize_key', (array) $value ), $allowed ) );

					if ( ! $value ) {
						$value = array( 'menu_order' );
					}
				}

				$clean[ $key ] = $value;
				continue;
			}

			if ( is_string( $default ) && in_array( $default, array( 'yes', 'no' ), true ) ) {
				$clean[ $key ] = BMC_Settings::normalize_yesno( $value );
				continue;
			}

			if ( is_int( $default ) ) {
				$clean[ $key ] = self::clamp( $key, (int) $value );
				continue;
			}

			$clean[ $key ] = self::filter_text( $key, $value );
		}

		return $clean;
	}

	private static function clamp( $key, $value ) {
		$bounds = array(
			'shop_per_page'        => array( 1, 96 ),
			'shop_columns'         => array( 1, 6 ),
			'shop_columns_tablet'  => array( 1, 5 ),
			'shop_columns_mobile'  => array( 1, 3 ),
			'shop_gap'             => array( 0, 80 ),
			'shop_category_depth'  => array( 1, 4 ),
			'card_excerpt_words'   => array( 0, 80 ),
			'card_radius'          => array( 0, 48 ),
			'qv_width'             => array( 360, 1400 ),
			'filter_search_min'    => array( 1, 8 ),
		);

		if ( ! isset( $bounds[ $key ] ) ) {
			return max( 0, $value );
		}

		return max( $bounds[ $key ][0], min( $bounds[ $key ][1], $value ) );
	}

	private static function filter_text( $key, $value ) {
		$value = is_scalar( $value ) ? (string) $value : '';

		if ( 'card_image_ratio' === $key ) {
			$ratio = preg_replace( '/[^0-9:]/', '', $value );

			return in_array( $ratio, array( 'auto', '1:1', '4:3', '3:4', '16:9' ), true ) ? $ratio : '4:3';
		}

		$enums = array(
			'shop_source'         => array( 'all', 'ranks', 'mc', 'tag' ),
			'shop_pagination'     => array( 'numbers', 'load_more', 'none' ),
			'filter_style'        => array( 'pills', 'tabs', 'chips', 'select' ),
			'filter_position'     => array( 'top', 'side' ),
			'filter_default_sort' => array_keys( BMC_Settings::sort_options() ),
			'card_align'          => array( 'right', 'center' ),
			'card_hover'          => array( 'lift', 'glow', 'none' ),
			'card_click'          => array( 'quickview', 'single', 'none' ),
		);

		if ( isset( $enums[ $key ] ) ) {
			$value = sanitize_key( $value );

			return in_array( $value, $enums[ $key ], true ) ? $value : $enums[ $key ][0];
		}

		if ( in_array( $key, array( 'shop_heading', 'filter_title', 'qv_title_text' ), true ) ) {
			return sanitize_text_field( $value );
		}

		if ( in_array( $key, array( 'shop_count_text', 'shop_empty_text', 'shop_load_more_text', 'qv_loading_text', 'qv_error_text', 'qv_single_link_text', 'filter_reset_text' ), true ) ) {
			return sanitize_textarea_field( $value );
		}

		if ( in_array( $key, array( 'shop_heading_icon', 'filter_icon', 'card_button_icon' ), true ) ) {
			$icon = sanitize_key( $value );

			return ( class_exists( 'BMC_Icons' ) && BMC_Icons::has( $icon ) ) ? $icon : '';
		}

		return sanitize_text_field( $value );
	}

	public static function yesno( $value ) {
		return BMC_Settings::normalize_yesno( $value ) === 'yes';
	}

	public static function shortcode_shop( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'category'   => '',
				'source'     => '',
				'tag'        => '',
				'include'    => '',
				'exclude'    => '',
				'per_page'   => '',
				'columns'    => '',
				'gap'        => '',
				'filter'     => '',
				'style'      => '',
				'sort'       => '',
				'search'     => '',
				'pagination' => '',
				'heading'    => '',
				'click'      => '',
				'quickview'  => '',
				'ajax'       => '',
				'buy_now'    => '',
			),
			$atts,
			'bazzarmc_shop'
		);

		$overrides = array();

		if ( '' !== $atts['category'] ) {
			$overrides['shop_categories'] = array_filter( array_map( 'absint', array_map( 'trim', explode( ',', (string) $atts['category'] ) ) ) );
		}
		if ( '' !== $atts['source'] ) {
			$overrides['shop_source'] = $atts['source'];
		}
		if ( '' !== $atts['tag'] ) {
			$overrides['shop_source_tag'] = $atts['tag'];
		}
		if ( '' !== $atts['include'] ) {
			$overrides['shop_include'] = $atts['include'];
		}
		if ( '' !== $atts['exclude'] ) {
			$overrides['shop_exclude'] = $atts['exclude'];
		}
		if ( '' !== $atts['per_page'] ) {
			$overrides['shop_per_page'] = (int) $atts['per_page'];
		}
		if ( '' !== $atts['columns'] ) {
			$overrides['shop_columns'] = (int) $atts['columns'];
		}
		if ( '' !== $atts['gap'] ) {
			$overrides['shop_gap'] = (int) $atts['gap'];
		}
		if ( '' !== $atts['filter'] ) {
			$overrides['filter_enabled'] = $atts['filter'];
		}
		if ( '' !== $atts['style'] ) {
			$overrides['filter_style'] = $atts['style'];
		}
		if ( '' !== $atts['sort'] ) {
			$overrides['filter_default_sort'] = $atts['sort'];
		}
		if ( '' !== $atts['search'] ) {
			$overrides['filter_show_search'] = $atts['search'];
		}
		if ( '' !== $atts['pagination'] ) {
			$overrides['shop_pagination'] = $atts['pagination'];
		}
		if ( '' !== $atts['heading'] ) {
			$overrides['shop_heading'] = $atts['heading'];
		}
		if ( '' !== $atts['click'] ) {
			$overrides['card_click'] = $atts['click'];
		}
		if ( '' !== $atts['quickview'] ) {
			$overrides['qv_enabled'] = $atts['quickview'];
		}
		if ( '' !== $atts['ajax'] ) {
			$overrides['shop_ajax'] = $atts['ajax'];
		}
		if ( '' !== $atts['buy_now'] ) {
			$overrides['card_buy_now'] = $atts['buy_now'];
		}

		return self::render_shop( $overrides );
	}

	public static function shortcode_card( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'id'        => '',
				'quickview' => '',
				'click'     => '',
				'buy_now'   => '',
				'price'     => '',
				'excerpt'   => '',
				'image'     => '',
				'button'    => '',
			),
			$atts,
			'bazzarmc_product_card'
		);

		$product_id = absint( $atts['id'] );

		if ( ! $product_id ) {
			$product_id = (int) get_the_ID();
		}

		$overrides = array();

		if ( '' !== $atts['quickview'] ) {
			$overrides['qv_enabled'] = $atts['quickview'];
		}
		if ( '' !== $atts['click'] ) {
			$overrides['card_click'] = $atts['click'];
		}
		if ( '' !== $atts['buy_now'] ) {
			$overrides['card_buy_now'] = $atts['buy_now'];
		}
		if ( '' !== $atts['price'] ) {
			$overrides['card_show_price'] = $atts['price'];
		}
		if ( '' !== $atts['excerpt'] ) {
			$overrides['card_show_excerpt'] = $atts['excerpt'];
		}
		if ( '' !== $atts['image'] ) {
			$overrides['card_show_image'] = $atts['image'];
		}
		if ( '' !== $atts['button'] ) {
			$overrides['card_button_text'] = sanitize_text_field( (string) $atts['button'] );
		}

		return self::render_single_card( $product_id, $overrides );
	}

	public static function shortcode_filter( $atts = array() ) {
		$atts = shortcode_atts(
			array(
				'category' => '',
				'style'    => '',
				'sort'     => '',
				'search'   => '',
				'target'   => '',
				'ajax'     => '',
			),
			$atts,
			'bazzarmc_product_filter'
		);

		$overrides = array();

		if ( '' !== $atts['category'] ) {
			$overrides['shop_categories'] = array_filter( array_map( 'absint', array_map( 'trim', explode( ',', (string) $atts['category'] ) ) ) );
		}
		if ( '' !== $atts['style'] ) {
			$overrides['filter_style'] = $atts['style'];
		}
		if ( '' !== $atts['sort'] ) {
			$overrides['filter_default_sort'] = $atts['sort'];
		}
		if ( '' !== $atts['search'] ) {
			$overrides['filter_show_search'] = $atts['search'];
		}
		if ( '' !== $atts['ajax'] ) {
			$overrides['shop_ajax'] = $atts['ajax'];
		}

		return self::render_filter_only( $overrides, sanitize_html_class( (string) $atts['target'] ) );
	}

	public static function render_shop( array $overrides = array() ) {
		$blocked = BMC_Public::blocked( 'ویترین محصولات موقتاً غیرفعال است' );

		if ( null !== $blocked ) {
			return $blocked;
		}

		if ( ! function_exists( 'WC' ) || ! class_exists( 'WooCommerce' ) ) {
			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">برای نمایش ویترین محصولات، ووکامرس باید فعال باشد.</div></div>';
		}

		if ( ! self::enabled() ) {
			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">ویترین محصولات BazzarMc در تنظیمات غیرفعال شده است.</div></div>';
		}

		$cfg   = self::config( $overrides );
		$id    = self::next_id();
		$state = self::state( $_GET, $cfg ); // phpcs:ignore WordPress.Security.NonceVerification

		self::enqueue_assets( $cfg );

		if ( self::yesno( $cfg['qv_enabled'] ) ) {
			self::$modal = true;
		}

		return (string) BMC_Public::template(
			'catalog',
			array(
				'bmc_cfg'   => $cfg,
				'bmc_id'    => $id,
				'bmc_state' => $state,
			)
		);
	}

	public static function render_single_card( $product_id, array $overrides = array() ) {
		$product_id = absint( $product_id );

		if ( ! function_exists( 'wc_get_product' ) || ! $product_id ) {
			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">محصول انتخاب‌شده وجود ندارد.</div></div>';
		}

		$product = wc_get_product( $product_id );

		if ( ! $product ) {
			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">محصول انتخاب‌شده وجود ندارد.</div></div>';
		}

		$cfg = self::config( $overrides );
		$id  = self::next_id();

		self::enqueue_assets( $cfg );

		if ( self::yesno( $cfg['qv_enabled'] ) ) {
			self::$modal = true;
		}

		return '<div class="bmc-wrap bmc-shop bmc-shop--single" dir="rtl" id="' . esc_attr( $id ) . '" data-bmc-shop="' . esc_attr( $id ) . '" data-bmc-cfg="' . esc_attr( wp_json_encode( $cfg ) ) . '">'
			. '<div class="bmc-shop__grid" style="--bmc-cols:1;--bmc-cols-tablet:1;--bmc-cols-mobile:1;--bmc-gap:' . (int) $cfg['shop_gap'] . 'px">'
			. self::render_card( $product, $cfg, array( 'index' => 0, 'id' => $id ) )
			. '</div></div>';
	}

	public static function render_filter_only( array $overrides = array(), $target = '' ) {
		if ( ! function_exists( 'WC' ) || ! class_exists( 'WooCommerce' ) ) {
			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">برای نمایش نوار فیلتر، ووکامرس باید فعال باشد.</div></div>';
		}

		$overrides['filter_enabled'] = 'yes';

		$cfg   = self::config( $overrides );
		$id    = self::next_id();
		$state = self::state( $_GET, $cfg ); // phpcs:ignore WordPress.Security.NonceVerification

		self::enqueue_assets( $cfg );

		return '<div class="bmc-wrap bmc-shop bmc-shop--filter-only" dir="rtl" id="' . esc_attr( $id ) . '" data-bmc-shop="' . esc_attr( $id ) . '" data-bmc-ajax="' . ( self::yesno( $cfg['shop_ajax'] ) ? '1' : '0' ) . '" data-bmc-cfg="' . esc_attr( wp_json_encode( $cfg ) ) . '">'
			. self::render_filter( $cfg, $id, $state, $target )
			. '</div>';
	}

	public static function render_filter( array $cfg, $id, array $state, $target = '' ) {
		if ( ! self::yesno( $cfg['filter_enabled'] ) ) {
			return '';
		}

		$vars = array(
			'bmc_cfg'    => $cfg,
			'bmc_id'     => (string) $id,
			'bmc_state'  => $state,
			'bmc_target' => (string) $target,
			'bmc_terms'  => self::categories( $cfg ),
		);

		return (string) BMC_Public::template( 'catalog-filter', $vars );
	}

	public static function render_grid( array $cfg, $id, array $state ) {
		$result = self::query( $cfg, $state );

		$vars = array(
			'bmc_cfg'    => $cfg,
			'bmc_id'     => (string) $id,
			'bmc_state'  => $state,
			'bmc_items'  => $result['items'],
			'bmc_total'  => $result['total'],
			'bmc_pages'  => $result['pages'],
		);

		return (string) BMC_Public::template( 'catalog-grid', $vars );
	}

	public static function render_cards( array $cfg, $id, array $state ) {
		$result = self::query( $cfg, $state );
		$html   = '';

		foreach ( $result['items'] as $index => $product ) {
			$html .= self::render_card( $product, $cfg, array( 'index' => $index, 'id' => $id ) );
		}

		if ( '' === $html ) {
			$html = '<div class="bmc-shop__empty">' . esc_html( (string) $cfg['shop_empty_text'] ) . '</div>';
		}

		return $html;
	}

	public static function render_card( $product, array $cfg, array $args = array() ) {
		if ( ! $product || ! is_object( $product ) ) {
			return '';
		}

		$index = isset( $args['index'] ) ? (int) $args['index'] : 0;
		$id    = isset( $args['id'] ) ? (string) $args['id'] : '';

		$click = (string) $cfg['card_click'];

		if ( ! self::yesno( $cfg['qv_enabled'] ) && 'quickview' === $click ) {
			$click = self::single_enabled() ? 'single' : 'none';
		}

		if ( ! self::single_enabled() && 'single' === $click ) {
			$click = self::yesno( $cfg['qv_enabled'] ) ? 'quickview' : 'none';
		}

		$permalink = (string) get_permalink( $product->get_id() );
		$link      = $permalink;

		if ( 'quickview' === $click ) {
			$link = self::single_enabled() ? $permalink : (string) add_query_arg( 'bmc_qv', (int) $product->get_id(), self::clean_url() );
		} elseif ( 'none' === $click ) {
			$link = '';
		}

		if ( self::yesno( $cfg['qv_enabled'] ) ) {
			self::$modal = true;
		}

		$vars = array(
			'bmc_p'     => $product,
			'bmc_cfg'   => $cfg,
			'bmc_index' => $index,
			'bmc_id'    => $id,
			'bmc_link'  => $link,
			'bmc_click' => $click,
			'bmc_data'  => self::card_data( $product, $cfg ),
		);

		return (string) BMC_Public::template( 'product-card', $vars );
	}

	public static function card_data( $product, array $cfg ) {
		$rank  = class_exists( 'BMC_Ranks' ) ? BMC_Ranks::rank_for_product( $product->get_id() ) : null;
		$terms = array();

		if ( taxonomy_exists( 'product_cat' ) ) {
			$raw = (array) get_the_terms( $product->get_id(), 'product_cat' );

			foreach ( $raw as $term ) {
				if ( $term && ! is_wp_error( $term ) ) {
					$terms[] = (string) $term->name;
				}
			}
		}

		$on_sale    = (bool) $product->is_on_sale();
		$regular    = (float) $product->get_regular_price();
		$sale       = (float) $product->get_sale_price();
		$percent    = ( $on_sale && $regular > 0 && $sale >= 0 ) ? (int) round( ( ( $regular - $sale ) / $regular ) * 100 ) : 0;
		$in_stock   = (bool) $product->is_in_stock();
		$purchasable = (bool) $product->is_purchasable();

		return array(
			'rank'        => $rank,
			'rank_label'  => $rank ? (string) $rank['name'] : '',
			'rank_days'   => $rank ? (int) $rank['days'] : 0,
			'rank_level'  => $rank ? (int) $rank['level'] : 0,
			'categories'  => $terms,
			'category'    => $terms ? $terms[0] : '',
			'on_sale'     => $on_sale,
			'sale_percent' => $percent,
			'in_stock'    => $in_stock,
			'purchasable' => $purchasable,
			'is_variable' => $product->is_type( 'variable' ) || $product->is_type( 'grouped' ),
			'rating'      => (float) $product->get_average_rating(),
			'rating_count' => (int) $product->get_rating_count(),
			'stock_text'  => $in_stock ? ( $product->managing_stock() ? 'موجودی: ' . BMC_Helpers::to_persian_digits( (int) $product->get_stock_quantity() ) : 'موجود' ) : 'ناموجود',
			'blocked'     => class_exists( 'BMC_Ranks' ) && is_user_logged_in() ? (bool) BMC_Ranks::is_downgrade( get_current_user_id(), $product->get_id() ) : false,
			'blocked_msg' => class_exists( 'BMC_Ranks' ) && is_user_logged_in() ? (string) BMC_Ranks::blocked_message( get_current_user_id(), $product->get_id() ) : '',
		);
	}

	public static function quick_view_html( $bmc_product, array $cfg ) {
		global $post, $product;

		if ( ! $bmc_product ) {
			return '';
		}

		$bmc_prev_post    = isset( $post ) ? $post : null;
		$bmc_prev_product = isset( $product ) ? $product : null;

		$post    = get_post( $bmc_product->get_id() ); // phpcs:ignore WordPress.WP.GlobalVariablesOverride
		$product = $bmc_product; // phpcs:ignore WordPress.WP.GlobalVariablesOverride

		if ( $post ) {
			setup_postdata( $post );
		}

		$html = (string) BMC_Public::template(
			'quick-view',
			array(
				'bmc_p'   => $bmc_product,
				'bmc_cfg' => $cfg,
				'bmc_data' => self::card_data( $bmc_product, $cfg ),
			)
		);

		if ( $post ) {
			wp_reset_postdata();
		}

		$post    = $bmc_prev_post; // phpcs:ignore WordPress.WP.GlobalVariablesOverride
		$product = $bmc_prev_product; // phpcs:ignore WordPress.WP.GlobalVariablesOverride

		return $html;
	}

	public static function state( $input, array $cfg ) {
		$input = is_array( $input ) ? $input : array();

		$cat  = isset( $input['bmc_cat'] ) ? sanitize_title( (string) $input['bmc_cat'] ) : '';
		$sort = isset( $input['bmc_sort'] ) ? sanitize_key( (string) $input['bmc_sort'] ) : '';
		$s    = isset( $input['bmc_s'] ) ? sanitize_text_field( (string) $input['bmc_s'] ) : '';
		if ( isset( $input['bmc_paged'] ) && '' !== (string) $input['bmc_paged'] ) {
			$page = max( 1, absint( $input['bmc_paged'] ) );
		} else {
			$page = max( 1, (int) get_query_var( 'paged' ) );
		}

		$allowed = array_keys( BMC_Settings::sort_options() );

		if ( '' === $sort || ! in_array( $sort, $allowed, true ) ) {
			$sort = (string) $cfg['filter_default_sort'];
		}

		if ( ! in_array( $sort, $allowed, true ) ) {
			$sort = 'menu_order';
		}

		return array(
			'cat'  => $cat,
			'sort' => $sort,
			's'    => $s,
			'page' => max( 1, $page ),
		);
	}

	public static function state_url( array $state ) {
		$args = array();

		if ( '' !== $state['cat'] ) {
			$args['bmc_cat'] = $state['cat'];
		}
		if ( '' !== $state['s'] ) {
			$args['bmc_s'] = $state['s'];
		}
		if ( '' !== $state['sort'] ) {
			$args['bmc_sort'] = $state['sort'];
		}
		if ( $state['page'] > 1 ) {
			$args['bmc_paged'] = (int) $state['page'];
		}

		$url = self::clean_url();

		return $args ? (string) add_query_arg( $args, $url ) : $url;
	}

	public static function current_url() {
		if ( '' !== self::$base_url ) {
			return self::$base_url;
		}

		$uri = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '/'; // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		$uri = sanitize_text_field( $uri );

		return (string) esc_url_raw( home_url( $uri ) );
	}

	public static function clean_url() {
		return (string) remove_query_arg( array( 'bmc_cat', 'bmc_sort', 'bmc_s', 'bmc_paged', 'bmc_qv' ), self::current_url() );
	}

	public static function set_base_url( $url ) {
		$url = (string) esc_url_raw( (string) $url );

		if ( '' === $url ) {
			return;
		}

		$home = (string) wp_parse_url( home_url(), PHP_URL_HOST );
		$host = (string) wp_parse_url( $url, PHP_URL_HOST );

		if ( $host && $home && strtolower( $host ) !== strtolower( $home ) ) {
			return;
		}

		self::$base_url = $url;
	}

	public static function categories( array $cfg ) {
		if ( ! taxonomy_exists( 'product_cat' ) ) {
			return array();
		}

		$selected = array_values( array_filter( array_map( 'absint', (array) $cfg['shop_categories'] ) ) );
		$base     = $selected ? $selected : self::top_level_ids();
		$ids      = self::expand_ids( $base, max( 1, (int) $cfg['shop_category_depth'] ) );

		if ( ! $ids ) {
			return array();
		}

		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'include'    => $ids,
				'hide_empty' => self::yesno( $cfg['shop_hide_empty_cats'] ),
				'orderby'    => 'name',
				'order'      => 'ASC',
			)
		);

		if ( is_wp_error( $terms ) || ! $terms ) {
			return array();
		}

		$out = array();

		foreach ( $terms as $term ) {
			$thumb = 0;

			if ( self::yesno( $cfg['filter_show_thumb'] ) ) {
				$thumb_id = (int) get_term_meta( (int) $term->term_id, 'thumbnail_id', true );

				if ( $thumb_id ) {
					$thumb = (string) wp_get_attachment_image_url( $thumb_id, 'thumbnail' );
				}
			}

			$out[] = array(
				'id'    => (int) $term->term_id,
				'slug'  => (string) $term->slug,
				'name'  => (string) $term->name,
				'count' => (int) $term->count,
				'parent' => (int) $term->parent,
				'thumb' => $thumb,
				'depth' => self::term_depth( $term ),
			);
		}

		return $out;
	}

	public static function category_ids( array $cfg ) {
		$out = array();

		foreach ( self::categories( $cfg ) as $term ) {
			$out[] = (int) $term['id'];
		}

		return $out;
	}

	private static function top_level_ids() {
		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'parent'     => 0,
				'hide_empty' => false,
				'fields'     => 'ids',
			)
		);

		if ( is_wp_error( $terms ) ) {
			return array();
		}

		return array_map( 'absint', (array) $terms );
	}

	private static function expand_ids( array $ids, $depth ) {
		$ids   = array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
		$level = $ids;

		for ( $i = 1; $i < $depth; $i++ ) {
			if ( ! $level ) {
				break;
			}

			$children = get_terms(
				array(
					'taxonomy'   => 'product_cat',
					'parent'     => $level,
					'hide_empty' => false,
					'fields'     => 'ids',
				)
			);

			if ( is_wp_error( $children ) || ! $children ) {
				break;
			}

			$level = array_map( 'absint', (array) $children );
			$ids   = array_merge( $ids, $level );
		}

		return array_values( array_unique( array_filter( array_map( 'absint', $ids ) ) ) );
	}

	private static function term_depth( $term ) {
		$depth  = 0;
		$parent = (int) $term->parent;
		$guard  = 0;

		while ( $parent > 0 && $guard < 10 ) {
			$depth++;
			$parent_term = get_term( $parent, 'product_cat' );

			if ( ! $parent_term || is_wp_error( $parent_term ) ) {
				break;
			}

			$parent = (int) $parent_term->parent;
			$guard++;
		}

		return $depth;
	}

	public static function rank_product_ids( $source = 'ranks' ) {
		$source = 'mc' === $source ? 'mc' : 'ranks';

		if ( isset( self::$rank_ids[ $source ] ) ) {
			return self::$rank_ids[ $source ];
		}

		$cache_key = 'bmc_catalog_rank_ids_' . $source;
		$cached    = get_transient( $cache_key );

		if ( is_array( $cached ) ) {
			self::$rank_ids[ $source ] = $cached;

			return $cached;
		}

		$out = array();

		if ( class_exists( 'BMC_Ranks' ) && BMC_Ranks::enabled() ) {
			$ids = get_posts(
				array(
					'post_type'      => 'product',
					'post_status'    => 'publish',
					'posts_per_page' => 500,
					'fields'         => 'ids',
					'no_found_rows'  => true,
				)
			);

			foreach ( (array) $ids as $product_id ) {
				$rank = BMC_Ranks::rank_for_product( (int) $product_id );

				if ( ! $rank ) {
					continue;
				}

				if ( 'mc' === $source && 'minecraft' !== $rank['source'] ) {
					continue;
				}

				$out[] = (int) $product_id;
			}
		}

		set_transient( $cache_key, $out, 600 );

		self::$rank_ids[ $source ] = $out;

		return $out;
	}

	public static function orderby_args( $sort ) {
		$sort = (string) $sort;

		if ( function_exists( 'WC' ) && WC() && ! empty( WC()->query ) && method_exists( WC()->query, 'get_catalog_orderby_args' ) ) {
			$raw = (array) WC()->query->get_catalog_orderby_args( $sort );
			$out = array();

			if ( ! empty( $raw['orderby'] ) ) {
				$out['orderby'] = $raw['orderby'];
			}
			if ( ! empty( $raw['order'] ) ) {
				$out['order'] = $raw['order'];
			}
			if ( ! empty( $raw['meta_key'] ) ) {
				$out['meta_key'] = $raw['meta_key'];
			}

			if ( $out ) {
				return $out;
			}
		}

		switch ( $sort ) {
			case 'date':
				return array( 'orderby' => 'date', 'order' => 'DESC' );
			case 'price':
				return array( 'orderby' => 'meta_value_num', 'order' => 'ASC', 'meta_key' => '_price' );
			case 'price-desc':
				return array( 'orderby' => 'meta_value_num', 'order' => 'DESC', 'meta_key' => '_price' );
			case 'popularity':
				return array( 'orderby' => 'meta_value_num', 'order' => 'DESC', 'meta_key' => 'total_sales' );
			case 'rating':
				return array( 'orderby' => 'meta_value_num', 'order' => 'DESC', 'meta_key' => '_wc_average_rating' );
			case 'title':
				return array( 'orderby' => 'title', 'order' => 'ASC' );
			case 'menu_order':
			default:
				return array( 'orderby' => 'menu_order title', 'order' => 'ASC' );
		}
	}

	public static function query( array $cfg, array $state ) {
		$tax = array();

		if ( '' !== $state['cat'] ) {
			$tax[] = array(
				'taxonomy' => 'product_cat',
				'field'    => 'slug',
				'terms'    => array( $state['cat'] ),
			);
		} elseif ( ! empty( $cfg['shop_categories'] ) ) {
			$selected = array_values( array_filter( array_map( 'absint', (array) $cfg['shop_categories'] ) ) );
			$ids      = self::expand_ids( $selected, max( 1, (int) $cfg['shop_category_depth'] ) );
			if ( $ids ) {
				$tax[] = array(
					'taxonomy' => 'product_cat',
					'field'    => 'term_id',
					'terms'    => $ids,
				);
			}
		}

		if ( 'tag' === $cfg['shop_source'] && '' !== (string) $cfg['shop_source_tag'] ) {
			$tax[] = array(
				'taxonomy' => 'product_tag',
				'field'    => 'slug',
				'terms'    => array( sanitize_title( (string) $cfg['shop_source_tag'] ) ),
			);
		}

		if ( function_exists( 'wc_get_product_visibility_term_ids' ) ) {
			$visibility = (array) wc_get_product_visibility_term_ids();

			if ( ! empty( $visibility['exclude-from-catalog'] ) ) {
				$tax[] = array(
					'taxonomy' => 'product_visibility',
					'field'    => 'term_taxonomy_id',
					'terms'    => array( (int) $visibility['exclude-from-catalog'] ),
					'operator' => 'NOT IN',
				);
			}
		}

		$args = array(
			'post_type'           => 'product',
			'post_status'         => 'publish',
			'posts_per_page'      => max( 1, (int) $cfg['shop_per_page'] ),
			'paged'               => max( 1, (int) $state['page'] ),
			'ignore_sticky_posts' => true,
		);

		if ( $tax ) {
			$args['tax_query'] = $tax; // phpcs:ignore WordPress.DB.SlowDBQuery
		}

		$include = array_values( array_filter( array_map( 'absint', array_map( 'trim', explode( ',', (string) $cfg['shop_include'] ) ) ) ) );
		$exclude = array_values( array_filter( array_map( 'absint', array_map( 'trim', explode( ',', (string) $cfg['shop_exclude'] ) ) ) ) );

		if ( in_array( $cfg['shop_source'], array( 'ranks', 'mc' ), true ) ) {
			$rank_ids = self::rank_product_ids( $cfg['shop_source'] );
			$include  = $include ? array_values( array_intersect( $include, $rank_ids ) ) : $rank_ids;

			if ( ! $include ) {
				$include = array( 0 );
			}
		}

		if ( $include ) {
			$args['post__in'] = $include;
		}

		if ( $exclude ) {
			$args['post__not_in'] = $exclude;
		}

		if ( '' !== $state['s'] ) {
			$args['s'] = $state['s'];
		}

		$order = self::orderby_args( $state['sort'] );

		foreach ( $order as $key => $value ) {
			$args[ $key ] = $value;
		}

		$query = new WP_Query( apply_filters( 'bmc_catalog_query_args', $args, $cfg, $state ) );

		$items = array();

		foreach ( (array) $query->posts as $post_obj ) {
			$product = function_exists( 'wc_get_product' ) ? wc_get_product( $post_obj ) : null;

			if ( ! $product || ! is_object( $product ) ) {
				continue;
			}

			if ( method_exists( $product, 'is_visible' ) && ! $product->is_visible() ) {
				continue;
			}

			$items[] = $product;
		}

		return array(
			'items' => $items,
			'total' => (int) $query->found_posts,
			'pages' => (int) $query->max_num_pages,
		);
	}

	public static function shop_url() {
		$page_id = (int) BMC_Settings::get( 'page_shop', 0 );

		if ( $page_id ) {
			$url = (string) get_permalink( $page_id );

			if ( $url ) {
				return $url;
			}
		}

		if ( function_exists( 'wc_get_page_permalink' ) ) {
			$url = (string) wc_get_page_permalink( 'shop' );

			if ( $url ) {
				return $url;
			}
		}

		return home_url( '/' );
	}

	public static function redirect_target_url() {
		$target = (string) BMC_Settings::get( 'single_redirect_target', 'shop' );

		if ( 'home' === $target ) {
			return home_url( '/' );
		}

		if ( 'page' === $target ) {
			$page_id = (int) BMC_Settings::get( 'single_redirect_page', 0 );
			$url     = $page_id ? (string) get_permalink( $page_id ) : '';

			return $url ? $url : self::shop_url();
		}

		return self::shop_url();
	}

	public static function single_product_gate() {
		if ( ! function_exists( 'is_product' ) || ! is_product() ) {
			return;
		}

		$mode = self::single_mode();

		if ( 'enabled' === $mode ) {
			return;
		}

		if ( 'redirect' === $mode ) {
			wp_safe_redirect( self::redirect_target_url(), 302 );
			exit;
		}

		global $wp_query;

		if ( $wp_query ) {
			$wp_query->set_404();
		}

		status_header( 404 );
		nocache_headers();

		self::$force_404 = true;
	}

	public static function single_product_template( $template ) {
		if ( ! self::$force_404 ) {
			return $template;
		}

		$fallback = get_query_template( '404' );

		return $fallback ? $fallback : $template;
	}

	public static function maybe_prefill_modal() {
		if ( ! isset( $_GET['bmc_qv'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return;
		}

		if ( ! self::quick_view_enabled() || ! function_exists( 'wc_get_product' ) ) {
			return;
		}

		$product_id = absint( wp_unslash( $_GET['bmc_qv'] ) ); // phpcs:ignore WordPress.Security.NonceVerification
		$product    = $product_id ? wc_get_product( $product_id ) : null;

		if ( ! $product || ! $product->is_visible() ) {
			return;
		}

		self::$modal         = true;
		self::$modal_product = (int) $product_id;
		self::$modal_cfg     = self::config();

		self::enqueue_assets( self::$modal_cfg );
	}

	public static function print_modal() {
		if ( ! self::$modal || self::$modal_printed ) {
			return;
		}

		self::$modal_printed = true;

		$cfg = self::$modal_cfg ? self::$modal_cfg : self::config();

		BMC_Public::enqueue_base_assets();

		$content = '';

		if ( self::$modal_product && function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( self::$modal_product );

			if ( $product && $product->is_visible() ) {
				$content = self::quick_view_html( $product, $cfg );
			}
		}

		echo BMC_Public::template( // phpcs:ignore WordPress.Security.EscapeOutput
			'quick-view-modal',
			array(
				'bmc_cfg'     => $cfg,
				'bmc_content' => $content,
				'bmc_open'    => '' !== $content,
			)
		);
	}

	public static function register_assets() {
		wp_register_script( 'bmc-catalog', BMC_URL . 'assets/js/bmc-catalog.js', array( 'jquery', 'bmc-icons' ), BMC_VERSION, true );

		wp_localize_script(
			'bmc-catalog',
			'bmcCatalog',
			array(
				'ajaxUrl' => admin_url( 'admin-ajax.php' ),
				'nonce'   => wp_create_nonce( 'bmc_public' ),
				'i18n'    => array(
					'loading'  => (string) BMC_Settings::get( 'qv_loading_text', 'در حال بارگذاری محصول…' ),
					'error'    => (string) BMC_Settings::get( 'qv_error_text', 'امکان بارگذاری این محصول وجود ندارد.' ),
					'moreText' => (string) BMC_Settings::get( 'shop_load_more_text', 'نمایش محصولات بیشتر' ),
				),
			)
		);
	}

	public static function enqueue_assets( array $cfg = array() ) {
		if ( ! did_action( 'wp_enqueue_scripts' ) && ! doing_action( 'wp_enqueue_scripts' ) ) {
			self::register_assets();
		}

		BMC_Public::enqueue_base_assets();

		if ( ! wp_script_is( 'bmc-catalog', 'registered' ) ) {
			self::register_assets();
		}

		wp_enqueue_script( 'bmc-catalog' );

		if ( self::yesno( isset( $cfg['qv_enabled'] ) ? $cfg['qv_enabled'] : 'yes' ) && wp_script_is( 'wc-add-to-cart-variation', 'registered' ) ) {
			wp_enqueue_script( 'wc-add-to-cart-variation' );
		}

		self::$assets = true;
	}

	public static function next_id() {
		self::$seq++;

		return 'bmc-shop-' . self::$seq;
	}

	public static function ajax_filter() {
		check_ajax_referer( 'bmc_public', 'nonce' );

		$cfg   = self::sanitize_config( self::posted_cfg() );
		$id    = isset( $_POST['instance'] ) ? sanitize_html_class( wp_unslash( (string) $_POST['instance'] ) ) : self::next_id();
		$state = self::state( $_POST, $cfg ); // phpcs:ignore WordPress.Security.NonceVerification

		if ( isset( $_POST['base'] ) ) {
			self::set_base_url( wp_unslash( (string) $_POST['base'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		}

		self::register_assets();

		$result = self::query( $cfg, $state );
		$target = isset( $_POST['target'] ) ? sanitize_html_class( wp_unslash( (string) $_POST['target'] ) ) : '';

		wp_send_json_success(
			array(
				'grid'   => self::render_grid( $cfg, $id, $state ),
				'filter' => self::render_filter( $cfg, $id, $state, $target ),
				'total'  => $result['total'],
				'shown'  => count( $result['items'] ),
				'pages'  => $result['pages'],
				'page'   => $state['page'],
				'url'    => self::state_url( $state ),
				'count'  => self::count_text( $cfg, count( $result['items'] ), $result['total'] ),
			)
		);
	}

	public static function ajax_more() {
		check_ajax_referer( 'bmc_public', 'nonce' );

		$cfg   = self::sanitize_config( self::posted_cfg() );
		$id    = isset( $_POST['instance'] ) ? sanitize_html_class( wp_unslash( (string) $_POST['instance'] ) ) : self::next_id();
		$state = self::state( $_POST, $cfg ); // phpcs:ignore WordPress.Security.NonceVerification

		if ( isset( $_POST['base'] ) ) {
			self::set_base_url( wp_unslash( (string) $_POST['base'] ) ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput
		}

		self::register_assets();

		$result = self::query( $cfg, $state );
		$html   = '';

		foreach ( $result['items'] as $index => $product ) {
			$html .= self::render_card( $product, $cfg, array( 'index' => $index, 'id' => $id ) );
		}

		wp_send_json_success(
			array(
				'cards' => $html,
				'pages' => $result['pages'],
				'page'  => $state['page'],
				'total' => $result['total'],
				'url'   => self::state_url( $state ),
			)
		);
	}

	public static function ajax_quick_view() {
		check_ajax_referer( 'bmc_public', 'nonce' );

		$product_id = isset( $_POST['product_id'] ) ? absint( $_POST['product_id'] ) : 0;
		$cfg        = self::sanitize_config( self::posted_cfg() );

		if ( ! $product_id || ! function_exists( 'wc_get_product' ) ) {
			wp_send_json_error( array( 'message' => (string) $cfg['qv_error_text'] ) );
		}

		$product = wc_get_product( $product_id );

		if ( ! $product || ! $product->is_visible() ) {
			wp_send_json_error( array( 'message' => (string) $cfg['qv_error_text'] ) );
		}

		self::register_assets();

		wp_send_json_success(
			array(
				'html'  => self::quick_view_html( $product, $cfg ),
				'title' => (string) $product->get_name(),
			)
		);
	}

	private static function posted_cfg() {
		if ( ! isset( $_POST['cfg'] ) ) {
			return array();
		}

		$raw = json_decode( (string) wp_unslash( $_POST['cfg'] ), true ); // phpcs:ignore WordPress.Security.ValidatedSanitizedInput

		return is_array( $raw ) ? $raw : array();
	}

	public static function count_text( array $cfg, $shown, $total ) {
		if ( ! self::yesno( $cfg['shop_show_count'] ) ) {
			return '';
		}

		$text = (string) $cfg['shop_count_text'];

		if ( '' === trim( $text ) ) {
			return '';
		}

		$text = str_replace( '{shown}', BMC_Helpers::to_persian_digits( (int) $shown ), $text );
		$text = str_replace( '{total}', BMC_Helpers::to_persian_digits( (int) $total ), $text );

		return $text;
	}

	public static function buy_now_redirect( $url ) {
		if ( empty( $_REQUEST['bmc_buy_now'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
			return $url;
		}

		return function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : $url;
	}

	public static function add_to_cart_url( $product, $buy_now = false ) {
		$id  = (int) $product->get_id();
		$url = (string) $product->add_to_cart_url();

		if ( $buy_now ) {
			$url = (string) add_query_arg( array( 'add-to-cart' => $id, 'bmc_buy_now' => '1' ), self::clean_url() );
		}

		return $url;
	}

	public static function grid_style( array $cfg ) {
		return sprintf(
			'--bmc-cols:%1$d;--bmc-cols-tablet:%2$d;--bmc-cols-mobile:%3$d;--bmc-gap:%4$dpx;--bmc-card-radius:%5$dpx;',
			max( 1, (int) $cfg['shop_columns'] ),
			max( 1, (int) $cfg['shop_columns_tablet'] ),
			max( 1, (int) $cfg['shop_columns_mobile'] ),
			max( 0, (int) $cfg['shop_gap'] ),
			max( 0, (int) $cfg['card_radius'] )
		);
	}

	public static function ratio_style( array $cfg ) {
		$ratios = array(
			'1:1'  => '1 / 1',
			'4:3'  => '4 / 3',
			'3:4'  => '3 / 4',
			'16:9' => '16 / 9',
		);

		$ratio = (string) $cfg['card_image_ratio'];

		if ( ! isset( $ratios[ $ratio ] ) ) {
			return '';
		}

		return '--bmc-card-ratio:' . $ratios[ $ratio ] . ';';
	}

	public static function product_options( $limit = 300 ) {
		$options = array();

		if ( ! function_exists( 'wc_get_products' ) ) {
			return $options;
		}

		$products = (array) wc_get_products(
			array(
				'limit'   => max( 10, (int) $limit ),
				'status'  => 'publish',
				'orderby' => 'title',
				'order'   => 'ASC',
				'return'  => 'objects',
			)
		);

		foreach ( $products as $product ) {
			if ( ! is_object( $product ) || ! method_exists( $product, 'get_id' ) ) {
				continue;
			}

			$options[ (int) $product->get_id() ] = (string) $product->get_name();
		}

		return $options;
	}

	public static function icon_options() {
		return array(
			''                  => '— بدون آیکون —',
			'storefront'        => 'فروشگاه',
			'filter_list'       => 'فیلتر',
			'tune'              => 'تنظیم دقیق',
			'manage_search'     => 'جست‌وجو',
			'search'            => 'ذره‌بین',
			'shopping_cart'     => 'سبد خرید',
			'shopping_basket'   => 'سبد',
			'add'               => 'افزودن',
			'payments'          => 'پرداخت',
			'sell'              => 'برچسب قیمت',
			'percent'           => 'درصد تخفیف',
			'category'          => 'دسته‌بندی',
			'inventory_2'       => 'محصول',
			'inventory'         => 'انبار',
			'dashboard'         => 'شبکه',
			'visibility'        => 'مشاهده',
			'open_in_new'       => 'بازکردن',
			'military_tech'     => 'رنک',
			'workspace_premium' => 'رنک ویژه',
			'schedule'          => 'زمان',
			'timer'             => 'تایمر',
			'star'              => 'امتیاز',
			'refresh'           => 'بازنشانی',
			'description'       => 'توضیحات',
			'list_alt'          => 'فهرست',
		);
	}

	public static function category_options() {
		$options = array();

		if ( ! taxonomy_exists( 'product_cat' ) ) {
			return $options;
		}

		$terms = get_terms(
			array(
				'taxonomy'   => 'product_cat',
				'hide_empty' => false,
				'orderby'    => 'name',
				'order'      => 'ASC',
			)
		);

		if ( is_wp_error( $terms ) ) {
			return $options;
		}

		foreach ( (array) $terms as $term ) {
			$prefix = self::term_depth( $term ) > 0 ? '— ' : '';
			$options[ (int) $term->term_id ] = $prefix . (string) $term->name . ' (' . BMC_Helpers::to_persian_digits( (int) $term->count ) . ')';
		}

		return $options;
	}
}
