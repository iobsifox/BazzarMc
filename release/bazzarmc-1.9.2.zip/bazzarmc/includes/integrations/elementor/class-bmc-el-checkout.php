<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class BMC_EL_Checkout extends BMC_EL_Base {

	public function get_name() {
		return 'bmc-checkout';
	}

	public function get_title() {
		return self::txt( 'Custom Checkout', 'تسویه‌حساب اختصاصی' );
	}

	public function get_icon() {
		return 'eicon-product-add-to-cart';
	}

	protected function bmc_slug() {
		return 'checkout';
	}

	protected function extra_keywords() {
		return array( 'checkout', 'payment', 'gate', 'چک‌اوت', 'پرداخت' );
	}

	protected function extra_scripts() {
		return array( 'bmc-checkout' );
	}

	protected function content_controls() {
		$this->start_controls_section(
			'bmc_sec_content',
			array(
				'label' => 'چک‌اوت',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'bmc_notice',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => 'فرم چک‌اوت اختصاصی BazzarMc با خلاصهٔ سفارش و درگاه‌های همان ووکامرس. اگر اکانت ماینکرافت متصل نباشد، به‌جای فرم، پیام مسدودسازی نمایش داده می‌شود.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_control(
			'hide_gate',
			array(
				'label'        => 'نمایش فرم حتی بدون اتصال اکانت',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'description'  => 'فقط برای پیش‌نمایش طراحی؛ در زمان ثبت سفارش همچنان بررسی اتصال انجام می‌شود.',
			)
		);

		$this->add_control(
			'co_layout_heading',
			array(
				'label' => 'چیدمان فرم خرید',
				'type'  => Controls_Manager::HEADING,
			)
		);

		$this->add_control(
			'co_cards',
			array(
				'label'       => 'کارت‌های نمایش‌داده‌شده',
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'options'     => array(
					'mc'      => 'اکانت ماینکرافت',
					'buyer'   => 'اطلاعات خریدار',
					'payment' => 'روش پرداخت',
					'extra'   => 'اطلاعات تکمیلی (فیلدهای دلخواه)',
				),
				'default'     => array(),
				'label_block' => true,
				'description' => 'خالی = همان کارت‌های انتخاب‌شده در تنظیمات افزونه.',
			)
		);

		$this->add_control(
			'co_columns',
			array(
				'label'   => 'ستون‌بندی فیلدها',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''  => 'پیش‌فرض (از تنظیمات افزونه)',
					'1' => 'یک ستونه',
					'2' => 'دو ستونه',
				),
			)
		);

		$this->add_control(
			'co_custom_fields',
			array(
				'label'       => 'فیلدهای دلخواه فرم خرید',
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'options'     => array(
					''    => 'پیش‌فرض (از فرم‌ساز افزونه)',
					'yes' => 'نمایش داده شوند',
					'no'  => 'پنهان شوند',
				),
				'description' => 'فیلدهایی که در تب «پرداخت ← فیلدهای دلخواه فرم خرید» ساخته‌اید.',
			)
		);

		$this->add_control(
			'co_extra_title',
			array(
				'label'       => 'عنوان کارت اطلاعات تکمیلی',
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'placeholder' => 'اطلاعات تکمیلی',
				'condition'   => array( 'co_custom_fields!' => 'no' ),
			)
		);

		$this->add_control(
			'co_submit',
			array(
				'label'   => 'متن دکمهٔ ثبت سفارش',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'co_steps',
			array(
				'label'   => 'نوار مرحله‌ها',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''    => 'پیش‌فرض (از تنظیمات افزونه)',
					'no'  => 'خیر',
					'yes' => 'بله',
				),
			)
		);

		$this->add_control(
			'co_back',
			array(
				'label'   => 'لینک بازگشت به سبد خرید',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''    => 'پیش‌فرض (از تنظیمات افزونه)',
					'no'  => 'خیر',
					'yes' => 'بله',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function style_controls() {
		$this->field_style_controls();
		$this->button_style_controls();

		$this->start_controls_section(
			'bmc_sec_checkout_style',
			array(
				'label' => 'چک‌اوت',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'section_typography',
				'label'    => 'تایپوگرافی عنوان بخش‌ها',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-card__title, {{WRAPPER}} .bmc-el h3',
			)
		);

		$this->add_control(
			'section_color',
			array(
				'label'     => 'رنگ عنوان بخش‌ها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-card__title, {{WRAPPER}} .bmc-el h3' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'card_padding',
			array(
				'label'      => 'فاصلهٔ داخلی کارت‌ها',
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'card_bg',
			array(
				'label'     => 'پس‌زمینهٔ کارت‌ها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-card' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'summary_bg',
			array(
				'label'     => 'پس‌زمینهٔ خلاصهٔ سفارش',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-summary, {{WRAPPER}} .bmc-el .bmc-check-side' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'gate_bg',
			array(
				'label'     => 'پس‌زمینهٔ پیام مسدودسازی',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-gate' => 'background: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function layout_overrides( $settings ) {
		$overrides = array();

		if ( isset( $settings['co_steps'] ) && '' !== (string) $settings['co_steps'] ) {
			$overrides['steps'] = (string) $settings['co_steps'];
		}

		if ( isset( $settings['co_back'] ) && '' !== (string) $settings['co_back'] ) {
			$overrides['back_to_cart'] = (string) $settings['co_back'];
		}

		if ( ! empty( $settings['co_submit'] ) ) {
			$overrides['submit_text'] = (string) $settings['co_submit'];
		}

		if ( isset( $settings['co_columns'] ) && '' !== (string) $settings['co_columns'] ) {
			$overrides['columns'] = (string) $settings['co_columns'];
		}

		if ( ! empty( $settings['co_cards'] ) && is_array( $settings['co_cards'] ) ) {
			$overrides['cards'] = array_map( 'sanitize_key', $settings['co_cards'] );
		}

		if ( isset( $settings['co_custom_fields'] ) && '' !== (string) $settings['co_custom_fields'] ) {
			$overrides['custom_fields'] = (string) $settings['co_custom_fields'];
		}

		if ( ! empty( $settings['co_extra_title'] ) ) {
			$overrides['extra_title'] = sanitize_text_field( (string) $settings['co_extra_title'] );
		}

		return $overrides;
	}

	protected function render_inner( $settings ) {
		if ( $this->woocommerce_missing() ) {
			return $this->notice( 'برای نمایش چک‌اوت، ووکامرس باید فعال باشد.' );
		}

		$overrides = $this->layout_overrides( $settings );

		if ( 'yes' === $settings['hide_gate'] ) {
			BMC_Public::enqueue_base_assets();

			ob_start();
			BMC_Checkout::render_checkout( $overrides );

			return (string) ob_get_clean();
		}

		return BMC_Public::shortcode_checkout(
			array(
				'steps'   => isset( $overrides['steps'] ) ? $overrides['steps'] : '',
				'back'    => isset( $overrides['back_to_cart'] ) ? $overrides['back_to_cart'] : '',
				'submit'  => isset( $overrides['submit_text'] ) ? $overrides['submit_text'] : '',
				'columns'       => isset( $overrides['columns'] ) ? $overrides['columns'] : '',
				'cards'         => isset( $overrides['cards'] ) ? implode( ',', $overrides['cards'] ) : '',
				'custom_fields' => isset( $overrides['custom_fields'] ) ? $overrides['custom_fields'] : '',
				'extra_title'   => isset( $overrides['extra_title'] ) ? $overrides['extra_title'] : '',
			)
		);
	}
}
