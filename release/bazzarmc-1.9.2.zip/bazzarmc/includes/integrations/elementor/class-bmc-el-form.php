<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Repeater;
use Elementor\Group_Control_Typography;

class BMC_EL_Form extends BMC_EL_Base {

	public function get_name() {
		return 'bmc-form';
	}

	public function get_title() {
		return self::txt( 'Custom Form', 'فرم اختصاصی BazzarMc' );
	}

	public function get_icon() {
		return 'eicon-form-horizontal';
	}

	protected function bmc_slug() {
		return 'form';
	}

	protected function extra_keywords() {
		return array( 'form', 'فرم', 'فرم‌ساز', 'تماس', 'contact', 'builder' );
	}

	protected function extra_scripts() {
		return array( 'bmc-form' );
	}

	protected function forms_ready() {
		return class_exists( 'BMC_Forms' ) && method_exists( 'BMC_Forms', 'enabled' ) && BMC_Forms::enabled();
	}

	protected function content_controls() {
		$choices = array( 'saved' => 'فرم ساخته‌شده در پیشخوان', 'builder' => 'ساخت فرم در همین ویجت' );
		$saved   = $this->forms_ready() ? BMC_Forms::choices( true ) : array();

		$this->start_controls_section(
			'bmc_sec_form_source',
			array(
				'label' => 'فرم',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'bmc_form_notice',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => 'فرم‌ساز BazzarMc: فیلدها را بچینید، سپس برای هر ارسال می‌توانید ورودی ذخیره کنید، ایمیل بفرستید، وب‌هوک صدا بزنید، تیکت پشتیبانی بسازید یا کاربر را به صفحهٔ دیگری ببرید.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_control(
			'form_source',
			array(
				'label'   => 'منبع فرم',
				'type'    => Controls_Manager::SELECT,
				'default' => $saved ? 'saved' : 'builder',
				'options' => $choices,
			)
		);

		$this->add_control(
			'form_id',
			array(
				'label'       => 'فرم انتخابی',
				'type'        => Controls_Manager::SELECT2,
				'options'     => $saved ? $saved : array( 0 => '— هنوز فرمی ساخته نشده —' ),
				'default'     => $saved ? (string) array_key_first( $saved ) : '0',
				'label_block' => true,
				'condition'   => array( 'form_source' => 'saved' ),
				'description' => 'فرم‌ها از پیشخوان ← BazzarMc ← فرم‌ها مدیریت می‌شوند.',
			)
		);

		$this->add_control(
			'form_title_override',
			array(
				'label'     => 'عنوان نمایشی (اختیاری)',
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'condition' => array( 'form_source' => 'saved' ),
			)
		);

		$this->add_control(
			'form_submit_override',
			array(
				'label'     => 'متن دکمهٔ ارسال (اختیاری)',
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'condition' => array( 'form_source' => 'saved' ),
			)
		);

		$this->end_controls_section();

		$this->builder_controls();
		$this->action_controls();
	}

	protected function builder_controls() {
		$this->start_controls_section(
			'bmc_sec_form_builder',
			array(
				'label'     => 'سازندهٔ فرم',
				'tab'       => Controls_Manager::TAB_CONTENT,
				'condition' => array( 'form_source' => 'builder' ),
			)
		);

		$this->add_control(
			'builder_title',
			array(
				'label'   => 'عنوان فرم',
				'type'    => Controls_Manager::TEXT,
				'default' => 'فرم درخواست',
			)
		);

		$this->add_control(
			'builder_description',
			array(
				'label'   => 'توضیح بالای فرم',
				'type'    => Controls_Manager::TEXTAREA,
				'rows'    => 2,
				'default' => '',
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'field_type',
			array(
				'label'   => 'نوع فیلد',
				'type'    => Controls_Manager::SELECT,
				'default' => 'text',
				'options' => $this->forms_ready() ? BMC_Forms::field_types() : array( 'text' => 'متن کوتاه' ),
			)
		);

		$repeater->add_control(
			'field_label',
			array(
				'label'   => 'برچسب',
				'type'    => Controls_Manager::TEXT,
				'default' => 'فیلد جدید',
			)
		);

		$repeater->add_control(
			'field_placeholder',
			array(
				'label'   => 'placeholder',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$repeater->add_control(
			'field_help',
			array(
				'label'   => 'راهنمای زیر فیلد',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$repeater->add_control(
			'field_options',
			array(
				'label'       => 'گزینه‌ها (هر خط یک گزینه)',
				'type'        => Controls_Manager::TEXTAREA,
				'rows'        => 4,
				'default'     => '',
				'condition'   => array(
					'field_type' => array( 'select', 'radio', 'checkbox_group' ),
				),
				'description' => 'برای مقدار متفاوت از برچسب: مقدار|برچسب',
			)
		);

		$repeater->add_control(
			'field_default',
			array(
				'label'   => 'مقدار پیش‌فرض',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$repeater->add_control(
			'field_required',
			array(
				'label'        => 'الزامی',
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => 'بله',
				'label_off'    => 'خیر',
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$repeater->add_control(
			'field_width',
			array(
				'label'   => 'عرض',
				'type'    => Controls_Manager::SELECT,
				'default' => '100',
				'options' => array(
					'100' => 'تمام عرض',
					'75'  => 'سه‌چهارم',
					'66'  => 'دو‌سوم',
					'50'  => 'نصف',
					'33'  => 'یک‌سوم',
					'25'  => 'یک‌چهارم',
				),
			)
		);

		$repeater->add_control(
			'field_min',
			array(
				'label'     => 'حداقل طول / مقدار',
				'type'      => Controls_Manager::NUMBER,
				'min'       => 0,
				'max'       => 100000,
				'default'   => 0,
				'condition' => array(
					'field_type' => array( 'text', 'textarea', 'email', 'tel', 'number', 'url', 'mc_username' ),
				),
			)
		);

		$repeater->add_control(
			'field_max',
			array(
				'label'     => 'حداکثر طول / مقدار',
				'type'      => Controls_Manager::NUMBER,
				'min'       => 0,
				'max'       => 100000,
				'default'   => 0,
				'condition' => array(
					'field_type' => array( 'text', 'textarea', 'email', 'tel', 'number', 'url', 'mc_username' ),
				),
			)
		);

		$repeater->add_control(
			'field_rows',
			array(
				'label'     => 'تعداد ردیف',
				'type'      => Controls_Manager::NUMBER,
				'min'       => 2,
				'max'       => 20,
				'default'   => 4,
				'condition' => array( 'field_type' => 'textarea' ),
			)
		);

		$repeater->add_control(
			'field_pattern',
			array(
				'label'       => 'الگوی اعتبارسنجی (regex)',
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'condition'   => array(
					'field_type' => array( 'text', 'tel', 'number' ),
				),
				'description' => 'مثال: ^09\d{9}$',
			)
		);

		$repeater->add_control(
			'field_message',
			array(
				'label'     => 'پیام خطای دلخواه',
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'condition' => array(
					'field_type' => array( 'text', 'tel', 'number' ),
				),
			)
		);

		$repeater->add_control(
			'field_iran_phone',
			array(
				'label'        => 'اعتبارسنجی شمارهٔ ایرانی',
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => 'بله',
				'label_off'    => 'خیر',
				'return_value' => 'yes',
				'default'      => '',
				'condition'    => array( 'field_type' => 'tel' ),
			)
		);

		$repeater->add_control(
			'field_accept',
			array(
				'label'       => 'پسوندهای مجاز (jpg,pdf,…)',
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'condition'   => array( 'field_type' => 'file' ),
			)
		);

		$repeater->add_control(
			'field_html',
			array(
				'label'     => 'متن یا HTML',
				'type'      => Controls_Manager::TEXTAREA,
				'rows'      => 3,
				'default'   => '',
				'condition' => array( 'field_type' => 'html' ),
			)
		);

		$repeater->add_control(
			'field_checked',
			array(
				'label'        => 'از قبل تیک‌خورده',
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => 'بله',
				'label_off'    => 'خیر',
				'return_value' => 'yes',
				'default'      => '',
				'condition'    => array( 'field_type' => 'checkbox' ),
			)
		);

		$this->add_control(
			'form_fields',
			array(
				'label'       => 'فیلدها',
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(
					array(
						'field_type'  => 'text',
						'field_label' => 'نام و نام خانوادگی',
						'field_width' => '50',
					),
					array(
						'field_type'  => 'tel',
						'field_label' => 'شمارهٔ تماس',
						'field_width' => '50',
					),
					array(
						'field_type'  => 'textarea',
						'field_label' => 'متن درخواست',
						'field_width' => '100',
					),
				),
				'title_field' => '{{{ field_label }}}',
			)
		);

		$this->add_control(
			'builder_submit_text',
			array(
				'label'   => 'متن دکمهٔ ارسال',
				'type'    => Controls_Manager::TEXT,
				'default' => 'ارسال درخواست',
			)
		);

		$this->add_control(
			'builder_success',
			array(
				'label'   => 'پیام موفقیت',
				'type'    => Controls_Manager::TEXTAREA,
				'rows'    => 2,
				'default' => 'درخواست شما با موفقیت ثبت شد. به‌زودی با شما تماس می‌گیریم.',
			)
		);

		$this->add_control(
			'builder_labels_position',
			array(
				'label'   => 'جای برچسب فیلدها',
				'type'    => Controls_Manager::SELECT,
				'default' => 'top',
				'options' => array(
					'top'    => 'بالای فیلد',
					'inline' => 'کنار فیلد',
					'none'   => 'بدون برچسب (فقط placeholder)',
				),
			)
		);

		$this->add_control(
			'builder_gap',
			array(
				'label'     => 'فاصلهٔ بین فیلدها',
				'type'      => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'     => array(
					'px' => array(
						'min' => 4,
						'max' => 48,
					),
				),
				'default'   => array(
					'unit' => 'px',
					'size' => 16,
				),
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-form__grid' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'builder_login_required',
			array(
				'label'        => 'فقط کاربران واردشده',
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => 'بله',
				'label_off'    => 'خیر',
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'builder_honeypot',
			array(
				'label'        => 'تلهٔ ضدربات (honeypot)',
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => 'روشن',
				'label_off'    => 'خاموش',
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'builder_allow_files',
			array(
				'label'        => 'اجازهٔ آپلود فایل',
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => 'بله',
				'label_off'    => 'خیر',
				'return_value' => 'yes',
				'default'      => '',
				'description'  => 'برای فعال‌شدن، در پیشخوان ← فرم‌ها هم «اجازهٔ آپلود فایل» روشن باشد.',
			)
		);

		$this->end_controls_section();
	}

	protected function action_controls() {
		$this->start_controls_section(
			'bmc_sec_form_actions',
			array(
				'label' => 'عملیات پس از ارسال',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'act_save_entries',
			array(
				'label'        => 'ذخیرهٔ ورودی‌ها در پیشخوان',
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => 'بله',
				'label_off'    => 'خیر',
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'act_email_enabled',
			array(
				'label'        => 'ارسال ایمیل',
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => 'بله',
				'label_off'    => 'خیر',
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'act_email_to',
			array(
				'label'       => 'گیرندهٔ ایمیل',
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'condition'   => array( 'act_email_enabled' => 'yes' ),
				'description' => 'خالی = ایمیل مدیر سایت. چند آدرس را با کاما جدا کنید.',
			)
		);

		$this->add_control(
			'act_email_subject',
			array(
				'label'     => 'موضوع ایمیل',
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'condition' => array( 'act_email_enabled' => 'yes' ),
			)
		);

		$this->add_control(
			'act_webhook_enabled',
			array(
				'label'        => 'فراخوانی وب‌هوک',
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => 'بله',
				'label_off'    => 'خیر',
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'act_webhook_url',
			array(
				'label'     => 'آدرس وب‌هوک',
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'condition' => array( 'act_webhook_enabled' => 'yes' ),
			)
		);

		$this->add_control(
			'act_ticket_enabled',
			array(
				'label'        => 'ساخت تیکت پشتیبانی',
				'type'         => Controls_Manager::SWITCHER,
				'label_on'     => 'بله',
				'label_off'    => 'خیر',
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'act_ticket_category',
			array(
				'label'     => 'دستهٔ تیکت',
				'type'      => Controls_Manager::SELECT,
				'default'   => 'other',
				'options'   => $this->forms_ready() ? BMC_Forms::ticket_categories() : array( 'other' => 'سایر' ),
				'condition' => array( 'act_ticket_enabled' => 'yes' ),
			)
		);

		$this->add_control(
			'act_ticket_priority',
			array(
				'label'     => 'اولویت تیکت',
				'type'      => Controls_Manager::SELECT,
				'default'   => 'normal',
				'options'   => $this->forms_ready() ? BMC_Forms::ticket_priorities() : array( 'normal' => 'عادی' ),
				'condition' => array( 'act_ticket_enabled' => 'yes' ),
			)
		);

		$this->add_control(
			'act_redirect_url',
			array(
				'label'       => 'انتقال پس از ارسال موفق',
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'description' => 'خالی = نمایش پیام موفقیت در همان صفحه.',
			)
		);

		$this->end_controls_section();
	}

	protected function style_controls() {
		$this->field_style_controls( 'فیلدهای فرم' );
		$this->button_style_controls();

		$this->start_controls_section(
			'bmc_sec_form_style',
			array(
				'label' => 'فرم',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'form_title_typography',
				'label'    => 'تایپوگرافی عنوان فرم',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-form-wrap .bmc-title',
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'form_label_typography',
				'label'    => 'تایپوگرافی برچسب فیلدها',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-form-wrap .bmc-label',
			)
		);

		$this->add_responsive_control(
			'form_max_width',
			array(
				'label'      => 'حداکثر پهنای فرم',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array(
						'min' => 320,
						'max' => 1400,
					),
					'%'  => array(
						'min' => 30,
						'max' => 100,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-form-wrap .bmc-container' => 'max-width: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'form_card_bg',
			array(
				'label'     => 'پس‌زمینهٔ کارت فرم',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-form-wrap .bmc-card, {{WRAPPER}} .bmc-el .bmc-form-wrap .bmc-wrap' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'form_accent',
			array(
				'label'     => 'رنگ تأکیدی فرم',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-form-wrap' => '--bmc-accent: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'form_padding',
			array(
				'label'      => 'فاصلهٔ داخلی کارت',
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', 'em', '%' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-form-wrap .bmc-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function builder_config( $settings ) {
		$config = array(
			'title'           => isset( $settings['builder_title'] ) ? (string) $settings['builder_title'] : '',
			'description'     => isset( $settings['builder_description'] ) ? (string) $settings['builder_description'] : '',
			'submit_text'     => isset( $settings['builder_submit_text'] ) ? (string) $settings['builder_submit_text'] : 'ارسال',
			'success_message' => isset( $settings['builder_success'] ) ? (string) $settings['builder_success'] : '',
			'labels_position' => isset( $settings['builder_labels_position'] ) ? (string) $settings['builder_labels_position'] : 'top',
			'gap'             => isset( $settings['builder_gap']['size'] ) ? (int) $settings['builder_gap']['size'] : 16,
			'login_required'  => $this->on( $settings, 'builder_login_required' ),
			'honeypot'        => $this->on( $settings, 'builder_honeypot', true ),
			'save_entries'    => $this->on( $settings, 'act_save_entries', true ),
			'allow_files'     => $this->on( $settings, 'builder_allow_files' ),
			'fields'          => array(),
		);

		$rows = isset( $settings['form_fields'] ) && is_array( $settings['form_fields'] ) ? $settings['form_fields'] : array();
		$i    = 0;

		foreach ( $rows as $row ) {
			if ( ! is_array( $row ) ) {
				continue;
			}

			$type = isset( $row['field_type'] ) ? (string) $row['field_type'] : 'text';

			$field = array(
				'type'        => $type,
				'label'       => isset( $row['field_label'] ) ? (string) $row['field_label'] : '',
				'placeholder' => isset( $row['field_placeholder'] ) ? (string) $row['field_placeholder'] : '',
				'help'        => isset( $row['field_help'] ) ? (string) $row['field_help'] : '',
				'default'     => isset( $row['field_default'] ) ? (string) $row['field_default'] : '',
				'required'    => 'yes' === ( isset( $row['field_required'] ) ? (string) $row['field_required'] : '' ) ? 1 : 0,
				'width'       => isset( $row['field_width'] ) ? (int) $row['field_width'] : 100,
				'min'         => isset( $row['field_min'] ) ? (int) $row['field_min'] : 0,
				'max'         => isset( $row['field_max'] ) ? (int) $row['field_max'] : 0,
				'rows'        => isset( $row['field_rows'] ) ? (int) $row['field_rows'] : 4,
				'pattern'     => isset( $row['field_pattern'] ) ? (string) $row['field_pattern'] : '',
				'message'     => isset( $row['field_message'] ) ? (string) $row['field_message'] : '',
				'accept'      => isset( $row['field_accept'] ) ? (string) $row['field_accept'] : '',
				'iran_phone'  => 'yes' === ( isset( $row['field_iran_phone'] ) ? (string) $row['field_iran_phone'] : '' ) ? 1 : 0,
				'options'     => array(),
			);

			if ( 'checkbox' === $type && 'yes' === ( isset( $row['field_checked'] ) ? (string) $row['field_checked'] : '' ) ) {
				$field['default'] = '1';
			}

			if ( 'html' === $type ) {
				$field['default'] = isset( $row['field_html'] ) ? (string) $row['field_html'] : '';
			}

			if ( in_array( $type, array( 'select', 'radio', 'checkbox_group' ), true ) ) {
				$raw = isset( $row['field_options'] ) ? (string) $row['field_options'] : '';

				foreach ( preg_split( '/\r\n|\r|\n/', $raw ) as $line ) {
					$line = trim( $line );

					if ( '' === $line ) {
						continue;
					}

					if ( false !== strpos( $line, '|' ) ) {
						list( $value, $label ) = array_map( 'trim', explode( '|', $line, 2 ) );
						$field['options'][]    = array(
							'value' => $value,
							'label' => '' === $label ? $value : $label,
						);
						continue;
					}

					$field['options'][] = array(
						'value' => $line,
						'label' => $line,
					);
				}
			}

			$config['fields'][] = $field;
			$i++;
		}

		$config = array_merge( $config, $this->action_config( $settings ) );

		return $config;
	}

	protected function action_config( $settings ) {
		return array(
			'email_enabled'   => $this->on( $settings, 'act_email_enabled' ),
			'email_to'        => isset( $settings['act_email_to'] ) ? (string) $settings['act_email_to'] : '',
			'email_subject'   => isset( $settings['act_email_subject'] ) ? (string) $settings['act_email_subject'] : '',
			'webhook_enabled' => $this->on( $settings, 'act_webhook_enabled' ),
			'webhook_url'     => isset( $settings['act_webhook_url'] ) ? (string) $settings['act_webhook_url'] : '',
			'ticket_enabled'  => $this->on( $settings, 'act_ticket_enabled' ),
			'ticket_category' => isset( $settings['act_ticket_category'] ) ? (string) $settings['act_ticket_category'] : 'other',
			'ticket_priority' => isset( $settings['act_ticket_priority'] ) ? (string) $settings['act_ticket_priority'] : 'normal',
			'redirect_url'    => isset( $settings['act_redirect_url'] ) ? (string) $settings['act_redirect_url'] : '',
		);
	}

	protected function on( $settings, $key, $default = false ) {
		if ( ! isset( $settings[ $key ] ) || '' === $settings[ $key ] ) {
			return $default ? 1 : 0;
		}

		return 'yes' === (string) $settings[ $key ] ? 1 : 0;
	}

	protected function render_inner( $settings ) {
		if ( ! $this->forms_ready() ) {
			return $this->notice( 'فرم‌ساز BazzarMc غیرفعال است. از پیشخوان ← BazzarMc ← فرم‌ها آن را روشن کنید.' );
		}

		$source    = isset( $settings['form_source'] ) ? (string) $settings['form_source'] : 'saved';
		$overrides = array();

		if ( '' !== trim( (string) ( isset( $settings['form_title_override'] ) ? $settings['form_title_override'] : '' ) ) ) {
			$overrides['title'] = (string) $settings['form_title_override'];
		}

		if ( '' !== trim( (string) ( isset( $settings['form_submit_override'] ) ? $settings['form_submit_override'] : '' ) ) ) {
			$overrides['submit_text'] = (string) $settings['form_submit_override'];
		}

		if ( 'builder' === $source ) {
			$config = $this->builder_config( $settings );

			if ( empty( $config['fields'] ) ) {
				return $this->editor_placeholder( 'هیچ فیلدی اضافه نشده است. از بخش «سازندهٔ فرم» فیلد اضافه کنید.' );
			}

			return (string) BMC_Forms::render( $config );
		}

		$form_id = isset( $settings['form_id'] ) ? (int) $settings['form_id'] : 0;

		if ( ! $form_id ) {
			return $this->editor_placeholder( 'یک فرم را از فهرست انتخاب کنید یا منبع فرم را روی «ساخت فرم در همین ویجت» بگذارید.' );
		}

		if ( $overrides ) {
			$form = BMC_Forms::get( $form_id );

			if ( ! $form ) {
				return $this->notice( 'فرم انتخابی پیدا نشد.' );
			}

			$form['id'] = $form_id;

			return (string) BMC_Forms::render( array_merge( $form, $overrides ), array() );
		}

		return (string) BMC_Forms::render( $form_id );
	}
}
