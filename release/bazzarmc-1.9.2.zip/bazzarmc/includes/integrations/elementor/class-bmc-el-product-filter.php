<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class BMC_EL_Product_Filter extends BMC_EL_Base {

	public function get_name() {
		return 'bmc-product-filter';
	}

	public function get_title() {
		return self::txt( 'Product Filter', 'فیلتر محصولات' );
	}

	public function get_icon() {
		return 'eicon-filter';
	}

	protected function bmc_slug() {
		return 'product-filter';
	}

	protected function extra_keywords() {
		return array( 'filter', 'category', 'search', 'sort', 'فیلتر', 'دسته‌بندی', 'جستجو', 'مرتب‌سازی' );
	}

	protected function extra_scripts() {
		return array( 'bmc-catalog' );
	}

	private function yesno_options() {
		return array(
			''    => 'پیش‌فرض (از تنظیمات افزونه)',
			'no'  => 'خیر',
			'yes' => 'بله',
		);
	}

	protected function content_controls() {
		$this->start_controls_section(
			'bmc_sec_content',
			array(
				'label' => 'نوار فیلتر',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'bmc_notice',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => 'نوار فیلتر از دسته‌بندی‌های محصول ووکامرس ساخته می‌شود و ویترین محصولاتِ همان صفحه را فیلتر می‌کند. اگر ویجت ویترین در همین صفحه باشد، فیلتر به‌صورت خودکار به آن وصل می‌شود.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_control(
			'target',
			array(
				'label'       => 'شناسهٔ ویترین هدف',
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'description' => 'خالی = اولین ویترین همان صفحه. شناسه از attribute «data-bmc-shop» ویترین خوانده می‌شود.',
			)
		);

		$this->add_control(
			'shop_categories',
			array(
				'label'       => 'دسته‌بندی‌های فیلتر',
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'default'     => array(),
				'options'     => $this->category_options(),
				'description' => 'خالی = همهٔ دسته‌بندی‌های سطح اول.',
			)
		);

		$this->add_control(
			'shop_category_depth',
			array(
				'label'   => 'عمق دسته‌بندی‌ها',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''  => 'پیش‌فرض',
					'1' => '۱ — فقط خود دسته‌ها',
					'2' => '۲ — با زیردسته‌ها',
					'3' => '۳ — سه سطح',
					'4' => '۴ — چهار سطح',
				),
			)
		);

		$this->add_control(
			'shop_hide_empty_cats',
			array(
				'label'   => 'پنهان‌کردن دستهٔ خالی',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'filter_style',
			array(
				'label'   => 'سبک فیلتر',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''       => 'پیش‌فرض',
					'pills'  => 'دکمه‌های گرد',
					'tabs'   => 'زبانه‌ای',
					'chips'  => 'چیپس فشرده',
					'select' => 'فهرست کشویی',
				),
			)
		);

		$this->add_control(
			'filter_title',
			array(
				'label'   => 'عنوان نوار فیلتر',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'filter_icon',
			array(
				'label'   => 'آیکون عنوان',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'filter_show_all',
			array(
				'label'   => 'گزینهٔ «همه»',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'filter_all_label',
			array(
				'label'   => 'متن گزینهٔ «همه»',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'filter_show_counts',
			array(
				'label'   => 'شمارش محصولات دسته',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'filter_show_thumb',
			array(
				'label'   => 'تصویر دسته',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'filter_sticky',
			array(
				'label'   => 'چسبان در اسکرول',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'filter_show_sort',
			array(
				'label'   => 'فهرست مرتب‌سازی',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'filter_sort_label',
			array(
				'label'   => 'برچسب مرتب‌سازی',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'filter_sort_options',
			array(
				'label'    => 'گزینه‌های مرتب‌سازی',
				'type'     => Controls_Manager::SELECT2,
				'multiple' => true,
				'default'  => array(),
				'options'  => BMC_Settings::sort_options(),
			)
		);

		$this->add_control(
			'filter_default_sort',
			array(
				'label'   => 'مرتب‌سازی پیش‌فرض',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array_merge( array( '' => 'پیش‌فرض' ), BMC_Settings::sort_options() ),
			)
		);

		$this->add_control(
			'filter_show_search',
			array(
				'label'   => 'جعبهٔ جست‌وجو',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'filter_search_placeholder',
			array(
				'label'   => 'placeholder جست‌وجو',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'filter_search_min',
			array(
				'label'       => 'حداقل نویسهٔ جست‌وجوی زنده',
				'type'        => Controls_Manager::NUMBER,
				'min'         => 1,
				'max'         => 8,
				'default'     => '',
				'description' => 'تا این تعداد نویسه، جست‌وجوی خودکار اجرا نمی‌شود.',
			)
		);

		$this->add_control(
			'filter_show_reset',
			array(
				'label'   => 'دکمهٔ پاک‌کردن فیلتر',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => $this->yesno_options(),
			)
		);

		$this->add_control(
			'filter_reset_text',
			array(
				'label'   => 'متن دکمهٔ پاک‌کردن',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'shop_ajax',
			array(
				'label'       => 'فیلتر زنده (AJAX)',
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'options'     => $this->yesno_options(),
				'description' => 'خیر = فیلترها با پیوند و فرم GET انجام می‌شوند.',
			)
		);

		$this->end_controls_section();
	}

	protected function style_controls() {
		$this->start_controls_section(
			'bmc_sec_filter_style',
			array(
				'label' => 'ظاهر نوار فیلتر',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'filter_bg',
			array(
				'label'     => 'پس‌زمینهٔ نوار فیلتر',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-filter' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'filter_border_color',
			array(
				'label'     => 'رنگ حاشیهٔ نوار فیلتر',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-filter' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'filter_radius',
			array(
				'label'      => 'گردی گوشه‌ها',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', 'rem' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-filter' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'filter_padding',
			array(
				'label'      => 'فاصلهٔ داخلی',
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-filter' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'filter_gap',
			array(
				'label'      => 'فاصلهٔ بین گزینه‌ها',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 30,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-filter__cats' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'filter_typography',
				'label'    => 'تایپوگرافی گزینه‌ها',
				'selector' => '{{WRAPPER}} .bmc-filter__item',
			)
		);

		$this->add_control(
			'filter_item_bg',
			array(
				'label'     => 'پس‌زمینهٔ گزینه',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-filter__item' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'filter_item_color',
			array(
				'label'     => 'رنگ گزینه',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-filter__item' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'filter_item_border_color',
			array(
				'label'     => 'رنگ حاشیهٔ گزینه',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-filter__item' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'filter_item_active_bg',
			array(
				'label'     => 'پس‌زمینهٔ گزینهٔ فعال',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-filter__item.is-active' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'filter_item_active_color',
			array(
				'label'     => 'رنگ گزینهٔ فعال',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-filter__item.is-active' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'filter_item_radius',
			array(
				'label'      => 'گردی گزینه‌ها',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-filter__item' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'filter_count_color',
			array(
				'label'     => 'رنگ شمارش دسته',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-filter__count' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'filter_count_bg',
			array(
				'label'     => 'پس‌زمینهٔ شمارش دسته',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-filter__count' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'filter_title_color',
			array(
				'label'     => 'رنگ عنوان',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-filter__title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_section();

		$this->field_style_controls( 'جعبهٔ جست‌وجو و مرتب‌سازی' );
		$this->button_style_controls( 'دکمه‌های فیلتر' );
	}

	private function category_options() {
		$options = array();

		if ( ! class_exists( 'BMC_Catalog' ) ) {
			return $options;
		}

		foreach ( BMC_Catalog::category_options() as $id => $label ) {
			$options[ (string) $id ] = $label;
		}

		return $options;
	}

	private function overrides( $settings ) {
		$keys = array(
			'shop_category_depth', 'shop_hide_empty_cats', 'filter_style', 'filter_title', 'filter_icon',
			'filter_show_all', 'filter_all_label', 'filter_show_counts', 'filter_show_thumb', 'filter_sticky',
			'filter_show_sort', 'filter_sort_label', 'filter_default_sort', 'filter_show_search',
			'filter_search_placeholder', 'filter_search_min', 'filter_show_reset', 'filter_reset_text', 'shop_ajax',
		);

		$out = array();

		foreach ( $keys as $key ) {
			if ( ! isset( $settings[ $key ] ) || '' === $settings[ $key ] || null === $settings[ $key ] ) {
				continue;
			}

			$out[ $key ] = $settings[ $key ];
		}

		if ( ! empty( $settings['shop_categories'] ) && is_array( $settings['shop_categories'] ) ) {
			$out['shop_categories'] = array_map( 'absint', $settings['shop_categories'] );
		}

		if ( ! empty( $settings['filter_sort_options'] ) && is_array( $settings['filter_sort_options'] ) ) {
			$out['filter_sort_options'] = array_map( 'sanitize_key', $settings['filter_sort_options'] );
		}

		return $out;
	}

	protected function render_inner( $settings ) {
		if ( $this->woocommerce_missing() ) {
			return $this->notice( 'برای نمایش نوار فیلتر، ووکامرس باید فعال باشد.' );
		}

		if ( ! class_exists( 'BMC_Catalog' ) ) {
			return $this->notice( 'ماژول ویترین BazzarMc در دسترس نیست.' );
		}

		$target = isset( $settings['target'] ) ? sanitize_html_class( (string) $settings['target'] ) : '';

		return (string) BMC_Catalog::render_filter_only( $this->overrides( $settings ), $target );
	}
}
