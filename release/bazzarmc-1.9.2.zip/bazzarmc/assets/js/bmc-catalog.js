(function ($) {
	'use strict';

	var cfg = window.bmcCatalog || {};
	var i18n = cfg.i18n || {};
	var busy = {};
	var debounce = {};
	var lastOpener = null;

	function escapeHtml(text) {
		return String(text === null || typeof text === 'undefined' ? '' : text)
			.replace(/&/g, '&amp;')
			.replace(/</g, '&lt;')
			.replace(/>/g, '&gt;')
			.replace(/"/g, '&quot;');
	}

	function parseCfg($el) {
		var raw = $el && $el.length ? $el.attr('data-bmc-cfg') : '';

		if (!raw) {
			return {};
		}

		try {
			var parsed = JSON.parse(raw);
			return parsed && typeof parsed === 'object' ? parsed : {};
		} catch (error) {
			return {};
		}
	}

	function findShopContainer($filter) {
		var target = $filter && $filter.length ? ($filter.attr('data-bmc-target') || '') : '';
		if (target) {
			var $target = $('#' + target);
			if ($target.length) {
				return $target;
			}
			var $named = $('[data-bmc-shop="' + target + '"]');
			if ($named.length) {
				return $named;
			}
		}

		if ($filter && $filter.length) {
			var $parentShop = $filter.closest('[data-bmc-shop]:not(.bmc-shop--filter-only)');
			if ($parentShop.length) {
				return $parentShop;
			}
		}

		var $pageShop = $('[data-bmc-shop]:not(.bmc-shop--filter-only)').first();
		if ($pageShop.length) {
			return $pageShop;
		}

		return $filter && $filter.length ? $filter.closest('[data-bmc-shop]') : $('[data-bmc-shop]').first();
	}

	function isAjax($filter) {
		return $filter.length && $filter.attr('data-bmc-ajax') === '1';
	}

	function updateUrl(url) {
		if (url && window.history && window.history.replaceState) {
			window.history.replaceState({}, '', url);
		}
	}

	function readState($filter) {
		var cat = '';
		var $active = $filter.find('.bmc-filter__item.is-active').first();

		if ($active.length) {
			cat = $active.attr('data-bmc-cat') || '';
		}

		var $select = $filter.find('[data-bmc-cat-select]').first();

		if ($select.length) {
			cat = $select.val() || '';
		}

		var $sort = $filter.find('[data-bmc-sort]').first();
		var $search = $filter.find('[data-bmc-search]').first();

		return {
			cat: cat,
			sort: $sort.length ? ($sort.val() || '') : ($filter.attr('data-bmc-default-sort') || ''),
			s: $search.length ? ($search.val() || '') : '',
			page: 1
		};
	}

	function loadingHtml() {
		return '<div class="bmc-qv__loading"><span class="bmc-qv__spinner"></span><span>' + escapeHtml(i18n.loading || '') + '</span></div>';
	}

	function initForms($scope) {
		$scope.find('form.variations_form').each(function () {
			var $form = $(this);

			if ($form.attr('data-bmc-vf') === '1') {
				return;
			}

			$form.attr('data-bmc-vf', '1');

			if ($.fn.wc_variation_form) {
				try {
					$form.wc_variation_form();
				} catch (error) {
					$form.removeAttr('data-bmc-vf');
				}
			} else {
				$form.removeAttr('data-bmc-vf');
			}
		});
	}

	function openQuickView(productId, $scope) {
		productId = parseInt(productId, 10) || 0;

		if (!productId) {
			return;
		}

		var $modal = $('#bmcQv');

		if (!$modal.length) {
			return;
		}

		var $body = $modal.find('[data-bmc-qv-content]').first();
		var $root = findShopContainer($scope);

		lastOpener = $scope && $scope.length ? $scope[0] : (document.activeElement || null);

		$body.html(loadingHtml());
		$modal.prop('hidden', false).addClass('is-open');
		$('body').addClass('bmc-qv-lock');
		$modal.find('.bmc-qv__close').first().trigger('focus');

		$.post(cfg.ajaxUrl, {
			action: 'bmc_quick_view',
			nonce: cfg.nonce,
			product_id: productId,
			cfg: JSON.stringify(parseCfg($root))
		}).done(function (res) {
			if (res && res.success && res.data && res.data.html) {
				$body.html(res.data.html);

				if (res.data.title) {
					$modal.find('#bmcQvTitle').text(res.data.title);
				}

				initForms($body);

				return;
			}

			var message = res && res.data && res.data.message ? res.data.message : (i18n.error || '');

			$body.html('<div class="bmc-qv__error">' + escapeHtml(message) + '</div>');
		}).fail(function () {
			$body.html('<div class="bmc-qv__error">' + escapeHtml(i18n.error || '') + '</div>');
		});
	}

	function closeQuickView() {
		var $modal = $('#bmcQv');

		if (!$modal.length || $modal.prop('hidden')) {
			return;
		}

		$modal.removeClass('is-open').prop('hidden', true);
		$('body').removeClass('bmc-qv-lock');
		$modal.find('[data-bmc-qv-content]').first().empty();

		if (lastOpener && typeof lastOpener.focus === 'function') {
			try {
				lastOpener.focus();
			} catch (error) {
				lastOpener = null;
			}
		}

		lastOpener = null;
	}

	function applyFilter($filter, options) {
		if (!$filter || !$filter.length) {
			return;
		}

		options = options || {};

		var $shop = findShopContainer($filter);
		var $filterRoot = $filter.closest('[data-bmc-cfg]');
		var shopKey = $shop.length ? ($shop.attr('data-bmc-shop') || 'shop') : 'shop';

		if (busy[shopKey]) {
			return;
		}

		var state = readState($filter);

		if (typeof options.cat !== 'undefined') {
			state.cat = options.cat;
		}

		if (options.page) {
			state.page = options.page;
		}

		var shopCfg = parseCfg($shop);
		var filterCfg = parseCfg($filterRoot);
		var mergedCfg = $.extend({}, shopCfg, filterCfg);

		busy[shopKey] = true;
		if ($shop.length) {
			$shop.addClass('is-loading');
		}
		$filter.addClass('is-loading');

		var $results = $shop.length ? $shop.find('.bmc-shop__results').first() : $();
		var $main = $shop.length ? $shop.find('.bmc-shop__main').first() : $();

		$.post(cfg.ajaxUrl, {
			action: 'bmc_shop_filter',
			nonce: cfg.nonce,
			instance: shopKey,
			target: $filter.attr('data-bmc-target') || '',
			base: window.location.href.split('?')[0],
			cfg: JSON.stringify(mergedCfg),
			bmc_cat: state.cat,
			bmc_sort: state.sort,
			bmc_s: state.s,
			bmc_paged: state.page
		}).done(function (res) {
			if (!res || !res.success || !res.data) {
				return;
			}

			var data = res.data;

			if (data.grid && $shop.length) {
				if ($results.length) {
					$results.replaceWith(data.grid);
				} else if ($main.length) {
					$main.html(data.grid);
				} else {
					$shop.html(data.grid);
				}
			}

			if (data.filter) {
				$filter.replaceWith(data.filter);
			}

			updateUrl(data.url);
		}).always(function () {
			busy[shopKey] = false;
			if ($shop.length) {
				$shop.removeClass('is-loading');
			}
			$filter.removeClass('is-loading');
		});
	}

	$(document).on('click', '.bmc-pcard', function (event) {
		var $card = $(this);

		if ($card.attr('data-bmc-click') !== 'quickview') {
			return;
		}

		if ($(event.target).closest('[data-bmc-noqv], a.bmc-btn, button, input, select, textarea, label').length) {
			return;
		}

		var productId = parseInt($card.attr('data-bmc-product'), 10) || 0;

		if (!productId) {
			return;
		}

		event.preventDefault();
		openQuickView(productId, $card);
	});

	$(document).on('click', '[data-bmc-qv-open]', function (event) {
		event.preventDefault();
		event.stopPropagation();
		openQuickView($(this).attr('data-bmc-qv-open'), $(this));
	});

	$(document).on('click', '[data-bmc-qv-close]', function (event) {
		event.preventDefault();
		closeQuickView();
	});

	$(document).on('keydown', function (event) {
		if (27 === event.keyCode) {
			closeQuickView();
		}
	});

	$(document).on('keydown', '.bmc-pcard', function (event) {
		var $card = $(this);

		if ($card.attr('data-bmc-click') !== 'quickview') {
			return;
		}

		if (13 !== event.keyCode && 32 !== event.keyCode) {
			return;
		}

		if ($(event.target).closest('[data-bmc-noqv], a.bmc-btn, button, input, select, textarea, label').length) {
			return;
		}

		var productId = parseInt($card.attr('data-bmc-product'), 10) || 0;

		if (!productId) {
			return;
		}

		event.preventDefault();
		openQuickView(productId, $card);
	});

	$(document).on('click', '[data-bmc-filter] .bmc-filter__item', function (event) {
		var $filter = $(this).closest('[data-bmc-filter]');

		if (!isAjax($filter)) {
			return;
		}

		event.preventDefault();
		applyFilter($filter, { cat: $(this).attr('data-bmc-cat') || '' });
	});

	$(document).on('change', '[data-bmc-filter] [data-bmc-cat-select], [data-bmc-filter] [data-bmc-sort]', function () {
		var $filter = $(this).closest('[data-bmc-filter]');

		if (!isAjax($filter)) {
			return;
		}

		applyFilter($filter);
	});

	$(document).on('submit', '[data-bmc-filter] .bmc-filter__tools', function (event) {
		var $filter = $(this).closest('[data-bmc-filter]');

		if (!isAjax($filter)) {
			return;
		}

		event.preventDefault();
		applyFilter($filter);
	});

	$(document).on('click', '[data-bmc-filter] [data-bmc-reset]', function (event) {
		var $filter = $(this).closest('[data-bmc-filter]');

		if (!isAjax($filter)) {
			return;
		}

		event.preventDefault();

		$filter.find('[data-bmc-search]').val('');

		var $sort = $filter.find('[data-bmc-sort]').first();
		var fallback = $filter.attr('data-bmc-default-sort') || '';

		if ($sort.length && fallback) {
			$sort.val(fallback);
		}

		applyFilter($filter, { cat: '' });
	});

	$(document).on('input', '[data-bmc-filter] [data-bmc-search]', function () {
		var $filter = $(this).closest('[data-bmc-filter]');

		if (!isAjax($filter)) {
			return;
		}

		var min = parseInt($filter.attr('data-bmc-search-min'), 10) || 2;
		var value = $(this).val() || '';
		var key = 'search-' + ($filter.attr('data-bmc-filter') || 'main');

		if (debounce[key]) {
			clearTimeout(debounce[key]);
		}

		if (value.length > 0 && value.length < min) {
			return;
		}

		debounce[key] = setTimeout(function () {
			applyFilter($filter);
		}, 450);
	});

	$(document).on('click', '[data-bmc-shop] .bmc-shop__pages a, [data-bmc-shop] .bmc-shop__page', function (event) {
		var $root = findShopContainer($(this));

		if (!$root.length || $root.attr('data-bmc-ajax') !== '1') {
			return;
		}

		var href = $(this).attr('href') || '';
		var match = href.match(/bmc_paged=(\d+)/);

		if (!match) {
			return;
		}

		event.preventDefault();

		var $filter = $('[data-bmc-filter]').first();

		if ($filter.length) {
			applyFilter($filter, { page: parseInt(match[1], 10) || 1 });
		}
	});

	$(document).on('click', '[data-bmc-more]', function (event) {
		event.preventDefault();

		var $button = $(this);
		var id = $button.attr('data-bmc-more') || '';
		var page = parseInt($button.attr('data-bmc-page'), 10) || 2;
		var $root = id ? $('#' + id) : findShopContainer($button);

		if (!$root.length) {
			return;
		}

		var $filter = $('[data-bmc-filter]').first();
		var state = $filter.length ? readState($filter) : { cat: '', sort: '', s: '', page: 1 };

		$button.prop('disabled', true).addClass('is-loading');

		$.post(cfg.ajaxUrl, {
			action: 'bmc_shop_more',
			nonce: cfg.nonce,
			instance: id || $root.attr('data-bmc-shop') || '',
			base: window.location.href.split('?')[0],
			cfg: JSON.stringify(parseCfg($root)),
			bmc_cat: state.cat,
			bmc_sort: state.sort,
			bmc_s: state.s,
			bmc_paged: page
		}).done(function (res) {
			if (!res || !res.success || !res.data) {
				$button.prop('disabled', false).removeClass('is-loading');

				return;
			}

			var data = res.data;
			var $grid = $root.find('[data-bmc-grid]').first();

			if ($grid.length && data.cards) {
				$grid.append(data.cards);
			}

			if (data.page >= data.pages) {
				$button.closest('.bmc-shop__more-wrap').remove();
			} else {
				$button.attr('data-bmc-page', data.page + 1).prop('disabled', false).removeClass('is-loading');
			}

			updateUrl(data.url);
		}).fail(function () {
			$button.prop('disabled', false).removeClass('is-loading');
		});
	});

	$(function () {
		var $modal = $('#bmcQv');

		if ($modal.length && $modal.hasClass('is-open')) {
			$('body').addClass('bmc-qv-lock');
			initForms($modal.find('[data-bmc-qv-content]').first());
		}
	});
}(jQuery));
