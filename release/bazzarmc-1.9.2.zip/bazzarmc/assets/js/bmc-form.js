(function ($) {
	'use strict';

	if (typeof bmcForm === 'undefined') {
		return;
	}

	var i18n = bmcForm.i18n || {};

	function alertBox($form) {
		var $wrap = $form.closest('.bmc-form-wrap');
		var id = $form.data('form-id');
		var $box = $('#bmcFormAlert-' + id);

		if (!$box.length) {
			$box = $('<div></div>').attr('id', 'bmcFormAlert-' + id);
			$wrap.find('.bmc-container').prepend($box);
		}

		return $box;
	}

	function showAlert($form, type, message) {
		var icon = type === 'ok' ? 'check_circle' : (type === 'warn' ? 'warning' : 'error');
		var svg = (typeof window.bmcIcon === 'function') ? window.bmcIcon(icon, '', 20) : '';

		alertBox($form).html(
			'<div class="bmc-alert bmc-alert--' + type + '">' +
			'<span class="bmc-alert__icon">' + svg + '</span>' +
			'<div>' + $('<span>').text(message).html() + '</div></div>'
		);
	}

	function clearAlert($form) {
		alertBox($form).empty();
	}

	function fieldBox($form, id) {
		return $form.find('[data-field="' + id + '"]');
	}

	function setFieldError($form, id, message) {
		var $box = fieldBox($form, id);

		$box.addClass('has-error');
		$box.find('.bmc-form__error').text(message).show();
	}

	function clearFieldErrors($form) {
		$form.find('.bmc-form__field').removeClass('has-error');
		$form.find('.bmc-form__error').text('').hide();
	}

	function showFieldErrors($form, errors) {
		$.each(errors || {}, function (id, message) {
			setFieldError($form, id, message);
		});

		var $first = $form.find('.has-error').first();

		if ($first.length) {
			$('html, body').animate({ scrollTop: $first.offset().top - 120 }, 260);
		}
	}

	function valueOf($input) {
		if ($input.attr('type') === 'checkbox' && !$input.is('[name$="[]"]')) {
			return $input.prop('checked') ? '1' : '';
		}

		return $.trim(String($input.val() || ''));
	}

	function validate($form) {
		var errors = {};

		clearFieldErrors($form);

		$form.find('.bmc-form__field').each(function () {
			var $field = $(this);
			var id = $field.data('field');
			var $inputs = $field.find('input, select, textarea');

			if (!$inputs.length) {
				return;
			}

			var $first = $inputs.first();
			var type = $first.attr('type') || $first.prop('tagName').toLowerCase();
			var required = $first.prop('required');
			var isGroup = $first.is('[name$="[]"]');
			var value = isGroup ? $inputs.filter(':checked').map(function () { return $(this).val(); }).get() : valueOf($first);
			var empty = isGroup ? !value.length : value === '';

			if (required && empty) {
				errors[id] = $first.attr('type') === 'checkbox' && !isGroup ? i18n.select || 'این گزینه باید تأیید شود.' : (i18n.required || 'این فیلد الزامی است.');
				return;
			}

			if (empty) {
				return;
			}

			if (type === 'email' && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(value)) {
				errors[id] = i18n.email || 'ایمیل معتبر وارد کنید.';
				return;
			}

			if (type === 'tel' && !/^[0-9+\-\s]{6,20}$/.test(value)) {
				errors[id] = i18n.tel || 'شمارهٔ تماس معتبر وارد کنید.';
				return;
			}

			if (type === 'number' && isNaN(parseFloat(value))) {
				errors[id] = i18n.number || 'عدد معتبر وارد کنید.';
				return;
			}

			if (type === 'url' && !/^https?:\/\/.+\..+/.test(value)) {
				errors[id] = i18n.url || 'آدرس وب معتبر وارد کنید.';
				return;
			}

			if ($first.attr('dir') === 'ltr' && $first.attr('maxlength') === '16' && $field.hasClass('bmc-form__field--mc_username')) {
				if (!/^[A-Za-z0-9_]{3,16}$/.test(value)) {
					errors[id] = i18n.player || 'نام کاربری ماینکرافت معتبر نیست.';
					return;
				}
			}

			var max = parseInt($first.attr('maxlength'), 10);

			if (!isNaN(max) && max > 0 && String(value).length > max) {
				errors[id] = i18n.max || 'مقدار واردشده طولانی است.';
			}
		});

		if (typeof bmcForm.maxSize === 'number' && bmcForm.maxSize > 0) {
			$form.find('input[type="file"]').each(function () {
				var file = this.files && this.files.length ? this.files[0] : null;

				if (file && file.size > bmcForm.maxSize) {
					errors[$(this).closest('.bmc-form__field').data('field')] = i18n.filelarge || 'حجم فایل بیش از حد مجاز است.';
				}
			});
		}

		showFieldErrors($form, errors);

		return $.isEmptyObject(errors);
	}

	function setBusy($form, busy) {
		var $button = $form.find('button[type="submit"]');
		var label = $button.find('span:last');

		$form.data('bmc-busy', busy ? 1 : 0);
		$button.prop('disabled', !!busy);
		$form.toggleClass('is-loading', !!busy);

		if (busy) {
			if (!$button.data('label')) {
				$button.data('label', label.text());
			}

			label.text(i18n.sending || 'در حال ارسال…');
		} else if ($button.data('label')) {
			label.text($button.data('label'));
		}
	}

	$(document).on('submit', 'form.bmc-form-el', function (e) {
		var $form = $(this);

		if ($form.data('bmc-busy')) {
			e.preventDefault();
			return false;
		}

		if (!validate($form)) {
			e.preventDefault();
			return false;
		}

		e.preventDefault();

		clearAlert($form);
		setBusy($form, true);

		var data = new FormData($form[0]);
		data.append('action', 'bmc_form_submit');
		data.append('bmc_form_nonce', $form.data('nonce'));

		$.ajax({
			url: bmcForm.ajaxUrl,
			type: 'POST',
			data: data,
			processData: false,
			contentType: false,
			dataType: 'json'
		}).done(function (res) {
			setBusy($form, false);

			if (res && res.success) {
				showAlert($form, 'ok', (res.data && res.data.message) || 'ارسال شد.');
				$form[0].reset();
				$form.find('.bmc-form__filetext').each(function () {
					$(this).text($(this).data('default') || 'انتخاب فایل');
				});

				if (res.data && res.data.redirect) {
					setTimeout(function () { window.location.href = res.data.redirect; }, 1100);
				}
			} else {
				var payload = (res && res.data) ? res.data : {};
				showAlert($form, 'error', payload.message || (i18n.error || 'ارسال ناموفق بود.'));
				showFieldErrors($form, payload.errors || {});
			}
		}).fail(function (xhr) {
			setBusy($form, false);

			var payload = (xhr && xhr.responseJSON && xhr.responseJSON.data) ? xhr.responseJSON.data : {};
			showAlert($form, 'error', payload.message || (i18n.error || 'ارسال ناموفق بود.'));
			showFieldErrors($form, payload.errors || {});
		});

		return false;
	});

	$(document).on('input', '.bmc-form__field--mc_username input', function () {
		var $input = $(this);
		var $img = $input.closest('.bmc-form__player').find('img[data-bmc-head-for]');

		if (!$img.length) {
			return;
		}

		clearTimeout($input.data('bmc-timer'));

		$input.data('bmc-timer', setTimeout(function () {
			var name = $.trim($input.val());

			if (!/^[A-Za-z0-9_]{3,16}$/.test(name)) {
				$img.attr('src', 'https://mc-heads.net/avatar/MHF_Question/48');
				return;
			}

			$img.attr('src', 'https://mc-heads.net/avatar/' + encodeURIComponent(name) + '/48?t=' + Date.now());
		}, 520));
	});

	$(document).on('input change', 'textarea[maxlength]', function () {
		var $area = $(this);
		var $count = $area.closest('.bmc-form__field').find('[data-count-for="' + $area.attr('id') + '"]');

		if ($count.length) {
			$count.text(String($area.val().length) + '/' + $area.attr('maxlength'));
		}
	});

	$(document).on('change', '.bmc-form__file input[type="file"]', function () {
		var $box = $(this).closest('.bmc-form__file');
		var $text = $box.find('.bmc-form__filetext');

		if (!$text.data('default')) {
			$text.data('default', $text.text());
		}

		var file = this.files && this.files.length ? this.files[0] : null;
		$text.text(file ? file.name : $text.data('default'));
		$box.toggleClass('has-file', !!file);
	});

	$(document).on('input', '.bmc-form__field input, .bmc-form__field select, .bmc-form__field textarea', function () {
		$(this).closest('.bmc-form__field').removeClass('has-error').find('.bmc-form__error').text('').hide();
	});
})(jQuery);
