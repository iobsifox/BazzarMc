(function () {
	'use strict';

	if (!window.bmcBlocks) {
		return;
	}

	var cfg = window.bmcBlocks;

	function buildField() {
		var wrap = document.createElement('div');
		wrap.className = 'bmc-blocks-fields wc-block-components-panel wc-block-components-card';

		var title = document.createElement('div');
		title.className = 'bmc-blocks-title';
		title.textContent = 'اطلاعات ماینکرافت';
		wrap.appendChild(title);

		var label = document.createElement('label');
		label.className = 'bmc-blocks-label';
		label.textContent = (cfg.labels && cfg.labels.player) || 'نام کاربری ماینکرافت';
		wrap.appendChild(label);

		var input = document.createElement('input');
		input.type = 'text';
		input.name = cfg.playerField;
		input.className = 'bmc-blocks-input wc-block-components-text-input';
		input.dir = 'ltr';
		input.value = cfg.player || '';
		wrap.appendChild(input);

		var gift = document.createElement('label');
		gift.className = 'bmc-blocks-gift';

		var checkbox = document.createElement('input');
		checkbox.type = 'checkbox';
		checkbox.name = cfg.giftField;
		checkbox.value = '1';
		gift.appendChild(checkbox);

		var text = document.createElement('span');
		text.textContent = (cfg.labels && cfg.labels.gift) || 'این خرید هدیه است';
		gift.appendChild(text);

		wrap.appendChild(gift);

		return wrap;
	}

	function inject() {
		if (document.querySelector('.bmc-blocks-fields')) {
			return;
		}

		var host = document.querySelector('.wc-block-checkout__contact-fields')
			|| document.querySelector('.wc-block-checkout__shipping-fields')
			|| document.querySelector('.wc-block-checkout__payment-method')
			|| document.querySelector('.wc-block-checkout');

		if (!host) {
			return;
		}

		var field = buildField();
		host.parentNode.insertBefore(field, host);
	}

	function start() {
		inject();

		var observer = new MutationObserver(function () {
			inject();
		});

		observer.observe(document.body, { childList: true, subtree: true });
	}

	if (document.readyState === 'loading') {
		document.addEventListener('DOMContentLoaded', start);
	} else {
		start();
	}
})();
