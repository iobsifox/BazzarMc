(function () {
	'use strict';

	function ready(fn) {
		if (document.readyState !== 'loading') {
			fn();
			return;
		}

		document.addEventListener('DOMContentLoaded', fn);
	}

	function navigate(select) {
		var url = select.value;

		if (url && url !== '#') {
			window.location.href = url;
		}
	}

	function syncActive(nav) {
		var active = nav.querySelector('.bmc-nav__item.is-active');
		var list = nav.querySelector('.bmc-nav__list');

		if (!active || !list) {
			return;
		}

		var mode = nav.getAttribute('data-bmc-mobile') || '';

		if ('scroll' !== mode) {
			return;
		}

		var target = active.offsetLeft - (list.clientWidth / 2) + (active.clientWidth / 2);

		if (target > 0) {
			list.scrollLeft = -target;
		}
	}

	function getAjaxUrl() {
		if (window.bmcFrontend && window.bmcFrontend.ajaxUrl) {
			return window.bmcFrontend.ajaxUrl;
		}
		if (window.bmcLink && window.bmcLink.ajaxUrl) {
			return window.bmcLink.ajaxUrl;
		}
		return '/wp-admin/admin-ajax.php';
	}

	function getNonce() {
		if (window.bmcFrontend && window.bmcFrontend.nonce) {
			return window.bmcFrontend.nonce;
		}
		if (window.bmcLink && window.bmcLink.publicNonce) {
			return window.bmcLink.publicNonce;
		}
		return '';
	}

	function ensureOrderModal() {
		var modal = document.getElementById('bmcOrderModal');
		if (modal) {
			return modal;
		}

		modal = document.createElement('div');
		modal.className = 'bmc-omodal';
		modal.id = 'bmcOrderModal';
		modal.setAttribute('dir', 'rtl');
		modal.setAttribute('role', 'dialog');
		modal.setAttribute('aria-modal', 'true');
		modal.setAttribute('aria-labelledby', 'bmcOrderModalTitle');
		modal.hidden = true;

		modal.innerHTML =
			'<div class="bmc-omodal__scrim" data-bmc-omodal-close></div>' +
			'<div class="bmc-omodal__panel">' +
				'<div class="bmc-omodal__bar">' +
					'<span class="bmc-omodal__bar-icon">' +
						(window.bmcIcon ? window.bmcIcon('receipt_long', { size: 18 }) : '') +
					'</span>' +
					'<h3 class="bmc-omodal__title" id="bmcOrderModalTitle">جزئیات سفارش</h3>' +
					'<button type="button" class="bmc-omodal__close" data-bmc-omodal-close aria-label="بستن">' +
						(window.bmcIcon ? window.bmcIcon('close', { size: 18 }) : '×') +
					'</button>' +
				'</div>' +
				'<div class="bmc-omodal__body" id="bmcOrderModalBody">' +
					'<div class="bmc-omodal__loading">' +
						'<span class="bmc-omodal__spinner"></span>' +
						'<span>در حال بارگذاری اطلاعات سفارش…</span>' +
					'</div>' +
				'</div>' +
			'</div>';

		document.body.appendChild(modal);
		return modal;
	}

	function openOrderModal(orderId) {
		var modal = ensureOrderModal();
		var titleEl = document.getElementById('bmcOrderModalTitle');
		var bodyEl = document.getElementById('bmcOrderModalBody');

		if (titleEl) {
			titleEl.textContent = 'سفارش #' + orderId;
		}

		if (bodyEl) {
			bodyEl.innerHTML =
				'<div class="bmc-omodal__loading">' +
					'<span class="bmc-omodal__spinner"></span>' +
					'<span>در حال بارگذاری اطلاعات سفارش…</span>' +
				'</div>';
		}

		modal.hidden = false;
		document.body.classList.add('bmc-omodal-lock');

		requestAnimationFrame(function () {
			modal.classList.add('is-open');
		});

		var params = new URLSearchParams();
		params.append('action', 'bmc_get_order_details');
		params.append('order_id', String(orderId));
		params.append('nonce', getNonce());

		fetch(getAjaxUrl(), {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
				'X-Requested-With': 'XMLHttpRequest'
			},
			body: params.toString(),
			credentials: 'same-origin'
		})
		.then(function (res) {
			if (!res.ok && res.status !== 400 && res.status !== 401 && res.status !== 403 && res.status !== 404) {
				throw new Error('HTTP ' + res.status);
			}
			return res.json();
		})
		.then(function (res) {
			if (res && res.success && res.data) {
				if (titleEl && res.data.title) {
					titleEl.textContent = res.data.title;
				}
				if (bodyEl && res.data.html) {
					bodyEl.innerHTML = res.data.html;
				}
			} else {
				var msg = (res && res.data && res.data.message) ? res.data.message : 'خطا در دریافت اطلاعات سفارش.';
				if (bodyEl) {
					bodyEl.innerHTML =
						'<div class="bmc-omodal__error">' +
							(window.bmcIcon ? window.bmcIcon('error', { size: 20 }) : '') +
							'<span>' + msg + '</span>' +
						'</div>';
				}
			}
		})
		.catch(function (err) {
			if (bodyEl) {
				bodyEl.innerHTML =
					'<div class="bmc-omodal__error">' +
						(window.bmcIcon ? window.bmcIcon('error', { size: 20 }) : '') +
						'<span>خطا در دریافت اطلاعات سفارش. لطفاً مجدداً تلاش کنید.</span>' +
					'</div>';
			}
		});
	}

	function closeOrderModal() {
		var modal = document.getElementById('bmcOrderModal');
		if (!modal) {
			return;
		}

		modal.classList.remove('is-open');
		document.body.classList.remove('bmc-omodal-lock');

		setTimeout(function () {
			modal.hidden = true;
		}, 220);
	}

	function extractOrderId(el) {
		var id = el.getAttribute('data-bmc-order-id');
		if (id && !isNaN(parseInt(id, 10))) {
			return parseInt(id, 10);
		}

		var href = el.getAttribute('href') || '';
		var match = href.match(/view-order\/(\d+)/i) || href.match(/orders\/(\d+)/i) || href.match(/order-view\/(\d+)/i) || href.match(/[?&]view-order=(\d+)/i);
		if (match && match[1]) {
			return parseInt(match[1], 10);
		}

		var text = el.textContent || '';
		var numMatch = text.match(/#?(\d+)/);
		if (numMatch && numMatch[1] && (el.classList.contains('view') || el.closest('.woocommerce-orders-table'))) {
			return parseInt(numMatch[1], 10);
		}

		return 0;
	}

	function handleOrderClicks(e) {
		if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) {
			return;
		}

		var closeBtn = e.target.closest('[data-bmc-omodal-close]');
		if (closeBtn) {
			e.preventDefault();
			closeOrderModal();
			return;
		}

		var link = e.target.closest('.bmc-order-modal-open, [data-bmc-order-id], .woocommerce-orders-table__cell-order-number a, .woocommerce-orders-table__cell-order-actions a.view, .bmc-ctx-list a[href*="view-order"]');
		if (!link) {
			return;
		}

		var orderId = extractOrderId(link);
		if (orderId > 0) {
			e.preventDefault();
			openOrderModal(orderId);
		}
	}

	ready(function () {
		document.addEventListener('click', handleOrderClicks);

		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' || e.keyCode === 27) {
				closeOrderModal();
			}
		});

		var selects = document.querySelectorAll('[data-bmc-nav-select]');

		Array.prototype.forEach.call(selects, function (select) {
			if (select.getAttribute('data-bmc-bound') === '1') {
				return;
			}

			select.setAttribute('data-bmc-bound', '1');
			select.addEventListener('change', function () {
				navigate(select);
			});
		});

		var navs = document.querySelectorAll('.bmc-nav[data-bmc-mobile]');

		Array.prototype.forEach.call(navs, function (nav) {
			if (nav.getAttribute('data-bmc-synced') === '1') {
				return;
			}

			nav.setAttribute('data-bmc-synced', '1');
			syncActive(nav);

			window.addEventListener('resize', function () {
				var bp = parseInt(nav.getAttribute('data-bmc-breakpoint') || '0', 10);

				if (bp && window.innerWidth <= bp) {
					syncActive(nav);
				}
			});
		});
	});
})();
