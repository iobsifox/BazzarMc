<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$gate = isset( $gate ) ? (array) $gate : array();

$reason     = isset( $gate['reason'] ) ? $gate['reason'] : 'unlinked';
$is_guest   = 'guest' === $reason;
$title      = $is_guest ? 'برای خرید وارد حساب شوید' : (string) BMC_Settings::get( 'txt_not_linked_title', 'اکانت ماینکرافت شما متصل نیست' );
$body       = $is_guest ? (string) BMC_Settings::get( 'txt_not_linked_body' ) : (string) BMC_Settings::get( 'txt_not_linked_body' );
$theme      = 'light' === BMC_Settings::get( 'checkout_theme' ) ? ' bmc-theme-light' : '';
$cart_count = function_exists( 'WC' ) && WC()->cart ? WC()->cart->get_cart_contents_count() : 0;
$cart_total = function_exists( 'WC' ) && WC()->cart ? WC()->cart->get_total() : '';
$login_url  = BMC_Auth::login_url();
$link_url   = BMC_Public::link_page_url();
$checkout_url = function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : '';
?>
<div class="bmc-wrap<?php echo esc_attr( $theme ); ?>">
	<div class="bmc-container bmc-container--narrow">

		<div class="bmc-card bmc-gate is-locked bmc-fade">
			<div class="bmc-gate__icon"><?php bmc_icon( $is_guest ? 'key' : 'link_off', array( 'size' => 46 ) ); ?></div>

			<h2 class="bmc-title"><?php echo esc_html( $title ); ?></h2>
			<p class="bmc-subtitle"><?php echo esc_html( $body ); ?></p>

			<?php if ( $cart_count ) : ?>
				<div class="bmc-alert bmc-alert--info" style="text-align:right;margin-top:18px">
					<span class="bmc-alert__icon"><?php bmc_icon( 'shopping_cart', array( 'size' => 18 ) ); ?></span>
					<div>
						سبد خرید شما حفظ شده است
						(<?php echo esc_html( BMC_Helpers::to_persian_digits( $cart_count ) ); ?> کالا
						<?php if ( $cart_total ) : ?>
							— <?php echo wp_kses_post( $cart_total ); ?>
						<?php endif; ?>
						). بعد از اتصال می‌توانید همین‌جا پرداخت را ادامه دهید.
					</div>
				</div>
			<?php endif; ?>

			<div class="bmc-gate__actions">
				<?php if ( $is_guest ) : ?>
					<a class="bmc-btn" href="<?php echo esc_url( add_query_arg( 'redirect_to', rawurlencode( $checkout_url ), $login_url ) ); ?>">ورود با شمارهٔ موبایل</a>
					<a class="bmc-btn bmc-btn--ghost" href="<?php echo esc_url( wp_login_url( $checkout_url ) ); ?>">ورود با رمز عبور</a>
				<?php else : ?>
					<a class="bmc-btn" href="<?php echo esc_url( $link_url ); ?>">اتصال اکانت ماینکرافت</a>
					<a class="bmc-btn bmc-btn--ghost" href="<?php echo esc_url( function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/' ) ); ?>">بازگشت به سبد خرید</a>
				<?php endif; ?>
			</div>

			<div class="bmc-steps" style="margin-top:26px">
				<div class="bmc-step"><strong>۱.</strong> اکانت ماینکرافت را متصل کنید.</div>
				<div class="bmc-step"><strong>۲.</strong> به صفحهٔ خرید برگردید.</div>
				<div class="bmc-step"><strong>۳.</strong> پرداخت کنید؛ آیتم در بازی تحویل داده می‌شود.</div>
			</div>
		</div>

		<?php if ( ! $is_guest ) : ?>
			<div style="margin-top:16px">
				<?php echo BMC_Public::shortcode_account(); ?>
			</div>
		<?php endif; ?>

	</div>
</div>
