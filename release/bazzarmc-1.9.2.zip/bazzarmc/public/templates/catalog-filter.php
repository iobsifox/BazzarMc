<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_style    = in_array( $bmc_cfg['filter_style'], array( 'pills', 'tabs', 'chips', 'select' ), true ) ? $bmc_cfg['filter_style'] : 'pills';
$bmc_ajax     = BMC_Catalog::yesno( $bmc_cfg['shop_ajax'] ) ? '1' : '0';
$bmc_base     = (string) BMC_Catalog::clean_url();
$bmc_cat      = (string) $bmc_state['cat'];
$bmc_s        = (string) $bmc_state['s'];
$bmc_sort     = (string) $bmc_state['sort'];
$bmc_default  = (string) $bmc_cfg['filter_default_sort'];
$bmc_labels   = BMC_Settings::sort_options();
$bmc_terms    = is_array( $bmc_terms ) ? $bmc_terms : array();
$bmc_search   = BMC_Catalog::yesno( $bmc_cfg['filter_show_search'] );
$bmc_sorting  = BMC_Catalog::yesno( $bmc_cfg['filter_show_sort'] );
$bmc_reset    = BMC_Catalog::yesno( $bmc_cfg['filter_show_reset'] ) && ( '' !== $bmc_cat || '' !== $bmc_s || $bmc_sort !== $bmc_default );
$bmc_counts   = BMC_Catalog::yesno( $bmc_cfg['filter_show_counts'] );

$bmc_classes = array( 'bmc-filter', 'bmc-filter--' . $bmc_style );

if ( BMC_Catalog::yesno( $bmc_cfg['filter_sticky'] ) ) {
	$bmc_classes[] = 'bmc-filter--sticky';
}

$bmc_total_count = 0;

foreach ( $bmc_terms as $bmc_term ) {
	$bmc_total_count += (int) $bmc_term['count'];
}
?>
<div class="<?php echo esc_attr( implode( ' ', $bmc_classes ) ); ?>" data-bmc-filter="<?php echo esc_attr( $bmc_id ); ?>" data-bmc-ajax="<?php echo esc_attr( $bmc_ajax ); ?>" data-bmc-default-sort="<?php echo esc_attr( $bmc_default ); ?>" data-bmc-search-min="<?php echo esc_attr( (int) $bmc_cfg['filter_search_min'] ); ?>"<?php echo $bmc_target ? ' data-bmc-target="' . esc_attr( $bmc_target ) . '"' : ''; ?>>
	<?php if ( '' !== trim( (string) $bmc_cfg['filter_title'] ) ) : ?>
		<div class="bmc-filter__title">
			<?php if ( '' !== (string) $bmc_cfg['filter_icon'] ) : ?>
				<?php bmc_icon( $bmc_cfg['filter_icon'], array( 'size' => 17 ) ); ?>
			<?php endif; ?>
			<span><?php echo esc_html( $bmc_cfg['filter_title'] ); ?></span>
		</div>
	<?php endif; ?>

	<?php if ( 'select' !== $bmc_style ) : ?>
		<div class="bmc-filter__cats">
			<?php if ( BMC_Catalog::yesno( $bmc_cfg['filter_show_all'] ) ) : ?>
				<a class="bmc-filter__item<?php echo '' === $bmc_cat ? ' is-active' : ''; ?>" href="<?php echo esc_url( $bmc_base ); ?>" data-bmc-cat="">
					<span class="bmc-filter__name"><?php echo esc_html( (string) $bmc_cfg['filter_all_label'] ); ?></span>
					<?php if ( $bmc_counts && $bmc_total_count > 0 ) : ?>
						<span class="bmc-filter__count"><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_total_count ) ); ?></span>
					<?php endif; ?>
				</a>
			<?php endif; ?>

			<?php foreach ( $bmc_terms as $bmc_term ) : ?>
				<a class="bmc-filter__item<?php echo $bmc_cat === $bmc_term['slug'] ? ' is-active' : ''; ?><?php echo $bmc_term['depth'] > 0 ? ' bmc-filter__item--child' : ''; ?>" href="<?php echo esc_url( (string) add_query_arg( 'bmc_cat', $bmc_term['slug'], $bmc_base ) ); ?>" data-bmc-cat="<?php echo esc_attr( $bmc_term['slug'] ); ?>">
					<?php if ( $bmc_term['thumb'] ) : ?>
						<img class="bmc-filter__thumb" src="<?php echo esc_url( $bmc_term['thumb'] ); ?>" alt="" loading="lazy" />
					<?php endif; ?>
					<span class="bmc-filter__name"><?php echo esc_html( $bmc_term['name'] ); ?></span>
					<?php if ( $bmc_counts ) : ?>
						<span class="bmc-filter__count"><?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_term['count'] ) ); ?></span>
					<?php endif; ?>
				</a>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>

	<form class="bmc-filter__tools" method="get" action="<?php echo esc_url( $bmc_base ); ?>">
		<input type="hidden" name="bmc_cat" value="<?php echo esc_attr( $bmc_cat ); ?>" />

		<?php if ( 'select' === $bmc_style ) : ?>
			<label class="bmc-filter__field bmc-filter__field--cats">
				<?php if ( '' !== (string) $bmc_cfg['filter_icon'] ) : ?>
					<?php bmc_icon( $bmc_cfg['filter_icon'], array( 'size' => 16 ) ); ?>
				<?php endif; ?>
				<select name="bmc_cat" data-bmc-cat-select>
					<?php if ( BMC_Catalog::yesno( $bmc_cfg['filter_show_all'] ) ) : ?>
						<option value="" <?php selected( '' === $bmc_cat ); ?>><?php echo esc_html( (string) $bmc_cfg['filter_all_label'] ); ?></option>
					<?php endif; ?>
					<?php foreach ( $bmc_terms as $bmc_term ) : ?>
						<option value="<?php echo esc_attr( $bmc_term['slug'] ); ?>" <?php selected( $bmc_cat === $bmc_term['slug'] ); ?>>
							<?php echo esc_html( str_repeat( '— ', (int) $bmc_term['depth'] ) . $bmc_term['name'] . ( $bmc_counts ? ' (' . BMC_Helpers::to_persian_digits( (int) $bmc_term['count'] ) . ')' : '' ) ); ?>
						</option>
					<?php endforeach; ?>
				</select>
			</label>
		<?php endif; ?>

		<?php if ( $bmc_search ) : ?>
			<label class="bmc-filter__field bmc-filter__field--search">
				<?php bmc_icon( 'search', array( 'size' => 16 ) ); ?>
				<input type="search" name="bmc_s" value="<?php echo esc_attr( $bmc_s ); ?>" placeholder="<?php echo esc_attr( (string) $bmc_cfg['filter_search_placeholder'] ); ?>" data-bmc-search autocomplete="off" />
			</label>
		<?php endif; ?>

		<?php if ( $bmc_sorting ) : ?>
			<label class="bmc-filter__field bmc-filter__field--sort">
				<?php bmc_icon( 'tune', array( 'size' => 16 ) ); ?>
				<?php if ( '' !== trim( (string) $bmc_cfg['filter_sort_label'] ) ) : ?>
					<span class="bmc-filter__sort-label"><?php echo esc_html( (string) $bmc_cfg['filter_sort_label'] ); ?></span>
				<?php endif; ?>
				<select name="bmc_sort" data-bmc-sort>
					<?php foreach ( (array) $bmc_cfg['filter_sort_options'] as $bmc_option ) : ?>
						<?php if ( ! isset( $bmc_labels[ $bmc_option ] ) ) : ?>
							<?php continue; ?>
						<?php endif; ?>
						<option value="<?php echo esc_attr( $bmc_option ); ?>" <?php selected( $bmc_sort === $bmc_option ); ?>><?php echo esc_html( $bmc_labels[ $bmc_option ] ); ?></option>
					<?php endforeach; ?>
				</select>
			</label>
		<?php endif; ?>

		<button type="submit" class="bmc-btn bmc-btn-o bmc-btn--sm bmc-filter__go" data-bmc-apply>
			<?php bmc_icon( 'manage_search', array( 'size' => 16 ) ); ?>
			<span>اعمال فیلتر</span>
		</button>

		<?php if ( $bmc_reset ) : ?>
			<a class="bmc-btn bmc-btn-g bmc-btn--sm bmc-filter__reset" href="<?php echo esc_url( $bmc_base ); ?>" data-bmc-reset>
				<?php bmc_icon( 'refresh', array( 'size' => 16 ) ); ?>
				<span><?php echo esc_html( (string) $bmc_cfg['filter_reset_text'] ); ?></span>
			</a>
		<?php endif; ?>
	</form>
</div>
