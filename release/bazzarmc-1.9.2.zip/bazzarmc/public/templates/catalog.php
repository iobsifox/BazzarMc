<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_side = 'side' === $bmc_cfg['filter_position'];
$bmc_ajax = BMC_Catalog::yesno( $bmc_cfg['shop_ajax'] ) ? '1' : '0';

$bmc_classes = array( 'bmc-wrap', 'bmc-shop' );

if ( $bmc_side ) {
	$bmc_classes[] = 'bmc-shop--side';
}

if ( 'light' === BMC_Settings::get( 'checkout_theme' ) ) {
	$bmc_classes[] = 'bmc-shop--light';
}
?>
<section class="<?php echo esc_attr( implode( ' ', $bmc_classes ) ); ?>" id="<?php echo esc_attr( $bmc_id ); ?>" dir="rtl" data-bmc-shop="<?php echo esc_attr( $bmc_id ); ?>" data-bmc-ajax="<?php echo esc_attr( $bmc_ajax ); ?>" data-bmc-cfg="<?php echo esc_attr( wp_json_encode( $bmc_cfg ) ); ?>">
	<?php if ( '' !== trim( (string) $bmc_cfg['shop_heading'] ) ) : ?>
		<header class="bmc-shop__head">
			<?php if ( '' !== (string) $bmc_cfg['shop_heading_icon'] ) : ?>
				<span class="bmc-shop__head-icon"><?php bmc_icon( $bmc_cfg['shop_heading_icon'], array( 'size' => 20 ) ); ?></span>
			<?php endif; ?>
			<h2 class="bmc-shop__title"><?php echo esc_html( $bmc_cfg['shop_heading'] ); ?></h2>
		</header>
	<?php endif; ?>

	<div class="bmc-shop__layout">
		<?php echo BMC_Catalog::render_filter( $bmc_cfg, $bmc_id, $bmc_state ); // phpcs:ignore WordPress.Security.EscapeOutput ?>

		<div class="bmc-shop__main">
			<?php echo BMC_Catalog::render_grid( $bmc_cfg, $bmc_id, $bmc_state ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		</div>
	</div>
</section>
