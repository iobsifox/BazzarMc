<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_classes = array( 'bmc-qv' );

if ( 'light' === BMC_Settings::get( 'checkout_theme' ) ) {
	$bmc_classes[] = 'bmc-qv--light';
}

if ( ! empty( $bmc_open ) ) {
	$bmc_classes[] = 'is-open';
}

$bmc_width   = max( 360, (int) $bmc_cfg['qv_width'] );
$bmc_content = isset( $bmc_content ) ? (string) $bmc_content : '';
$bmc_loading = (string) $bmc_cfg['qv_loading_text'];
?>
<div class="<?php echo esc_attr( implode( ' ', $bmc_classes ) ); ?>" id="bmcQv" dir="rtl" role="dialog" aria-modal="true" aria-labelledby="bmcQvTitle" data-bmc-qv-root<?php echo $bmc_content ? '' : ' hidden'; ?>>
	<div class="bmc-qv__scrim" data-bmc-qv-close></div>

	<div class="bmc-qv__panel" style="--bmc-qv-w:<?php echo esc_attr( $bmc_width ); ?>px">
		<div class="bmc-qv__bar">
			<span class="bmc-qv__bar-icon"><?php bmc_icon( 'visibility', array( 'size' => 17 ) ); ?></span>
			<h3 id="bmcQvTitle"><?php echo esc_html( (string) $bmc_cfg['qv_title_text'] ); ?></h3>
			<button type="button" class="bmc-qv__close" data-bmc-qv-close aria-label="<?php echo esc_attr( (string) $bmc_cfg['qv_close_text'] ); ?>">
				<?php bmc_icon( 'close', array( 'size' => 18 ) ); ?>
			</button>
		</div>

		<div class="bmc-qv__body" data-bmc-qv-content>
			<?php if ( $bmc_content ) : ?>
				<?php echo $bmc_content; // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<?php else : ?>
				<div class="bmc-qv__loading">
					<span class="bmc-qv__spinner"></span>
					<span><?php echo esc_html( $bmc_loading ); ?></span>
				</div>
			<?php endif; ?>
		</div>
	</div>
</div>
