<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_cart         = function_exists( 'WC' ) ? WC()->cart : null;
$bmc_theme        = (string) BMC_Settings::get( 'checkout_theme', 'dark' );
$bmc_accent       = (string) BMC_Settings::get( 'checkout_accent', '#3ddc84' );
$bmc_gate         = BMC_Checkout::gate_status();
$bmc_cart_ok      = empty( $bmc_gate['ok'] ) ? false : true;
$bmc_show_coupon  = BMC_Settings::bool( 'checkout_show_coupon', true );
$bmc_args         = isset( $bmc_args ) && is_array( $bmc_args ) ? $bmc_args : array();
$bmc_inline_forced = isset( $bmc_args['inline'] ) && null !== $bmc_args['inline'] ? (bool) $bmc_args['inline'] : null;
$bmc_inline_ok    = BMC_Settings::bool( 'cart_inline_checkout', false );
$bmc_inline       = null !== $bmc_inline_forced ? $bmc_inline_forced : ( $bmc_inline_ok && ( isset( $_GET['bmc_checkout'] ) || 'custom' === (string) BMC_Settings::get( 'cart_mode', 'wc' ) ) );
$bmc_steps_on     = isset( $bmc_args['steps'] ) && null !== $bmc_args['steps'] ? (bool) $bmc_args['steps'] : BMC_Settings::bool( 'cart_steps_nav', true );
$bmc_empty_text   = ! empty( $bmc_args['empty_text'] ) ? (string) $bmc_args['empty_text'] : '';
$bmc_button_text  = ! empty( $bmc_args['button_text'] ) ? (string) $bmc_args['button_text'] : (string) BMC_Settings::get( 'cart_button_text', 'ثبت و پرداخت سفارش' );
$bmc_link_url     = BMC_Checkout::connect_url();
$bmc_player       = is_user_logged_in() ? BMC_Link::get_linked_player( get_current_user_id() ) : '';
?>
<div class="bmc-wrap bmc-cart-wrap bmc-theme-<?php echo esc_attr( $bmc_theme ); ?>" style="--bmc-accent:<?php echo esc_attr( $bmc_accent ); ?>">

	<div class="bmc-cart-head">
		<h2><?php bmc_icon( 'shopping_cart', array( 'size' => 21 ) ); ?> سبد خرید شما</h2>
		<span class="bmc-pill">
			<?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_cart ? (int) $bmc_cart->get_cart_contents_count() : 0 ) ); ?> قلم
		</span>
	</div>

	<?php if ( $bmc_steps_on ) : ?>
		<?php echo BMC_Checkout::steps_nav( 'cart' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
	<?php endif; ?>

	<?php if ( function_exists( 'wc_print_notices' ) ) : ?>
		<div class="bmc-notices"><?php wc_print_notices(); ?></div>
	<?php endif; ?>

	<?php if ( ! $bmc_cart || $bmc_cart->is_empty() ) : ?>

		<div class="bmc-empty">
			<div class="bmc-empty-icon"><?php bmc_icon( 'shopping_basket', array( 'size' => 46 ) ); ?></div>
			<h3>سبد خرید شما خالی است</h3>
			<p><?php echo esc_html( $bmc_empty_text ? $bmc_empty_text : 'برای خرید آیتم‌های ماینکرافت به فروشگاه بروید.' ); ?></p>
			<a class="bmc-btn bmc-btn-p" href="<?php echo esc_url( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' ) ); ?>">رفتن به فروشگاه</a>
		</div>

	<?php else : ?>

		<div class="bmc-cart-grid">

			<form class="bmc-cart-form" action="<?php echo esc_url( function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '' ); ?>" method="post">

				<div class="bmc-cart-items">
					<?php
					foreach ( $bmc_cart->get_cart() as $bmc_key => $bmc_item ) {
						$bmc_product = isset( $bmc_item['data'] ) ? $bmc_item['data'] : null;

						if ( ! $bmc_product ) {
							continue;
						}

						$bmc_qty       = isset( $bmc_item['quantity'] ) ? (int) $bmc_item['quantity'] : 1;
						$bmc_line      = isset( $bmc_item['line_subtotal'] ) ? (float) $bmc_item['line_subtotal'] : 0;
						$bmc_synced    = BMC_Checkout::is_synced_product( isset( $bmc_item['product_id'] ) ? absint( $bmc_item['product_id'] ) : 0 );
						$bmc_variation = isset( $bmc_item['variation'] ) && is_array( $bmc_item['variation'] ) ? $bmc_item['variation'] : array();
						?>
						<div class="bmc-cart-row">
							<div class="bmc-cart-thumb">
								<?php echo wp_kses_post( $bmc_product->get_image( 'woocommerce_thumbnail', array( 'class' => 'bmc-img' ) ) ); ?>
							</div>

							<div class="bmc-cart-info">
								<div class="bmc-cart-name">
									<?php echo esc_html( $bmc_product->get_name() ); ?>
									<?php if ( $bmc_synced ) : ?>
										<span class="bmc-tag bmc-tag-ok"><?php bmc_icon( 'sports_esports', array( 'size' => 14 ) ); ?> تحویل در ماینکرافت</span>
									<?php endif; ?>
								</div>

								<?php if ( $bmc_variation ) : ?>
									<div class="bmc-cart-meta">
										<?php
										foreach ( $bmc_variation as $bmc_meta_key => $bmc_meta_value ) {
											echo '<span>' . esc_html( wc_attribute_label( $bmc_meta_key ) ) . ': ' . esc_html( $bmc_meta_value ) . '</span>';
										}
										?>
									</div>
								<?php endif; ?>

								<div class="bmc-cart-unit">
									<?php echo wp_kses_post( wc_price( $bmc_product->get_price() ) ); ?>
								</div>
							</div>

							<div class="bmc-cart-qty">
								<label for="bmc-qty-<?php echo esc_attr( $bmc_key ); ?>">تعداد</label>
								<input
									id="bmc-qty-<?php echo esc_attr( $bmc_key ); ?>"
									type="number"
									min="1"
									step="1"
									name="cart[<?php echo esc_attr( $bmc_key ); ?>][qty]"
									value="<?php echo esc_attr( $bmc_qty ); ?>">
							</div>

							<div class="bmc-cart-line">
								<?php echo wp_kses_post( wc_price( $bmc_line ) ); ?>
							</div>

							<a class="bmc-cart-remove" href="<?php echo esc_url( function_exists( 'wc_get_cart_remove_url' ) ? wc_get_cart_remove_url( $bmc_key ) : '#' ); ?>" title="حذف"><?php bmc_icon( 'close', array( 'size' => 14 ) ); ?></a>
						</div>
						<?php
					}
					?>
				</div>

				<div class="bmc-cart-actions">
					<button type="submit" name="update_cart" value="1" class="bmc-btn bmc-btn-o"><?php bmc_icon( 'refresh', array( 'size' => 16 ) ); ?> به‌روزرسانی سبد</button>
					<a class="bmc-btn bmc-btn-g" href="<?php echo esc_url( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' ) ); ?>">ادامهٔ خرید</a>
					<?php wp_nonce_field( 'woocommerce-cart' ); ?>
				</div>
			</form>

			<aside class="bmc-cart-side">

				<?php if ( $bmc_show_coupon && ! $bmc_cart->has_discount() ) : ?>
					<form class="bmc-coupon" action="<?php echo esc_url( function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '' ); ?>" method="post">
						<label for="bmc-coupon-code">کد تخفیف</label>
						<div class="bmc-coupon-row">
							<input id="bmc-coupon-code" type="text" name="coupon_code" class="bmc-input" dir="ltr" placeholder="COUPON">
							<button type="submit" name="apply_coupon" value="1" class="bmc-btn bmc-btn-o">اعمال</button>
						</div>
						<?php wp_nonce_field( 'woocommerce-cart' ); ?>
					</form>
				<?php elseif ( $bmc_cart->has_discount() ) : ?>
					<div class="bmc-coupon-applied">
						<span><?php bmc_icon( 'confirmation_number', array( 'size' => 16 ) ); ?> کد تخفیف اعمال شد</span>
						<a href="<?php echo esc_url( function_exists( 'wc_get_cart_remove_coupon_url' ) ? wc_get_cart_remove_coupon_url( (string) current( $bmc_cart->get_coupons() ) ) : '#' ); ?>">حذف</a>
					</div>
				<?php endif; ?>

				<div class="bmc-totals">
					<div class="bmc-trow">
						<span>جمع سبد</span>
						<b><?php echo wp_kses_post( wc_price( $bmc_cart->get_subtotal() ) ); ?></b>
					</div>

					<?php if ( $bmc_cart->get_discount_total() > 0 ) : ?>
						<div class="bmc-trow bmc-discount">
							<span>تخفیف</span>
							<b>− <?php echo wp_kses_post( wc_price( $bmc_cart->get_discount_total() ) ); ?></b>
						</div>
					<?php endif; ?>

					<?php if ( $bmc_cart->needs_shipping() && $bmc_cart->get_shipping_total() > 0 ) : ?>
						<div class="bmc-trow">
							<span>هزینهٔ ارسال</span>
							<b><?php echo wp_kses_post( wc_price( $bmc_cart->get_shipping_total() ) ); ?></b>
						</div>
					<?php endif; ?>

					<?php if ( $bmc_cart->get_taxes() ) : ?>
						<?php foreach ( $bmc_cart->get_tax_totals() as $bmc_tax_code => $bmc_tax ) : ?>
							<div class="bmc-trow">
								<span><?php echo esc_html( $bmc_tax->label ); ?></span>
								<b><?php echo wp_kses_post( $bmc_tax->formatted_amount ); ?></b>
							</div>
						<?php endforeach; ?>
					<?php endif; ?>

					<div class="bmc-trow bmc-grand">
						<span>مبلغ قابل پرداخت</span>
						<b><?php echo wp_kses_post( wc_price( $bmc_cart->get_total( 'edit' ) ) ); ?></b>
					</div>
				</div>

				<?php if ( $bmc_cart_ok ) : ?>

					<?php if ( $bmc_player ) : ?>
						<div class="bmc-linked-pill"><?php bmc_icon( 'check_circle', array( 'size' => 16 ) ); ?> آیتم‌ها به بازیکن <b dir="ltr"><?php echo esc_html( $bmc_player ); ?></b> تحویل می‌شود</div>
					<?php endif; ?>

					<?php if ( $bmc_inline ) : ?>
						<a class="bmc-btn bmc-btn-p bmc-btn-block" href="#bmc-inline-checkout">ادامه و تکمیل پرداخت <?php bmc_icon( 'arrow_downward', array( 'size' => 16 ) ); ?></a>
					<?php else : ?>
						<a class="bmc-btn bmc-btn-p bmc-btn-block" href="<?php echo esc_url( function_exists( 'wc_get_checkout_url' ) ? wc_get_checkout_url() : '' ); ?>"><?php echo esc_html( $bmc_button_text ); ?> ←</a>
					<?php endif; ?>

				<?php else : ?>

					<div class="bmc-gate-box">
						<div class="bmc-gate-icon"><?php bmc_icon( 'lock', array( 'size' => 34 ) ); ?></div>
						<strong>پرداخت فعال نیست</strong>
						<p><?php echo esc_html( '' !== trim( (string) $bmc_gate['message'] ) ? $bmc_gate['message'] : (string) BMC_Settings::get( 'txt_cart_blocked' ) ); ?></p>
						<a class="bmc-btn bmc-btn-p bmc-btn-block" href="<?php echo esc_url( $bmc_link_url ); ?>">
							<?php bmc_icon( 'link', array( 'size' => 16 ) ); ?> <?php echo esc_html( 'guest' === $bmc_gate['reason'] ? 'ورود و اتصال اکانت' : 'اتصال اکانت ماینکرافت' ); ?>
						</a>
						<span class="bmc-btn bmc-btn-disabled bmc-btn-block"><?php echo esc_html( $bmc_button_text ); ?></span>
					</div>

				<?php endif; ?>

				<div class="bmc-side-note">
					<?php bmc_icon( 'lock_person', array( 'size' => 15 ) ); ?> پرداخت از طریق درگاه امن بانکی انجام می‌شود و آیتم‌ها پس از تأیید، در صف تحویل سرور قرار می‌گیرند.
				</div>
			</aside>
		</div>

		<?php if ( $bmc_inline && $bmc_cart_ok ) : ?>
			<div id="bmc-inline-checkout" class="bmc-inline-checkout">
				<?php BMC_Checkout::render_checkout(); ?>
			</div>
		<?php else : ?>
			<p class="bmc-side-note bmc-cart-separate">
				<?php bmc_icon( 'payments', array( 'size' => 15 ) ); ?>
				سبد خرید و صفحهٔ پرداخت از هم جدا هستند؛ برای تکمیل سفارش به صفحهٔ پرداخت بروید.
			</p>
		<?php endif; ?>

	<?php endif; ?>
</div>
