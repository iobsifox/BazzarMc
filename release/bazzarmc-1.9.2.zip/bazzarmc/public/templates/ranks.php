<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_ranks = ( isset( $bmc_ranks ) && is_array( $bmc_ranks ) ) ? $bmc_ranks : array();

$bmc_ranks = array_merge(
	array(
		'user_id'     => get_current_user_id(),
		'title'       => 'رنک‌های شما',
		'title_icon'  => 'workspace_premium',
		'progress'    => true,
		'role'        => true,
		'expiry'      => true,
		'empty_text'  => 'هنوز رنکی خریداری نکرده‌اید. با خرید رنک، نقش مربوطه به‌صورت خودکار به حساب شما اضافه می‌شود.',
		'shop_button' => true,
		'shop_label'  => 'مشاهدهٔ فروشگاه',
		'sort'        => 'expiry',
	),
	$bmc_ranks
);

$bmc_uid    = (int) $bmc_ranks['user_id'];
$bmc_grants = $bmc_uid ? BMC_Roles::active_grants( $bmc_uid ) : array();

if ( 'level' === $bmc_ranks['sort'] && count( $bmc_grants ) > 1 ) {
	usort(
		$bmc_grants,
		function ( $a, $b ) {
			$la = isset( $a['level'] ) ? (int) $a['level'] : 0;
			$lb = isset( $b['level'] ) ? (int) $b['level'] : 0;

			if ( $la === $lb ) {
				return 0;
			}

			return $lb > $la ? 1 : -1;
		}
	);
}

$bmc_shop_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
?>
<div class="bmc-ranklist">
	<?php if ( '' !== trim( (string) $bmc_ranks['title'] ) ) : ?>
		<header class="bmc-acard__boxlabel">
			<?php if ( $bmc_ranks['title_icon'] ) : ?>
				<?php bmc_icon( $bmc_ranks['title_icon'], array( 'size' => 16 ) ); ?>
			<?php endif; ?>
			<?php echo esc_html( $bmc_ranks['title'] ); ?>
			<span class="bmc-chip"><?php bmc_icon( 'category', array( 'size' => 13 ) ); ?> <?php echo esc_html( BMC_Helpers::to_persian_digits( count( $bmc_grants ) ) ); ?> مورد</span>
		</header>
	<?php endif; ?>

	<?php if ( $bmc_grants ) : ?>
		<div class="bmc-ranks">
			<?php foreach ( $bmc_grants as $bmc_grant ) : ?>
				<?php
				$bmc_days     = max( 1, (int) ( isset( $bmc_grant['days'] ) ? $bmc_grant['days'] : 0 ) );
				$bmc_permanent = ! empty( $bmc_grant['permanent'] );
				$bmc_pct      = $bmc_permanent ? 100 : max( 2, min( 100, (int) round( ( (int) $bmc_grant['remaining'] / ( $bmc_days * DAY_IN_SECONDS ) ) * 100 ) ) );
				$bmc_urgent   = $bmc_permanent ? false : (int) $bmc_grant['remaining'] < ( 3 * DAY_IN_SECONDS );
				?>
				<article class="bmc-rank<?php echo $bmc_urgent ? ' is-urgent' : ''; ?>">
					<span class="bmc-rank__icon"><?php bmc_icon( $bmc_urgent ? 'hourglass_bottom' : 'trophy', array( 'size' => 18 ) ); ?></span>
					<div class="bmc-rank__body">
						<strong><?php echo esc_html( ! empty( $bmc_grant['label'] ) ? $bmc_grant['label'] : $bmc_grant['role_label'] ); ?></strong>
						<?php if ( $bmc_ranks['role'] ) : ?>
							<small><?php bmc_icon( 'badge', array( 'size' => 12 ) ); ?> نقش: <?php echo esc_html( $bmc_grant['role_label'] ); ?><?php echo empty( $bmc_grant['still_has_role'] ) ? ' — در انتظار اعمال' : ''; ?></small>
						<?php endif; ?>
					</div>
					<div class="bmc-rank__time">
						<span class="bmc-pill<?php echo $bmc_urgent ? ' bmc-pill--warn' : ''; ?>">
							<?php bmc_icon( $bmc_permanent ? 'all_inclusive' : 'timer', array( 'size' => 13 ) ); ?>
							<?php echo esc_html( $bmc_grant['remaining_human'] ); ?>
							<?php echo $bmc_permanent ? '' : ' باقی مانده'; ?>
						</span>
						<?php if ( $bmc_ranks['expiry'] && ! $bmc_permanent && ! empty( $bmc_grant['expires_jalali'] ) ) : ?>
							<small><?php bmc_icon( 'calendar_month', array( 'size' => 12 ) ); ?> تا <?php echo esc_html( $bmc_grant['expires_jalali'] ); ?></small>
						<?php endif; ?>
						<?php if ( $bmc_ranks['progress'] && ! $bmc_permanent ) : ?>
							<span class="bmc-bar"><i style="width:<?php echo esc_attr( $bmc_pct ); ?>%"></i></span>
						<?php endif; ?>
					</div>
				</article>
			<?php endforeach; ?>
		</div>
	<?php else : ?>
		<p class="bmc-acard__hint"><?php echo esc_html( $bmc_ranks['empty_text'] ); ?></p>
		<?php if ( $bmc_ranks['shop_button'] ) : ?>
			<a class="bmc-btn bmc-btn-o bmc-btn-sm" href="<?php echo esc_url( $bmc_shop_url ); ?>"><?php bmc_icon( 'storefront', array( 'size' => 15 ) ); ?> <?php echo esc_html( $bmc_ranks['shop_label'] ); ?></a>
		<?php endif; ?>
	<?php endif; ?>
</div>
