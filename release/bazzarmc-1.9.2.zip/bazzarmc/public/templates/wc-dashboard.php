<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_is_subpage = false;

if ( function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url() ) {
	$bmc_is_subpage = true;
}

if ( class_exists( 'BMC_Account_Endpoints' ) && '' !== BMC_Account_Endpoints::current_endpoint() ) {
	$bmc_is_subpage = true;
}

if ( ! empty( $_SERVER['REQUEST_URI'] ) && function_exists( 'wc_get_page_permalink' ) ) {
	$bmc_base_path = trim( (string) wp_parse_url( wc_get_page_permalink( 'myaccount' ), PHP_URL_PATH ), '/' );
	$bmc_req_path  = trim( (string) wp_parse_url( $_SERVER['REQUEST_URI'], PHP_URL_PATH ), '/' );
	if ( '' !== $bmc_base_path && '' !== $bmc_req_path && $bmc_req_path !== $bmc_base_path && 0 === stripos( $bmc_req_path, $bmc_base_path ) ) {
		$bmc_is_subpage = true;
	}
}

if ( $bmc_is_subpage ) {
	if ( class_exists( 'BMC_Account_Endpoints' ) && BMC_Account_Endpoints::is_current( 'connect' ) ) {
		BMC_Public::my_account_content();
		return;
	}

	if ( class_exists( 'BMC_Account_Endpoints' ) && BMC_Account_Endpoints::is_current( 'tickets' ) ) {
		if ( class_exists( 'BMC_Tickets' ) ) {
			BMC_Tickets::render_list_endpoint();
		}
		return;
	}

	return;
}

$bmc_user = wp_get_current_user();

$bmc_allowed_html = array(
	'a' => array(
		'href' => array(),
	),
);
?>

<p>
	<?php
	printf(
		wp_kses( __( 'Hello %1$s (not %1$s? <a href="%2$s">Log out</a>)', 'woocommerce' ), $bmc_allowed_html ),
		'<strong>' . esc_html( $bmc_user->display_name ) . '</strong>',
		esc_url( wp_logout_url( home_url( '/' ) ) )
	);
	?>
</p>

<?php
echo BMC_Public::render_account_card();

do_action( 'woocommerce_account_dashboard' );
do_action( 'woocommerce_before_my_account' );
do_action( 'woocommerce_after_my_account' );
