<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! empty( $modal_root ) ) {
	$theme_class = 'light' === BMC_Settings::get( 'checkout_theme' ) ? ' bmc-omodal--light' : '';
	?>
	<div class="bmc-omodal<?php echo esc_attr( $theme_class ); ?>" id="bmcOrderModal" dir="rtl" role="dialog" aria-modal="true" aria-labelledby="bmcOrderModalTitle" hidden>
		<div class="bmc-omodal__scrim" data-bmc-omodal-close></div>
		<div class="bmc-omodal__panel">
			<div class="bmc-omodal__bar">
				<span class="bmc-omodal__bar-icon"><?php bmc_icon( 'receipt_long', array( 'size' => 18 ) ); ?></span>
				<h3 class="bmc-omodal__title" id="bmcOrderModalTitle">جزئیات سفارش</h3>
				<button type="button" class="bmc-omodal__close" data-bmc-omodal-close aria-label="بستن">
					<?php bmc_icon( 'close', array( 'size' => 18 ) ); ?>
				</button>
			</div>
			<div class="bmc-omodal__body" id="bmcOrderModalBody">
				<div class="bmc-omodal__loading">
					<span class="bmc-omodal__spinner"></span>
					<span>در حال بارگذاری اطلاعات سفارش…</span>
				</div>
			</div>
		</div>
	</div>
	<?php
	return;
}

if ( empty( $order ) || ! is_object( $order ) || ! method_exists( $order, 'get_id' ) ) {
	?>
	<div class="bmc-omodal__error">
		<?php bmc_icon( 'error', array( 'size' => 20 ) ); ?>
		<span>اطلاعات سفارش در دسترس نیست.</span>
	</div>
	<?php
	return;
}

$order_id     = (int) $order->get_id();
$order_number = method_exists( $order, 'get_order_number' ) ? (string) $order->get_order_number() : (string) $order_id;
$status       = method_exists( $order, 'get_status' ) ? (string) $order->get_status() : '';
$status_label = function_exists( 'wc_get_order_status_name' ) ? wc_get_order_status_name( $status ) : $status;
$date_created = method_exists( $order, 'get_date_created' ) ? $order->get_date_created() : null;
$timestamp    = $date_created && method_exists( $date_created, 'getTimestamp' ) ? (int) $date_created->getTimestamp() : 0;
$payment_name = method_exists( $order, 'get_payment_method_title' ) ? (string) $order->get_payment_method_title() : '';
$total_fmt    = method_exists( $order, 'get_formatted_order_total' ) ? wp_strip_all_tags( (string) $order->get_formatted_order_total() ) : '';
$view_url     = method_exists( $order, 'get_view_order_url' ) ? (string) $order->get_view_order_url() : '#';
$customer_id  = (int) $order->get_customer_id();

$status_tones = array(
	'completed'  => 'green',
	'processing' => 'blue',
	'on-hold'    => 'warn',
	'pending'    => 'warn',
	'cancelled'  => 'danger',
	'refunded'   => 'muted',
	'failed'     => 'danger',
);
$tone = isset( $status_tones[ $status ] ) ? $status_tones[ $status ] : 'muted';

$player = (string) $order->get_meta( '_bmc_player', true );
if ( '' === $player && $customer_id && class_exists( 'BMC_Link' ) ) {
	$player = (string) BMC_Link::get_linked_player( $customer_id );
}

$deliveries = array();
if ( class_exists( 'BMC_Deliveries' ) && method_exists( 'BMC_Deliveries', 'for_order' ) ) {
	$deliveries = BMC_Deliveries::for_order( $order_id );
}

$items = method_exists( $order, 'get_items' ) ? $order->get_items() : array();
?>

<div class="bmc-omodal__grid-meta">
	<div class="bmc-omodal__meta-card">
		<small><?php bmc_icon( 'tag', array( 'size' => 14 ) ); ?> شماره سفارش</small>
		<strong>#<?php echo esc_html( BMC_Helpers::to_persian_digits( $order_number ) ); ?></strong>
	</div>

	<div class="bmc-omodal__meta-card">
		<small><?php bmc_icon( 'schedule', array( 'size' => 14 ) ); ?> وضعیت پرداخت</small>
		<div>
			<span class="bmc-pill bmc-pill--<?php echo esc_attr( $tone ); ?>"><?php echo esc_html( $status_label ); ?></span>
		</div>
	</div>

	<div class="bmc-omodal__meta-card">
		<small><?php bmc_icon( 'calendar_month', array( 'size' => 14 ) ); ?> زمان ثبت</small>
		<strong><?php echo esc_html( $timestamp ? BMC_Jalali::format( $timestamp, true ) : '—' ); ?></strong>
	</div>

	<div class="bmc-omodal__meta-card">
		<small><?php bmc_icon( 'payments', array( 'size' => 14 ) ); ?> روش پرداخت</small>
		<strong><?php echo esc_html( $payment_name ? $payment_name : 'پرداخت آنلاین' ); ?></strong>
	</div>
</div>

<?php if ( $player || $deliveries ) : ?>
	<div class="bmc-omodal__box">
		<h4 class="bmc-omodal__box-title">
			<?php bmc_icon( 'sports_esports', array( 'size' => 16 ) ); ?>
			اطلاعات تحویل در سرور ماینکرافت
		</h4>
		<div class="bmc-acard__facts" style="margin:0;">
			<?php if ( $player ) : ?>
				<li>
					<?php bmc_icon( 'sports_esports', array( 'size' => 14 ) ); ?>
					نام کاربری تحویل‌گیرنده: <strong dir="ltr"><?php echo esc_html( $player ); ?></strong>
				</li>
			<?php endif; ?>
			<?php if ( $deliveries ) : ?>
				<li>
					<?php bmc_icon( 'inventory_2', array( 'size' => 14 ) ); ?>
					اقلام تحویل: <strong><?php echo esc_html( BMC_Helpers::to_persian_digits( count( $deliveries ) ) ); ?> قلم در سیستم ماینکرافت</strong>
				</li>
			<?php endif; ?>
		</div>
	</div>
<?php endif; ?>

<div class="bmc-omodal__box">
	<h4 class="bmc-omodal__box-title">
		<?php bmc_icon( 'shopping_basket', array( 'size' => 16 ) ); ?>
		محصولات و اقلام خریداری‌شده
	</h4>

	<ul class="bmc-omodal__items-list">
		<?php foreach ( (array) $items as $item_id => $item ) : ?>
			<?php
			if ( ! is_object( $item ) ) {
				continue;
			}
			$product_id = method_exists( $item, 'get_product_id' ) ? (int) $item->get_product_id() : 0;
			$product    = method_exists( $item, 'get_product' ) ? $item->get_product() : null;
			$item_name  = method_exists( $item, 'get_name' ) ? (string) $item->get_name() : 'محصول';
			$item_qty   = method_exists( $item, 'get_quantity' ) ? (int) $item->get_quantity() : 1;
			$subtotal   = method_exists( $order, 'get_formatted_line_subtotal' ) ? wp_strip_all_tags( (string) $order->get_formatted_line_subtotal( $item ) ) : '';
			$thumb_url  = $product_id ? get_the_post_thumbnail_url( $product_id, 'thumbnail' ) : '';
			?>
			<li class="bmc-omodal__item">
				<div class="bmc-omodal__item-img">
					<?php if ( $thumb_url ) : ?>
						<img src="<?php echo esc_url( $thumb_url ); ?>" alt="" width="44" height="44" />
					<?php else : ?>
						<?php bmc_icon( 'shopping_bag', array( 'size' => 20 ) ); ?>
					<?php endif; ?>
				</div>

				<div class="bmc-omodal__item-body">
					<div class="bmc-omodal__item-title">
						<?php echo esc_html( $item_name ); ?>
					</div>
					<div class="bmc-omodal__item-sub">
						<span>تعداد: <?php echo esc_html( BMC_Helpers::to_persian_digits( $item_qty ) ); ?></span>
						<?php if ( $product && method_exists( $product, 'get_price' ) ) : ?>
							<span>قیمت واحد: <?php echo esc_html( function_exists( 'wc_price' ) ? wp_strip_all_tags( wc_price( $product->get_price() ) ) : $product->get_price() ); ?></span>
						<?php endif; ?>
					</div>
				</div>

				<div class="bmc-omodal__item-total">
					<?php echo esc_html( $subtotal ); ?>
				</div>
			</li>
		<?php endforeach; ?>
	</ul>
</div>

<div class="bmc-omodal__totals">
	<?php if ( method_exists( $order, 'get_subtotal_to_display' ) ) : ?>
		<div class="bmc-omodal__totals-row">
			<span>جمع جزء:</span>
			<span><?php echo esc_html( wp_strip_all_tags( (string) $order->get_subtotal_to_display() ) ); ?></span>
		</div>
	<?php endif; ?>

	<?php if ( method_exists( $order, 'get_discount_total' ) && (float) $order->get_discount_total() > 0 ) : ?>
		<div class="bmc-omodal__totals-row">
			<span>تخفیف:</span>
			<span>-<?php echo esc_html( function_exists( 'wc_price' ) ? wp_strip_all_tags( wc_price( $order->get_discount_total() ) ) : $order->get_discount_total() ); ?></span>
		</div>
	<?php endif; ?>

	<div class="bmc-omodal__totals-row is-grand">
		<span>مبلغ کل پرداختی:</span>
		<span><?php echo esc_html( $total_fmt ); ?></span>
	</div>
</div>

<div class="bmc-omodal__actions">
	<a href="<?php echo esc_url( $view_url ); ?>" class="bmc-btn bmc-btn-p bmc-btn-sm" target="_blank" rel="noopener">
		<?php bmc_icon( 'print', array( 'size' => 15 ) ); ?>
		مشاهده کامل فاکتور / چاپ
	</a>

	<?php if ( class_exists( 'BMC_Tickets' ) && BMC_Tickets::enabled() ) : ?>
		<a href="<?php echo esc_url( add_query_arg( array( 'bmc_new' => '1', 'order_id' => $order_id ), BMC_Tickets::url() ) ); ?>" class="bmc-btn bmc-btn-o bmc-btn-sm">
			<?php bmc_icon( 'support_agent', array( 'size' => 15 ) ); ?>
			درخواست پشتیبانی برای این سفارش
		</a>
	<?php endif; ?>

	<button type="button" class="bmc-btn bmc-btn-o bmc-btn-sm" data-bmc-omodal-close style="margin-inline-start:auto;">
		<?php bmc_icon( 'close', array( 'size' => 15 ) ); ?>
		بستن
	</button>
</div>
