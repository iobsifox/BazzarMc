<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_id_prod  = (int) $bmc_p->get_id();
$bmc_name     = (string) $bmc_p->get_name();
$bmc_show_img = BMC_Catalog::yesno( $bmc_cfg['card_show_image'] );
$bmc_qv       = BMC_Catalog::yesno( $bmc_cfg['qv_enabled'] ) && 'quickview' === $bmc_click;
$bmc_link     = (string) $bmc_link;
$bmc_classes  = array( 'bmc-pcard', 'bmc-pcard--' . $bmc_cfg['card_hover'], 'bmc-pcard--align-' . $bmc_cfg['card_align'] );

if ( $bmc_data['on_sale'] ) {
	$bmc_classes[] = 'is-sale';
}

if ( ! $bmc_data['in_stock'] ) {
	$bmc_classes[] = 'is-out';
}

if ( $bmc_data['blocked'] ) {
	$bmc_classes[] = 'is-blocked';
}

$bmc_style = (string) BMC_Catalog::ratio_style( $bmc_cfg );

$bmc_focus_attrs = '';

if ( $bmc_qv ) {
	$bmc_focus_attrs = ' tabindex="0" aria-haspopup="dialog"';
}

$bmc_link_attrs = '';

if ( $bmc_qv ) {
	$bmc_link_attrs = ' data-bmc-qv="' . esc_attr( $bmc_id_prod ) . '" aria-label="' . esc_attr( 'مشاهدهٔ سریع ' . $bmc_name ) . '"';
}

$bmc_excerpt = trim( wp_strip_all_tags( (string) $bmc_p->get_short_description() ) );

if ( '' === $bmc_excerpt ) {
	$bmc_excerpt = trim( wp_strip_all_tags( (string) $bmc_p->get_description() ) );
}

$bmc_words = (int) $bmc_cfg['card_excerpt_words'];

if ( $bmc_words > 0 && '' !== $bmc_excerpt ) {
	$bmc_excerpt = wp_trim_words( $bmc_excerpt, $bmc_words, '…' );
} elseif ( 0 === $bmc_words ) {
	$bmc_excerpt = '';
}
?>
<article class="<?php echo esc_attr( implode( ' ', $bmc_classes ) ); ?>" data-bmc-card="<?php echo esc_attr( $bmc_id_prod ); ?>" data-bmc-click="<?php echo esc_attr( $bmc_click ); ?>" data-bmc-product="<?php echo esc_attr( $bmc_id_prod ); ?>"<?php echo $bmc_focus_attrs; // phpcs:ignore WordPress.Security.EscapeOutput ?><?php echo $bmc_style ? ' style="' . esc_attr( $bmc_style ) . '"' : ''; ?>>
	<?php if ( $bmc_show_img ) : ?>
		<div class="bmc-pcard__media">
			<?php if ( $bmc_link ) : ?>
				<a class="bmc-pcard__link" href="<?php echo esc_url( $bmc_link ); ?>"<?php echo $bmc_link_attrs; // phpcs:ignore WordPress.Security.EscapeOutput ?>>
					<?php echo wp_kses_post( $bmc_p->get_image( 'woocommerce_thumbnail', array( 'class' => 'bmc-pcard__img', 'loading' => 'lazy' ) ) ); ?>
				</a>
			<?php else : ?>
				<span class="bmc-pcard__link bmc-pcard__link--static">
					<?php echo wp_kses_post( $bmc_p->get_image( 'woocommerce_thumbnail', array( 'class' => 'bmc-pcard__img', 'loading' => 'lazy' ) ) ); ?>
				</span>
			<?php endif; ?>

			<div class="bmc-pcard__badges">
				<?php if ( $bmc_data['on_sale'] && BMC_Catalog::yesno( $bmc_cfg['card_show_sale_badge'] ) ) : ?>
					<span class="bmc-pcard__badge bmc-pcard__badge--sale">
						<?php bmc_icon( 'percent', array( 'size' => 13 ) ); ?>
						<?php echo esc_html( trim( (string) $bmc_cfg['card_sale_badge_text'] ) . ( $bmc_data['sale_percent'] > 0 ? ' ' . BMC_Helpers::to_persian_digits( $bmc_data['sale_percent'] ) . '٪' : '' ) ); ?>
					</span>
				<?php endif; ?>

				<?php if ( $bmc_data['rank_label'] && BMC_Catalog::yesno( $bmc_cfg['card_show_rank_badge'] ) ) : ?>
					<span class="bmc-pcard__badge bmc-pcard__badge--rank">
						<?php bmc_icon( 'military_tech', array( 'size' => 13 ) ); ?>
						<?php echo esc_html( $bmc_data['rank_label'] ); ?>
					</span>
				<?php endif; ?>

				<?php if ( ! $bmc_data['in_stock'] ) : ?>
					<span class="bmc-pcard__badge bmc-pcard__badge--out">
						<?php bmc_icon( 'inventory', array( 'size' => 13 ) ); ?>
						<?php echo esc_html( (string) $bmc_cfg['card_button_text_soldout'] ); ?>
					</span>
				<?php endif; ?>
			</div>

			<?php if ( $bmc_qv && BMC_Catalog::yesno( $bmc_cfg['card_qv_hint'] ) ) : ?>
				<span class="bmc-pcard__qv">
					<?php bmc_icon( 'visibility', array( 'size' => 16 ) ); ?>
					<span>مشاهدهٔ سریع</span>
				</span>
			<?php endif; ?>
		</div>
	<?php endif; ?>

	<div class="bmc-pcard__body">
		<?php if ( $bmc_data['category'] && BMC_Catalog::yesno( $bmc_cfg['card_show_category'] ) ) : ?>
			<span class="bmc-pcard__cat">
				<?php bmc_icon( 'category', array( 'size' => 13 ) ); ?>
				<?php echo esc_html( $bmc_data['category'] ); ?>
			</span>
		<?php endif; ?>

		<h3 class="bmc-pcard__title">
			<?php if ( $bmc_link ) : ?>
				<a href="<?php echo esc_url( $bmc_link ); ?>"<?php echo $bmc_link_attrs; // phpcs:ignore WordPress.Security.EscapeOutput ?>><?php echo esc_html( $bmc_name ); ?></a>
			<?php else : ?>
				<?php echo esc_html( $bmc_name ); ?>
			<?php endif; ?>
		</h3>

		<?php if ( $bmc_data['rating'] > 0 && BMC_Catalog::yesno( $bmc_cfg['card_show_rating'] ) ) : ?>
			<span class="bmc-pcard__rating">
				<?php bmc_icon( 'star', array( 'size' => 14 ) ); ?>
				<span><?php echo esc_html( BMC_Helpers::to_persian_digits( number_format_i18n( $bmc_data['rating'], 1 ) ) ); ?></span>
				<?php if ( $bmc_data['rating_count'] > 0 ) : ?>
					<span class="bmc-pcard__rating-count">(<?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_data['rating_count'] ) ); ?>)</span>
				<?php endif; ?>
			</span>
		<?php endif; ?>

		<?php if ( $bmc_excerpt && BMC_Catalog::yesno( $bmc_cfg['card_show_excerpt'] ) ) : ?>
			<p class="bmc-pcard__excerpt"><?php echo esc_html( $bmc_excerpt ); ?></p>
		<?php endif; ?>

		<?php if ( $bmc_data['rank_days'] > 0 && BMC_Catalog::yesno( $bmc_cfg['card_show_meta'] ) ) : ?>
			<span class="bmc-pcard__meta">
				<?php bmc_icon( 'schedule', array( 'size' => 14 ) ); ?>
				<span>اعتبار رنک: <?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_data['rank_days'] ) ); ?> روز</span>
			</span>
		<?php endif; ?>

		<?php if ( BMC_Catalog::yesno( $bmc_cfg['card_show_stock'] ) && $bmc_data['in_stock'] ) : ?>
			<span class="bmc-pcard__stock">
				<?php bmc_icon( 'check_circle', array( 'size' => 14 ) ); ?>
				<span><?php echo esc_html( $bmc_data['stock_text'] ); ?></span>
			</span>
		<?php endif; ?>

		<?php if ( BMC_Catalog::yesno( $bmc_cfg['card_show_price'] ) ) : ?>
			<div class="bmc-pcard__price"><?php echo wp_kses_post( $bmc_p->get_price_html() ); ?></div>
		<?php endif; ?>

		<?php if ( $bmc_data['blocked'] && $bmc_data['blocked_msg'] ) : ?>
			<div class="bmc-pcard__note"><?php echo esc_html( $bmc_data['blocked_msg'] ); ?></div>
		<?php endif; ?>
	</div>

	<div class="bmc-pcard__foot">
		<?php if ( $bmc_data['blocked'] ) : ?>
			<span class="bmc-btn bmc-btn-disabled bmc-btn-block bmc-pcard__buy" data-bmc-noqv="1">
				<?php bmc_icon( 'lock', array( 'size' => 16 ) ); ?>
				<span><?php echo esc_html( (string) $bmc_cfg['card_button_text_soldout'] ); ?></span>
			</span>
		<?php elseif ( ! $bmc_data['in_stock'] || ! $bmc_data['purchasable'] ) : ?>
			<span class="bmc-btn bmc-btn-disabled bmc-btn-block bmc-pcard__buy" data-bmc-noqv="1">
				<?php bmc_icon( 'inventory', array( 'size' => 16 ) ); ?>
				<span><?php echo esc_html( (string) $bmc_cfg['card_button_text_soldout'] ); ?></span>
			</span>
		<?php elseif ( $bmc_data['is_variable'] ) : ?>
			<?php if ( BMC_Catalog::single_enabled() ) : ?>
				<a class="bmc-btn bmc-btn-p bmc-btn-block bmc-pcard__buy" href="<?php echo esc_url( (string) get_permalink( $bmc_id_prod ) ); ?>" data-bmc-noqv="1">
					<?php bmc_icon( (string) $bmc_cfg['card_button_icon'], array( 'size' => 16 ) ); ?>
					<span><?php echo esc_html( (string) $bmc_cfg['card_button_text_variable'] ); ?></span>
				</a>
			<?php else : ?>
				<button type="button" class="bmc-btn bmc-btn-p bmc-btn-block bmc-pcard__buy" data-bmc-qv-open="<?php echo esc_attr( $bmc_id_prod ); ?>" data-bmc-noqv="1">
					<?php bmc_icon( (string) $bmc_cfg['card_button_icon'], array( 'size' => 16 ) ); ?>
					<span><?php echo esc_html( (string) $bmc_cfg['card_button_text_variable'] ); ?></span>
				</button>
			<?php endif; ?>
		<?php else : ?>
			<a class="bmc-btn bmc-btn-p bmc-btn-block bmc-pcard__buy ajax_add_to_cart add_to_cart_button" href="<?php echo esc_url( (string) BMC_Catalog::add_to_cart_url( $bmc_p ) ); ?>" data-product_id="<?php echo esc_attr( $bmc_id_prod ); ?>" data-product_sku="<?php echo esc_attr( (string) $bmc_p->get_sku() ); ?>" data-quantity="1" data-bmc-noqv="1" rel="nofollow" aria-label="<?php echo esc_attr( (string) $bmc_cfg['card_button_text'] . ' — ' . $bmc_name ); ?>">
				<?php bmc_icon( (string) $bmc_cfg['card_button_icon'], array( 'size' => 16 ) ); ?>
				<span><?php echo esc_html( (string) $bmc_cfg['card_button_text'] ); ?></span>
			</a>
		<?php endif; ?>

		<?php if ( BMC_Catalog::yesno( $bmc_cfg['card_buy_now'] ) && $bmc_data['purchasable'] && $bmc_data['in_stock'] && ! $bmc_data['blocked'] && ! $bmc_data['is_variable'] ) : ?>
			<a class="bmc-btn bmc-btn-o bmc-btn-block bmc-pcard__buynow" href="<?php echo esc_url( (string) BMC_Catalog::add_to_cart_url( $bmc_p, true ) ); ?>" data-bmc-noqv="1">
				<?php bmc_icon( 'payments', array( 'size' => 16 ) ); ?>
				<span><?php echo esc_html( (string) $bmc_cfg['card_buy_now_text'] ); ?></span>
			</a>
		<?php endif; ?>
	</div>
</article>
