<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'bmc_render_checkout_field' ) ) {

	function bmc_render_checkout_field( $key, $field, $value = '', $width = 0 ) {
		$type        = isset( $field['type'] ) ? $field['type'] : 'text';
		$label       = isset( $field['label'] ) ? $field['label'] : '';
		$required    = ! empty( $field['required'] );
		$placeholder = isset( $field['placeholder'] ) ? $field['placeholder'] : ( isset( $field['label'] ) ? $field['label'] : '' );
		$options     = isset( $field['options'] ) && is_array( $field['options'] ) ? $field['options'] : array();
		$classes     = 'bmc-input' . ( isset( $field['input_class'] ) ? ' ' . implode( ' ', (array) $field['input_class'] ) : '' );
		$custom      = isset( $field['custom_attributes'] ) && is_array( $field['custom_attributes'] ) ? $field['custom_attributes'] : array();

		if ( 'hidden' === $type ) {
			printf( '<input type="hidden" name="%1$s" value="%2$s" />', esc_attr( $key ), esc_attr( $value ) );
			return;
		}

		$bmc_col_open  = $width ? '<div class="bmc-col-' . (int) $width . '">' : '';
		$bmc_col_close = $width ? '</div>' : '';

		if ( 'checkbox' === $type ) {
			echo $bmc_col_open; // phpcs:ignore WordPress.Security.EscapeOutput
			printf(
				'<label class="bmc-check"><input type="checkbox" name="%1$s" id="%1$s" value="1" %2$s /><span>%3$s</span></label>',
				esc_attr( $key ),
				checked( ! empty( $value ), true, false ),
				esc_html( $label )
			);
			echo $bmc_col_close; // phpcs:ignore WordPress.Security.EscapeOutput
			return;
		}

		echo $bmc_col_open; // phpcs:ignore WordPress.Security.EscapeOutput
		echo '<div class="bmc-field">';

		if ( $label ) {
			printf(
				'<label class="bmc-label" for="%1$s">%2$s%3$s</label>',
				esc_attr( $key ),
				esc_html( $label ),
				$required ? ' <span class="req">*</span>' : ''
			);
		}

		if ( 'select' === $type || 'country' === $type || 'state' === $type ) {
			printf( '<select class="%1$s" name="%2$s" id="%2$s">', esc_attr( $classes ), esc_attr( $key ) );
			foreach ( $options as $opt_value => $opt_label ) {
				printf(
					'<option value="%1$s" %2$s>%3$s</option>',
					esc_attr( $opt_value ),
					selected( (string) $value, (string) $opt_value, false ),
					esc_html( $opt_label )
				);
			}
			echo '</select>';
		} elseif ( 'textarea' === $type ) {
			printf(
				'<textarea class="%1$s" name="%2$s" id="%2$s" rows="3" placeholder="%3$s" %4$s>%5$s</textarea>',
				esc_attr( $classes ),
				esc_attr( $key ),
				esc_attr( $placeholder ),
				$required ? 'required' : '',
				esc_textarea( $value )
			);
		} else {
			$attrs = '';
			foreach ( $custom as $attr_key => $attr_value ) {
				$attrs .= ' ' . esc_attr( $attr_key ) . '="' . esc_attr( $attr_value ) . '"';
			}

			printf(
				'<input class="%1$s" type="%2$s" name="%3$s" id="%3$s" placeholder="%4$s" value="%5$s" %6$s %7$s />',
				esc_attr( $classes ),
				esc_attr( in_array( $type, array( 'email', 'tel', 'password', 'number' ), true ) ? $type : 'text' ),
				esc_attr( $key ),
				esc_attr( $placeholder ),
				esc_attr( $value ),
				$required ? 'required' : '',
				$attrs
			);
		}

		if ( ! empty( $field['description'] ) ) {
			echo '<p class="bmc-hint">' . wp_kses_post( $field['description'] ) . '</p>';
		}

		echo '</div>';
		echo $bmc_col_close; // phpcs:ignore WordPress.Security.EscapeOutput
	}
}

if ( ! function_exists( 'bmc_render_checkout_rows' ) ) {

	function bmc_render_checkout_rows( array $rows, array &$rendered, $allow_custom = true ) {
		foreach ( $rows as $row ) {
			if ( ! empty( $row['custom'] ) ) {
				if ( ! $allow_custom || ! class_exists( 'BMC_Checkout_Fields' ) ) {
					continue;
				}

				BMC_Checkout_Fields::render_field_row( $row['cf'], isset( $row['value'] ) ? $row['value'] : '', $row['width'] );
				$rendered[] = $row['key'];
				continue;
			}

			$key   = $row['key'];
			$field = $row['field'];
			$value = '';

			if ( isset( $field['value'] ) ) {
				$value = $field['value'];
			} elseif ( function_exists( 'is_user_logged_in' ) && is_user_logged_in() ) {
				$value = get_user_meta( get_current_user_id(), $key, true );
			}

			if ( 'billing_phone' === $key && ! $value && class_exists( 'BMC_Auth' ) ) {
				$value = BMC_Auth::get_user_mobile( get_current_user_id() );
			}

			if ( 'billing_email' === $key && ! $value && function_exists( 'is_user_logged_in' ) && is_user_logged_in() ) {
				$value = wp_get_current_user()->user_email;
			}

			if ( 'billing_first_name' === $key && ! $value && function_exists( 'is_user_logged_in' ) && is_user_logged_in() ) {
				$value = wp_get_current_user()->first_name;
			}

			if ( 'billing_last_name' === $key && ! $value && function_exists( 'is_user_logged_in' ) && is_user_logged_in() ) {
				$value = wp_get_current_user()->last_name;
			}

			if ( 'hidden' === ( isset( $field['type'] ) ? $field['type'] : 'text' ) ) {
				bmc_render_checkout_field( $key, $field, $value );
				continue;
			}

			bmc_render_checkout_field( $key, $field, $value, $row['width'] );
			$rendered[] = $key;
		}
	}
}

$bmc_theme   = 'light' === BMC_Settings::get( 'checkout_theme' ) ? ' bmc-theme-light' : '';
$bmc_fields  = WC()->checkout()->get_checkout_fields();
$bmc_user    = wp_get_current_user();
$bmc_linked  = BMC_Link::is_linked( get_current_user_id() );
$bmc_player  = BMC_Link::get_linked_player( get_current_user_id() );
$bmc_head    = BMC_Helpers::mc_head( $bmc_player ? $bmc_player : 'MHF_Question', 96 );
$bmc_mobile  = BMC_Auth::get_user_mobile( get_current_user_id() );
$bmc_summary = BMC_Checkout::summary_data();
$bmc_layout  = BMC_Checkout::layout( isset( $bmc_atts ) ? (array) $bmc_atts : array() );
$bmc_plan    = BMC_Checkout::field_plan( $bmc_fields, isset( $bmc_atts ) ? (array) $bmc_atts : array() );
$bmc_custom  = ! empty( $bmc_layout['custom'] );

foreach ( $bmc_plan as $bmc_section_key => $bmc_section_rows ) {
	foreach ( $bmc_section_rows as $bmc_row_index => $bmc_row_item ) {
		if ( ! empty( $bmc_row_item['custom'] ) && ! $bmc_custom ) {
			unset( $bmc_plan[ $bmc_section_key ][ $bmc_row_index ] );
		}
	}

	$bmc_plan[ $bmc_section_key ] = array_values( $bmc_plan[ $bmc_section_key ] );
}

$bmc_rendered = array();
$bmc_cart_url = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : '';
$bmc_terms   = function_exists( 'wc_terms_and_conditions_page_id' ) ? wc_terms_and_conditions_page_id() : 0;

$bmc_gateways = array();
if ( function_exists( 'WC' ) && WC()->payment_gateways() ) {
	$bmc_gateways = WC()->payment_gateways()->get_available_payment_gateways();
}

$bmc_base_country = function_exists( 'WC' ) ? WC()->countries->get_base_country() : 'IR';
$bmc_base_state   = function_exists( 'WC' ) ? WC()->countries->get_base_state() : '';
?>
<div class="bmc-wrap<?php echo esc_attr( $bmc_theme ); ?>" id="bmcCheckoutWrap">
	<div class="bmc-container bmc-container--wide">

		<?php if ( $bmc_layout['steps'] ) : ?>
			<?php echo BMC_Checkout::steps_nav( 'checkout' ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
		<?php endif; ?>

		<div class="bmc-head">
			<span class="bmc-kicker"><?php bmc_icon( 'shopping_cart', array( 'size' => 15 ) ); ?> تکمیل خرید</span>
			<h2 class="bmc-title">ثبت سفارش و پرداخت</h2>
			<p class="bmc-subtitle">
				<?php if ( $bmc_linked ) : ?>
					اکانت ماینکرافت شما متصل است؛ آیتم‌ها پس از پرداخت به‌صورت خودکار در سرور تحویل داده می‌شود.
				<?php else : ?>
					اطلاعات زیر را بررسی کنید و پرداخت را انجام دهید.
				<?php endif; ?>
			</p>

			<?php if ( $bmc_layout['back_to_cart'] && $bmc_cart_url ) : ?>
				<a class="bmc-backlink" href="<?php echo esc_url( $bmc_cart_url ); ?>">
					<?php bmc_icon( 'keyboard_arrow_right', array( 'size' => 16 ) ); ?> بازگشت به سبد خرید و ویرایش آیتم‌ها
				</a>
			<?php endif; ?>
		</div>

		<div id="bmcCheckoutAlert"></div>

		<form id="bmcCheckoutForm" class="bmc-grid bmc-grid--checkout" autocomplete="on" novalidate>

			<input type="hidden" name="security" value="<?php echo esc_attr( wp_create_nonce( 'woocommerce-process_checkout' ) ); ?>" />
			<input type="hidden" name="billing_country" value="<?php echo esc_attr( $bmc_base_country ); ?>" />
			<input type="hidden" name="billing_state" value="<?php echo esc_attr( $bmc_base_state ); ?>" />
			<input type="hidden" name="_bmc_checkout" value="1" />
			<?php if ( $bmc_terms ) : ?>
				<input type="hidden" name="terms-field" value="1" />
			<?php endif; ?>

			<div class="bmc-grid bmc-checkout-cards bmc-cols--<?php echo esc_attr( $bmc_layout['columns'] ); ?>" style="gap:16px">

				<?php foreach ( $bmc_layout['cards'] as $bmc_card ) : ?>

				<?php if ( 'mc' === $bmc_card ) : ?>
				<div class="bmc-card bmc-card--mc">
					<div class="bmc-card__head">
						<h3 class="bmc-card__title"><span class="bmc-dot"></span> <?php echo esc_html( $bmc_layout['titles']['mc'] ); ?></h3>
						<?php if ( $bmc_linked ) : ?>
							<span class="bmc-badge bmc-badge--ok"><?php bmc_icon( 'check', array( 'size' => 14 ) ); ?> متصل</span>
						<?php else : ?>
							<span class="bmc-badge bmc-badge--warn">هدیه</span>
						<?php endif; ?>
					</div>

					<div class="bmc-status">
						<div class="bmc-avatar">
							<img id="bmcCheckoutHead" src="<?php echo esc_url( $bmc_head ); ?>" alt="" />
						</div>
						<div style="flex:1;min-width:0">
							<?php if ( $bmc_linked ) : ?>
								<p class="bmc-player-name" style="font-size:18px"><?php echo esc_html( $bmc_player ); ?></p>
								<p class="bmc-hint" style="margin:2px 0 0">آیتم‌ها به این اکانت تحویل داده می‌شود.</p>
								<input type="hidden" name="<?php echo esc_attr( BMC_Checkout::FIELD_PLAYER ); ?>" value="<?php echo esc_attr( $bmc_player ); ?>" />
							<?php else : ?>
								<label class="bmc-check" style="margin-bottom:10px">
									<input type="checkbox" name="<?php echo esc_attr( BMC_Checkout::FIELD_GIFT ); ?>" id="bmcGiftToggle" value="1" />
									<span>این سفارش هدیه است (برای بازیکن دیگری خرید می‌کنم)</span>
								</label>

								<div id="bmcGiftFields">
									<label class="bmc-label" for="bmcGiftPlayer">نام کاربری ماینکرافت دریافت‌کننده <span class="req">*</span></label>
									<input class="bmc-input" type="text" dir="ltr" id="bmcGiftPlayer"
										name="<?php echo esc_attr( BMC_Checkout::FIELD_PLAYER ); ?>"
										placeholder="Notch" maxlength="16"
										style="text-align:left;font-family:Consolas,monospace" />
									<p class="bmc-hint">
										<?php if ( 'premium' === BMC_Settings::get( 'username_policy' ) ) : ?>
											نام کاربری باید یک اکانت اصلی (پرمیوم) موجانگ باشد.
										<?php else : ?>
											نام کاربری بازیکن دریافت‌کننده را دقیق وارد کنید.
										<?php endif; ?>
									</p>
								</div>
							<?php endif; ?>
						</div>
					</div>

					<?php if ( $bmc_plan['mc'] ) : ?>
						<div class="bmc-fields-grid" style="margin-top:14px">
							<?php bmc_render_checkout_rows( $bmc_plan['mc'], $bmc_rendered, $bmc_custom ); ?>
						</div>
					<?php endif; ?>
				</div>

				<?php elseif ( 'buyer' === $bmc_card ) : ?>
				<div class="bmc-card bmc-card--buyer">
					<div class="bmc-card__head">
						<h3 class="bmc-card__title"><span class="bmc-dot"></span> <?php echo esc_html( $bmc_layout['titles']['buyer'] ); ?></h3>
						<?php if ( is_user_logged_in() ) : ?>
							<span class="bmc-badge"><?php echo esc_html( $bmc_user->display_name ); ?></span>
						<?php else : ?>
							<a class="bmc-btn bmc-btn--ghost bmc-btn--sm" href="<?php echo esc_url( BMC_Auth::login_url() ); ?>">ورود</a>
						<?php endif; ?>
					</div>

					<?php if ( $bmc_plan['buyer'] ) : ?>
						<div class="bmc-fields-grid">
							<?php bmc_render_checkout_rows( $bmc_plan['buyer'], $bmc_rendered, $bmc_custom ); ?>
						</div>
					<?php endif; ?>

					<?php if ( $bmc_plan['order'] ) : ?>
						<div class="bmc-fields-grid">
							<?php bmc_render_checkout_rows( $bmc_plan['order'], $bmc_rendered, $bmc_custom ); ?>
						</div>
					<?php endif; ?>

					<?php if ( $bmc_plan['shipping'] ) : ?>
						<div class="bmc-fields-grid">
							<?php bmc_render_checkout_rows( $bmc_plan['shipping'], $bmc_rendered, $bmc_custom ); ?>
						</div>
					<?php endif; ?>

					<?php
					if ( ! $bmc_rendered ) {
						echo '<p class="bmc-subtitle">نیازی به تکمیل اطلاعات اضافی نیست — فقط روش پرداخت را انتخاب کنید.</p>';
					}
					?>
				</div>

				<?php elseif ( 'extra' === $bmc_card ) : ?>
				<?php if ( $bmc_plan['extra'] ) : ?>
				<div class="bmc-card bmc-card--extra">
					<div class="bmc-card__head">
						<h3 class="bmc-card__title"><span class="bmc-dot"></span> <?php echo esc_html( $bmc_layout['titles']['extra'] ); ?></h3>
					</div>

					<div class="bmc-fields-grid">
						<?php bmc_render_checkout_rows( $bmc_plan['extra'], $bmc_rendered, $bmc_custom ); ?>
					</div>
				</div>
				<?php endif; ?>

				<?php elseif ( 'payment' === $bmc_card ) : ?>
				<div class="bmc-card bmc-card--payment">
					<div class="bmc-card__head">
						<h3 class="bmc-card__title"><span class="bmc-dot"></span> <?php echo esc_html( $bmc_layout['titles']['payment'] ); ?></h3>
					</div>

					<?php if ( $bmc_plan['payment'] ) : ?>
						<div class="bmc-fields-grid" style="margin-bottom:14px">
							<?php bmc_render_checkout_rows( $bmc_plan['payment'], $bmc_rendered, $bmc_custom ); ?>
						</div>
					<?php endif; ?>

					<?php if ( empty( $bmc_gateways ) ) : ?>
						<div class="bmc-alert bmc-alert--error">
							<span class="bmc-alert__icon"><?php bmc_icon( 'warning', array( 'size' => 20 ) ); ?></span>
							<div>هیچ درگاه پرداخت فعالی یافت نشد. از پنل ووکامرس یک درگاه (مثل زرین‌پال) را فعال کنید.</div>
						</div>
					<?php else : ?>
						<div class="bmc-pay" id="bmcPayMethods">
							<?php $bmc_first = true; ?>
							<?php foreach ( $bmc_gateways as $bmc_gw_id => $bmc_gateway ) : ?>
								<label class="bmc-pay__option<?php echo $bmc_first ? ' is-selected' : ''; ?>" data-gateway="<?php echo esc_attr( $bmc_gw_id ); ?>">
									<input type="radio" name="payment_method" value="<?php echo esc_attr( $bmc_gw_id ); ?>" <?php checked( $bmc_first ); ?> />
									<?php if ( $bmc_gateway->icon ) : ?>
										<img class="bmc-pay__icon" src="<?php echo esc_url( $bmc_gateway->icon ); ?>" alt="" />
									<?php endif; ?>
									<span style="flex:1">
										<span class="bmc-pay__label"><?php echo wp_kses_post( $bmc_gateway->get_title() ); ?></span>
										<?php if ( $bmc_gateway->get_description() ) : ?>
											<span class="bmc-pay__desc"><?php echo wp_kses_post( $bmc_gateway->get_description() ); ?></span>
										<?php endif; ?>
									</span>
								</label>
								<?php $bmc_first = false; ?>
							<?php endforeach; ?>
						</div>
					<?php endif; ?>

					<?php if ( $bmc_terms ) : ?>
						<label class="bmc-check" style="margin-top:14px">
							<input type="checkbox" name="terms" id="bmcTerms" value="1" />
							<span>
								<a href="<?php echo esc_url( get_permalink( $bmc_terms ) ); ?>" target="_blank" rel="noopener">قوانین و مقررات</a> را می‌پذیرم.
							</span>
						</label>
					<?php endif; ?>
				</div>

				<?php endif; ?>

				<?php endforeach; ?>
			</div>

			<div class="bmc-card bmc-card--summary" id="bmcSummaryCard">
				<div class="bmc-card__head">
					<h3 class="bmc-card__title"><span class="bmc-dot"></span> <?php echo esc_html( $bmc_layout['titles']['summary'] ); ?></h3>
					<span class="bmc-badge" id="bmcCartCount"><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_summary['item_count'] ) ); ?> کالا</span>
				</div>

				<ul class="bmc-summary__items" id="bmcItems">
					<?php foreach ( $bmc_summary['items'] as $bmc_item ) : ?>
						<li class="bmc-summary__item">
							<?php if ( ! empty( $bmc_item['image'] ) ) : ?>
								<img class="bmc-summary__thumb" src="<?php echo esc_url( $bmc_item['image'] ); ?>" alt="" />
							<?php else : ?>
								<span class="bmc-summary__thumb" style="display:grid;place-items:center"><?php bmc_icon( 'inventory_2', array( 'size' => 22 ) ); ?></span>
							<?php endif; ?>
							<span class="bmc-summary__name">
								<?php echo esc_html( $bmc_item['name'] ); ?>
								<small>تعداد: <?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_item['qty'] ) ); ?><?php echo $bmc_item['synced'] ? ' • تحویل در بازی' : ''; ?></small>
							</span>
							<span class="bmc-summary__price"><?php echo wp_kses_post( $bmc_item['total'] ); ?></span>
						</li>
					<?php endforeach; ?>
				</ul>

				<?php if ( BMC_Settings::bool( 'checkout_show_coupon', true ) ) : ?>
					<div class="bmc-coupon">
						<input class="bmc-input" type="text" id="bmcCouponInput" placeholder="کد تخفیف" />
						<button type="button" class="bmc-btn bmc-btn--ghost" id="bmcApplyCoupon">اعمال</button>
					</div>
					<div class="bmc-coupon-tags" id="bmcCouponTags">
						<?php foreach ( $bmc_summary['coupons'] as $bmc_coupon ) : ?>
							<span class="bmc-tag"><?php echo esc_html( $bmc_coupon ); ?> <button type="button" data-coupon="<?php echo esc_attr( $bmc_coupon ); ?>">×</button></span>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>

				<div id="bmcTotals" style="margin-top:14px">
					<?php foreach ( $bmc_summary['totals'] as $bmc_row ) : ?>
						<div class="bmc-summary__row<?php echo isset( $bmc_row['class'] ) ? ' ' . esc_attr( $bmc_row['class'] ) : ''; ?>">
							<span><?php echo esc_html( $bmc_row['label'] ); ?></span>
							<span><?php echo wp_kses_post( $bmc_row['value'] ); ?></span>
						</div>
					<?php endforeach; ?>
				</div>

				<div class="bmc-summary__total">
					<span>مبلغ قابل پرداخت</span>
					<span class="amount" id="bmcGrandTotal"><?php echo wp_kses_post( $bmc_summary['grand_total'] ); ?></span>
				</div>

				<button type="submit" class="bmc-btn bmc-btn--block" id="bmcPlaceOrder" style="margin-top:18px" <?php echo empty( $bmc_gateways ) ? 'disabled' : ''; ?>>
					<span class="bmc-spin"></span>
					<span><?php echo esc_html( $bmc_layout['submit_text'] ); ?></span>
				</button>

				<p class="bmc-hint" style="text-align:center;margin-top:12px">
					<?php bmc_icon( 'lock', array( 'size' => 15 ) ); ?> پرداخت از طریق درگاه امن بانکی انجام می‌شود.
				</p>
			</div>

		</form>
	</div>
</div>
