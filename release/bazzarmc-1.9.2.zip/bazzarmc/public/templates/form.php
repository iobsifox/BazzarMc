<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_form      = isset( $bmc_form ) && is_array( $bmc_form ) ? $bmc_form : array();
$bmc_form_id   = isset( $bmc_form['id'] ) ? (int) $bmc_form['id'] : 0;
$bmc_theme     = 'light' === ( isset( $bmc_form['theme'] ) ? $bmc_form['theme'] : 'inherit' )
	? ' bmc-theme-light'
	: ( 'inherit' === ( isset( $bmc_form['theme'] ) ? $bmc_form['theme'] : 'inherit' ) && 'light' === BMC_Settings::get( 'checkout_theme' ) ? ' bmc-theme-light' : '' );
$bmc_accent    = ! empty( $bmc_form['accent'] ) ? (string) $bmc_form['accent'] : (string) BMC_Settings::get( 'checkout_accent', '#3ddc84' );
$bmc_fields    = isset( $bmc_form['fields'] ) && is_array( $bmc_form['fields'] ) ? $bmc_form['fields'] : array();
$bmc_gap       = isset( $bmc_form['gap'] ) ? (int) $bmc_form['gap'] : 16;
$bmc_bordered  = empty( $bmc_form['bordered'] ) ? ' bmc-form-wrap--plain' : '';
$bmc_labels    = isset( $bmc_form['labels_position'] ) ? (string) $bmc_form['labels_position'] : 'top';
$bmc_has_files = false;
$bmc_back_url  = isset( $_SERVER['REQUEST_URI'] ) ? home_url( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) ) : home_url( '/' );
$bmc_notice_ok = '';
$bmc_notice_no = '';

foreach ( $bmc_fields as $bmc_field ) {
	if ( 'file' === $bmc_field['type'] ) {
		$bmc_has_files = true;
		break;
	}
}

if ( isset( $_GET['bmc_form'] ) && (int) $_GET['bmc_form'] === $bmc_form_id ) {
	if ( isset( $_GET['bmc_form_ok'] ) ) {
		$bmc_notice_ok = sanitize_text_field( rawurldecode( wp_unslash( $_GET['bmc_form_ok'] ) ) );
	}

	if ( isset( $_GET['bmc_form_error'] ) ) {
		$bmc_notice_no = sanitize_text_field( rawurldecode( wp_unslash( $_GET['bmc_form_error'] ) ) );
	}
}
?>
<div class="bmc-wrap bmc-form-wrap<?php echo esc_attr( $bmc_theme . $bmc_bordered ); ?> bmc-form-labels--<?php echo esc_attr( $bmc_labels ); ?>"
	id="bmcFormWrap-<?php echo esc_attr( $bmc_form_id ); ?>"
	data-bmc-form="<?php echo esc_attr( $bmc_form_id ); ?>"
	style="--bmc-accent:<?php echo esc_attr( $bmc_accent ); ?>;--bmc-form-gap:<?php echo esc_attr( $bmc_gap ); ?>px">

	<div class="bmc-container bmc-container--narrow">

		<?php if ( ! empty( $bmc_form['show_title'] ) && ( $bmc_form['title'] || $bmc_form['description'] ) ) : ?>
			<div class="bmc-head">
				<span class="bmc-kicker"><?php bmc_icon( 'dynamic_form', array( 'size' => 15 ) ); ?> فرم</span>
				<?php if ( $bmc_form['title'] ) : ?>
					<h2 class="bmc-title"><?php echo esc_html( $bmc_form['title'] ); ?></h2>
				<?php endif; ?>
				<?php if ( $bmc_form['description'] ) : ?>
					<p class="bmc-subtitle"><?php echo wp_kses_post( $bmc_form['description'] ); ?></p>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<div id="bmcFormAlert-<?php echo esc_attr( $bmc_form_id ); ?>">
			<?php if ( $bmc_notice_ok ) : ?>
				<div class="bmc-alert bmc-alert--ok"><span class="bmc-alert__icon"><?php bmc_icon( 'check_circle', array( 'size' => 20 ) ); ?></span><div><?php echo esc_html( $bmc_notice_ok ); ?></div></div>
			<?php endif; ?>
			<?php if ( $bmc_notice_no ) : ?>
				<div class="bmc-alert bmc-alert--error"><span class="bmc-alert__icon"><?php bmc_icon( 'error', array( 'size' => 20 ) ); ?></span><div><?php echo esc_html( $bmc_notice_no ); ?></div></div>
			<?php endif; ?>
		</div>

		<?php if ( ! $bmc_fields ) : ?>
			<div class="bmc-alert bmc-alert--warn">
				<span class="bmc-alert__icon"><?php bmc_icon( 'warning', array( 'size' => 20 ) ); ?></span>
				<div>این فرم هنوز فیلدی ندارد. از پیشخوان ← BazzarMc ← فرم‌ها فیلدها را اضافه کنید.</div>
			</div>
		<?php else : ?>

			<form class="bmc-form-el"
				id="bmcForm-<?php echo esc_attr( $bmc_form_id ); ?>"
				method="post"
				action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>"
				data-form-id="<?php echo esc_attr( $bmc_form_id ); ?>"
				data-nonce="<?php echo esc_attr( BMC_Forms::nonce( $bmc_form_id ) ); ?>"
				autocomplete="on"
				novalidate
				<?php echo $bmc_has_files ? 'enctype="multipart/form-data"' : ''; ?>>

				<input type="hidden" name="action" value="bmc_form_submit" />
				<input type="hidden" name="bmc_form_id" value="<?php echo esc_attr( $bmc_form_id ); ?>" />
				<input type="hidden" name="bmc_form_nonce" value="<?php echo esc_attr( BMC_Forms::nonce( $bmc_form_id ) ); ?>" />
				<input type="hidden" name="bmc_form_back" value="<?php echo esc_url( $bmc_back_url ); ?>" />

				<?php if ( ! empty( $bmc_form['honeypot'] ) ) : ?>
					<div class="bmc-hp" aria-hidden="true">
						<label for="bmcHp-<?php echo esc_attr( $bmc_form_id ); ?>">این فیلد را خالی بگذارید</label>
						<input type="text" id="bmcHp-<?php echo esc_attr( $bmc_form_id ); ?>" name="bmc_hp" value="" tabindex="-1" autocomplete="off" />
					</div>
				<?php endif; ?>

				<div class="bmc-form__grid">
					<?php
					foreach ( $bmc_fields as $bmc_field ) {
						$bmc_field['labels_position'] = $bmc_labels;

						echo BMC_Forms::render_field( $bmc_field ); // phpcs:ignore WordPress.Security.EscapeOutput
					}
					?>
				</div>

				<div class="bmc-form__footer">
					<button type="submit" class="bmc-btn bmc-btn--block" id="bmcFormSubmit-<?php echo esc_attr( $bmc_form_id ); ?>">
						<span class="bmc-spin"></span>
						<span><?php echo esc_html( $bmc_form['submit_text'] ); ?></span>
					</button>

					<p class="bmc-hint bmc-form__secure">
						<?php bmc_icon( 'lock', array( 'size' => 14 ) ); ?>
						اطلاعات شما فقط برای پاسخ‌گویی به همین درخواست استفاده می‌شود.
					</p>
				</div>
			</form>

		<?php endif; ?>
	</div>
</div>
