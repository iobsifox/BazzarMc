<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_uid      = get_current_user_id();
$bmc_counts   = BMC_Tickets::counts( $bmc_uid );
$bmc_show_new = isset( $_GET['new'] ) && '0' !== $_GET['new']; // phpcs:ignore WordPress.Security.NonceVerification
$bmc_paged    = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1; // phpcs:ignore WordPress.Security.NonceVerification
$bmc_status_f = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification

$bmc_result = BMC_Tickets::query(
	array(
		'user_id'  => $bmc_uid,
		'status'   => $bmc_status_f,
		'page'     => $bmc_paged,
		'per_page' => BMC_Tickets::per_page(),
	)
);

$bmc_categories = BMC_Tickets::categories();
$bmc_products   = BMC_Tickets::product_choices( $bmc_uid );
$bmc_self_url   = remove_query_arg( array( 'bmc_ticket_msg', 'bmc_ticket_error' ) );

if ( ! $bmc_show_new && empty( $bmc_result['items'] ) ) {
	$bmc_show_new = true;
}
?>
<div class="bmc-wrap bmc-tickets" dir="rtl">
	<div class="bmc-tk-head">
		<div>
			<span class="bmc-kicker"><?php echo bmc_get_icon( 'support_agent', array( 'size' => 15 ) ); ?> پشتیبانی فروشگاه</span>
			<h2 class="bmc-title">تیکت‌های من</h2>
			<p class="bmc-hint">دربارهٔ محصولات خریداری‌شده، تحویل آیتم‌ها یا رنک خود تیکت بزنید؛ تیم پشتیبانی در همین گفت‌وگو پاسخ می‌دهد.</p>
		</div>

		<?php if ( $bmc_show_new ) : ?>
			<a class="bmc-btn bmc-btn--ghost" href="<?php echo esc_url( remove_query_arg( 'new', $bmc_self_url ) ); ?>">
				<?php echo bmc_get_icon( 'keyboard_arrow_right', array( 'size' => 17 ) ); ?> بازگشت به فهرست
			</a>
		<?php else : ?>
			<a class="bmc-btn" href="<?php echo esc_url( add_query_arg( 'new', '1', $bmc_self_url ) ); ?>#bmc-new-ticket">
				<?php echo bmc_get_icon( 'note_add', array( 'size' => 17 ) ); ?> ثبت تیکت جدید
			</a>
		<?php endif; ?>
	</div>

	<?php foreach ( BMC_Tickets::flash() as $bmc_notice ) : ?>
		<div class="bmc-notice <?php echo 'error' === $bmc_notice['type'] ? 'bmc-notice-warn' : 'bmc-notice-ok'; ?>">
			<?php echo bmc_get_icon( 'error' === $bmc_notice['type'] ? 'warning' : 'check_circle', array( 'size' => 17 ) ); ?>
			<span><?php echo esc_html( $bmc_notice['text'] ); ?></span>
		</div>
	<?php endforeach; ?>

	<div class="bmc-tk-stats">
		<a class="bmc-tk-stat <?php echo '' === $bmc_status_f ? 'is-active' : ''; ?>" href="<?php echo esc_url( remove_query_arg( 'status', $bmc_self_url ) ); ?>">
			<span class="bmc-tk-stat__value"><?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_counts['total'] ) ); ?></span>
			<span class="bmc-tk-stat__label">همهٔ تیکت‌ها</span>
		</a>

		<?php foreach ( BMC_Tickets::statuses() as $bmc_key => $bmc_meta ) : ?>
			<a class="bmc-tk-stat <?php echo $bmc_status_f === $bmc_key ? 'is-active' : ''; ?>" href="<?php echo esc_url( add_query_arg( 'status', $bmc_key, $bmc_self_url ) ); ?>">
				<span class="bmc-tk-stat__value"><?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_counts[ $bmc_key ] ) ); ?></span>
				<span class="bmc-tk-stat__label"><?php echo bmc_get_icon( $bmc_meta['icon'], array( 'size' => 14 ) ); ?> <?php echo esc_html( $bmc_meta['label'] ); ?></span>
			</a>
		<?php endforeach; ?>
	</div>

	<?php if ( $bmc_show_new ) : ?>
		<form method="post" action="<?php echo esc_url( $bmc_self_url ); ?>" class="bmc-card bmc-tk-form" id="bmc-new-ticket">
			<?php wp_nonce_field( BMC_Tickets::NONCE, 'bmc_ticket_nonce' ); ?>
			<input type="hidden" name="bmc_ticket_action" value="create" />

			<h3 class="bmc-card__title"><?php echo bmc_get_icon( 'note_add', array( 'size' => 18 ) ); ?> ثبت تیکت جدید</h3>

			<div class="bmc-field">
				<label class="bmc-label" for="bmc-ticket-subject">موضوع تیکت</label>
				<input class="bmc-input" type="text" id="bmc-ticket-subject" name="ticket_subject" maxlength="150" required
					placeholder="مثلاً: رنک VIP بعد از خرید فعال نشد" />
			</div>

			<div class="bmc-field-row">
				<div class="bmc-field">
					<label class="bmc-label" for="bmc-ticket-category">دستهٔ درخواست</label>
					<select class="bmc-input" id="bmc-ticket-category" name="ticket_category">
						<?php foreach ( $bmc_categories as $bmc_key => $bmc_meta ) : ?>
							<option value="<?php echo esc_attr( $bmc_key ); ?>"><?php echo esc_html( $bmc_meta['label'] ); ?></option>
						<?php endforeach; ?>
					</select>
				</div>

				<div class="bmc-field">
					<label class="bmc-label" for="bmc-ticket-product">محصول<?php echo BMC_Settings::bool( 'tickets_require_product', false ) ? ' (الزامی)' : ''; ?></label>
					<select class="bmc-input" id="bmc-ticket-product" name="ticket_product"
						<?php echo BMC_Settings::bool( 'tickets_require_product', false ) ? 'required' : ''; ?>>
						<?php foreach ( $bmc_products as $bmc_pid => $bmc_label ) : ?>
							<option value="<?php echo esc_attr( $bmc_pid ); ?>"><?php echo esc_html( $bmc_label ); ?></option>
						<?php endforeach; ?>
					</select>
					<span class="bmc-hint">فقط محصولاتی که خریده‌اید در این فهرست هستند.</span>
				</div>
			</div>

			<div class="bmc-field">
				<label class="bmc-label" for="bmc-ticket-body">شرح درخواست</label>
				<textarea class="bmc-input" id="bmc-ticket-body" name="ticket_body" rows="6" required
					placeholder="توضیح دهید چه اتفاقی افتاده، نام کاربری ماینکرافت و شمارهٔ سفارش را هم بنویسید…"></textarea>
			</div>

			<div class="bmc-tk-form__foot">
				<span class="bmc-hint"><?php echo bmc_get_icon( 'info', array( 'size' => 14 ) ); ?> پس از ثبت، کد پیگیری دریافت می‌کنید و پاسخ‌ها در همین صفحه نمایش داده می‌شوند.</span>
				<button type="submit" class="bmc-btn"><?php echo bmc_get_icon( 'send', array( 'size' => 17 ) ); ?> ثبت تیکت</button>
			</div>
		</form>
	<?php endif; ?>

	<?php if ( empty( $bmc_result['items'] ) ) : ?>
		<div class="bmc-card bmc-empty">
			<span class="bmc-empty-icon"><?php echo bmc_get_icon( 'inbox', array( 'size' => 38 ) ); ?></span>
			<p>هنوز تیکتی ثبت نکرده‌اید.</p>
			<?php if ( ! $bmc_show_new ) : ?>
				<a class="bmc-btn bmc-btn--sm" href="<?php echo esc_url( add_query_arg( 'new', '1', $bmc_self_url ) ); ?>#bmc-new-ticket">ثبت اولین تیکت</a>
			<?php endif; ?>
		</div>
	<?php else : ?>
		<div class="bmc-tk-list">
			<?php foreach ( $bmc_result['items'] as $bmc_row ) : ?>
				<?php $bmc_meta = BMC_Tickets::status_meta( $bmc_row->status ); ?>
				<a class="bmc-tk-item bmc-tk-item--<?php echo esc_attr( $bmc_meta['tone'] ); ?>" href="<?php echo esc_url( BMC_Tickets::url( (int) $bmc_row->id ) ); ?>">
					<span class="bmc-tk-item__icon"><?php echo bmc_get_icon( $bmc_meta['icon'], array( 'size' => 20 ) ); ?></span>

					<span class="bmc-tk-item__body">
						<span class="bmc-tk-item__title"><?php echo esc_html( $bmc_row->subject ); ?></span>
						<span class="bmc-tk-item__meta">
							<code><?php echo esc_html( BMC_Tickets::reference( $bmc_row->id ) ); ?></code>
							<span><?php echo esc_html( BMC_Tickets::category_label( $bmc_row->category ) ); ?></span>
							<?php $bmc_product_name = BMC_Tickets::ticket_product_name( $bmc_row ); ?>
							<?php if ( $bmc_product_name ) : ?>
								<span><?php echo bmc_get_icon( 'inventory_2', array( 'size' => 13 ) ); ?> <?php echo esc_html( $bmc_product_name ); ?></span>
							<?php endif; ?>
							<span><?php echo bmc_get_icon( 'chat', array( 'size' => 13 ) ); ?> <?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_row->replies ) ); ?> پیام</span>
							<span><?php echo bmc_get_icon( 'schedule', array( 'size' => 13 ) ); ?> <?php echo esc_html( BMC_Jalali::format( $bmc_row->updated_at ) ); ?></span>
						</span>
					</span>

					<span class="bmc-tk-item__status">
						<span class="bmc-pill"><?php echo esc_html( $bmc_meta['label'] ); ?></span>
						<?php if ( 'staff' === $bmc_row->last_reply_by && 'closed' !== $bmc_row->status ) : ?>
							<span class="bmc-tag bmc-tag-ok">پاسخ جدید</span>
						<?php endif; ?>
					</span>
				</a>
			<?php endforeach; ?>
		</div>

		<?php if ( $bmc_result['pages'] > 1 ) : ?>
			<div class="bmc-tk-pager">
				<?php for ( $bmc_i = 1; $bmc_i <= $bmc_result['pages']; $bmc_i++ ) : ?>
					<a class="<?php echo $bmc_i === (int) $bmc_result['page'] ? 'is-active' : ''; ?>"
						href="<?php echo esc_url( add_query_arg( 'paged', $bmc_i, $bmc_self_url ) ); ?>">
						<?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_i ) ); ?>
					</a>
				<?php endfor; ?>
			</div>
		<?php endif; ?>
	<?php endif; ?>
</div>
