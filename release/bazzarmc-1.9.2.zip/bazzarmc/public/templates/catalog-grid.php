<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_items   = is_array( $bmc_items ) ? $bmc_items : array();
$bmc_total   = (int) $bmc_total;
$bmc_pages   = (int) $bmc_pages;
$bmc_page    = max( 1, (int) $bmc_state['page'] );
$bmc_base    = (string) BMC_Catalog::clean_url();
$bmc_count   = (string) BMC_Catalog::count_text( $bmc_cfg, count( $bmc_items ), $bmc_total );

$bmc_args = array();

if ( '' !== (string) $bmc_state['cat'] ) {
	$bmc_args['bmc_cat'] = (string) $bmc_state['cat'];
}

if ( '' !== (string) $bmc_state['s'] ) {
	$bmc_args['bmc_s'] = (string) $bmc_state['s'];
}

if ( '' !== (string) $bmc_state['sort'] ) {
	$bmc_args['bmc_sort'] = (string) $bmc_state['sort'];
}

$bmc_page_url = function ( $page ) use ( $bmc_base, $bmc_args ) {
	$page = max( 1, (int) $page );

	if ( 1 === $page ) {
		return (string) remove_query_arg( 'bmc_paged', $bmc_base );
	}

	return (string) add_query_arg( array_merge( $bmc_args, array( 'bmc_paged' => $page ) ), $bmc_base );
};
?>
<div class="bmc-shop__results">
	<?php if ( '' !== $bmc_count ) : ?>
		<div class="bmc-shop__count" data-bmc-count>
			<?php bmc_icon( 'inventory_2', array( 'size' => 15 ) ); ?>
			<span><?php echo esc_html( $bmc_count ); ?></span>
		</div>
	<?php endif; ?>

	<?php if ( $bmc_items ) : ?>
		<div class="bmc-shop__grid" data-bmc-grid="<?php echo esc_attr( $bmc_id ); ?>" style="<?php echo esc_attr( BMC_Catalog::grid_style( $bmc_cfg ) . BMC_Catalog::ratio_style( $bmc_cfg ) ); ?>">
			<?php foreach ( $bmc_items as $bmc_index => $bmc_product ) : ?>
				<?php echo BMC_Catalog::render_card( $bmc_product, $bmc_cfg, array( 'index' => $bmc_index, 'id' => $bmc_id ) ); // phpcs:ignore WordPress.Security.EscapeOutput ?>
			<?php endforeach; ?>
		</div>
	<?php else : ?>
		<div class="bmc-shop__empty">
			<?php bmc_icon( 'search', array( 'size' => 30 ) ); ?>
			<p><?php echo esc_html( (string) $bmc_cfg['shop_empty_text'] ); ?></p>
		</div>
	<?php endif; ?>

	<?php if ( $bmc_pages > 1 && 'none' !== $bmc_cfg['shop_pagination'] ) : ?>
		<?php if ( 'numbers' === $bmc_cfg['shop_pagination'] ) : ?>
			<nav class="bmc-shop__pages" data-bmc-pages aria-label="صفحه‌بندی محصولات">
				<?php if ( $bmc_page > 1 ) : ?>
					<a class="bmc-shop__page bmc-shop__page--nav" href="<?php echo esc_url( $bmc_page_url( $bmc_page - 1 ) ); ?>" data-bmc-page-link="<?php echo esc_attr( $bmc_page - 1 ); ?>">
						<?php bmc_icon( 'keyboard_arrow_right', array( 'size' => 18 ) ); ?>
					</a>
				<?php endif; ?>

				<?php
				$bmc_links = (array) paginate_links(
					array(
						'base'      => $bmc_base . ( false === strpos( $bmc_base, '?' ) ? '?' : '&' ) . ( $bmc_args ? http_build_query( $bmc_args ) . '&' : '' ) . 'bmc_paged=%#%',
						'format'    => '',
						'current'   => $bmc_page,
						'total'     => $bmc_pages,
						'type'      => 'array',
						'prev_next' => false,
						'add_args'  => false,
					)
				);

				foreach ( $bmc_links as $bmc_link ) :
					?>
					<span class="bmc-shop__page-wrap"><?php echo wp_kses_post( $bmc_link ); ?></span>
				<?php endforeach; ?>

				<?php if ( $bmc_page < $bmc_pages ) : ?>
					<a class="bmc-shop__page bmc-shop__page--nav" href="<?php echo esc_url( $bmc_page_url( $bmc_page + 1 ) ); ?>" data-bmc-page-link="<?php echo esc_attr( $bmc_page + 1 ); ?>">
						<?php bmc_icon( 'keyboard_arrow_left', array( 'size' => 18 ) ); ?>
					</a>
				<?php endif; ?>
			</nav>
		<?php elseif ( $bmc_page < $bmc_pages ) : ?>
			<div class="bmc-shop__more-wrap">
				<button type="button" class="bmc-btn bmc-btn-o bmc-shop__more" data-bmc-more="<?php echo esc_attr( $bmc_id ); ?>" data-bmc-page="<?php echo esc_attr( $bmc_page + 1 ); ?>">
					<?php bmc_icon( 'keyboard_arrow_down', array( 'size' => 18 ) ); ?>
					<span><?php echo esc_html( (string) $bmc_cfg['shop_load_more_text'] ); ?></span>
				</button>
			</div>
		<?php endif; ?>
	<?php endif; ?>
</div>
