<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_id_prod   = (int) $bmc_p->get_id();
$bmc_name      = (string) $bmc_p->get_name();
$bmc_cats      = (array) $bmc_data['categories'];
$bmc_sku       = (string) $bmc_p->get_sku();
$bmc_show_cart = BMC_Catalog::yesno( $bmc_cfg['qv_show_add_to_cart'] );
$bmc_single    = BMC_Catalog::single_enabled();

$bmc_cart_html = '';

if ( $bmc_show_cart && function_exists( 'woocommerce_template_single_add_to_cart' ) ) {
	ob_start();
	woocommerce_template_single_add_to_cart();
	$bmc_cart_html = (string) ob_get_clean();
}

$bmc_attrs_html = '';

if ( BMC_Catalog::yesno( $bmc_cfg['qv_show_attributes'] ) && function_exists( 'woocommerce_display_product_attributes' ) ) {
	ob_start();
	woocommerce_display_product_attributes( $bmc_p );
	$bmc_attrs_html = (string) ob_get_clean();
}

$bmc_desc = '';

if ( BMC_Catalog::yesno( $bmc_cfg['qv_show_description'] ) ) {
	$bmc_desc = trim( (string) $bmc_p->get_description() );
	$bmc_desc = '' !== $bmc_desc ? wp_kses_post( wpautop( $bmc_desc ) ) : '';
}

$bmc_short = '';

if ( BMC_Catalog::yesno( $bmc_cfg['qv_show_excerpt'] ) ) {
	$bmc_short = trim( (string) $bmc_p->get_short_description() );
	$bmc_short = '' !== $bmc_short ? wp_kses_post( wpautop( $bmc_short ) ) : '';
}
?>
<div class="bmc-qv__product" data-bmc-qv-product="<?php echo esc_attr( $bmc_id_prod ); ?>">
	<div class="bmc-qv__top">
		<?php if ( BMC_Catalog::yesno( $bmc_cfg['qv_show_image'] ) ) : ?>
			<div class="bmc-qv__media">
				<?php echo wp_kses_post( $bmc_p->get_image( 'woocommerce_single', array( 'class' => 'bmc-qv__img' ) ) ); ?>
				<?php if ( $bmc_data['on_sale'] ) : ?>
					<span class="bmc-pcard__badge bmc-pcard__badge--sale">
						<?php bmc_icon( 'percent', array( 'size' => 13 ) ); ?>
						<?php echo esc_html( trim( (string) $bmc_cfg['card_sale_badge_text'] ) . ( $bmc_data['sale_percent'] > 0 ? ' ' . BMC_Helpers::to_persian_digits( $bmc_data['sale_percent'] ) . '٪' : '' ) ); ?>
					</span>
				<?php endif; ?>
			</div>
		<?php endif; ?>

		<div class="bmc-qv__info">
			<?php if ( $bmc_data['category'] ) : ?>
				<span class="bmc-pcard__cat">
					<?php bmc_icon( 'category', array( 'size' => 13 ) ); ?>
					<?php echo esc_html( $bmc_data['category'] ); ?>
				</span>
			<?php endif; ?>

			<h3 class="bmc-qv__name"><?php echo esc_html( $bmc_name ); ?></h3>

			<?php if ( $bmc_data['rating'] > 0 ) : ?>
				<span class="bmc-pcard__rating">
					<?php bmc_icon( 'star', array( 'size' => 14 ) ); ?>
					<span><?php echo esc_html( BMC_Helpers::to_persian_digits( number_format_i18n( $bmc_data['rating'], 1 ) ) ); ?></span>
					<?php if ( $bmc_data['rating_count'] > 0 ) : ?>
						<span class="bmc-pcard__rating-count">(<?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_data['rating_count'] ) ); ?> رای)</span>
					<?php endif; ?>
				</span>
			<?php endif; ?>

			<?php if ( BMC_Catalog::yesno( $bmc_cfg['qv_show_price'] ) ) : ?>
				<div class="bmc-qv__price"><?php echo wp_kses_post( $bmc_p->get_price_html() ); ?></div>
			<?php endif; ?>

			<?php if ( $bmc_data['rank_label'] && BMC_Catalog::yesno( $bmc_cfg['qv_show_rank'] ) ) : ?>
				<div class="bmc-qv__rank">
					<?php bmc_icon( 'military_tech', array( 'size' => 16 ) ); ?>
					<span>رنک <?php echo esc_html( $bmc_data['rank_label'] ); ?><?php echo $bmc_data['rank_days'] > 0 ? ' — اعتبار ' . esc_html( BMC_Helpers::to_persian_digits( $bmc_data['rank_days'] ) ) . ' روز' : ''; ?></span>
				</div>
			<?php endif; ?>

			<?php if ( $bmc_short ) : ?>
				<div class="bmc-qv__excerpt"><?php echo $bmc_short; // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
			<?php endif; ?>

			<?php if ( BMC_Catalog::yesno( $bmc_cfg['qv_show_meta'] ) ) : ?>
				<ul class="bmc-qv__meta">
					<?php if ( $bmc_cats ) : ?>
						<li>
							<span class="bmc-qv__meta-key"><?php bmc_icon( 'sell', array( 'size' => 14 ) ); ?> دسته‌بندی‌ها</span>
							<span class="bmc-qv__meta-val"><?php echo esc_html( implode( '، ', $bmc_cats ) ); ?></span>
						</li>
					<?php endif; ?>

					<?php if ( '' !== $bmc_sku ) : ?>
						<li>
							<span class="bmc-qv__meta-key"><?php bmc_icon( 'qr_code_2', array( 'size' => 14 ) ); ?> شناسهٔ محصول</span>
							<span class="bmc-qv__meta-val" dir="ltr"><?php echo esc_html( $bmc_sku ); ?></span>
						</li>
					<?php endif; ?>

					<li>
						<span class="bmc-qv__meta-key"><?php bmc_icon( $bmc_data['in_stock'] ? 'check_circle' : 'cancel', array( 'size' => 14 ) ); ?> وضعیت موجودی</span>
						<span class="bmc-qv__meta-val"><?php echo esc_html( $bmc_data['stock_text'] ); ?></span>
					</li>

					<?php if ( ! $bmc_single ) : ?>
						<li>
							<span class="bmc-qv__meta-key"><?php bmc_icon( 'info', array( 'size' => 14 ) ); ?> صفحهٔ تکی محصول</span>
							<span class="bmc-qv__meta-val">غیرفعال — خرید از همین پنجره انجام می‌شود</span>
						</li>
					<?php endif; ?>
				</ul>
			<?php endif; ?>

			<?php if ( $bmc_data['blocked'] && $bmc_data['blocked_msg'] ) : ?>
				<div class="bmc-alert bmc-alert--warn"><?php bmc_icon( 'warning', array( 'size' => 16 ) ); ?> <?php echo esc_html( $bmc_data['blocked_msg'] ); ?></div>
			<?php endif; ?>

			<?php if ( $bmc_cart_html ) : ?>
				<div class="bmc-qv__buy"><?php echo $bmc_cart_html; // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
			<?php endif; ?>

			<?php if ( $bmc_single && BMC_Catalog::yesno( $bmc_cfg['qv_show_single_link'] ) ) : ?>
				<a class="bmc-btn bmc-btn-g bmc-btn--sm bmc-qv__single" href="<?php echo esc_url( (string) get_permalink( $bmc_id_prod ) ); ?>">
					<?php bmc_icon( 'open_in_new', array( 'size' => 15 ) ); ?>
					<span><?php echo esc_html( (string) $bmc_cfg['qv_single_link_text'] ); ?></span>
				</a>
			<?php endif; ?>
		</div>
	</div>

	<?php if ( $bmc_desc ) : ?>
		<div class="bmc-qv__section">
			<h4 class="bmc-qv__section-title">
				<?php bmc_icon( 'description', array( 'size' => 16 ) ); ?>
				<span>توضیحات محصول</span>
			</h4>
			<div class="bmc-qv__desc"><?php echo $bmc_desc; // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
		</div>
	<?php endif; ?>

	<?php if ( $bmc_attrs_html ) : ?>
		<div class="bmc-qv__section">
			<h4 class="bmc-qv__section-title">
				<?php bmc_icon( 'list_alt', array( 'size' => 16 ) ); ?>
				<span>ویژگی‌ها</span>
			</h4>
			<div class="bmc-qv__attrs bmc-table"><?php echo $bmc_attrs_html; // phpcs:ignore WordPress.Security.EscapeOutput ?></div>
		</div>
	<?php endif; ?>
</div>
