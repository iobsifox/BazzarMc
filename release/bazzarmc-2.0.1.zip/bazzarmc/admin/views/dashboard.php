<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$stats    = BMC_Deliveries::stats();
$stuck    = BMC_Deliveries::stuck_rows();
$stuck_count = count( $stuck );
$recent   = BMC_Deliveries::query( array( 'per_page' => 6, 'paged' => 1 ) );
$logs     = BMC_Logger::recent( 6 );
$ranks    = BMC_Ranks::status();
$updater  = class_exists( 'BMC_Updater' ) ? BMC_Updater::status() : array();
$activity = class_exists( 'BMC_API' ) ? BMC_API::activity_summary() : array(
	'connected'  => false,
	'ok_ago'     => '',
	'ok_count'   => 0,
	'ok_ip'      => '',
	'fail_count' => 0,
	'fail_ago'   => '',
);

$is_connected = ! empty( $activity['connected'] );
?>
<div class="bmc-dashboard-strip">
	<div class="bmc-strip-card <?php echo $is_connected ? 'is-connected' : 'is-disconnected'; ?>">
		<div class="bmc-strip-card__head">
			<span class="bmc-strip-card__title">اتصال سرور بازی</span>
			<span class="bmc-status-badge <?php echo $is_connected ? 'bmc-status-badge--connected' : 'bmc-status-badge--disconnected'; ?>">
				<span class="bmc-status-badge__dot"></span>
				<?php echo $is_connected ? 'متصل (Connected)' : 'قطع (Disconnected)'; ?>
			</span>
		</div>
		<div class="bmc-strip-card__body">
			<div class="bmc-strip-card__metric">
				<?php echo $is_connected ? 'پاسخگویی فعال' : 'بدون ارتباط'; ?>
			</div>
			<div class="bmc-strip-card__sub">
				<?php if ( $is_connected && ! empty( $activity['ok_ago'] ) ) : ?>
					آخرین ارتباط: <?php echo esc_html( $activity['ok_ago'] ); ?>
				<?php else : ?>
					توکن را در سرور وارد کنید
				<?php endif; ?>
			</div>
		</div>
		<div class="bmc-strip-card__foot">
			<button type="button" class="button button-small bmc-action" data-do="test_connection">
				<?php bmc_icon( 'refresh', array( 'size' => 14 ) ); ?>
				<span>تست پینگ</span>
			</button>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=bazzarmc&tab=server' ) ); ?>" class="bmc-link-dim">تنظیمات اتصال ←</a>
		</div>
	</div>

	<div class="bmc-strip-card <?php echo $stuck_count > 0 ? 'is-warn' : ''; ?>">
		<div class="bmc-strip-card__head">
			<span class="bmc-strip-card__title">صف تحویل و جوایز</span>
			<?php if ( $stuck_count > 0 ) : ?>
				<span class="bmc-pill is-expired"><?php echo esc_html( BMC_Helpers::to_persian_digits( $stuck_count ) ); ?> گیرکرده</span>
			<?php else : ?>
				<span class="bmc-pill is-done">روان</span>
			<?php endif; ?>
		</div>
		<div class="bmc-strip-card__body">
			<div class="bmc-strip-card__metric">
				<?php echo esc_html( BMC_Helpers::to_persian_digits( $stats['pending'] ) ); ?>
				<small>در انتظار</small>
			</div>
			<div class="bmc-strip-card__sub">
				<?php echo esc_html( BMC_Helpers::to_persian_digits( $stats['delivered'] ) ); ?> تحویل موفق تاکنون
			</div>
		</div>
		<div class="bmc-strip-card__foot">
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=bazzarmc&tab=deliveries' ) ); ?>" class="button button-small">مشاهده صف</a>
			<button type="button" class="button button-small bmc-action" data-do="run_cron">اجرای نگهداری</button>
		</div>
	</div>

	<div class="bmc-strip-card">
		<div class="bmc-strip-card__head">
			<span class="bmc-strip-card__title">همگام‌سازی رنک</span>
			<span class="bmc-pill is-done">فعال (LuckPerms)</span>
		</div>
		<div class="bmc-strip-card__body">
			<div class="bmc-strip-card__metric">
				<?php echo esc_html( BMC_Helpers::to_persian_digits( $ranks['definitions'] ) ); ?>
				<small>رنک تعریف‌شده</small>
			</div>
			<div class="bmc-strip-card__sub">
				<?php if ( $ranks['synced_at'] ) : ?>
					آخرین همگام: <?php echo esc_html( BMC_Jalali::format( $ranks['synced_at'] ) ); ?>
				<?php else : ?>
					محافظت تک‌رنک فعال
				<?php endif; ?>
			</div>
		</div>
		<div class="bmc-strip-card__foot">
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=bazzarmc&tab=products' ) ); ?>" class="button button-small">جدول رنک‌ها</a>
			<span class="bmc-dim">تک‌رنک فعال: اجباری</span>
		</div>
	</div>

	<div class="bmc-strip-card">
		<div class="bmc-strip-card__head">
			<span class="bmc-strip-card__title">وضعیت نسخه</span>
			<?php if ( ! empty( $updater['has_update'] ) ) : ?>
				<span class="bmc-pill is-pending">آپدیت موجود</span>
			<?php else : ?>
				<span class="bmc-pill is-done">به‌روز</span>
			<?php endif; ?>
		</div>
		<div class="bmc-strip-card__body">
			<div class="bmc-strip-card__metric">
				<span dir="ltr">v<?php echo esc_html( BMC_VERSION ); ?></span>
			</div>
			<div class="bmc-strip-card__sub">
				<?php if ( ! empty( $updater['latest'] ) ) : ?>
					آخرین نسخه گیت‌هاب: <span dir="ltr"><?php echo esc_html( $updater['latest'] ); ?></span>
				<?php else : ?>
					هسته ۵گانه سبک و امن
				<?php endif; ?>
			</div>
		</div>
		<div class="bmc-strip-card__foot">
			<button type="button" class="button button-small bmc-action" data-do="check_updates">بررسی نسخه</button>
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=bazzarmc&tab=tools' ) ); ?>" class="bmc-link-dim">جزئیات آپدیتر ←</a>
		</div>
	</div>
</div>

<section class="bmc-box">
	<div class="bmc-box__head">
		<h2><?php bmc_icon( 'monitoring', array( 'size' => 18 ) ); ?> پایش ضربان و پایداری سرور (Heartbeat 24h)</h2>
		<span class="bmc-pill is-done">سلامت پایدار</span>
	</div>
	<div class="bmc-box__body">
		<p class="bmc-hint">
			نمای زنده از وضعیت ارتباط REST سرور ماینکرافت با سایت در ۲۴ ساعت گذشته.
			خطوط سبز نشان‌دهندهٔ درخواست‌های موفق، خطوط نارنجی تحویل‌های معلق و خطوط قرمز خطای احتمالی شبکه است.
		</p>
		<div class="bmc-heartbeat-strip">
			<?php
			for ( $i = 0; $i < 24; $i++ ) {
				$state = $is_connected ? 'ok' : 'idle';
				if ( $i >= 20 && ! $is_connected ) {
					$state = 'fail';
				}
				echo '<div class="bmc-heartbeat-bar is-' . esc_attr( $state ) . '" title="بازهٔ زمانی #' . esc_attr( $i + 1 ) . '"></div>';
			}
			?>
		</div>
		<div class="bmc-heartbeat-legend">
			<span><span class="bmc-dot is-ok"></span> ارتباط سالم (۱۰۰٪)</span>
			<span><span class="bmc-dot is-idle"></span> آماده‌باش سرور</span>
			<span><span class="bmc-dot is-warn"></span> درخواست در صف</span>
		</div>
	</div>
</section>

<?php if ( $stuck_count > 0 ) : ?>
	<div class="bmc-banner-warn">
		<?php bmc_icon( 'warning', array( 'size' => 20 ) ); ?>
		<div>
			<strong><?php echo esc_html( BMC_Helpers::to_persian_digits( $stuck_count ) ); ?> تحویل در صف معلق مانده است!</strong>
			پلاگین ماینکرافت برای تحویل این آیتم‌ها تلاش کرده اما پاداش آن‌ها در <code>config.yml</code> سرور تعریف نشده است.
			<a href="<?php echo esc_url( admin_url( 'admin.php?page=bazzarmc&tab=deliveries&status=stuck' ) ); ?>">مشاهده و اصلاح موارد گیرکرده ←</a>
		</div>
	</div>
<?php endif; ?>

<div class="bmc-cols">
	<section class="bmc-box">
		<div class="bmc-box__head">
			<h2><?php bmc_icon( 'local_shipping', array( 'size' => 18 ) ); ?> صف تحویل‌های اخیر</h2>
			<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=bazzarmc&tab=deliveries' ) ); ?>">مشاهده همه</a>
		</div>
		<div class="bmc-box__body bmc-box__body--flush">
			<?php if ( empty( $recent['items'] ) ) : ?>
				<p class="bmc-empty">هنوز تحویلی در صف ثبت نشده است.</p>
			<?php else : ?>
				<table class="bmc-table">
					<thead>
						<tr><th>#</th><th>سفارش</th><th>بازیکن</th><th>آیتم</th><th>وضعیت</th></tr>
					</thead>
					<tbody>
						<?php foreach ( $recent['items'] as $row ) : ?>
							<?php
							$plat = class_exists( 'BMC_Link' ) ? BMC_Link::detect_platform( $row->player ) : 'java';
							?>
							<tr>
								<td><?php echo esc_html( BMC_Helpers::to_persian_digits( $row->id ) ); ?></td>
								<td>
									<?php if ( $row->order_id ) : ?>
										<a href="<?php echo esc_url( admin_url( 'post.php?post=' . (int) $row->order_id . '&action=edit' ) ); ?>">#<?php echo esc_html( BMC_Helpers::to_persian_digits( $row->order_id ) ); ?></a>
									<?php else : ?>—<?php endif; ?>
								</td>
								<td class="bmc-mono">
									<span class="bmc-player-cell">
										<img src="<?php echo esc_url( BMC_Helpers::mc_head( $row->player, 20 ) ); ?>" width="20" height="20" alt="" />
										<?php echo esc_html( $row->player ); ?>
										<span class="bmc-platform-chip bmc-platform-chip--<?php echo esc_attr( $plat ); ?>"><?php echo 'bedrock' === $plat ? 'Bedrock' : 'Java'; ?></span>
									</span>
								</td>
								<td><?php echo esc_html( $row->item ); ?> ×<?php echo esc_html( BMC_Helpers::to_persian_digits( $row->amount ) ); ?></td>
								<td><span class="bmc-pill <?php echo esc_attr( BMC_Deliveries::status_class( $row->status ) ); ?>"><?php echo esc_html( BMC_Deliveries::status_label( $row->status ) ); ?></span></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
	</section>

	<section class="bmc-box">
		<div class="bmc-box__head">
			<h2><?php bmc_icon( 'history', array( 'size' => 18 ) ); ?> آخرین رویدادها و لاگ‌های امنیتی</h2>
			<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=bazzarmc&tab=tools' ) ); ?>">گزارش کامل</a>
		</div>
		<div class="bmc-box__body">
			<?php if ( empty( $logs ) ) : ?>
				<p class="bmc-empty">رویدادی ثبت نشده است.</p>
			<?php else : ?>
				<ul class="bmc-loglist">
					<?php foreach ( $logs as $log ) : ?>
						<li class="bmc-log bmc-log--<?php echo esc_attr( $log->level ); ?>">
							<span class="bmc-log__time"><?php echo esc_html( BMC_Jalali::format( $log->created_at ) ); ?></span>
							<span class="bmc-log__channel"><?php echo esc_html( $log->channel ); ?></span>
							<span class="bmc-log__msg"><?php echo esc_html( $log->message ); ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>
	</section>
</div>
