<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$view_mode     = isset( $_GET['view'] ) && 'history' === $_GET['view'] ? 'history' : 'queue';
$filter_status = isset( $_GET['status'] ) ? sanitize_text_field( wp_unslash( $_GET['status'] ) ) : '';
$filter_search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
$filter_order  = isset( $_GET['order_id'] ) ? (int) $_GET['order_id'] : 0;
$paged         = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;

if ( 'history' === $view_mode && '' === $filter_status ) {
	$query_status = (string) BMC_Deliveries::STATUS_DELIVERED;
} elseif ( 'queue' === $view_mode && '' === $filter_status ) {
	$query_status = (string) BMC_Deliveries::STATUS_PENDING;
} else {
	$query_status = $filter_status;
}

$result = BMC_Deliveries::query(
	array(
		'status'   => $query_status,
		'search'   => $filter_search,
		'order_id' => $filter_order,
		'paged'    => $paged,
		'per_page' => 20,
	)
);

$stats       = BMC_Deliveries::stats();
$stuck       = BMC_Deliveries::stuck_rows();
$stuck_count = count( $stuck );

$base_url = admin_url( 'admin.php?page=bazzarmc&tab=deliveries' );
?>

<div class="bmc-deliveries-header">
	<div class="bmc-view-toggle" role="tablist">
		<a href="<?php echo esc_url( add_query_arg( 'view', 'queue', $base_url ) ); ?>" class="bmc-view-toggle__btn <?php echo 'queue' === $view_mode ? 'is-active' : ''; ?>">
			<?php bmc_icon( 'pending_actions', array( 'size' => 16 ) ); ?>
			<span>صف تحویل جاری (Queue)</span>
			<span class="bmc-counter"><?php echo esc_html( BMC_Helpers::to_persian_digits( $stats['pending'] ) ); ?></span>
		</a>
		<a href="<?php echo esc_url( add_query_arg( 'view', 'history', $base_url ) ); ?>" class="bmc-view-toggle__btn <?php echo 'history' === $view_mode ? 'is-active' : ''; ?>">
			<?php bmc_icon( 'history', array( 'size' => 16 ) ); ?>
			<span>تاریخچه تحویل‌های تکمیل‌شده (History)</span>
			<span class="bmc-counter"><?php echo esc_html( BMC_Helpers::to_persian_digits( $stats['delivered'] ) ); ?></span>
		</a>
	</div>

	<div class="bmc-inline">
		<button type="button" class="button button-primary" id="bmcOpenGrantModal">
			<?php bmc_icon( 'card_giftcard', array( 'size' => 16 ) ); ?>
			<span>+ اعطای دستی پاداش (New Grant)</span>
		</button>
		<a class="button" href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'bmc_export', '1', $base_url ), 'bmc_export', 'bmc_nonce' ) ); ?>">
			<?php bmc_icon( 'file_download', array( 'size' => 15 ) ); ?>
			<span>خروجی CSV</span>
		</a>
		<button type="button" class="button bmc-action" data-do="run_cron">
			<?php bmc_icon( 'refresh', array( 'size' => 15 ) ); ?>
			<span>نگهداری صف</span>
		</button>
	</div>
</div>

<?php if ( 'queue' === $view_mode && $stuck_count > 0 ) : ?>
	<div class="bmc-banner-warn">
		<?php bmc_icon( 'error', array( 'size' => 20 ) ); ?>
		<div>
			<strong><?php echo esc_html( BMC_Helpers::to_persian_digits( $stuck_count ) ); ?> تحویل در صف گیر کرده است!</strong>
			پلاگین ماینکرافت تلاش کرده ولی پاداشی برای کلید محصول در <code>config.yml</code> پیدا نشده است.
			برای رفع: کلید پیشنهادی در ستون «گزارش» را در بخش <code>products</code> فایل <code>config.yml</code> تعریف کرده و در کنسول دستور <code dir="ltr">bmc reload</code> را بزنید.
		</div>
	</div>
<?php endif; ?>

<section class="bmc-box">
	<div class="bmc-box__head">
		<div class="bmc-inline">
			<h2>
				<?php echo 'history' === $view_mode ? bmc_get_icon( 'inventory_2', array( 'size' => 18 ) ) . ' تاریخچه تحویل‌های موفق' : bmc_get_icon( 'local_shipping', array( 'size' => 18 ) ) . ' صف خریدهای در انتظار تحویل'; ?>
			</h2>
			<span class="bmc-pill <?php echo 'history' === $view_mode ? 'is-done' : 'is-pending'; ?>">
				<?php echo 'history' === $view_mode ? esc_html( BMC_Helpers::to_persian_digits( $stats['delivered'] ) ) . ' تحویل‌شده' : esc_html( BMC_Helpers::to_persian_digits( $stats['pending'] ) ) . ' در انتظار'; ?>
			</span>
		</div>

		<form method="get" class="bmc-toolbar bmc-toolbar--compact">
			<input type="hidden" name="page" value="bazzarmc" />
			<input type="hidden" name="tab" value="deliveries" />
			<input type="hidden" name="view" value="<?php echo esc_attr( $view_mode ); ?>" />
			<input type="search" class="bmc-input bmc-input--sm" name="s" value="<?php echo esc_attr( $filter_search ); ?>" placeholder="جست‌وجوی بازیکن یا کد خرید…" />
			<input type="number" class="bmc-input bmc-input--sm" name="order_id" value="<?php echo esc_attr( $filter_order ? $filter_order : '' ); ?>" placeholder="شماره سفارش" style="max-width:110px" />
			<button type="submit" class="button button-small">فیلتر</button>
		</form>
	</div>

	<div class="bmc-box__body bmc-box__body--flush">
		<?php if ( empty( $result['items'] ) ) : ?>
			<p class="bmc-empty">موردی در این بخش یافت نشد.</p>
		<?php else : ?>
			<table class="bmc-table bmc-table--full">
				<thead>
					<tr>
						<th>#</th>
						<th>سفارش</th>
						<th>بازیکن و پلتفرم</th>
						<th>پاداش / آیتم</th>
						<th>تعداد</th>
						<th>کد خرید</th>
						<th>منبع</th>
						<th>تاریخ ثبت</th>
						<th>گزارش سرور</th>
						<th>عملیات</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $result['items'] as $row ) : ?>
						<?php
						$plat = class_exists( 'BMC_Link' ) ? BMC_Link::detect_platform( $row->player ) : 'java';
						$is_manual = empty( $row->order_id );
						?>
						<tr data-id="<?php echo esc_attr( $row->id ); ?>">
							<td><?php echo esc_html( BMC_Helpers::to_persian_digits( $row->id ) ); ?></td>
							<td>
								<?php if ( $row->order_id ) : ?>
									<a href="<?php echo esc_url( admin_url( 'post.php?post=' . (int) $row->order_id . '&action=edit' ) ); ?>" class="bmc-link-order">
										#<?php echo esc_html( BMC_Helpers::to_persian_digits( $row->order_id ) ); ?>
									</a>
								<?php else : ?>
									<span class="bmc-dim">دستی</span>
								<?php endif; ?>
							</td>
							<td class="bmc-mono">
								<span class="bmc-player-cell">
									<img src="<?php echo esc_url( BMC_Helpers::mc_head( $row->player, 22 ) ); ?>" width="22" height="22" alt="" />
									<strong><?php echo esc_html( $row->player ); ?></strong>
									<span class="bmc-platform-chip bmc-platform-chip--<?php echo esc_attr( $plat ); ?>"><?php echo 'bedrock' === $plat ? 'Bedrock' : 'Java'; ?></span>
								</span>
							</td>
							<td>
								<strong><?php echo esc_html( $row->item ); ?></strong>
								<?php if ( $row->product_id ) : ?>
									<small class="bmc-dim">(ID: <?php echo esc_html( BMC_Helpers::to_persian_digits( $row->product_id ) ); ?>)</small>
								<?php endif; ?>
							</td>
							<td><?php echo esc_html( BMC_Helpers::to_persian_digits( $row->amount ) ); ?></td>
							<td class="bmc-mono"><code class="bmc-code-pill"><?php echo esc_html( $row->code ); ?></code></td>
							<td>
								<span class="bmc-pill <?php echo $is_manual ? 'is-info' : 'is-done'; ?>">
									<?php echo $is_manual ? 'اعطای دستی' : 'خرید فروشگاه'; ?>
								</span>
							</td>
							<td class="bmc-dim"><?php echo esc_html( BMC_Jalali::format( $row->created_at ) ); ?></td>
							<td class="bmc-report-cell">
								<?php $attempts = isset( $row->attempts ) ? (int) $row->attempts : 0; ?>
								<?php if ( ! empty( $row->note ) ) : ?>
									<span class="bmc-report <?php echo (int) $row->status === BMC_Deliveries::STATUS_DELIVERED ? 'is-ok' : 'is-warn'; ?>">
										<?php echo esc_html( $row->note ); ?>
									</span>
								<?php elseif ( (int) $row->status === BMC_Deliveries::STATUS_PENDING ) : ?>
									<span class="bmc-dim">کلید: <code dir="ltr"><?php echo esc_html( $row->delivery_key ? $row->delivery_key : $row->item ); ?></code></span>
								<?php else : ?>
									<span class="bmc-dim">—</span>
								<?php endif; ?>
								<?php if ( $attempts > 0 || ! empty( $row->last_attempt_at ) ) : ?>
									<small class="bmc-dim">
										تلاش: <?php echo esc_html( BMC_Helpers::to_persian_digits( $attempts ) ); ?>
										<?php if ( ! empty( $row->last_attempt_at ) ) : ?>
											— <?php echo esc_html( BMC_Jalali::format( $row->last_attempt_at ) ); ?>
										<?php endif; ?>
									</small>
								<?php endif; ?>
							</td>
							<td>
								<div class="bmc-row-actions">
									<?php if ( (int) $row->status !== BMC_Deliveries::STATUS_DELIVERED ) : ?>
										<button type="button" class="button button-small bmc-delivery-action" data-do="delivered" data-id="<?php echo esc_attr( $row->id ); ?>">تحویل شد</button>
									<?php else : ?>
										<button type="button" class="button button-small bmc-delivery-action" data-do="pending" data-id="<?php echo esc_attr( $row->id ); ?>">بازگشت به صف</button>
									<?php endif; ?>
									<?php if ( isset( $row->attempts ) && (int) $row->attempts > 0 ) : ?>
										<button type="button" class="button button-small bmc-delivery-action" data-do="clear_report" data-id="<?php echo esc_attr( $row->id ); ?>">پاک‌کردن گزارش</button>
									<?php endif; ?>
									<button type="button" class="button button-small button-link-delete bmc-delivery-action" data-do="delete" data-id="<?php echo esc_attr( $row->id ); ?>">حذف</button>
								</div>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<?php if ( $result['pages'] > 1 ) : ?>
				<div class="bmc-pagination">
					<?php
					echo wp_kses_post(
						paginate_links(
							array(
								'base'      => add_query_arg( 'paged', '%#%' ),
								'format'    => '',
								'current'   => $result['paged'],
								'total'     => $result['pages'],
								'prev_text' => '→',
								'next_text' => '←',
							)
						)
					);
					?>
				</div>
			<?php endif; ?>
		<?php endif; ?>
	</div>
</section>

<section class="bmc-box">
	<div class="bmc-box__head">
		<h2><?php bmc_icon( 'inventory', array( 'size' => 18 ) ); ?> پیکربندی صندوق جوایز و کریت‌ها (Reward Chests)</h2>
	</div>
	<div class="bmc-box__body">
		<p class="bmc-hint">
			نمونه‌های آماده برای تعریف صندوق پاداش روزانه، پاداش رأی‌دهی و باندل‌های خوش‌آمدگویی در فایل <code>config.yml</code> سرور ماینکرافت.
			بازیکنان می‌توانند با دستور <code dir="ltr">/mclink gui</code> در محیط بازی جوایز خود را دریافت کنند.
		</p>

		<div class="bmc-chest-cards-grid">
			<div class="bmc-chest-card">
				<div class="bmc-chest-card__head">
					<strong><?php bmc_icon( 'inventory_2', array( 'size' => 16 ) ); ?> صندوق رأی‌دهی (Vote Chest)</strong>
					<span class="bmc-pill is-done">آماده</span>
				</div>
				<div class="bmc-chest-card__body">
					<div class="bmc-prob-bar">
						<span style="width:50%;background:#3b82f6" title="الماس: ۵۰٪"></span>
						<span style="width:30%;background:#10b981" title="پول: ۳۰٪"></span>
						<span style="width:20%;background:#f59e0b" title="کلید طلایی: ۲۰٪"></span>
					</div>
					<small class="bmc-dim">اقلام: الماس (۵۰٪)، ۵۰۰۰ سکه (۳۰٪)، کلید کریت (۲۰٪)</small>
				</div>
			</div>

			<div class="bmc-chest-card">
				<div class="bmc-chest-card__head">
					<strong><?php bmc_icon( 'card_giftcard', array( 'size' => 16 ) ); ?> پاداش اولین خرید (First Purchase Bonus)</strong>
					<span class="bmc-pill is-done">آماده</span>
				</div>
				<div class="bmc-chest-card__body">
					<div class="bmc-prob-bar">
						<span style="width:70%;background:#8b5cf6" title="کیت آغازین: ۷۰٪"></span>
						<span style="width:30%;background:#ec4899" title="رنک موقت: ۳۰٪"></span>
					</div>
					<small class="bmc-dim">اقلام: کیت Rookie (۷۰٪)، رنک ۳ روزه VIP (۳۰٪)</small>
				</div>
			</div>
		</div>
	</div>
</section>

<div class="bmc-modal" id="bmcGrantModal" style="display:none">
	<div class="bmc-modal__backdrop"></div>
	<div class="bmc-modal__dialog">
		<div class="bmc-modal__head">
			<h3><?php bmc_icon( 'card_giftcard', array( 'size' => 18 ) ); ?> اعطای دستی پاداش به بازیکن (Manual Grant)</h3>
			<button type="button" class="bmc-modal__close" id="bmcCloseGrantModal">&times;</button>
		</div>
		<div class="bmc-modal__body">
			<form id="bmcGrantForm">
				<div class="bmc-row">
					<div class="bmc-row__label">
						<label>نام بازیکن ماینکرافت *</label>
						<span class="bmc-row__hint">نام کاربری دقیق بازیکن در سرور</span>
					</div>
					<div class="bmc-row__field">
						<input type="text" class="bmc-input" name="grant_player" id="bmcGrantPlayer" dir="ltr" placeholder="Notch" required />
					</div>
				</div>

				<div class="bmc-row">
					<div class="bmc-row__label">
						<label>شناسه یا نام پاداش (Item / Key) *</label>
						<span class="bmc-row__hint">کلید تعریف‌شده در config.yml یا نام محصول</span>
					</div>
					<div class="bmc-row__field">
						<input type="text" class="bmc-input" name="grant_item" id="bmcGrantItem" dir="ltr" placeholder="diamond_pack_1 یا vip" required />
					</div>
				</div>

				<div class="bmc-row">
					<div class="bmc-row__label">
						<label>تعداد</label>
					</div>
					<div class="bmc-row__field">
						<input type="number" class="bmc-input bmc-input--sm" name="grant_amount" id="bmcGrantAmount" min="1" max="9999" value="1" />
					</div>
				</div>

				<div class="bmc-row">
					<div class="bmc-row__label">
						<label>دلیل و یادداشت</label>
						<span class="bmc-row__hint">در گزارش‌ها و لاگ مدیر ثبت می‌شود</span>
					</div>
					<div class="bmc-row__field">
						<input type="text" class="bmc-input" name="grant_note" id="bmcGrantNote" placeholder="جایزه مسابقه / دلجویی پشتیبانی" />
					</div>
				</div>

				<div class="bmc-row">
					<div class="bmc-row__label">
						<label>زمان تحویل</label>
					</div>
					<div class="bmc-row__field">
						<label class="bmc-radio"><input type="radio" name="grant_timing" value="now" checked /> <span>تحویل آنی در صورت آنلاین بودن</span></label>
						<label class="bmc-radio" style="margin-right:16px"><input type="radio" name="grant_timing" value="join" /> <span>تحویل در ورود بعدی به سرور</span></label>
					</div>
				</div>
			</form>
		</div>
		<div class="bmc-modal__foot">
			<button type="button" class="button button-primary" id="bmcSubmitGrant">اعطا و ثبت در صف تحویل</button>
			<button type="button" class="button button-secondary" id="bmcCancelGrant">انصراف</button>
		</div>
	</div>
</div>
