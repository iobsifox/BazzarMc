<?php

if ( ! defined( 'WP_UNINSTALL_PLUGIN' ) ) {
	exit;
}

$bmc_settings = get_option( 'bmc_settings', array() );
$bmc_purge    = is_array( $bmc_settings ) && ! empty( $bmc_settings['purge_on_uninstall'] ) && 'yes' === $bmc_settings['purge_on_uninstall'];

if ( ! $bmc_purge ) {

	return;
}

global $wpdb;

$bmc_tables = array(
	'bmc_deliveries',
	'bmc_codes',
	'bmc_logs',
	'bmc_tickets',
	'bmc_ticket_replies',
	'bmc_forms',
	'bmc_form_entries',
	'bmc_form_fields',
	'bmc_fields',
	'bmc_checkout_fields',
);

foreach ( $bmc_tables as $bmc_table ) {
	$bmc_full = $wpdb->prefix . $bmc_table;
	$wpdb->query( "DROP TABLE IF EXISTS {$bmc_full}" );
}

$wpdb->query(
	$wpdb->prepare(
		"DELETE FROM {$wpdb->usermeta} WHERE meta_key IN (%s, %s, %s, %s, %s, %s)",
		'bmc_mc_player',
		'bmc_mc_uuid',
		'bmc_linked_at',
		'bmc_link_channel',
		'bmc_mobile',
		'minecraft_player'
	)
);

$bmc_options = array( 'bmc_settings', 'bmc_db_version', 'bmc_needs_setup', 'bmc_activated_at' );
foreach ( $bmc_options as $bmc_option ) {
	delete_option( $bmc_option );
}

$wpdb->query(
	"DELETE FROM {$wpdb->options} WHERE option_name LIKE '_transient_bmc_%' OR option_name LIKE '_transient_timeout_bmc_%'"
);
