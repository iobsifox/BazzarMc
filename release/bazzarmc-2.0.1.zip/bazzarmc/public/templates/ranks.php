<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_ranks = ( isset( $bmc_ranks ) && is_array( $bmc_ranks ) ) ? $bmc_ranks : array();

$bmc_ranks = array_merge(
	array(
		'user_id'     => get_current_user_id(),
		'title'       => 'رنک فعال شما',
		'title_icon'  => 'workspace_premium',
		'progress'    => true,
		'role'        => false,
		'expiry'      => true,
		'empty_text'  => 'هنوز رنک فعالی ندارید. با خرید رنک، دسترسی‌ها و پاداش‌ها به‌صورت خودکار در بازی به شما اعطا می‌شود.',
		'shop_button' => true,
		'shop_label'  => 'مشاهدهٔ فروشگاه',
		'sort'        => 'level',
	),
	$bmc_ranks
);

$bmc_uid    = (int) $bmc_ranks['user_id'];
$bmc_grants = $bmc_uid ? BMC_Roles::active_grants( $bmc_uid, true ) : array();

$bmc_shop_url = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
?>
<div class="bmc-ranklist">
	<?php if ( '' !== trim( (string) $bmc_ranks['title'] ) ) : ?>
		<header class="bmc-acard__boxlabel">
			<?php if ( $bmc_ranks['title_icon'] ) : ?>
				<?php bmc_icon( $bmc_ranks['title_icon'], array( 'size' => 16 ) ); ?>
			<?php endif; ?>
			<?php echo esc_html( $bmc_ranks['title'] ); ?>
			<?php if ( $bmc_grants ) : ?>
				<span class="bmc-chip bmc-chip--ok"><?php bmc_icon( 'verified', array( 'size' => 13 ) ); ?> فعال</span>
			<?php else : ?>
				<span class="bmc-chip bmc-chip--off"><?php bmc_icon( 'close', array( 'size' => 13 ) ); ?> بدون رنک</span>
			<?php endif; ?>
		</header>
	<?php endif; ?>

	<?php if ( $bmc_grants ) : ?>
		<?php
		$bmc_grant     = $bmc_grants[0];
		$bmc_days      = max( 1, (int) ( isset( $bmc_grant['days'] ) ? $bmc_grant['days'] : 0 ) );
		$bmc_permanent = ! empty( $bmc_grant['permanent'] );
		$bmc_pct       = $bmc_permanent ? 100 : max( 2, min( 100, (int) round( ( (int) $bmc_grant['remaining'] / ( $bmc_days * DAY_IN_SECONDS ) ) * 100 ) ) );
		$bmc_urgent    = $bmc_permanent ? false : (int) $bmc_grant['remaining'] < ( 3 * DAY_IN_SECONDS );
		$bmc_rank_img  = ! empty( $bmc_grant['image'] ) ? $bmc_grant['image'] : '';
		$bmc_rank_name = ! empty( $bmc_grant['label'] ) ? $bmc_grant['label'] : ( ! empty( $bmc_grant['role_label'] ) ? $bmc_grant['role_label'] : 'رنک ویژه' );
		?>
		<div class="bmc-rank-active<?php echo $bmc_urgent ? ' is-urgent' : ''; ?>">
			<div class="bmc-rank-active__media">
				<?php if ( $bmc_rank_img ) : ?>
					<img src="<?php echo esc_url( $bmc_rank_img ); ?>" alt="" class="bmc-rank-active__img" />
				<?php else : ?>
					<div class="bmc-rank-active__badge">
						<?php bmc_icon( 'trophy', array( 'size' => 28 ) ); ?>
					</div>
				<?php endif; ?>
			</div>
			<div class="bmc-rank-active__content">
				<strong class="bmc-rank-active__title"><?php echo esc_html( $bmc_rank_name ); ?></strong>
				<div class="bmc-rank-active__duration">
					<?php if ( $bmc_permanent ) : ?>
						<span class="bmc-pill bmc-pill--permanent">
							<?php bmc_icon( 'all_inclusive', array( 'size' => 13 ) ); ?> رنک دائمی (نامحدود)
						</span>
					<?php else : ?>
						<span class="bmc-pill<?php echo $bmc_urgent ? ' bmc-pill--warn' : ''; ?>">
							<?php bmc_icon( 'timer', array( 'size' => 13 ) ); ?> <?php echo esc_html( $bmc_grant['remaining_human'] ); ?> باقی مانده
						</span>
						<?php if ( $bmc_ranks['expiry'] && ! empty( $bmc_grant['expires_jalali'] ) ) : ?>
							<small class="bmc-rank-active__expiry"><?php bmc_icon( 'calendar_month', array( 'size' => 12 ) ); ?> معتبر تا <?php echo esc_html( $bmc_grant['expires_jalali'] ); ?></small>
						<?php endif; ?>
						<?php if ( $bmc_ranks['progress'] ) : ?>
							<span class="bmc-bar"><i style="width:<?php echo esc_attr( $bmc_pct ); ?>%"></i></span>
						<?php endif; ?>
					<?php endif; ?>
				</div>
			</div>
		</div>
	<?php else : ?>
		<p class="bmc-acard__hint"><?php echo esc_html( $bmc_ranks['empty_text'] ); ?></p>
		<?php if ( $bmc_ranks['shop_button'] ) : ?>
			<a class="bmc-btn bmc-btn-o bmc-btn-sm" href="<?php echo esc_url( $bmc_shop_url ); ?>"><?php bmc_icon( 'storefront', array( 'size' => 15 ) ); ?> <?php echo esc_html( $bmc_ranks['shop_label'] ); ?></a>
		<?php endif; ?>
	<?php endif; ?>
</div>
