<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! is_user_logged_in() || ! function_exists( 'wc_get_account_menu_items' ) ) {
	return;
}

do_action( 'woocommerce_before_account_navigation' );

$bmc_nav_html = '';

try {
	$bmc_nav_html = (string) BMC_Public::render_account_nav(
		array(
			'layout'     => 'vertical',
			'icons'      => true,
			'counts'     => true,
			'title'      => 'حساب کاربری',
			'title_icon' => 'account_circle',
		)
	);
} catch ( Throwable $bmc_nav_error ) {
	if ( class_exists( 'BMC_Safe' ) ) {
		BMC_Safe::collect( 'account:navigation', $bmc_nav_error );
	}

	$bmc_nav_html = '';
}

if ( '' === trim( $bmc_nav_html ) ) {
	$bmc_nav_html = BMC_Public::core_navigation_fallback();
}

echo '<div class="bmc-acct-nav-wrap woocommerce-MyAccount-navigation">';

echo $bmc_nav_html;

echo '</div>';

do_action( 'woocommerce_after_account_navigation' );
