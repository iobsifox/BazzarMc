<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_card = ( isset( $bmc_card ) && is_array( $bmc_card ) ) ? $bmc_card : array();

$bmc_card = array_merge(
	array(
		'user_id'       => get_current_user_id(),
		'title'         => '',
		'title_icon'    => 'account_circle',
		'layout'        => 'grid',
		'columns'       => 2,
		'kicker'        => true,
		'kicker_text'   => '',
		'email'         => true,
		'mobile'        => true,
		'orders'        => true,
		'roles'         => true,
		'mc_box'        => true,
		'ranks_box'     => true,
		'links'         => true,
		'link_items'    => array( 'orders', 'addresses', 'details', 'logout' ),
		'unlinked_text' => '',
		'no_ranks_text' => '',
		'manage_label'  => '',
		'connect_label' => '',
		'avatar_size'   => 64,
		'context'       => 'dashboard',
		'context_box'   => false,
		'compact'       => false,
	),
	$bmc_card
);

$bmc_uid  = (int) $bmc_card['user_id'];
$bmc_user = get_userdata( $bmc_uid );

if ( ! $bmc_user ) {
	return;
}

$bmc_first = trim( (string) get_user_meta( $bmc_uid, 'first_name', true ) );
$bmc_last  = trim( (string) get_user_meta( $bmc_uid, 'last_name', true ) );

if ( '' === $bmc_first && '' === $bmc_last ) {
	$bmc_first = trim( (string) get_user_meta( $bmc_uid, 'billing_first_name', true ) );
	$bmc_last  = trim( (string) get_user_meta( $bmc_uid, 'billing_last_name', true ) );
}

$bmc_realname = trim( $bmc_first . ' ' . $bmc_last );

if ( '' === $bmc_realname ) {
	$bmc_realname = (string) $bmc_user->display_name;
}

$bmc_email   = (string) $bmc_user->user_email;
$bmc_mobile  = $bmc_card['mobile'] ? (string) BMC_Auth::get_user_mobile( $bmc_uid ) : '';
$bmc_player  = (string) BMC_Link::get_linked_player( $bmc_uid );
$bmc_linked  = BMC_Link::is_linked( $bmc_uid );
$bmc_uuid    = (string) BMC_Link::get_linked_uuid( $bmc_uid );
$bmc_link_at = (int) get_user_meta( $bmc_uid, BMC_Link::META_LINKED_AT, true );
$bmc_grants  = $bmc_card['ranks_box'] ? BMC_Roles::active_grants( $bmc_uid ) : array();
$bmc_manage  = class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::url( 'connect' ) : '#';
$bmc_connect = $bmc_manage;
$bmc_initial = function_exists( 'mb_substr' ) ? mb_substr( $bmc_realname, 0, 1 ) : substr( $bmc_realname, 0, 1 );
$bmc_avatar  = max( 24, min( 160, (int) $bmc_card['avatar_size'] ) );

$bmc_orders_count = 0;
$bmc_orders_url   = function_exists( 'wc_get_account_endpoint_url' ) ? wc_get_account_endpoint_url( 'orders' ) : '#';

if ( $bmc_card['orders'] && function_exists( 'wc_get_orders' ) ) {
	$bmc_orders_count = count(
		wc_get_orders(
			array(
				'customer' => $bmc_uid,
				'limit'    => -1,
				'return'   => 'ids',
			)
		)
	);
}

$bmc_role_labels = array();

if ( $bmc_card['roles'] ) {
	foreach ( (array) $bmc_user->roles as $bmc_role_slug ) {
		if ( in_array( $bmc_role_slug, array( 'customer', 'subscriber' ), true ) ) {
			continue;
		}

		$bmc_role_labels[] = BMC_Roles::role_label( $bmc_role_slug );
	}
}

$bmc_addresses_url = function_exists( 'wc_get_account_endpoint_url' ) ? wc_get_account_endpoint_url( 'edit-address' ) : '#';
$bmc_details_url   = function_exists( 'wc_get_account_endpoint_url' ) ? wc_get_account_endpoint_url( 'edit-account' ) : '#';
$bmc_home_url      = function_exists( 'home_url' ) ? home_url( '/' ) : '/';
$bmc_logout_url    = function_exists( 'wp_logout_url' ) ? wp_logout_url( $bmc_home_url ) : '#';

$bmc_link_items = array_values( array_filter( (array) $bmc_card['link_items'] ) );

$bmc_hour = (int) gmdate( 'G', BMC_Helpers::now_timestamp() );

if ( '' !== trim( (string) $bmc_card['kicker_text'] ) ) {
	$bmc_kicker = (string) $bmc_card['kicker_text'];
} else {
	$bmc_kicker = $bmc_hour < 12 ? 'صبح بخیر' : ( $bmc_hour < 17 ? 'ظهر بخیر' : 'وقت بخیر' );
}

$bmc_unlinked = '' !== trim( (string) $bmc_card['unlinked_text'] )
	? (string) $bmc_card['unlinked_text']
	: 'حساب شما هنوز به اکانت ماینکرافت متصل نیست. برای دریافت خودکار خریدها و جوایز در بازی، اکانت خود را متصل کنید.';

$bmc_no_ranks = '' !== trim( (string) $bmc_card['no_ranks_text'] )
	? (string) $bmc_card['no_ranks_text']
	: 'هنوز رنکی فعال نکرده‌اید.';

$bmc_manage_label  = '' !== trim( (string) $bmc_card['manage_label'] ) ? (string) $bmc_card['manage_label'] : 'مدیریت اتصال';
$bmc_connect_label = '' !== trim( (string) $bmc_card['connect_label'] ) ? (string) $bmc_card['connect_label'] : 'اتصال اکانت ماینکرافت';

$bmc_cols       = max( 1, min( 4, (int) $bmc_card['columns'] ) );
$bmc_grid_style = ' style="grid-template-columns:repeat(' . esc_attr( $bmc_cols ) . ',minmax(0,1fr))"';
?>
<?php if ( '' !== trim( (string) $bmc_card['title'] ) ) : ?>
	<header class="bmc-acard-title">
		<?php if ( $bmc_card['title_icon'] ) : ?>
			<?php bmc_icon( $bmc_card['title_icon'], array( 'size' => 19 ) ); ?>
		<?php endif; ?>
		<span><?php echo esc_html( $bmc_card['title'] ); ?></span>
	</header>
<?php endif; ?>

<div class="bmc-acard">
	<div class="bmc-acard__head">
		<div class="bmc-acard__avatar" style="width:<?php echo esc_attr( $bmc_avatar ); ?>px;height:<?php echo esc_attr( $bmc_avatar ); ?>px;">
			<?php if ( $bmc_linked && $bmc_player ) : ?>
				<img src="<?php echo esc_url( BMC_Helpers::mc_head( $bmc_player, 96 ) ); ?>" alt="" width="<?php echo esc_attr( $bmc_avatar ); ?>" height="<?php echo esc_attr( $bmc_avatar ); ?>" />
			<?php else : ?>
				<span><?php echo esc_html( $bmc_initial ); ?></span>
			<?php endif; ?>
		</div>

		<div class="bmc-acard__id">
			<?php if ( $bmc_card['kicker'] ) : ?>
				<span class="bmc-acard__kicker"><?php bmc_icon( 'waving_hand', array( 'size' => 15 ) ); ?> <?php echo esc_html( $bmc_kicker ); ?></span>
			<?php endif; ?>
			<h2 class="bmc-acard__name">
				<?php echo esc_html( $bmc_realname ); ?>
			</h2>
			<div class="bmc-acard__meta">
				<?php if ( $bmc_card['email'] && $bmc_email ) : ?>
					<span><?php bmc_icon( 'mail', array( 'size' => 14 ) ); ?> <?php echo esc_html( $bmc_email ); ?></span>
				<?php endif; ?>
				<?php if ( $bmc_mobile ) : ?>
					<span dir="ltr"><?php bmc_icon( 'smartphone', array( 'size' => 14 ) ); ?> <?php echo esc_html( $bmc_mobile ); ?></span>
				<?php endif; ?>
				<?php if ( $bmc_card['orders'] ) : ?>
					<span><?php bmc_icon( 'receipt_long', array( 'size' => 14 ) ); ?> <?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_orders_count ) ); ?> سفارش</span>
				<?php endif; ?>
				<?php if ( $bmc_role_labels ) : ?>
					<span><?php bmc_icon( 'workspace_premium', array( 'size' => 14 ) ); ?> <?php echo esc_html( implode( '، ', $bmc_role_labels ) ); ?></span>
				<?php endif; ?>
			</div>
		</div>

		<div class="bmc-acard__badges">
			<span class="bmc-chip <?php echo $bmc_linked ? 'bmc-chip--ok' : 'bmc-chip--off'; ?>">
				<?php bmc_icon( $bmc_linked ? 'verified' : 'link_off', array( 'size' => 14 ) ); ?>
				<?php echo $bmc_linked ? 'متصل به ماینکرافت' : 'متصل نیست'; ?>
			</span>
		</div>
	</div>

	<div class="bmc-acard__grid"<?php echo $bmc_grid_style; ?>>
		<?php if ( $bmc_card['mc_box'] ) : ?>
			<section class="bmc-acard__box bmc-acard__box--mc">
				<header class="bmc-acard__boxlabel">
					<?php bmc_icon( 'sports_esports', array( 'size' => 16 ) ); ?>
					اکانت ماینکرافت
				</header>
				<?php if ( $bmc_linked && $bmc_player ) : ?>
					<div class="bmc-acard__player">
						<img class="bmc-acard__playerhead" src="<?php echo esc_url( BMC_Helpers::mc_head( $bmc_player, 48 ) ); ?>" alt="" width="36" height="36" />
						<div class="bmc-acard__playerinfo">
							<strong dir="ltr" class="bmc-acard__playername"><?php echo esc_html( $bmc_player ); ?></strong>
							<?php if ( $bmc_link_at ) : ?>
								<small>اتصال در <?php echo esc_html( BMC_Jalali::format( $bmc_link_at, false ) ); ?></small>
							<?php endif; ?>
						</div>
					</div>
					<a href="<?php echo esc_url( $bmc_manage ); ?>" class="bmc-btn bmc-btn-o bmc-btn-sm"><?php bmc_icon( 'tune', array( 'size' => 14 ) ); ?> <?php echo esc_html( $bmc_manage_label ); ?></a>
				<?php else : ?>
					<p class="bmc-acard__hint"><?php echo esc_html( $bmc_unlinked ); ?></p>
					<a href="<?php echo esc_url( $bmc_connect ); ?>" class="bmc-btn bmc-btn-p bmc-btn-sm"><?php bmc_icon( 'link', array( 'size' => 14 ) ); ?> <?php echo esc_html( $bmc_connect_label ); ?></a>
				<?php endif; ?>
			</section>
		<?php endif; ?>

		<?php if ( $bmc_card['ranks_box'] ) : ?>
			<section class="bmc-acard__box bmc-acard__box--ranks">
				<header class="bmc-acard__boxlabel">
					<?php bmc_icon( 'military_tech', array( 'size' => 16 ) ); ?>
					رنک و اشتراک‌ها
				</header>
				<?php if ( $bmc_grants ) : ?>
					<ul class="bmc-acard__rankslist">
						<?php foreach ( $bmc_grants as $bmc_grant ) : ?>
							<li>
								<span class="bmc-acard__rankname"><?php echo esc_html( $bmc_grant['label'] ); ?></span>
								<span class="bmc-acard__rankmeta">
									<?php if ( empty( $bmc_grant['expires_at'] ) ) : ?>
										<span class="bmc-pill bmc-pill--perm">دائمی</span>
									<?php else : ?>
										<span class="bmc-pill bmc-pill--time">تا <?php echo esc_html( BMC_Jalali::format( strtotime( $bmc_grant['expires_at'] ), false ) ); ?></span>
									<?php endif; ?>
								</span>
							</li>
						<?php endforeach; ?>
					</ul>
				<?php else : ?>
					<p class="bmc-acard__hint"><?php echo esc_html( $bmc_no_ranks ); ?></p>
				<?php endif; ?>
			</section>
		<?php endif; ?>
	</div>

	<?php if ( $bmc_card['links'] && $bmc_link_items ) : ?>
		<footer class="bmc-acard__foot">
			<div class="bmc-acard__links">
				<?php if ( in_array( 'orders', $bmc_link_items, true ) && $bmc_orders_url ) : ?>
					<a href="<?php echo esc_url( $bmc_orders_url ); ?>" class="bmc-acard__link"><?php bmc_icon( 'receipt_long', array( 'size' => 15 ) ); ?> سفارش‌ها</a>
				<?php endif; ?>
				<?php if ( in_array( 'addresses', $bmc_link_items, true ) && $bmc_addresses_url ) : ?>
					<a href="<?php echo esc_url( $bmc_addresses_url ); ?>" class="bmc-acard__link"><?php bmc_icon( 'location_on', array( 'size' => 15 ) ); ?> آدرس‌ها</a>
				<?php endif; ?>
				<?php if ( in_array( 'details', $bmc_link_items, true ) && $bmc_details_url ) : ?>
					<a href="<?php echo esc_url( $bmc_details_url ); ?>" class="bmc-acard__link"><?php bmc_icon( 'manage_accounts', array( 'size' => 15 ) ); ?> جزئیات حساب</a>
				<?php endif; ?>
				<?php if ( in_array( 'logout', $bmc_link_items, true ) && $bmc_logout_url ) : ?>
					<a href="<?php echo esc_url( $bmc_logout_url ); ?>" class="bmc-acard__link bmc-acard__link--logout"><?php bmc_icon( 'logout', array( 'size' => 15 ) ); ?> خروج</a>
				<?php endif; ?>
			</div>
		</footer>
	<?php endif; ?>
</div>
