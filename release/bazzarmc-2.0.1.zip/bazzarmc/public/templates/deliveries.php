<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_deliveries = ( isset( $bmc_deliveries ) && is_array( $bmc_deliveries ) ) ? $bmc_deliveries : array();

$bmc_deliveries = array_merge(
	array(
		'user_id'    => get_current_user_id(),
		'title'      => 'تحویل‌های من',
		'title_icon' => 'inventory_2',
		'status'     => '',
		'limit'      => 10,
		'code'       => true,
		'order'      => true,
		'date'       => true,
		'layout'     => 'list',
		'hint'       => true,
		'counts'     => false,
		'empty_text' => 'موردی برای نمایش وجود ندارد.',
	),
	$bmc_deliveries
);

$bmc_uid = (int) $bmc_deliveries['user_id'];

if ( ! $bmc_uid ) {
	echo '<div class="bmc-alert bmc-alert--warn">برای مشاهدهٔ تحویل‌ها وارد حساب کاربری شوید.</div>';
	return;
}

$bmc_status = '';

if ( 'pending' === $bmc_deliveries['status'] ) {
	$bmc_status = BMC_Deliveries::STATUS_PENDING;
} elseif ( 'delivered' === $bmc_deliveries['status'] ) {
	$bmc_status = BMC_Deliveries::STATUS_DELIVERED;
}

$bmc_rows = BMC_Deliveries::for_user( $bmc_uid, array( 'status' => $bmc_status, 'limit' => (int) $bmc_deliveries['limit'] ) );
$bmc_counts = $bmc_deliveries['counts'] ? BMC_Deliveries::counts_for_user( $bmc_uid ) : array();
$bmc_layout = 'table' === $bmc_deliveries['layout'] ? 'table' : 'list';
$bmc_player = (string) BMC_Link::get_linked_player( $bmc_uid );

$bmc_show_note     = BMC_Settings::bool( 'delivery_note_user', true );
$bmc_show_attempts = BMC_Settings::bool( 'delivery_show_attempts', true );
$bmc_any_note      = false;

if ( $bmc_show_note ) {
	foreach ( $bmc_rows as $bmc_check ) {
		if ( ! empty( $bmc_check->note ) || ( $bmc_show_attempts && ! empty( $bmc_check->attempts ) ) ) {
			$bmc_any_note = true;
			break;
		}
	}
}
?>
<div class="bmc-deliv bmc-deliv--<?php echo esc_attr( $bmc_layout ); ?>">
	<?php if ( '' !== trim( (string) $bmc_deliveries['title'] ) ) : ?>
		<header class="bmc-acard__boxlabel">
			<?php if ( $bmc_deliveries['title_icon'] ) : ?>
				<?php bmc_icon( $bmc_deliveries['title_icon'], array( 'size' => 16 ) ); ?>
			<?php endif; ?>
			<?php echo esc_html( $bmc_deliveries['title'] ); ?>
			<span class="bmc-chip"><?php bmc_icon( 'list_alt', array( 'size' => 13 ) ); ?> <?php echo esc_html( BMC_Helpers::to_persian_digits( count( $bmc_rows ) ) ); ?> مورد</span>
			<?php if ( $bmc_counts ) : ?>
				<span class="bmc-chip"><?php bmc_icon( 'hourglass_empty', array( 'size' => 13 ) ); ?> <?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_counts['pending'] ) ); ?> در انتظار</span>
			<?php endif; ?>
		</header>
	<?php endif; ?>

	<?php if ( $bmc_deliveries['hint'] && $bmc_player ) : ?>
		<p class="bmc-deliv__hint"><?php bmc_icon( 'sports_esports', array( 'size' => 14 ) ); ?> آیتم‌های در انتظار تحویل، در اولین ورود با اکانت <strong dir="ltr"><?php echo esc_html( $bmc_player ); ?></strong> به سرور یا از منوی دریافت داخل بازی تحویل داده می‌شود.</p>
	<?php elseif ( $bmc_deliveries['hint'] ) : ?>
		<p class="bmc-deliv__hint"><?php bmc_icon( 'link_off', array( 'size' => 14 ) ); ?> برای دریافت آیتم‌ها در بازی، ابتدا اکانت ماینکرافت خود را متصل کنید.</p>
	<?php endif; ?>

	<?php if ( ! $bmc_rows ) : ?>
		<p class="bmc-acard__hint"><?php echo esc_html( $bmc_deliveries['empty_text'] ); ?></p>
	<?php elseif ( 'table' === $bmc_layout ) : ?>
		<div class="bmc-table-wrap">
			<table class="bmc-table bmc-table--full">
				<thead>
					<tr>
						<th>محصول</th>
						<?php if ( $bmc_deliveries['code'] ) : ?>
							<th>کد خرید</th>
						<?php endif; ?>
						<?php if ( $bmc_deliveries['order'] ) : ?>
							<th>سفارش</th>
						<?php endif; ?>
						<th>وضعیت</th>
						<?php if ( $bmc_any_note ) : ?>
							<th>گزارش</th>
						<?php endif; ?>
						<?php if ( $bmc_deliveries['date'] ) : ?>
							<th>تاریخ</th>
						<?php endif; ?>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $bmc_rows as $bmc_row ) : ?>
						<?php
						$bmc_name = (string) BMC_API::product_name( (int) $bmc_row->product_id, (int) $bmc_row->variation_id );

						if ( '' === $bmc_name ) {
							$bmc_name = (string) $bmc_row->item;
						}

						$bmc_status_class = (string) BMC_Deliveries::status_class( (int) $bmc_row->status );
						?>
						<tr>
							<td>
								<strong><?php echo esc_html( $bmc_name ? $bmc_name : '—' ); ?></strong>
								<?php if ( (int) $bmc_row->amount > 1 ) : ?>
									<small>×<?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_row->amount ) ); ?></small>
								<?php endif; ?>
							</td>
							<?php if ( $bmc_deliveries['code'] ) : ?>
								<td dir="ltr"><code><?php echo esc_html( BMC_API::purchase_code( $bmc_row ) ); ?></code></td>
							<?php endif; ?>
							<?php if ( $bmc_deliveries['order'] ) : ?>
								<td dir="ltr"><?php echo esc_html( BMC_API::order_number( (int) $bmc_row->order_id ) ); ?></td>
							<?php endif; ?>
							<td><span class="bmc-pill <?php echo esc_attr( $bmc_status_class ); ?>"><?php echo esc_html( BMC_Deliveries::status_label( (int) $bmc_row->status ) ); ?></span></td>
							<?php if ( $bmc_any_note ) : ?>
								<td class="bmc-deliv__report">
									<?php if ( ! empty( $bmc_row->note ) ) : ?>
										<span><?php echo (int) $bmc_row->status === BMC_Deliveries::STATUS_DELIVERED ? 'خلاصهٔ پاداش: ' : 'دلیل: '; ?><?php echo esc_html( $bmc_row->note ); ?></span>
									<?php endif; ?>
									<?php if ( $bmc_show_attempts && ! empty( $bmc_row->attempts ) ) : ?>
										<small>تلاش‌ها: <?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_row->attempts ) ); ?><?php echo ! empty( $bmc_row->last_attempt_at ) ? ' — ' . esc_html( BMC_Jalali::format( $bmc_row->last_attempt_at ) ) : ''; ?></small>
									<?php endif; ?>
								</td>
							<?php endif; ?>
							<?php if ( $bmc_deliveries['date'] ) : ?>
								<td><?php echo esc_html( BMC_Jalali::format( $bmc_row->created_at ) ); ?></td>
							<?php endif; ?>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>
		</div>
	<?php else : ?>
		<div class="bmc-deliv__list">
			<?php foreach ( $bmc_rows as $bmc_row ) : ?>
				<?php
				$bmc_name = (string) BMC_API::product_name( (int) $bmc_row->product_id, (int) $bmc_row->variation_id );

				if ( '' === $bmc_name ) {
					$bmc_name = (string) $bmc_row->item;
				}

				$bmc_pending      = (int) $bmc_row->status === BMC_Deliveries::STATUS_PENDING;
				$bmc_status_class = (string) BMC_Deliveries::status_class( (int) $bmc_row->status );
				?>
				<article class="bmc-deliv__item<?php echo $bmc_pending ? ' is-pending' : ''; ?>">
					<span class="bmc-deliv__icon"><?php bmc_icon( $bmc_pending ? 'hourglass_empty' : 'task_alt', array( 'size' => 18 ) ); ?></span>
					<div class="bmc-deliv__body">
						<strong><?php echo esc_html( $bmc_name ? $bmc_name : '—' ); ?><?php echo (int) $bmc_row->amount > 1 ? ' ×' . esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_row->amount ) ) : ''; ?></strong>
						<div class="bmc-deliv__meta">
							<?php if ( $bmc_deliveries['code'] ) : ?>
								<span><?php bmc_icon( 'qr_code_2', array( 'size' => 13 ) ); ?> کد خرید: <code dir="ltr"><?php echo esc_html( BMC_API::purchase_code( $bmc_row ) ); ?></code></span>
							<?php endif; ?>
							<?php if ( $bmc_deliveries['order'] ) : ?>
								<span><?php bmc_icon( 'receipt_long', array( 'size' => 13 ) ); ?> سفارش <span dir="ltr"><?php echo esc_html( BMC_API::order_number( (int) $bmc_row->order_id ) ); ?></span></span>
							<?php endif; ?>
							<?php if ( $bmc_deliveries['date'] ) : ?>
								<span><?php bmc_icon( 'calendar_month', array( 'size' => 13 ) ); ?> <?php echo esc_html( BMC_Jalali::format( $bmc_row->created_at ) ); ?></span>
							<?php endif; ?>
						</div>
						<?php if ( $bmc_show_note && ( ! empty( $bmc_row->note ) || ( $bmc_show_attempts && ! empty( $bmc_row->attempts ) ) ) ) : ?>
							<p class="bmc-deliv__note<?php echo $bmc_pending ? ' is-warn' : ' is-ok'; ?>">
								<?php bmc_icon( $bmc_pending ? 'warning' : 'check_circle', array( 'size' => 14 ) ); ?>
								<?php if ( ! empty( $bmc_row->note ) ) : ?>
									<span><?php echo $bmc_pending ? 'دلیل تحویل‌نشدن: ' : 'خلاصهٔ پاداش: '; ?><?php echo esc_html( $bmc_row->note ); ?></span>
								<?php endif; ?>
								<?php if ( $bmc_show_attempts && ! empty( $bmc_row->attempts ) ) : ?>
									<small>تلاش‌ها: <?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_row->attempts ) ); ?><?php echo ! empty( $bmc_row->last_attempt_at ) ? ' — ' . esc_html( BMC_Jalali::format( $bmc_row->last_attempt_at ) ) : ''; ?></small>
								<?php endif; ?>
							</p>
						<?php endif; ?>
					</div>
					<span class="bmc-pill <?php echo esc_attr( $bmc_status_class ); ?>"><?php echo esc_html( BMC_Deliveries::status_label( (int) $bmc_row->status ) ); ?></span>
				</article>
			<?php endforeach; ?>
		</div>
	<?php endif; ?>
</div>
