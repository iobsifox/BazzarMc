<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'wc_get_account_menu_items' ) ) {
	return;
}

$bmc_nav = ( isset( $bmc_nav ) && is_array( $bmc_nav ) ) ? $bmc_nav : array();

$bmc_nav = array_merge(
	array(
		'source_mode'   => 'default',
		'layout'        => 'vertical',
		'icons'         => true,
		'counts'        => true,
		'items'         => array(),
		'nav_items'     => array(),
		'extra'         => array(),
		'title'         => '',
		'title_icon'    => 'menu_book',
		'active_only'   => false,
		'mobile'        => '',
		'mobile_labels' => null,
		'mobile_sticky' => null,
		'breakpoint'    => 0,
	),
	$bmc_nav
);

$bmc_icons = array(
	'dashboard'       => 'dashboard',
	'orders'          => 'receipt_long',
	'view-order'      => 'description',
	'downloads'       => 'download',
	'edit-address'    => 'location_on',
	'payment-methods' => 'account_balance_wallet',
	'edit-account'    => 'person',
	'connect'         => 'sports_esports',
	'customer-logout' => 'logout',
	'lost-password'   => 'lock',
);

$bmc_icons = apply_filters( 'bmc_account_nav_icons', $bmc_icons );

$bmc_normalize_endpoint = function ( $key ) {
	$key = sanitize_key( (string) $key );
	$aliases = array(
		'minecraft'       => 'connect',
		'mc-link'         => 'connect',
		'bmc-connect'     => 'connect',
		'logout'          => 'customer-logout',
		'account-details' => 'edit-account',
		'addresses'       => 'edit-address',
		'address'         => 'edit-address',
	);

	return isset( $aliases[ $key ] ) ? $aliases[ $key ] : $key;
};

$bmc_canonical_defaults = array(
	'dashboard' => array(
		'label' => function_exists( '__' ) ? __( 'Dashboard', 'woocommerce' ) : 'پیشخوان',
		'icon'  => 'dashboard',
		'url'   => function_exists( 'wc_get_account_endpoint_url' ) ? (string) wc_get_account_endpoint_url( 'dashboard' ) : '#',
	),
	'orders' => array(
		'label' => function_exists( '__' ) ? __( 'Orders', 'woocommerce' ) : 'سفارش‌ها',
		'icon'  => 'receipt_long',
		'url'   => function_exists( 'wc_get_account_endpoint_url' ) ? (string) wc_get_account_endpoint_url( 'orders' ) : '#',
	),
	'downloads' => array(
		'label' => function_exists( '__' ) ? __( 'Downloads', 'woocommerce' ) : 'دانلودها',
		'icon'  => 'download',
		'url'   => function_exists( 'wc_get_account_endpoint_url' ) ? (string) wc_get_account_endpoint_url( 'downloads' ) : '#',
	),
	'edit-address' => array(
		'label' => function_exists( '__' ) ? __( 'Addresses', 'woocommerce' ) : 'آدرس‌ها',
		'icon'  => 'location_on',
		'url'   => function_exists( 'wc_get_account_endpoint_url' ) ? (string) wc_get_account_endpoint_url( 'edit-address' ) : '#',
	),
	'payment-methods' => array(
		'label' => function_exists( '__' ) ? __( 'Payment methods', 'woocommerce' ) : 'روش‌های پرداخت',
		'icon'  => 'account_balance_wallet',
		'url'   => function_exists( 'wc_get_account_endpoint_url' ) ? (string) wc_get_account_endpoint_url( 'payment-methods' ) : '#',
	),
	'edit-account' => array(
		'label' => function_exists( '__' ) ? __( 'Account details', 'woocommerce' ) : 'جزئیات حساب',
		'icon'  => 'person',
		'url'   => function_exists( 'wc_get_account_endpoint_url' ) ? (string) wc_get_account_endpoint_url( 'edit-account' ) : '#',
	),
	'connect' => array(
		'label' => class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::title( 'connect' ) : 'اتصال ماینکرافت',
		'icon'  => class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::icon( 'connect' ) : 'sports_esports',
		'url'   => class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::url( 'connect' ) : '#',
	),
	'customer-logout' => array(
		'label' => function_exists( '__' ) ? __( 'Log out', 'woocommerce' ) : 'خروج',
		'icon'  => 'logout',
		'url'   => function_exists( 'wc_logout_url' ) ? (string) wc_logout_url() : ( function_exists( 'wc_get_account_endpoint_url' ) ? (string) wc_get_account_endpoint_url( 'customer-logout' ) : '#' ),
	),
);

$bmc_wc_items = (array) wc_get_account_menu_items();
$bmc_layout = in_array( $bmc_nav['layout'], array( 'vertical', 'horizontal', 'pills' ), true ) ? $bmc_nav['layout'] : 'vertical';

$bmc_current = '';

if ( function_exists( 'WC' ) && WC() && isset( WC()->query ) && method_exists( WC()->query, 'get_current_endpoint' ) ) {
	$bmc_current = (string) WC()->query->get_current_endpoint();
}

if ( '' === $bmc_current && function_exists( 'is_wc_endpoint_url' ) ) {
	foreach ( array_keys( $bmc_wc_items ) as $bmc_key ) {
		if ( $bmc_key && is_wc_endpoint_url( $bmc_key ) ) {
			$bmc_current = (string) $bmc_key;
			break;
		}
	}
}

$bmc_resolve_row = function ( $endpoint, $custom_label = '', $custom_icon = '', $custom_url = '', $is_external = false, $show_badge = true ) use ( $bmc_normalize_endpoint, $bmc_canonical_defaults, $bmc_icons, $bmc_wc_items, $bmc_current, $bmc_nav ) {
	$norm = $bmc_normalize_endpoint( $endpoint );

	if ( 'custom' === $norm ) {
		if ( '' === trim( (string) $custom_url ) && '' === trim( (string) $custom_label ) ) {
			return null;
		}

		return array(
			'endpoint'    => 'custom',
			'url'         => (string) $custom_url,
			'label'       => '' !== trim( (string) $custom_label ) ? (string) $custom_label : 'پیوند',
			'icon'        => '' !== trim( (string) $custom_icon ) ? (string) $custom_icon : 'open_in_new',
			'active'      => false,
			'count'       => 0,
			'dot'         => false,
			'note'        => '',
			'is_external' => (bool) $is_external,
		);
	}

	$def = isset( $bmc_canonical_defaults[ $norm ] ) ? $bmc_canonical_defaults[ $norm ] : null;

	$url = '' !== trim( (string) $custom_url ) ? (string) $custom_url : '';

	if ( '' === $url ) {
		if ( 'connect' === $norm && class_exists( 'BMC_Account_Endpoints' ) ) {
			$url = (string) BMC_Account_Endpoints::url( 'connect' );
		} elseif ( 'customer-logout' === $norm && function_exists( 'wc_logout_url' ) ) {
			$url = (string) wc_logout_url();
		} elseif ( function_exists( 'wc_get_account_endpoint_url' ) ) {
			$url = (string) wc_get_account_endpoint_url( $endpoint );
		} elseif ( null !== $def ) {
			$url = (string) $def['url'];
		} else {
			$url = '#';
		}
	}

	$label = '' !== trim( (string) $custom_label ) ? (string) $custom_label : '';

	if ( '' === $label ) {
		if ( isset( $bmc_wc_items[ $endpoint ] ) ) {
			$label = (string) $bmc_wc_items[ $endpoint ];
		} elseif ( null !== $def ) {
			$label = (string) $def['label'];
		} else {
			$label = (string) $endpoint;
		}
	}

	$icon = '' !== trim( (string) $custom_icon ) ? (string) $custom_icon : '';

	if ( '' === $icon ) {
		if ( 'connect' === $norm && class_exists( 'BMC_Account_Endpoints' ) ) {
			$icon = (string) BMC_Account_Endpoints::icon( 'connect' );
		} elseif ( isset( $bmc_icons[ $endpoint ] ) ) {
			$icon = (string) $bmc_icons[ $endpoint ];
		} elseif ( isset( $bmc_icons[ $norm ] ) ) {
			$icon = (string) $bmc_icons[ $norm ];
		} elseif ( null !== $def ) {
			$icon = (string) $def['icon'];
		} else {
			$icon = 'keyboard_arrow_left';
		}
	}

	$active = false;

	if ( '' === $bmc_current && 'dashboard' === $norm ) {
		$active = true;
	} elseif ( '' !== $bmc_current ) {
		$norm_current = $bmc_normalize_endpoint( $bmc_current );

		if ( $bmc_current === $endpoint || $norm_current === $norm ) {
			$active = true;
		} elseif ( 'orders' === $norm && in_array( $bmc_current, array( 'orders', 'view-order' ), true ) ) {
			$active = true;
		} elseif ( 'connect' === $norm && in_array( $bmc_current, array( 'connect', 'minecraft', 'mc-link' ), true ) ) {
			$active = true;
		}
	}

	$meta = array( 'count' => 0, 'dot' => false, 'note' => '' );

	if ( $show_badge && $bmc_nav['counts'] && class_exists( 'BMC_Account_Endpoints' ) ) {
		if ( 'connect' === $norm ) {
			$meta = BMC_Account_Endpoints::nav_meta( 'connect' );
		}
	}

	return array(
		'endpoint'    => (string) $endpoint,
		'url'         => $url,
		'label'       => $label,
		'icon'        => $icon,
		'active'      => $active,
		'count'       => (int) $meta['count'],
		'dot'         => (bool) $meta['dot'],
		'note'        => (string) $meta['note'],
		'is_external' => (bool) $is_external,
	);
};

$bmc_rows = array();

if ( 'custom' === $bmc_nav['source_mode'] && ! empty( $bmc_nav['nav_items'] ) ) {
	foreach ( (array) $bmc_nav['nav_items'] as $bmc_item ) {
		if ( ! is_array( $bmc_item ) ) {
			continue;
		}

		$bmc_ep   = isset( $bmc_item['endpoint'] ) ? (string) $bmc_item['endpoint'] : 'dashboard';
		$bmc_lbl  = isset( $bmc_item['label'] ) ? (string) $bmc_item['label'] : '';
		$bmc_ico  = isset( $bmc_item['icon'] ) ? (string) $bmc_item['icon'] : '';
		$bmc_u    = isset( $bmc_item['url'] ) ? (string) $bmc_item['url'] : '';
		$bmc_ext  = ! empty( $bmc_item['is_external'] );
		$bmc_bg   = ! isset( $bmc_item['show_badge'] ) || (bool) $bmc_item['show_badge'];

		$row = $bmc_resolve_row( $bmc_ep, $bmc_lbl, $bmc_ico, $bmc_u, $bmc_ext, $bmc_bg );

		if ( null !== $row ) {
			$bmc_rows[] = $row;
		}
	}
} elseif ( ! empty( $bmc_nav['items'] ) ) {
	$bmc_selected = array_values( array_filter( (array) $bmc_nav['items'] ) );

	foreach ( $bmc_selected as $bmc_wanted ) {
		$row = $bmc_resolve_row( (string) $bmc_wanted );

		if ( null !== $row ) {
			$bmc_rows[] = $row;
		}
	}
} else {
	foreach ( $bmc_wc_items as $bmc_endpoint => $bmc_label ) {
		$row = $bmc_resolve_row( (string) $bmc_endpoint, (string) $bmc_label );

		if ( null !== $row ) {
			$bmc_rows[] = $row;
		}
	}
}

foreach ( (array) $bmc_nav['extra'] as $bmc_extra ) {
	if ( empty( $bmc_extra['label'] ) || empty( $bmc_extra['url'] ) ) {
		continue;
	}

	$bmc_rows[] = array(
		'endpoint'    => 'custom',
		'url'         => (string) $bmc_extra['url'],
		'label'       => (string) $bmc_extra['label'],
		'icon'        => ! empty( $bmc_extra['icon'] ) ? (string) $bmc_extra['icon'] : 'open_in_new',
		'active'      => false,
		'count'       => 0,
		'dot'         => false,
		'note'        => '',
		'is_external' => false,
	);
}

if ( $bmc_nav['active_only'] ) {
	$bmc_filtered = array();

	foreach ( $bmc_rows as $bmc_r ) {
		if ( ! empty( $bmc_r['active'] ) ) {
			$bmc_filtered[] = $bmc_r;
		}
	}

	$bmc_rows = $bmc_filtered;
}

if ( ! $bmc_rows ) {
	return;
}

$bmc_mobile_layouts = array( 'vertical', 'scroll', 'grid', 'icons', 'dropdown', 'collapse' );
$bmc_mobile         = sanitize_key( (string) $bmc_nav['mobile'] );

if ( '' === $bmc_mobile ) {
	$bmc_mobile = (string) BMC_Settings::get( 'nav_mobile_layout', 'scroll' );
}

if ( ! in_array( $bmc_mobile, $bmc_mobile_layouts, true ) ) {
	$bmc_mobile = 'scroll';
}

$bmc_mobile_labels = null === $bmc_nav['mobile_labels'] ? BMC_Settings::bool( 'nav_mobile_labels', true ) : (bool) $bmc_nav['mobile_labels'];
$bmc_mobile_sticky = null === $bmc_nav['mobile_sticky'] ? BMC_Settings::bool( 'nav_mobile_sticky', false ) : (bool) $bmc_nav['mobile_sticky'];
$bmc_breakpoint    = (int) $bmc_nav['breakpoint'] > 0 ? (int) $bmc_nav['breakpoint'] : BMC_Settings::int( 'nav_mobile_breakpoint', 782, 320, 1600 );

$bmc_nav_classes = ' bmc-nav--m-' . $bmc_mobile;

if ( $bmc_mobile_sticky ) {
	$bmc_nav_classes .= ' is-sticky-mobile';
}

if ( ! $bmc_mobile_labels ) {
	$bmc_nav_classes .= ' is-nolabels-mobile';
}

$bmc_active_row = null;

foreach ( $bmc_rows as $bmc_row ) {
	if ( ! empty( $bmc_row['active'] ) ) {
		$bmc_active_row = $bmc_row;
		break;
	}
}

if ( ! isset( $GLOBALS['bmc_nav_mobile_css'] ) || ! is_array( $GLOBALS['bmc_nav_mobile_css'] ) ) {
	$GLOBALS['bmc_nav_mobile_css'] = array();
}

if ( ! in_array( $bmc_breakpoint, $GLOBALS['bmc_nav_mobile_css'], true ) ) {
	$GLOBALS['bmc_nav_mobile_css'][] = $bmc_breakpoint;
	$bmc_bp_min                      = $bmc_breakpoint + 1;
	?>
	<style id="bmc-nav-mobile-<?php echo (int) $bmc_breakpoint; ?>">
		.bmc-nav__select { display: none; width: 100%; padding: 11px 12px; border-radius: var(--bmc-radius-sm); border: 1px solid var(--bmc-border); background: var(--bmc-surface); color: var(--bmc-text); font-family: var(--bmc-font); font-size: 14px; font-weight: 600; }
		.bmc-nav__collapse > summary { list-style: none; cursor: pointer; }
		.bmc-nav__collapse > summary::-webkit-details-marker { display: none; }
		@media (min-width: <?php echo (int) $bmc_bp_min; ?>px) {
			.bmc-nav__collapse > summary { display: none; }
			.bmc-nav__collapse > .bmc-nav__list { display: flex; }
		}
		@media (max-width: <?php echo (int) $bmc_breakpoint; ?>px) {
			.bmc-nav .bmc-nav__title { margin-bottom: 8px; font-size: 14px; }
			.bmc-nav--m-scroll .bmc-nav__list { flex-direction: row; flex-wrap: nowrap; overflow-x: auto; overflow-y: hidden; -webkit-overflow-scrolling: touch; scrollbar-width: none; padding-bottom: 4px; }
			.bmc-nav--m-scroll .bmc-nav__list::-webkit-scrollbar { display: none; height: 0; width: 0; }
			.bmc-nav--m-scroll .bmc-nav__item { flex: 0 0 auto; }
			.bmc-nav--m-scroll .bmc-nav__item a { white-space: nowrap; padding: 9px 12px; background: var(--bmc-surface); border-color: var(--bmc-border); }
			.bmc-nav--m-grid .bmc-nav__list { flex-direction: row; flex-wrap: wrap; }
			.bmc-nav--m-grid .bmc-nav__item { flex: 1 1 calc(33.333% - 6px); min-width: calc(33.333% - 6px); }
			.bmc-nav--m-grid .bmc-nav__item a { flex-direction: column; align-items: center; justify-content: center; text-align: center; gap: 4px; padding: 10px 6px; background: var(--bmc-surface); border-color: var(--bmc-border); }
			.bmc-nav--m-grid .bmc-nav__label { font-size: 11px; line-height: 1.4; }
			.bmc-nav--m-icons .bmc-nav__list { flex-direction: row; flex-wrap: wrap; justify-content: center; }
			.bmc-nav--m-icons .bmc-nav__item { flex: 1 1 auto; max-width: 78px; }
			.bmc-nav--m-icons .bmc-nav__item a { flex-direction: column; align-items: center; justify-content: center; text-align: center; gap: 4px; padding: 10px 4px; background: var(--bmc-surface); border-color: var(--bmc-border); }
			.bmc-nav--m-icons .bmc-nav__label { font-size: 10px; line-height: 1.3; }
			.bmc-nav--m-vertical .bmc-nav__list { flex-direction: column; }
			.bmc-nav--m-vertical .bmc-nav__item a { background: var(--bmc-surface); border-color: var(--bmc-border); }
			.bmc-nav--m-dropdown .bmc-nav__select { display: block; }
			.bmc-nav--m-dropdown .bmc-nav__list { display: none; }
			.bmc-nav--m-collapse .bmc-nav__collapse > summary { display: flex; align-items: center; gap: 8px; padding: 11px 12px; border-radius: var(--bmc-radius-sm); border: 1px solid var(--bmc-border); background: var(--bmc-surface); font-weight: 700; }
			.bmc-nav--m-collapse .bmc-nav__collapse > summary .bmc-nav__chev { margin-inline-start: auto; color: var(--bmc-muted); transition: transform .18s; }
			.bmc-nav--m-collapse .bmc-nav__collapse[open] > summary { margin-bottom: 8px; border-color: var(--bmc-accent); background: var(--bmc-accent-soft); }
			.bmc-nav--m-collapse .bmc-nav__collapse[open] > summary .bmc-nav__chev { transform: rotate(180deg); }
			.bmc-nav--m-collapse .bmc-nav__collapse[open] > .bmc-nav__list { display: flex; flex-direction: column; }
			.bmc-nav.is-nolabels-mobile .bmc-nav__label,
			.bmc-nav.is-nolabels-mobile .bmc-nav__note { display: none; }
			.bmc-nav.is-nolabels-mobile .bmc-nav__item a { justify-content: center; padding: 10px; gap: 0; }
			.bmc-nav.is-sticky-mobile { position: sticky; top: 0; z-index: 30; padding: 6px 0; background: var(--bmc-bg); border-bottom: 1px solid var(--bmc-border); }
			.bmc-nav.is-sticky-mobile .bmc-nav__title { display: none; }
			.bmc-nav .bmc-nav__count { font-size: 10px; padding: 0 5px; }
		}
	</style>
	<?php
}
?>
<div class="bmc-nav bmc-nav--<?php echo esc_attr( $bmc_layout ); ?><?php echo esc_attr( $bmc_nav_classes ); ?>" data-bmc-mobile="<?php echo esc_attr( $bmc_mobile ); ?>" data-bmc-breakpoint="<?php echo (int) $bmc_breakpoint; ?>">
	<?php if ( '' !== trim( (string) $bmc_nav['title'] ) ) : ?>
		<header class="bmc-nav__title">
			<?php if ( $bmc_nav['title_icon'] ) : ?>
				<?php bmc_icon( $bmc_nav['title_icon'], array( 'size' => 17 ) ); ?>
			<?php endif; ?>
			<span><?php echo esc_html( $bmc_nav['title'] ); ?></span>
		</header>
	<?php endif; ?>

	<?php if ( 'dropdown' === $bmc_mobile ) : ?>
		<select class="bmc-nav__select" data-bmc-nav-select aria-label="<?php echo esc_attr( '' !== trim( (string) $bmc_nav['title'] ) ? $bmc_nav['title'] : 'منوی حساب کاربری' ); ?>">
			<?php foreach ( $bmc_rows as $bmc_row ) : ?>
				<option value="<?php echo esc_url( $bmc_row['url'] ); ?>"<?php echo $bmc_row['active'] ? ' selected' : ''; ?>><?php echo esc_html( $bmc_row['label'] ); ?><?php echo $bmc_row['count'] > 0 ? ' (' . esc_html( BMC_Helpers::to_persian_digits( $bmc_row['count'] ) ) . ')' : ''; ?></option>
			<?php endforeach; ?>
		</select>
	<?php endif; ?>

	<?php if ( 'collapse' === $bmc_mobile ) : ?>
		<details class="bmc-nav__collapse">
			<summary>
				<?php bmc_icon( $bmc_active_row && $bmc_active_row['icon'] ? $bmc_active_row['icon'] : 'menu_book', array( 'size' => 17 ) ); ?>
				<span><?php echo esc_html( $bmc_active_row ? $bmc_active_row['label'] : 'منوی حساب کاربری' ); ?></span>
				<?php if ( $bmc_active_row && $bmc_active_row['count'] > 0 ) : ?>
					<span class="bmc-nav__count"><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_active_row['count'] ) ); ?></span>
				<?php endif; ?>
				<span class="bmc-nav__chev"><?php bmc_icon( 'keyboard_arrow_down', array( 'size' => 18 ) ); ?></span>
			</summary>
	<?php endif; ?>

	<ul class="bmc-nav__list">
		<?php foreach ( $bmc_rows as $bmc_row ) : ?>
			<li class="bmc-nav__item<?php echo $bmc_row['active'] ? ' is-active' : ''; ?>">
				<a href="<?php echo esc_url( $bmc_row['url'] ); ?>"<?php echo ! empty( $bmc_row['is_external'] ) ? ' target="_blank" rel="noopener noreferrer"' : ''; ?>>
					<?php if ( $bmc_nav['icons'] ) : ?>
						<span class="bmc-nav__icon"><?php bmc_icon( $bmc_row['icon'], array( 'size' => 17 ) ); ?></span>
					<?php endif; ?>
					<span class="bmc-nav__label"><?php echo esc_html( $bmc_row['label'] ); ?></span>
					<?php if ( ! empty( $bmc_row['note'] ) ) : ?>
						<span class="bmc-nav__note"><?php echo esc_html( $bmc_row['note'] ); ?></span>
					<?php endif; ?>
					<?php if ( $bmc_row['dot'] ) : ?>
						<span class="bmc-nav__dot"></span>
					<?php endif; ?>
					<?php if ( $bmc_row['count'] > 0 ) : ?>
						<span class="bmc-nav__count"><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_row['count'] ) ); ?></span>
					<?php endif; ?>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>

	<?php if ( 'collapse' === $bmc_mobile ) : ?>
		</details>
	<?php endif; ?>
</div>
