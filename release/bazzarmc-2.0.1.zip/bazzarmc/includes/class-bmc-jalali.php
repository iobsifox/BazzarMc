<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Jalali {

	const MONTHS = array( 'فروردین', 'اردیبهشت', 'خرداد', 'تیر', 'مرداد', 'شهریور', 'مهر', 'آبان', 'آذر', 'دی', 'بهمن', 'اسفند' );
	const WEEKDAYS = array( 'شنبه', 'یکشنبه', 'دوشنبه', 'سه‌شنبه', 'چهارشنبه', 'پنجشنبه', 'جمعه' );

	public static function to_jalali( $gy, $gm, $gd ) {
		$g_d_m = array( 0, 31, 59, 90, 120, 151, 181, 212, 243, 273, 304, 334 );

		$gy = (int) $gy;
		$gm = (int) $gm;
		$gd = (int) $gd;

		$gy2 = ( $gm > 2 ) ? ( $gy + 1 ) : $gy;
		$days = 355666 + ( 365 * $gy ) + (int) ( ( $gy2 + 3 ) / 4 ) - (int) ( ( $gy2 + 99 ) / 100 )
				+ (int) ( ( $gy2 + 399 ) / 400 ) + $gd + $g_d_m[ $gm - 1 ];

		$jy = -1595 + ( 33 * (int) ( $days / 12053 ) );
		$days %= 12053;

		$jy += 4 * (int) ( $days / 1461 );
		$days %= 1461;

		if ( $days > 365 ) {
			$jy += (int) ( ( $days - 1 ) / 365 );
			$days = ( $days - 1 ) % 365;
		}

		if ( $days < 186 ) {
			$jm = 1 + (int) ( $days / 31 );
			$jd = 1 + ( $days % 31 );
		} else {
			$jm = 7 + (int) ( ( $days - 186 ) / 30 );
			$jd = 1 + ( ( $days - 186 ) % 30 );
		}

		return array( $jy, $jm, $jd );
	}

	public static function to_gregorian( $jy, $jm, $jd ) {
		$jy = (int) $jy;
		$jm = (int) $jm;
		$jd = (int) $jd;

		$gy = ( $jm <= 6 ) ? ( $jy + 621 ) : ( $jy + 622 );
		$days = ( 365 * $jy ) + ( (int) ( $jy / 33 ) * 8 ) + (int) ( ( ( $jy % 33 ) + 3 ) / 4 )
				+ 78 + $jd + ( ( $jm < 7 ) ? ( $jm - 1 ) * 31 : ( ( $jm - 7 ) * 30 ) + 186 );

		$gy += 400 * (int) ( $days / 146097 );
		$days %= 146097;

		if ( $days > 36524 ) {
			$days--;
			$gy += 100 * (int) ( $days / 36524 );
			$days %= 36524;
			if ( $days >= 365 ) {
				$days++;
			}
		}

		$gy += 4 * (int) ( $days / 1461 );
		$days %= 1461;

		if ( $days > 365 ) {
			$gy += (int) ( ( $days - 1 ) / 365 );
			$days = ( $days - 1 ) % 365;
		}

		$gd = $days + 1;
		$sal_a = array(
			0, 31,
			( ( $gy % 4 === 0 && $gy % 100 !== 0 ) || ( $gy % 400 === 0 ) ) ? 29 : 28,
			31, 30, 31, 30, 31, 31, 30, 31, 30, 31,
		);

		$gm = 0;
		while ( $gm < 13 && $gd > $sal_a[ $gm ] ) {
			$gd -= $sal_a[ $gm ];
			$gm++;
		}

		return array( $gy, $gm, $gd );
	}

	public static function format( $timestamp, $with_time = true ) {
		if ( ! is_numeric( $timestamp ) ) {
			$timestamp = strtotime( (string) $timestamp );
		}

		$timestamp = (int) $timestamp;

		if ( $timestamp <= 0 ) {
			return '—';
		}

		list( $jy, $jm, $jd ) = self::to_jalali(
			(int) wp_date( 'Y', $timestamp ),
			(int) wp_date( 'n', $timestamp ),
			(int) wp_date( 'j', $timestamp )
		);

		$out = sprintf(
			'%s %s %s',
			BMC_Helpers::to_persian_digits( $jd ),
			self::MONTHS[ $jm - 1 ],
			BMC_Helpers::to_persian_digits( $jy )
		);

		if ( $with_time ) {
			$out .= ' — ' . BMC_Helpers::to_persian_digits( wp_date( 'H:i', $timestamp ) );
		}

		return $out;
	}

	public static function short( $timestamp ) {
		list( $jy, $jm, $jd ) = self::to_jalali(
			(int) wp_date( 'Y', $timestamp ),
			(int) wp_date( 'n', $timestamp ),
			(int) wp_date( 'j', $timestamp )
		);

		return sprintf(
			'%04d/%02d/%02d',
			$jy,
			$jm,
			$jd
		);
	}

	public static function weekday( $timestamp ) {

		$n = (int) wp_date( 'N', $timestamp );
		$map = array( 6 => 0, 7 => 1, 1 => 2, 2 => 3, 3 => 4, 4 => 5, 5 => 6 );
		return self::WEEKDAYS[ $map[ $n ] ];
	}
}
