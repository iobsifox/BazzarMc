<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Auth {

	const KNOWN_META_KEYS = array(
		'bmc_mobile',
		'mobile',
		'billing_phone',
		'digits_number',
		'digits_number_no',
		'digcell',
		'digits_mobile',
		'easylogin_mobile',
		'bilacell_mobile',
		'wp_sms_mobile',
		'darvaze_mobile',
		'user_mobile',
		'phone',
	);

	public static function init() {
		add_filter( 'woocommerce_checkout_get_value', array( __CLASS__, 'autofill_billing_phone' ), 10, 2 );
	}

	public static function meta_keys() {
		$configured = (array) BMC_Settings::get( 'mobile_meta_keys', array() );
		$keys       = array_merge( $configured, self::KNOWN_META_KEYS );
		$keys       = array_values( array_unique( array_filter( array_map( 'sanitize_key', $keys ) ) ) );

		return apply_filters( 'bmc_mobile_meta_keys', $keys );
	}

	public static function get_user_mobile( $user_id ) {
		$user_id = (int) $user_id;
		if ( ! $user_id ) {
			return '';
		}

		$own = BMC_Helpers::normalize_mobile( get_user_meta( $user_id, 'bmc_mobile', true ) );
		if ( $own ) {
			return $own;
		}

		foreach ( self::meta_keys() as $key ) {
			$value = get_user_meta( $user_id, $key, true );
			if ( is_array( $value ) ) {
				$value = reset( $value );
			}
			$mobile = BMC_Helpers::normalize_mobile( (string) $value );
			if ( $mobile ) {
				return $mobile;
			}
		}

		if ( function_exists( 'wc_get_orders' ) ) {
			$orders = wc_get_orders(
				array(
					'customer_id' => $user_id,
					'limit'       => 3,
					'orderby'     => 'date',
					'order'       => 'DESC',
					'return'      => 'ids',
				)
			);

			foreach ( (array) $orders as $order_id ) {
				$order = wc_get_order( $order_id );
				if ( $order ) {
					$mobile = BMC_Helpers::normalize_mobile( (string) $order->get_billing_phone() );
					if ( $mobile ) {
						return $mobile;
					}
				}
			}
		}

		return '';
	}

	public static function set_user_mobile( $user_id, $mobile ) {
		$mobile = BMC_Helpers::normalize_mobile( $mobile );
		if ( ! $mobile || ! $user_id ) {
			return false;
		}

		update_user_meta( (int) $user_id, 'bmc_mobile', $mobile );

		if ( ! get_user_meta( (int) $user_id, 'billing_phone', true ) ) {
			update_user_meta( (int) $user_id, 'billing_phone', $mobile );
		}

		return true;
	}

	public static function find_user_by_mobile( $mobile ) {
		global $wpdb;

		$mobile = BMC_Helpers::normalize_mobile( $mobile );
		if ( ! $mobile ) {
			return null;
		}

		$variants = BMC_Helpers::mobile_variants( $mobile );
		$keys     = self::meta_keys();

		if ( ! $variants || ! $keys ) {
			return null;
		}

		$in_keys     = "'" . implode( "','", array_map( 'esc_sql', $keys ) ) . "'";
		$in_variants = "'" . implode( "','", array_map( 'esc_sql', $variants ) ) . "'";

		$user_id = (int) $wpdb->get_var(
			"SELECT user_id FROM {$wpdb->usermeta}
			 WHERE meta_key IN ({$in_keys})
			   AND TRIM(meta_value) IN ({$in_variants})
			 ORDER BY (meta_key = 'bmc_mobile') DESC, user_id ASC
			 LIMIT 1"
		);

		if ( ! $user_id ) {

			$user = get_user_by( 'login', $mobile );
			if ( $user ) {
				return $user;
			}
			$user = get_user_by( 'login', substr( $mobile, 1 ) );
			return $user ? $user : null;
		}

		return get_userdata( $user_id );
	}

	public static function mask_mobile( $mobile ) {
		$mobile = BMC_Helpers::to_latin_digits( (string) $mobile );
		if ( strlen( $mobile ) < 7 ) {
			return $mobile;
		}
		return substr( $mobile, 0, 4 ) . '***' . substr( $mobile, -4 );
	}

	public static function mask_email( $email ) {
		$parts = explode( '@', (string) $email );
		if ( 2 !== count( $parts ) ) {
			return $email;
		}
		$name   = $parts[0];
		$masked = strlen( $name ) > 2 ? substr( $name, 0, 2 ) . '***' : $name . '***';
		return $masked . '@' . $parts[1];
	}

	public static function autofill_billing_phone( $value, $input ) {
		if ( 'billing_phone' === $input && ! $value && is_user_logged_in() ) {
			$mobile = self::get_user_mobile( get_current_user_id() );
			if ( $mobile ) {
				return $mobile;
			}
		}
		return $value;
	}

	public static function detected_integrations() {
		$candidates = array(
			'ایزی‌لاگین (Bigersoft)' => array( 'easylogin/easylogin.php', 'easy-login/easy-login.php', 'bigersoft-easylogin/easylogin.php' ),
			'دیجیتس (Digits)'        => array( 'digits/digits.php' ),
			'دروازه (Kamangir)'      => array( 'darvaze/darvaze.php', 'kamangir-darvaze/darvaze.php' ),
			'WP SMS'                 => array( 'wp-sms/wp-sms.php' ),
			'پیامیتو'                => array( 'payamito/payamito.php', 'payamito-plus/payamito-plus.php' ),
		);

		$active  = (array) get_option( 'active_plugins', array() );
		$network = (array) get_site_option( 'active_sitewide_plugins', array() );
		$all     = array_merge( $active, array_keys( $network ) );

		$found = array();

		foreach ( $candidates as $label => $slugs ) {
			foreach ( $slugs as $slug ) {
				if ( in_array( $slug, $all, true ) ) {
					$found[ $label ] = $slug;
					break;
				}
			}
		}

		return $found;
	}

	public static function login_url() {
		if ( function_exists( 'wc_get_page_permalink' ) ) {
			return (string) wc_get_page_permalink( 'myaccount' );
		}

		return wp_login_url();
	}
}
