<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Safe {

	const CRASH_OPTION  = 'bmc_crash_tracker';
	const NOTICE_OPTION = 'bmc_safe_notice';
	const LOG_CHANNEL   = 'safe';

	private static $booted    = false;
	private static $errors    = array();
	private static $override  = null;
	private static $recovered = false;
	private static $running   = array();

	public static function boot() {
		if ( self::$booted ) {
			return;
		}

		self::$booted = true;

		self::read_request_override();

		register_shutdown_function( array( __CLASS__, 'shutdown' ) );

		add_action( 'admin_notices', array( __CLASS__, 'admin_notice' ) );
		add_action( 'admin_init', array( __CLASS__, 'handle_admin_action' ) );

		if ( self::safe_mode() ) {
			self::recover();
		}
	}

	public static function booted() {
		return self::$booted;
	}

	public static function setting( $key, $default = null ) {
		if ( class_exists( 'BMC_Settings' ) ) {
			return BMC_Settings::get( $key, $default );
		}

		$all = get_option( 'bmc_settings', array() );

		if ( is_array( $all ) && array_key_exists( $key, $all ) ) {
			return $all[ $key ];
		}

		return $default;
	}

	public static function flag( $key, $default = false ) {
		$value = self::setting( $key, $default );

		if ( is_bool( $value ) ) {
			return $value;
		}

		if ( is_numeric( $value ) ) {
			return (bool) $value;
		}

		return in_array( strtolower( (string) $value ), array( 'yes', 'on', 'true', '1' ), true );
	}

	public static function guard( $label, callable $callback, $fallback = null ) {
		try {
			return $callback();
		} catch ( \Throwable $error ) {
			self::collect( $label, $error );

			return is_callable( $fallback ) ? $fallback( $error ) : $fallback;
		}
	}

	public static function start( $label ) {
		self::$running[ (string) $label ] = microtime( true );
	}

	public static function stop( $label ) {
		$label = (string) $label;

		if ( isset( self::$running[ $label ] ) ) {
			$elapsed = microtime( true ) - self::$running[ $label ];
			unset( self::$running[ $label ] );

			return $elapsed;
		}

		return 0;
	}

	public static function collect( $label, $error ) {
		$message = ( $error instanceof \Throwable ) ? $error->getMessage() : (string) $error;
		$file    = ( $error instanceof \Throwable ) ? $error->getFile() : '';
		$line    = ( $error instanceof \Throwable ) ? (int) $error->getLine() : 0;
		$trace   = ( $error instanceof \Throwable ) ? $error->getTraceAsString() : '';

		$record = array(
			'label'   => (string) $label,
			'message' => $message,
			'file'    => $file,
			'line'    => $line,
			'time'    => time(),
		);

		self::$errors[] = $record;

		if ( class_exists( 'BMC_Logger' ) ) {
			BMC_Logger::add(
				self::LOG_CHANNEL,
				'خطای مهارشده در ' . $label . ': ' . $message,
				array(
					'file' => $file,
					'line' => $line,
				),
				'error'
			);
		}

		error_log( 'BazzarMc Safe [' . $label . ']: ' . $message . ( $file ? ' in ' . $file . ':' . $line : '' ) );
	}

	public static function errors() {
		return self::$errors;
	}

	public static function shutdown() {
		$error = error_get_last();

		if ( ! $error ) {
			return;
		}

		$fatals = array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR );

		if ( ! in_array( $error['type'], $fatals, true ) ) {
			return;
		}

		if ( ! self::is_ours( $error ) ) {
			return;
		}

		self::record_fatal( $error );

		if ( self::flag( 'safe_autorecover', true ) ) {
			self::activate( 'auto' );
			self::recover();
		}
	}

	public static function is_ours( $error ) {
		if ( empty( $error['file'] ) ) {
			return false;
		}

		$file = wp_normalize_path( (string) $error['file'] );
		$path = wp_normalize_path( BMC_PATH );

		if ( 0 === strpos( $file, $path ) ) {
			return true;
		}

		return false !== strpos( (string) $error['message'], 'BMC_' );
	}

	public static function record_fatal( array $error ) {
		$state = self::state();

		$window = 600;
		$now    = time();

		if ( empty( $state['first'] ) || ( $now - (int) $state['first'] ) > $window ) {
			$state['first'] = $now;
			$state['count'] = 0;
		}

		$state['count'] = (int) $state['count'] + 1;
		$state['last']  = $now;
		$state['error'] = array(
			'type'    => isset( $error['type'] ) ? (int) $error['type'] : 0,
			'message' => isset( $error['message'] ) ? (string) $error['message'] : '',
			'file'    => isset( $error['file'] ) ? (string) $error['file'] : '',
			'line'    => isset( $error['line'] ) ? (int) $error['line'] : 0,
		);

		update_option( self::CRASH_OPTION, $state, false );

		$limit = (int) self::setting( 'safe_crash_limit', 2 );

		if ( $state['count'] >= $limit && self::flag( 'safe_guard', true ) ) {
			self::activate( 'auto' );
			self::notify_admin( $state );
		}
	}

	public static function state() {
		$state = get_option( self::CRASH_OPTION, array() );

		return is_array( $state ) ? array_merge(
			array(
				'count' => 0,
				'first' => 0,
				'last'  => 0,
				'error' => array(),
			),
			$state
		) : array( 'count' => 0, 'first' => 0, 'last' => 0, 'error' => array() );
	}

	public static function reset() {
		delete_option( self::CRASH_OPTION );
		delete_option( self::NOTICE_OPTION );
		self::$errors = array();

		return true;
	}

	public static function activate( $mode = 'on' ) {
		if ( ! class_exists( 'BMC_Settings' ) ) {
			return false;
		}

		$mode = 'auto' === $mode ? 'auto' : 'on';

		BMC_Settings::save( array( 'safe_mode' => $mode ) );

		self::$override = true;

		return true;
	}

	public static function deactivate() {
		if ( ! class_exists( 'BMC_Settings' ) ) {
			return false;
		}

		BMC_Settings::save(
			array(
				'safe_mode'         => 'off',
				'elementor_enabled' => 'yes',
				'myaccount_card'    => 'yes',
			)
		);

		self::$override = false;
		self::reset();

		return true;
	}

	public static function safe_mode() {
		if ( null !== self::$override ) {
			return (bool) self::$override;
		}

		if ( defined( 'BMC_SAFE_MODE' ) && BMC_SAFE_MODE ) {
			return true;
		}

		$mode = (string) self::setting( 'safe_mode', 'off' );

		return in_array( $mode, array( 'on', 'auto' ), true );
	}

	public static function safe_mode_reason() {
		if ( defined( 'BMC_SAFE_MODE' ) && BMC_SAFE_MODE ) {
			return 'constant';
		}

		if ( true === self::$override ) {
			return 'request';
		}

		$mode = (string) self::setting( 'safe_mode', 'off' );

		if ( 'auto' === $mode ) {
			return 'auto';
		}

		return 'on' === $mode ? 'manual' : '';
	}

	public static function read_request_override() {
		if ( ! isset( $_GET['bmc_safe'] ) ) {
			return;
		}

		if ( ! function_exists( 'current_user_can' ) || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		self::$override = ! empty( $_GET['bmc_safe'] ) && '0' !== (string) $_GET['bmc_safe'];
	}

	public static function recover() {
		if ( self::$recovered || ! class_exists( 'BMC_Settings' ) ) {
			return false;
		}

		self::$recovered = true;

		try {
			BMC_Settings::save(
				array(
					'elementor_enabled' => 'no',
					'myaccount_card'    => 'no',
				)
			);

			if ( class_exists( 'BMC_Logger' ) ) {
				BMC_Logger::add( 'safe', 'حالت ایمن فعال شد و بخش‌های غیرضروری خاموش شدند.', array(), 'warning' );
			}
		} catch ( \Throwable $e ) {
			self::collect( 'recover', $e );
			return false;
		}

		return true;
	}

	public static function notify_admin( array $state ) {
		if ( ! function_exists( 'get_option' ) || ! function_exists( 'wp_mail' ) ) {
			return false;
		}

		if ( get_option( self::NOTICE_OPTION ) ) {
			return false;
		}

		update_option( self::NOTICE_OPTION, time(), false );

		$emails = array_filter( array_map( 'trim', explode( ',', (string) self::setting( 'safe_notify_email', '' ) ) ) );

		if ( ! $emails ) {
			$emails = array( (string) get_option( 'admin_email' ) );
		}

		$subject = sprintf( '[%s] حالت ایمن BazzarMc فعال شد', wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ) );

		$msg  = "سلام مدیر سایت،\n\n";
		$msg .= "به‌دلیل بروز چند خطای مهلک در افزونهٔ BazzarMc، محافظ پایداری «حالت ایمن» را فعال کرد تا سایت از دسترس خارج نشود.\n\n";

		if ( ! empty( $state['error']['message'] ) ) {
			$msg .= "آخرین خطا:\n";
			$msg .= $state['error']['message'] . "\n";
			if ( ! empty( $state['error']['file'] ) ) {
				$msg .= 'در: ' . $state['error']['file'] . ':' . (int) $state['error']['line'] . "\n";
			}
			$msg .= "\n";
		}

		$msg .= "برای بررسی و غیرفعال‌کردن حالت ایمن وارد پیشخوان وردپرس شوید:\n";
		$msg .= admin_url( 'admin.php?page=bazzarmc&tab=tools' ) . "\n\n";
		$msg .= '— محافظ پایداری BazzarMc';

		foreach ( $emails as $email ) {
			if ( is_email( $email ) ) {
				wp_mail( $email, $subject, $msg );
			}
		}

		return true;
	}

	public static function admin_notice() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		if ( ! self::safe_mode() ) {
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		$url_off   = wp_nonce_url( admin_url( 'admin.php?page=bazzarmc&tab=tools&bmc_safe_action=off' ), 'bmc_safe', 'bmc_safe_nonce' );
		$url_tools = admin_url( 'admin.php?page=bazzarmc&tab=tools' );

		$reason = self::safe_mode_reason();
		$label  = 'auto' === $reason ? 'خودکار به‌دلیل خطای مهلک' : ( 'manual' === $reason ? 'دستی توسط مدیر' : 'از طریق فایل یا درخواست' );

		echo '<div class="notice notice-error is-dismissible bmc-safe-notice">';
		echo '<p><strong>حالت ایمن BazzarMc فعال است (' . esc_html( $label ) . ').</strong> ';
		echo 'ویجت‌های المنتور برای حفظ پایداری سایت غیرفعال شده‌اند.</p>';
		echo '<p><a class="button button-primary" href="' . esc_url( $url_off ) . '">خروج از حالت ایمن</a> ';
		echo '<a class="button" href="' . esc_url( $url_tools ) . '">مشاهدهٔ گزارش خطاها در تب ابزارها</a></p>';
		echo '</div>';
	}

	public static function handle_admin_action() {
		if ( empty( $_GET['bmc_safe_action'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}

		check_admin_referer( 'bmc_safe', 'bmc_safe_nonce' );

		$action = sanitize_key( wp_unslash( $_GET['bmc_safe_action'] ) );

		if ( 'on' === $action ) {
			self::activate( 'on' );
		} elseif ( 'off' === $action ) {
			self::deactivate();
		} elseif ( 'reset' === $action ) {
			self::reset();
		} elseif ( 'recover' === $action ) {
			self::recover();
		}

		wp_safe_redirect( admin_url( 'admin.php?page=bazzarmc&tab=tools&bmc_safe_done=' . rawurlencode( $action ) ) );
		exit;
	}

	public static function details_allowed() {
		return self::flag( 'safe_debug_display', false ) && function_exists( 'current_user_can' ) && current_user_can( 'manage_woocommerce' );
	}

	public static function blocked_box( $title = 'این بخش موقتاً غیرفعال است' ) {
		if ( ! function_exists( 'current_user_can' ) || ! current_user_can( 'manage_woocommerce' ) ) {
			return '';
		}

		return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">'
			. '<strong>' . esc_html( $title ) . '</strong> '
			. 'حالت ایمن BazzarMc فعال است. برای بازگردانی به پیشخوان ← BazzarMc ← ابزارها بروید.'
			. '</div></div>';
	}

	public static function health() {
		$checks = array();

		$checks[] = self::check_php();
		$checks[] = self::check_wordpress();
		$checks[] = self::check_woocommerce();
		$checks[] = self::check_elementor();
		$checks   = array_merge( $checks, self::check_files() );
		$checks   = array_merge( $checks, self::check_database() );
		$checks[] = self::check_pages();
		$checks[] = self::check_account_endpoints();
		$checks[] = self::check_delivery_queue();
		$checks[] = self::check_updater();
		$checks[] = self::check_cron();
		$checks[] = self::check_server();
		$checks[] = self::check_php_limits();
		$checks[] = self::check_safety();

		$checks = array_values( array_filter( $checks ) );

		return apply_filters( 'bmc_health_checks', $checks );
	}

	private static function check_php() {
		$status = 'ok';
		$detail = 'نسخهٔ PHP ' . PHP_VERSION;

		if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
			$status  = 'fail';
			$detail .= ' — افزونه به PHP ۷.۴ یا جدیدتر نیاز دارد.';
		} elseif ( version_compare( PHP_VERSION, '8.0', '<' ) ) {
			$status  = 'warn';
			$detail .= ' — پشتیبانی می‌شود اما PHP ۸.۱ به بالا توصیه می‌شود.';
		}

		return array(
			'key'    => 'php',
			'label'  => 'نسخهٔ PHP',
			'status' => $status,
			'detail' => $detail,
		);
	}

	private static function check_wordpress() {
		global $wp_version;

		$version = isset( $wp_version ) ? (string) $wp_version : get_bloginfo( 'version' );
		$status  = version_compare( $version, '6.0', '>=' ) ? 'ok' : 'warn';

		return array(
			'key'    => 'wp',
			'label'  => 'نسخهٔ وردپرس',
			'status' => $status,
			'detail' => 'نسخهٔ ' . $version . ( 'ok' === $status ? '' : ' — وردپرس ۶.۰ یا جدیدتر توصیه می‌شود.' ),
		);
	}

	private static function check_woocommerce() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return array(
				'key'    => 'wc',
				'label'  => 'افزونهٔ ووکامرس',
				'status' => 'fail',
				'detail' => 'ووکامرس نصب یا فعال نیست؛ فروشگاه بدون آن کار نمی‌کند.',
			);
		}

		$version = defined( 'WC_VERSION' ) ? (string) WC_VERSION : '';
		$status  = version_compare( $version, '5.0', '>=' ) ? 'ok' : 'warn';

		return array(
			'key'    => 'wc',
			'label'  => 'افزونهٔ ووکامرس',
			'status' => $status,
			'detail' => 'نسخهٔ ' . $version . ( 'ok' === $status ? '' : ' — ووکامرس ۵.۰ یا جدیدتر توصیه می‌شود.' ),
		);
	}

	private static function check_elementor() {
		if ( ! class_exists( '\Elementor\Plugin' ) ) {
			return array(
				'key'    => 'elementor',
				'label'  => 'یکپارچگی المنتور',
				'status' => 'info',
				'detail' => 'المنتور فعال نیست؛ ویجت‌های اختصاصی غیرفعال‌اند و افزونه با شورت‌کدها کار می‌کند.',
			);
		}

		$version   = defined( 'ELEMENTOR_VERSION' ) ? (string) ELEMENTOR_VERSION : '';
		$supported = version_compare( $version, '3.1.0', '>=' );

		return array(
			'key'    => 'elementor',
			'label'  => 'یکپارچگی المنتور',
			'status' => $supported ? 'ok' : 'warn',
			'detail' => 'نسخهٔ المنتور: ' . $version . ( $supported ? ' — ویجت‌ها آمادهٔ ثبت هستند.' : ' — المنتور ۳.۱ به بالا برای ثبت ویجت‌ها نیاز است.' ),
		);
	}

	private static function check_account_endpoints() {
		if ( ! class_exists( 'BMC_Account_Endpoints' ) ) {
			return array();
		}

		$rows   = BMC_Account_Endpoints::status_rows();
		$parts  = array();
		$status = 'ok';

		foreach ( $rows as $row ) {
			$parts[] = $row['label'] . ': ' . $row['slug'] . ( $row['in_menu'] ? '' : ' (پنهان)' );

			if ( empty( $row['url'] ) ) {
				$status = 'warn';
			}
		}

		if ( get_option( BMC_Account_Endpoints::FLUSH_OPTION, 0 ) ) {
			$status  = 'warn';
			$parts[] = 'بازسازی پیوندهای یکتا در انتظار اجرا است';
		}

		return array(
			'key'    => 'account_endpoints',
			'label'  => 'نقطه‌های فرود حساب کاربری',
			'status' => $status,
			'detail' => implode( ' — ', $parts ),
		);
	}

	private static function check_delivery_queue() {
		if ( ! class_exists( 'BMC_Deliveries' ) ) {
			return array();
		}

		$stuck  = BMC_Deliveries::stuck_rows();
		$count  = count( $stuck );
		$status = 'ok';
		$detail = 'همهٔ خریدهای در صف، تحویل داده شده‌اند.';

		if ( $count ) {
			$status = $count > 5 ? 'fail' : 'warn';

			$reasons = array();

			foreach ( $stuck as $row ) {
				$note = isset( $row->note ) ? trim( (string) $row->note ) : '';

				if ( '' !== $note ) {
					$reasons[ $note ] = isset( $reasons[ $note ] ) ? $reasons[ $note ] + 1 : 1;
				} else {
					$reasons['بدون گزارش از سرور بازی'] = 1;
				}
			}

			arsort( $reasons );

			$parts = array();

			foreach ( array_slice( $reasons, 0, 2, true ) as $reason => $times ) {
				$parts[] = $reason . ( $times > 1 ? ' (' . $times . ' مورد)' : '' );
			}

			$detail = sprintf( '%d خرید در صف گیر کرده است — %s', $count, implode( ' | ', $parts ) );
		}

		return array(
			'key'    => 'deliveries',
			'label'  => 'صف تحویل',
			'status' => $status,
			'detail' => $detail,
		);
	}

	private static function check_updater() {
		if ( ! class_exists( 'BMC_Updater' ) ) {
			return array();
		}

		return BMC_Updater::health_row();
	}

	private static function check_files() {
		$out      = array();
		$includes = array(
			'includes/class-bmc-icons.php',
			'includes/class-bmc-roles.php',
			'includes/class-bmc-ranks.php',
			'includes/class-bmc-helpers.php',
			'includes/class-bmc-jalali.php',
			'includes/class-bmc-logger.php',
			'includes/class-bmc-settings.php',
			'includes/class-bmc-safe.php',
			'includes/class-bmc-db.php',
			'includes/class-bmc-link.php',
			'includes/integrations/class-bmc-elementor.php',
			'includes/class-bmc-verify.php',
			'includes/class-bmc-cache.php',
			'includes/class-bmc-api.php',
			'includes/class-bmc-deliveries.php',
			'includes/class-bmc-auth.php',
			'includes/class-bmc-account-endpoints.php',
			'includes/class-bmc-account-card.php',
			'includes/class-bmc-updater.php',
			'includes/class-bmc-cron.php',
			'includes/class-bmc-public.php',
			'includes/class-bmc-admin.php',
			'includes/class-bmc-migrate.php',
		);

		$missing = array();

		foreach ( $includes as $file ) {
			if ( ! file_exists( BMC_PATH . $file ) ) {
				$missing[] = $file;
			}
		}

		$out[] = array(
			'key'    => 'includes',
			'label'  => 'فایل‌های هسته',
			'status' => $missing ? 'fail' : 'ok',
			'detail' => $missing ? 'فایل‌های گمشده: ' . implode( ', ', $missing ) : 'هر ' . count( $includes ) . ' فایل کلاس موجود است.',
		);

		$templates = array( 'account-card', 'account-nav', 'deliveries', 'link-box', 'ranks', 'wc-dashboard', 'wc-navigation' );
		$missing_t = array();

		foreach ( $templates as $tpl ) {
			if ( ! is_readable( BMC_PATH . 'public/templates/' . $tpl . '.php' ) ) {
				$missing_t[] = $tpl . '.php';
			}
		}

		$out[] = array(
			'key'    => 'templates',
			'label'  => 'قالب‌های نمایشی',
			'status' => $missing_t ? 'fail' : 'ok',
			'detail' => $missing_t ? 'قالب‌های گمشده: ' . implode( ', ', $missing_t ) : 'هر ' . count( $templates ) . ' قالب موجود و خوانا است.',
		);

		$assets = array(
			'assets/css/bmc-public.css',
			'assets/css/bmc-elementor.css',
			'assets/css/bmc-admin.css',
			'assets/js/bmc-icons.js',
			'assets/js/bmc-link.js',
			'assets/js/bmc-nav.js',
			'assets/js/bmc-admin.js',
		);
		$missing_a = array();

		foreach ( $assets as $asset ) {
			if ( ! is_readable( BMC_PATH . $asset ) ) {
				$missing_a[] = $asset;
			}
		}

		$out[] = array(
			'key'    => 'assets',
			'label'  => 'فایل‌های استایل و اسکریپت',
			'status' => $missing_a ? 'fail' : 'ok',
			'detail' => $missing_a ? 'گمشده: ' . implode( ', ', $missing_a ) : 'هر ' . count( $assets ) . ' فایل موجود است.',
		);

		return $out;
	}

	private static function check_database() {
		global $wpdb;

		$out    = array();
		$status = 'ok';

		if ( ! class_exists( 'BMC_DB' ) ) {
			return array( array( 'key' => 'db', 'label' => 'جدول‌های دیتابیس', 'status' => 'fail', 'detail' => 'کلاس دیتابیس بارگذاری نشده است.' ) );
		}

		try {
			$tables = BMC_DB::table_status();
		} catch ( \Throwable $e ) {
			self::collect( 'health:db', $e );

			return array( array( 'key' => 'db', 'label' => 'جدول‌های دیتابیس', 'status' => 'fail', 'detail' => 'خطا در خواندن وضعیت جدول‌ها: ' . $e->getMessage() ) );
		}

		$missing = array();
		$rows    = array();

		foreach ( $tables as $name => $info ) {
			if ( empty( $info['exists'] ) ) {
				$missing[] = $name;
			} else {
				$rows[] = $name . ': ' . (int) $info['rows'];
			}
		}

		if ( $missing ) {
			$status = 'fail';
		}

		$out[] = array(
			'key'    => 'db',
			'label'  => 'جدول‌های دیتابیس',
			'status' => $status,
			'detail' => $missing ? 'جدول‌های ساخته‌نشده: ' . implode( ', ', $missing ) . ' — دکمهٔ «بازسازی جدول‌ها» را بزنید.' : implode( ' | ', $rows ),
		);

		$version = function_exists( 'get_option' ) ? (string) get_option( 'bmc_db_version', '' ) : '';

		$out[] = array(
			'key'    => 'db_version',
			'label'  => 'نسخهٔ ساختار دیتابیس',
			'status' => ( $version && defined( 'BMC_DB_VERSION' ) && version_compare( $version, BMC_DB_VERSION, '<' ) ) ? 'warn' : 'ok',
			'detail' => 'نصب‌شده: ' . ( $version ? $version : '—' ) . ' | موردنیاز: ' . ( defined( 'BMC_DB_VERSION' ) ? BMC_DB_VERSION : '—' ),
		);

		unset( $wpdb );

		return $out;
	}

	private static function check_pages() {
		$labels = array(
			'page_link' => 'صفحهٔ اتصال اکانت',
		);

		$missing = array();

		foreach ( $labels as $key => $label ) {
			$id = (int) self::setting( $key, 0 );

			if ( ! $id || 'publish' !== get_post_status( $id ) ) {
				$missing[] = $label;
			}
		}

		return array(
			'key'    => 'pages',
			'label'  => 'صفحه‌های افزونه',
			'status' => $missing ? 'warn' : 'ok',
			'detail' => $missing ? 'تنظیم نشده یا منتشر نشده: ' . implode( '، ', $missing ) : 'صفحهٔ اتصال اکانت تنظیم و منتشر شده است.',
		);
	}

	private static function check_cron() {
		$next = function_exists( 'wp_next_scheduled' ) ? wp_next_scheduled( 'bmc_hourly_maintenance' ) : false;

		return array(
			'key'    => 'cron',
			'label'  => 'زمان‌بندی نگهداری',
			'status' => $next ? 'ok' : 'warn',
			'detail' => $next ? 'اجرای بعدی: ' . ( function_exists( 'wp_date' ) ? wp_date( 'Y-m-d H:i', $next ) : gmdate( 'Y-m-d H:i', (int) $next ) ) : 'زمان‌بندی ثبت نشده — از دکمهٔ «اجرای دستی نگهداری» استفاده کنید.',
		);
	}

	private static function check_server() {
		$token = (string) self::setting( 'api_token', '' );
		$ping  = function_exists( 'rest_url' ) ? rest_url( 'bazzarmc/v1/ping' ) : '';

		if ( ! $ping ) {
			return array(
				'key'    => 'server',
				'label'  => 'مسیر REST پلاگین ماینکرافت',
				'status' => 'warn',
				'detail' => 'rest_url در دسترس نیست.',
			);
		}

		$timeout = (int) apply_filters( 'bmc_http_timeout', 8 );
		$status  = 'ok';
		$detail  = '';

		try {
			$response = wp_remote_get(
				$ping,
				array(
					'timeout'     => min( 8, max( 3, $timeout ) ),
					'redirection' => 0,
					'headers'     => array( 'X-BMC-Token' => $token ),
					'sslverify'   => self::flag( 'ssl_verify', true ),
				)
			);

			if ( is_wp_error( $response ) ) {
				$status = 'warn';
				$detail = 'پینگ داخلی خطا داد: ' . $response->get_error_message();
			} else {
				$code = (int) wp_remote_retrieve_response_code( $response );
				$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );

				if ( 200 === $code && is_array( $body ) && ( ! empty( $body['ok'] ) || ! empty( $body['success'] ) ) ) {
					$detail = 'مسیر <code dir="ltr">bazzarmc/v1/ping</code> سالم پاسخ داد (کد ۲۰۰).';
				} else {
					$status = 'warn';
					$detail = 'پینگ پاسخ غیرمنتظره داد (کد ' . $code . ').';
					if ( is_array( $body ) && ! empty( $body['message'] ) ) {
						$detail .= ' پیام: ' . sanitize_text_field( (string) $body['message'] );
					}
				}
			}
		} catch ( \Throwable $e ) {
			self::collect( 'health:ping', $e );
			$status = 'warn';
			$detail = 'پینگ با خطا مواجه شد: ' . $e->getMessage();
		}

		if ( ! $token ) {
			$status = 'fail';
			$detail = 'توکن API ساخته نشده است؛ پلاگین ماینکرافت نمی‌تواند متصل شود.';
		}

		if ( self::flag( 'mojang_check', true ) ) {
			try {
				$mojang = wp_remote_get( 'https://api.mojang.com/users/profiles/minecraft/Notch', array( 'timeout' => 6 ) );
				$detail .= is_wp_error( $mojang )
					? ' | بررسی نام کاربری موجانگ: در دسترس نیست (' . $mojang->get_error_message() . ')'
					: ' | بررسی نام کاربری موجانگ: در دسترس (کد ' . (int) wp_remote_retrieve_response_code( $mojang ) . ')';
			} catch ( \Throwable $e ) {
				self::collect( 'health:mojang', $e );
				$detail .= ' | بررسی موجانگ با خطا مواجه شد.';
			}
		}

		if ( class_exists( 'BMC_API' ) ) {
			$activity = BMC_API::activity_summary();

			if ( ! empty( $activity['connected'] ) ) {
				$detail .= ' | آخرین درخواست موفق از سرور بازی: ' . $activity['ok_ago'] . ' پیش (' . $activity['ok_count'] . ' درخواست موفق از ' . $activity['ok_ip'] . ')';
			} elseif ( (int) $activity['fail_count'] > 0 ) {
				$status  = 'fail';
				$detail .= ' | سرور بازی درخواست می‌فرستد ولی توکن رد می‌شود (' . $activity['fail_count'] . ' بار؛ آخرین تلاش ' . $activity['fail_ago'] . ' پیش از ' . $activity['fail_ip'] . ')';
			} else {
				if ( 'ok' === $status ) {
					$status = 'warn';
				}

				$detail .= ' | هنوز هیچ درخواستی از سرور بازی ثبت نشده است';
			}
		}

		return array(
			'key'    => 'server',
			'label'  => 'اتصال و REST',
			'status' => $status,
			'detail' => $detail,
		);
	}

	private static function check_php_limits() {
		$memory = ini_get( 'memory_limit' );
		$bytes  = function_exists( 'wp_convert_hr_to_bytes' ) ? wp_convert_hr_to_bytes( $memory ) : 0;
		$status = ( $bytes && $bytes < 128 * 1024 * 1024 && -1 !== (int) $bytes ) ? 'warn' : 'ok';

		return array(
			'key'    => 'php_limits',
			'label'  => 'محدودیت‌های PHP',
			'status' => $status,
			'detail' => 'memory_limit: ' . ( $memory ? $memory : '—' ) . ( 'warn' === $status ? ' (۱۲۸ مگابایت یا بیشتر پیشنهاد می‌شود)' : '' ),
		);
	}

	private static function check_safety() {
		$safe_mode = self::safe_mode();
		$state     = self::state();

		$status = 'ok';
		$detail = 'سایت در وضعیت عادی کار می‌کند و محافظ فعال است.';

		if ( $safe_mode ) {
			$status = 'warn';
			$detail = 'حالت ایمن فعال است (' . self::safe_mode_reason() . ').';
		} elseif ( ! empty( $state['count'] ) ) {
			$status = 'warn';
			$detail = sprintf( '%d خطای مهلک در ۱۰ دقیقهٔ اخیر ثبت شده است.', (int) $state['count'] );
		}

		return array(
			'key'    => 'safety',
			'label'  => 'محافظ پایداری',
			'status' => $status,
			'detail' => $detail,
		);
	}

	public static function status_labels() {
		return array(
			'ok'   => 'سالم',
			'warn' => 'هشدار',
			'fail' => 'خطا',
			'info' => 'اطلاعات',
		);
	}
}
