<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Updater {

	const CACHE_OPTION   = 'bmc_update_cache';
	const NOTICE_OPTION  = 'bmc_update_notice_dismissed';
	const SLUG           = 'bazzarmc';
	const API_BASE       = 'https://api.github.com';
	const DEFAULT_REPO   = 'iobsifox/BazzarMc';

	public static function init() {
		add_filter( 'pre_set_site_transient_update_plugins', array( __CLASS__, 'check_transient' ), 20, 1 );
		add_filter( 'site_transient_update_plugins', array( __CLASS__, 'check_transient' ), 20, 1 );
		add_filter( 'plugins_api', array( __CLASS__, 'plugin_info' ), 20, 3 );
		add_filter( 'auto_update_plugin', array( __CLASS__, 'maybe_auto_update' ), 10, 2 );
		add_filter( 'http_request_args', array( __CLASS__, 'request_args' ), 10, 2 );
		add_action( 'upgrader_process_complete', array( __CLASS__, 'after_install' ), 10, 2 );
		add_action( 'admin_notices', array( __CLASS__, 'admin_notice' ) );
		add_action( 'bmc_maintenance', array( __CLASS__, 'scheduled_check' ) );

		add_action( 'wp_ajax_bmc_update_check', array( __CLASS__, 'ajax_check' ) );
		add_action( 'wp_ajax_bmc_update_dismiss', array( __CLASS__, 'ajax_dismiss' ) );

		add_filter( 'plugin_row_meta', array( __CLASS__, 'row_meta' ), 10, 4 );
		add_action( 'load-plugins.php', array( __CLASS__, 'maybe_force_check' ) );
		add_action( 'admin_notices', array( __CLASS__, 'check_notice' ) );
	}

	public static function row_meta( $meta, $plugin_file = '', $plugin_data = array(), $status = '' ) {
		unset( $plugin_data, $status );

		if ( ! is_array( $meta ) || BMC_BASENAME !== (string) $plugin_file || ! self::enabled() ) {
			return $meta;
		}

		if ( ! current_user_can( 'update_plugins' ) || ! BMC_Settings::bool( 'update_row_link', true ) ) {
			return $meta;
		}

		$url = wp_nonce_url( admin_url( 'plugins.php?bmc_check_update=1' ), 'bmc_check_update' );

		$meta[] = '<a href="' . esc_url( $url ) . '">' . esc_html( 'بررسی به‌روزرسانی BazzarMc' ) . '</a>';

		if ( self::has_update() ) {
			$cache  = self::cache();
			$update = admin_url( 'update-core.php' );

			$meta[] = '<a class="bmc-update-row" href="' . esc_url( $update ) . '"><strong>'
				. esc_html( 'نسخهٔ ' . $cache['version'] . ' آمادهٔ نصب است' ) . '</strong></a>';
		}

		return $meta;
	}

	public static function maybe_force_check() {
		if ( empty( $_GET['bmc_check_update'] ) ) {
			return;
		}

		if ( ! BMC_Settings::bool( 'update_check_plugins_page', true ) ) {
			return;
		}

		if ( ! current_user_can( 'update_plugins' ) ) {
			return;
		}

		check_admin_referer( 'bmc_check_update' );

		self::clear_cache();

		$info = self::fetch( true );

		delete_site_transient( 'update_plugins' );

		set_transient( 'bmc_update_check_result', self::status( $info ), 120 );

		wp_safe_redirect( admin_url( 'plugins.php?bmc_checked=1' ) );
		exit;
	}

	public static function check_notice() {
		if ( empty( $_GET['bmc_checked'] ) ) {
			return;
		}

		$status = get_transient( 'bmc_update_check_result' );

		if ( ! is_array( $status ) ) {
			return;
		}

		delete_transient( 'bmc_update_check_result' );

		if ( ! empty( $status['error'] ) ) {
			echo '<div class="notice notice-error is-dismissible"><p><strong>BazzarMc:</strong> '
				. esc_html( 'بررسی به‌روزرسانی ناموفق بود — ' . $status['error'] ) . '</p></div>';

			return;
		}

		if ( empty( $status['has_update'] ) ) {
			echo '<div class="notice notice-success is-dismissible"><p><strong>BazzarMc:</strong> '
				. esc_html( 'شما آخرین نسخه (' . $status['current'] . ') را نصب دارید.' ) . '</p></div>';

			return;
		}

		echo '<div class="notice notice-warning"><p><strong>BazzarMc:</strong> '
			. esc_html( 'نسخهٔ ' . $status['latest'] . ' در دسترس است. ' )
			. '<a class="button button-primary" href="' . esc_url( admin_url( 'plugins.php' ) ) . '">'
			. esc_html( 'همین حالا به‌روزرسانی کنید' ) . '</a></p></div>';
	}

	public static function enabled() {
		return BMC_Settings::bool( 'update_enabled', true );
	}

	public static function repo() {
		$repo = (string) BMC_Settings::get( 'update_repo', self::DEFAULT_REPO );

		return '' === trim( $repo ) ? self::DEFAULT_REPO : trim( $repo );
	}

	public static function channel() {
		return (string) BMC_Settings::get( 'update_channel', 'stable' );
	}

	public static function token() {
		return (string) BMC_Settings::get( 'update_token', '' );
	}

	public static function ttl_seconds() {
		return max( 1, BMC_Settings::int( 'update_ttl', 6, 1, 168 ) ) * HOUR_IN_SECONDS;
	}

	public static function release_url() {
		return 'https://github.com/' . self::repo() . '/releases';
	}

	public static function cache() {
		$cache = get_option( self::CACHE_OPTION, array() );

		if ( ! is_array( $cache ) ) {
			$cache = array();
		}

		return array_merge(
			array(
				'checked_at'   => 0,
				'version'      => '',
				'tag'          => '',
				'url'          => '',
				'package'      => '',
				'notes'        => '',
				'published_at' => '',
				'mc_jar'       => '',
				'mc_jar_url'   => '',
				'error'        => '',
			),
			$cache
		);
	}

	public static function is_fresh() {
		$cache = self::cache();

		return $cache['checked_at'] && ( time() - (int) $cache['checked_at'] ) < self::ttl_seconds();
	}

	public static function has_update() {
		if ( ! self::enabled() ) {
			return false;
		}

		$cache = self::cache();

		if ( '' === $cache['version'] || '' === $cache['package'] ) {
			return false;
		}

		return version_compare( $cache['version'], BMC_VERSION, '>' );
	}

	public static function request_args( $args, $url ) {
		if ( ! is_array( $args ) || ! is_string( $url ) ) {
			return $args;
		}

		$host = wp_parse_url( $url, PHP_URL_HOST );

		if ( 'api.github.com' !== $host ) {
			return $args;
		}

		if ( ! isset( $args['headers'] ) || ! is_array( $args['headers'] ) ) {
			$args['headers'] = array();
		}

		$args['headers']['User-Agent'] = 'BazzarMc/' . BMC_VERSION . ' (+https://github.com/' . self::repo() . ')';

		if ( ! isset( $args['headers']['Accept'] ) ) {
			$args['headers']['Accept'] = 'application/vnd.github+json';
		}

		if ( ! isset( $args['headers']['X-GitHub-Api-Version'] ) ) {
			$args['headers']['X-GitHub-Api-Version'] = '2022-11-28';
		}

		$token = self::token();

		if ( '' !== $token ) {
			$args['headers']['Authorization'] = 'Bearer ' . $token;
		}

		return $args;
	}

	public static function fetch( $force = false ) {
		if ( ! $force && self::is_fresh() ) {
			return self::cache();
		}

		$cache = self::cache();

		if ( ! self::enabled() ) {
			return $cache;
		}

		$url      = self::API_BASE . '/repos/' . self::repo() . '/releases?per_page=20';
		$response = wp_remote_get( $url, array( 'timeout' => 15, 'headers' => array() ) );

		$cache['checked_at'] = time();

		if ( is_wp_error( $response ) ) {
			$cache['error'] = $response->get_error_message();
			update_option( self::CACHE_OPTION, $cache, false );

			return $cache;
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );

		if ( 200 !== $code || ! is_array( $body ) ) {
			$cache['error'] = sprintf( 'پاسخ نامعتبر از گیت‌هاب (کد %d)', $code );
			update_option( self::CACHE_OPTION, $cache, false );

			return $cache;
		}

		$release = self::pick_release( $body );

		if ( ! $release ) {
			$cache['error']   = 'ریلیزی مطابق کانال انتخابی یافت نشد.';
			$cache['version'] = '';
			update_option( self::CACHE_OPTION, $cache, false );

			return $cache;
		}

		$version = self::release_version( $release );
		$assets  = isset( $release['assets'] ) && is_array( $release['assets'] ) ? $release['assets'] : array();

		$cache['error']        = '';
		$cache['version']      = $version;
		$cache['tag']          = isset( $release['tag_name'] ) ? (string) $release['tag_name'] : '';
		$cache['url']          = isset( $release['html_url'] ) ? (string) $release['html_url'] : self::release_url();
		$cache['published_at'] = isset( $release['published_at'] ) ? (string) $release['published_at'] : '';
		$cache['notes']        = self::clean_notes( isset( $release['body'] ) ? (string) $release['body'] : '' );
		$cache['package']      = self::find_asset( $assets, 'zip', 'bazzarmc-', $version );
		$cache['mc_jar']       = '';
		$cache['mc_jar_url']   = '';

		$jar = self::find_asset( $assets, 'jar', 'BazzarMC-' );

		if ( $jar ) {
			$cache['mc_jar']     = basename( (string) $jar );
			$cache['mc_jar_url'] = $jar;
		}

		if ( '' === $cache['package'] ) {
			$cache['error'] = 'فایل نصب (zip) در ریلیز ' . $cache['tag'] . ' پیدا نشد.';
		}

		update_option( self::CACHE_OPTION, $cache, false );

		self::maybe_notify( $cache );

		return $cache;
	}

	private static function maybe_notify( array $cache ) {
		if ( ! self::enabled() || '' === $cache['version'] || version_compare( $cache['version'], BMC_VERSION, '<=' ) ) {
			return;
		}

		if ( (string) get_option( 'bmc_update_notified', '' ) === (string) $cache['version'] ) {
			return;
		}

		$raw   = (string) BMC_Settings::get( 'update_notify_email', '' );
		$parts = preg_split( '/[\s,;]+/', $raw );
		$to    = array();

		foreach ( (array) $parts as $part ) {
			$part = sanitize_email( trim( (string) $part ) );

			if ( $part ) {
				$to[] = $part;
			}
		}

		$to = array_slice( array_unique( $to ), 0, 5 );

		if ( ! $to ) {
			return;
		}

		$site  = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );
		$body  = "نسخهٔ جدید افزونهٔ BazzarMc منتشر شد.

";
		$body .= 'نسخهٔ نصب‌شده: ' . BMC_VERSION . "
";
		$body .= 'نسخهٔ منتشرشده: ' . $cache['version'] . "
";
		$body .= 'کانال انتشار: ' . ( 'prerelease' === self::channel() ? 'پیش‌انتشار' : 'پایدار' ) . "
";
		$body .= 'نشانی ریلیز: ' . $cache['url'] . "
";

		if ( '' !== $cache['mc_jar'] ) {
			$body .= 'پلاگین ماینکرافت همراه این نسخه: ' . $cache['mc_jar'] . "
";
		}

		$body .= "
برای به‌روزرسانی: پیشخوان ← افزونه‌ها ← BazzarMc ← «به‌روزرسانی»
";
		$body .= 'یا: ' . admin_url( 'admin.php?page=bazzarmc&tab=tools' ) . "
";

		$sent = wp_mail(
			$to,
			sprintf( '[%s] نسخهٔ %s افزونهٔ BazzarMc منتشر شد', $site, $cache['version'] ),
			$body
		);

		if ( $sent ) {
			update_option( 'bmc_update_notified', $cache['version'], false );

			if ( class_exists( 'BMC_Logger' ) ) {
				BMC_Logger::add( 'update', sprintf( 'ایمیل اطلاع‌رسانی نسخهٔ %s ارسال شد.', $cache['version'] ), array(), 'info' );
			}
		}
	}

	private static function pick_release( array $releases ) {
		$prerelease_ok = 'prerelease' === self::channel();

		foreach ( $releases as $release ) {
			if ( ! is_array( $release ) ) {
				continue;
			}

			if ( ! empty( $release['draft'] ) ) {
				continue;
			}

			if ( ! $prerelease_ok && ! empty( $release['prerelease'] ) ) {
				continue;
			}

			if ( '' === self::release_version( $release ) ) {
				continue;
			}

			return $release;
		}

		return null;
	}

	public static function release_version( $release ) {
		if ( ! is_array( $release ) ) {
			return '';
		}

		$tag = isset( $release['tag_name'] ) ? trim( (string) $release['tag_name'] ) : '';

		if ( '' === $tag ) {
			$tag = isset( $release['name'] ) ? trim( (string) $release['name'] ) : '';
		}

		$tag = ltrim( $tag, 'vV' );

		return preg_match( '/^\d+\.\d+(\.\d+)?([.-][A-Za-z0-9.\-]+)?$/', $tag ) ? $tag : '';
	}

	private static function find_asset( array $assets, $extension, $prefix, $version = '' ) {
		$exact    = '';
		$prefixed = '';
		$fallback = '';

		foreach ( $assets as $asset ) {
			if ( ! is_array( $asset ) ) {
				continue;
			}

			$name = isset( $asset['name'] ) ? (string) $asset['name'] : '';
			$url  = isset( $asset['browser_download_url'] ) ? (string) $asset['browser_download_url'] : '';

			if ( '' === $name || '' === $url ) {
				continue;
			}

			if ( '.' . $extension !== strtolower( substr( $name, -1 - strlen( $extension ) ) ) ) {
				continue;
			}

			if ( '' !== $version && strtolower( $name ) === strtolower( $prefix . $version . '.' . $extension ) ) {
				$exact = $url;
				continue;
			}

			if ( '' === $prefixed && 0 === strpos( $name, $prefix ) ) {
				$prefixed = $url;
			}

			if ( '' === $fallback ) {
				$fallback = $url;
			}
		}

		if ( '' !== $exact ) {
			return $exact;
		}

		if ( '' !== $prefixed ) {
			return $prefixed;
		}

		return '' !== $version ? '' : $fallback;
	}

	private static function clean_notes( $notes ) {
		$notes = trim( (string) $notes );

		if ( '' === $notes ) {
			return '';
		}

		if ( function_exists( 'mb_substr' ) ) {
			$notes = mb_substr( $notes, 0, 12000 );
		} else {
			$notes = substr( $notes, 0, 12000 );
		}

		return $notes;
	}

	public static function check_transient( $transient ) {
		if ( ! is_object( $transient ) ) {
			return $transient;
		}

		if ( ! self::enabled() ) {
			if ( isset( $transient->response ) && is_array( $transient->response ) ) {
				unset( $transient->response[ BMC_BASENAME ] );
			}

			return $transient;
		}

		$info = self::fetch();

		if ( ! isset( $transient->response ) || ! is_array( $transient->response ) ) {
			$transient->response = array();
		}

		if ( '' === $info['version'] || '' === $info['package'] || version_compare( $info['version'], BMC_VERSION, '<=' ) ) {
			unset( $transient->response[ BMC_BASENAME ] );

			return $transient;
		}

		$transient->response[ BMC_BASENAME ] = self::update_object( $info );

		return $transient;
	}

	private static function update_object( array $info ) {
		return (object) array(
			'id'            => self::SLUG . '-' . $info['version'],
			'slug'          => self::SLUG,
			'plugin'        => BMC_BASENAME,
			'new_version'   => $info['version'],
			'url'           => $info['url'] ? $info['url'] : self::release_url(),
			'package'       => $info['package'],
			'icons'         => array(),
			'banners'       => array(),
			'banners_rtl'   => array(),
			'tested'        => get_bloginfo( 'version' ),
			'requires_php'  => '7.4',
			'requires'      => '6.0',
			'compatibility' => new stdClass(),
			'autoload'      => false,
		);
	}

	public static function plugin_info( $result, $action, $args ) {
		if ( 'plugin_information' !== $action || ! is_object( $args ) ) {
			return $result;
		}

		$slug = isset( $args->slug ) ? (string) $args->slug : '';

		if ( self::SLUG !== $slug && BMC_BASENAME !== $slug && 'bazzarmc/bazzarmc' !== $slug ) {
			return $result;
		}

		$info = self::fetch();

		if ( '' === $info['version'] ) {
			return $result;
		}

		$changelog = '' !== $info['notes'] ? $info['notes'] : 'یادداشت این نسخه در گیت‌هاب ثبت نشده است.';

		return (object) array(
			'name'              => 'BazzarMc',
			'slug'              => self::SLUG,
			'version'           => $info['version'],
			'author'            => '<a href="https://github.com/iobsifox">Obsifox Studio</a>',
			'homepage'          => 'https://github.com/' . self::repo(),
			'requires'          => '6.0',
			'tested'            => get_bloginfo( 'version' ),
			'requires_php'      => '7.4',
			'last_updated'      => $info['published_at'],
			'download_link'     => $info['package'],
			'sections'          => array(
				'description'    => self::description_html( $info ),
				'installation'   => '<p>از همین پنجره دکمهٔ «به‌روزرسانی» را بزنید؛ افزونه به‌صورت خودکار از ریلیز گیت‌هاب دانلود و جایگزین می‌شود. تنظیمات، جداول و تیکت‌ها حفظ می‌مانند.</p>',
				'changelog'      => '<div dir="rtl">' . wpautop( esc_html( $changelog ) ) . '</div>',
			),
			'short_description' => 'اتصال فروشگاه ووکامرس به سرور ماینکرافت — تحویل خودکار رنک و آیتم، ویترین محصولات، تیکت پشتیبانی و ویجت‌های المنتور.',
			'downloaded'        => 0,
			'rating'            => 0,
			'ratings'           => array(),
			'is_community'      => true,
			'external'          => true,
			'icons'             => array(),
			'banners'           => array(),
		);
	}

	private static function description_html( array $info ) {
		$jar = '' !== $info['mc_jar'] ? $info['mc_jar'] : '—';

		return '<div dir="rtl">'
			. '<p><strong>نسخهٔ منتشرشده:</strong> ' . esc_html( $info['version'] ) . ' (' . esc_html( $info['tag'] ) . ')</p>'
			. '<p><strong>پلاگین ماینکرافت همراه این نسخه:</strong> ' . esc_html( $jar ) . '</p>'
			. '<p><strong>نسخهٔ نصب‌شدهٔ شما:</strong> ' . esc_html( BMC_VERSION ) . '</p>'
			. '<p>منبع انتشار: <a href="' . esc_url( $info['url'] ) . '" target="_blank" rel="noopener">ریلیزهای گیت‌هاب</a></p>'
			. '</div>';
	}

	public static function maybe_auto_update( $update, $item ) {
		if ( ! is_object( $item ) ) {
			return $update;
		}

		$is_self = ( isset( $item->slug ) && self::SLUG === $item->slug )
			|| ( isset( $item->plugin ) && BMC_BASENAME === $item->plugin );

		if ( ! $is_self ) {
			return $update;
		}

		return $update || BMC_Settings::bool( 'update_auto', false );
	}

	public static function after_install( $upgrader, $hook_extra ) {
		if ( ! is_array( $hook_extra ) ) {
			return;
		}

		if ( ! isset( $hook_extra['action'] ) || 'update' !== $hook_extra['action'] ) {
			return;
		}

		if ( ! isset( $hook_extra['type'] ) || 'plugin' !== $hook_extra['type'] ) {
			return;
		}

		$plugins = isset( $hook_extra['plugins'] ) && is_array( $hook_extra['plugins'] ) ? $hook_extra['plugins'] : array();

		if ( ! in_array( BMC_BASENAME, $plugins, true ) ) {
			return;
		}

		delete_option( self::CACHE_OPTION );
		delete_option( self::NOTICE_OPTION );

		if ( class_exists( 'BMC_Logger' ) ) {
			BMC_Logger::add( 'update', 'افزونه از راه به‌روزرسانی وردپرس جایگزین شد.', array(), 'success' );
		}
	}

	public static function scheduled_check() {
		if ( ! self::enabled() ) {
			return;
		}

		if ( self::is_fresh() ) {
			return;
		}

		self::fetch( true );
	}

	public static function admin_notice() {
		if ( ! self::enabled() || ! BMC_Settings::bool( 'update_notice', true ) || ! self::has_update() ) {
			return;
		}

		if ( ! current_user_can( 'update_plugins' ) ) {
			return;
		}

		$info = self::cache();

		if ( (string) get_option( self::NOTICE_OPTION, '' ) === (string) $info['version'] ) {
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;

		if ( $screen && 'plugins' === $screen->id ) {
			return;
		}

		printf(
			'<div class="notice notice-info is-dismissible bmc-update-notice" data-version="%1$s"><p><strong>BazzarMc</strong> — نسخهٔ %2$s منتشر شده است (نسخهٔ نصب‌شده: %3$s).</p><p><a class="button button-primary" href="%4$s">به‌روزرسانی از صفحهٔ افزونه‌ها</a> <a class="button" href="%5$s" target="_blank" rel="noopener">یادداشت‌های نسخه</a> <button type="button" class="button-link bmc-update-dismiss">بعداً یادآوری کن</button></p></div>',
			esc_attr( $info['version'] ),
			esc_html( $info['version'] ),
			esc_html( BMC_VERSION ),
			esc_url( admin_url( 'plugins.php' ) ),
			esc_url( $info['url'] )
		);
	}

	public static function ajax_check() {
		if ( ! current_user_can( 'manage_options' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی ندارید.' ), 403 );
		}

		check_admin_referer( 'bmc_admin', 'security' );

		$info = self::fetch( true );

		wp_send_json_success( self::status( $info ) );
	}

	public static function ajax_dismiss() {
		if ( ! current_user_can( 'update_plugins' ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی ندارید.' ), 403 );
		}

		check_admin_referer( 'bmc_admin', 'security' );

		$version = isset( $_POST['version'] ) ? sanitize_text_field( wp_unslash( $_POST['version'] ) ) : '';

		update_option( self::NOTICE_OPTION, $version, false );

		wp_send_json_success( array( 'message' => 'یادآوری این نسخه غیرفعال شد.' ) );
	}

	public static function status( array $info = array() ) {
		if ( ! $info ) {
			$info = self::cache();
		}

		$latest = '' !== $info['version'] ? $info['version'] : '';

		return array(
			'enabled'      => self::enabled(),
			'current'      => BMC_VERSION,
			'latest'       => $latest,
			'has_update'   => self::has_update(),
			'channel'      => self::channel(),
			'repo'         => self::repo(),
			'checked_at'   => (int) $info['checked_at'],
			'checked_ago'  => $info['checked_at'] ? self::ago( time() - (int) $info['checked_at'] ) : '',
			'url'          => $info['url'] ? $info['url'] : self::release_url(),
			'package'      => $info['package'],
			'mc_jar'       => $info['mc_jar'],
			'mc_jar_url'   => $info['mc_jar_url'],
			'published_at' => $info['published_at'],
			'notes'        => $info['notes'],
			'error'        => $info['error'],
			'ttl_hours'    => max( 1, BMC_Settings::int( 'update_ttl', 6, 1, 168 ) ),
			'auto'         => BMC_Settings::bool( 'update_auto', false ),
			'token_set'    => '' !== self::token(),
		);
	}

	private static function ago( $seconds ) {
		$seconds = max( 0, (int) $seconds );

		if ( $seconds < 60 ) {
			return 'کمتر از یک دقیقه پیش';
		}

		if ( $seconds < HOUR_IN_SECONDS ) {
			return floor( $seconds / 60 ) . ' دقیقه پیش';
		}

		if ( $seconds < DAY_IN_SECONDS ) {
			return floor( $seconds / HOUR_IN_SECONDS ) . ' ساعت پیش';
		}

		return floor( $seconds / DAY_IN_SECONDS ) . ' روز پیش';
	}

	public static function clear_cache() {
		delete_option( self::CACHE_OPTION );
		delete_option( self::NOTICE_OPTION );
		delete_option( 'bmc_update_notified' );
	}

	public static function health_row() {
		if ( ! self::enabled() ) {
			return array(
				'key'    => 'updater',
				'label'  => 'به‌روزرسانی افزونه',
				'status' => 'warn',
				'detail' => 'بررسی خودکار به‌روزرسانی خاموش است (کلید update_enabled).',
			);
		}

		$info = self::cache();

		if ( '' !== $info['error'] ) {
			return array(
				'key'    => 'updater',
				'label'  => 'به‌روزرسانی افزونه',
				'status' => 'warn',
				'detail' => $info['error'],
			);
		}

		if ( '' === $info['version'] ) {
			return array(
				'key'    => 'updater',
				'label'  => 'به‌روزرسانی افزونه',
				'status' => 'info',
				'detail' => 'هنوز بررسی انجام نشده است — از تب ابزارها «بررسی اکنون» را بزنید.',
			);
		}

		if ( self::has_update() ) {
			return array(
				'key'    => 'updater',
				'label'  => 'به‌روزرسانی افزونه',
				'status' => 'warn',
				'detail' => sprintf( 'نسخهٔ %s منتشر شده است (نصب‌شده: %s) — از صفحهٔ افزونه‌ها به‌روزرسانی کنید.', $info['version'], BMC_VERSION ),
			);
		}

		return array(
			'key'    => 'updater',
			'label'  => 'به‌روزرسانی افزونه',
			'status' => 'ok',
			'detail' => sprintf( 'به‌روز هستید (%s) — آخرین بررسی: %s، کانال: %s', BMC_VERSION, $info['checked_at'] ? self::ago( time() - (int) $info['checked_at'] ) : '—', 'prerelease' === self::channel() ? 'پیش‌انتشار' : 'پایدار' ),
		);
	}
}
