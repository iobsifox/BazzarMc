<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Logger {

	const MAX_ROWS = 2000;

	public static function table_exists() {
		global $wpdb;

		$table = (string) BMC_DB::table( 'logs' );

		if ( '' === $table ) {
			return false;
		}

		try {
			$hide   = $wpdb->hide_errors();
			$exists = (string) $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $table ) ) === $table;

			if ( ! $hide ) {
				$wpdb->show_errors();
			}

			return $exists;
		} catch ( \Throwable $error ) {
			unset( $error );

			return false;
		}
	}

	public static function add( $channel, $message, array $context = array(), $level = 'info' ) {
		global $wpdb;

		if ( ! BMC_Settings::bool( 'debug_log', true ) ) {
			return;
		}

		$table = (string) BMC_DB::table( 'logs' );

		if ( '' === $table || ! is_object( $wpdb ) ) {
			return;
		}

		$hide = method_exists( $wpdb, 'hide_errors' ) ? (bool) $wpdb->hide_errors() : false;

		try {
			$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );

			if ( $count > self::MAX_ROWS ) {
				$wpdb->query( "DELETE FROM {$table} ORDER BY id ASC LIMIT 500" );
			}

			$wpdb->insert(
				$table,
				array(
					'channel'    => sanitize_key( $channel ),
					'level'      => sanitize_key( $level ),
					'message'    => sanitize_textarea_field( $message ),
					'context'    => $context ? wp_json_encode( $context, JSON_UNESCAPED_UNICODE ) : '',
					'ip_hash'    => BMC_Helpers::ip_hash(),
					'created_at' => current_time( 'mysql' ),
				),
				array( '%s', '%s', '%s', '%s', '%s', '%s' )
			);
		} catch ( \Throwable $error ) {
			unset( $error );
		}

		if ( ! $hide && method_exists( $wpdb, 'show_errors' ) ) {
			$wpdb->show_errors();
		}
	}

	public static function recent( $limit = 50, $channel = '' ) {
		global $wpdb;
		$table = BMC_DB::table( 'logs' );
		$limit = max( 1, min( 500, (int) $limit ) );

		if ( ! self::table_exists() ) {
			return array();
		}

		if ( $channel ) {
			$rows = $wpdb->get_results(
				$wpdb->prepare( "SELECT * FROM {$table} WHERE channel = %s ORDER BY id DESC LIMIT {$limit}", $channel )
			);
		} else {
			$rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC LIMIT {$limit}" );
		}

		return $rows ? $rows : array();
	}

	public static function clear( $days = 0 ) {
		global $wpdb;

		$days  = max( 0, (int) $days );
		$table = (string) BMC_DB::table( 'logs' );

		if ( '' === $table || ! self::table_exists() ) {
			return -1;
		}

		$hide = $wpdb->hide_errors();
		$rows = 0;

		try {
			if ( $days > 0 ) {
				$cut = gmdate( 'Y-m-d H:i:s', (int) current_time( 'timestamp' ) - ( $days * DAY_IN_SECONDS ) );
				$sql = $wpdb->prepare( "DELETE FROM {$table} WHERE created_at < %s", $cut );
			} else {
				$sql = "DELETE FROM {$table}";
			}

			if ( false === $wpdb->query( $sql ) ) {
				if ( ! $hide ) {
					$wpdb->show_errors();
				}

				return -2;
			}

			$rows = (int) $wpdb->rows_affected;
		} catch ( \Throwable $error ) {
			unset( $error );

			if ( ! $hide ) {
				$wpdb->show_errors();
			}

			return -2;
		}

		if ( ! $hide ) {
			$wpdb->show_errors();
		}

		return $rows;
	}
}
