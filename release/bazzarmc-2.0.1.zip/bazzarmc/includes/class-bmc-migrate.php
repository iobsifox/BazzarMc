<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Migrate {

	public static function init() {
		add_action( 'wp_ajax_bmc_run_migration', array( __CLASS__, 'ajax_run_migration' ) );
		add_action( 'admin_notices', array( __CLASS__, 'setup_notice' ) );
		add_action( 'wp_ajax_bmc_dismiss_notice', array( __CLASS__, 'ajax_dismiss_notice' ) );
	}

	public static function maybe_upgrade() {
		$installed = (string) get_option( 'bmc_installed_version', '' );

		if ( $installed === BMC_VERSION ) {
			return false;
		}

		$notes = array();

		if ( class_exists( 'BMC_DB' ) ) {
			BMC_DB::install();
			$notes[] = 'جدول‌های پایگاه داده به نسخهٔ ' . BMC_VERSION . ' به‌روزرسانی شدند';
		}

		if ( class_exists( 'BMC_Safe' ) && class_exists( 'BMC_Settings' ) ) {
			if ( 'off' !== (string) BMC_Settings::get( 'safe_mode', 'off' ) ) {
				BMC_Safe::deactivate();
				$notes[] = 'حالت ایمن خودکار خاموش شد و ماژول‌ها بازنشانی شدند';
			}

			if ( ! BMC_Settings::bool( 'elementor_enabled', true ) ) {
				BMC_Settings::save( array( 'elementor_enabled' => 'yes' ) );
			}
			if ( ! BMC_Settings::bool( 'myaccount_card', true ) ) {
				BMC_Settings::save( array( 'myaccount_card' => 'yes' ) );
			}
		}

		if ( class_exists( 'BMC_Settings' ) && 'premium' === (string) BMC_Settings::get( 'username_policy', 'any' ) ) {
			BMC_Settings::save( array( 'username_policy' => 'any' ) );
			$notes[] = 'سیاست نام کاربری به هر نام کاربری تغییر کرد';
		}

		if ( class_exists( 'BMC_Account_Endpoints' ) ) {
			BMC_Account_Endpoints::queue_flush();
			$notes[] = 'بازنشانی پیوندهای یکتا انجام شد';
		}

		update_option( 'bmc_installed_version', BMC_VERSION, false );

		if ( $notes && class_exists( 'BMC_Logger' ) ) {
			BMC_Logger::add(
				'update',
				'به‌روزرسانی به نسخهٔ ' . BMC_VERSION . ( $installed ? ' (از ' . $installed . ')' : '' ) . ': ' . implode( '؛ ', $notes ),
				array(),
				'info'
			);
		}

		return true;
	}

	public static function maybe_create_pages() {
		if ( ! BMC_Settings::get( 'page_link' ) ) {
			$page_id = self::create_page(
				'اتصال اکانت ماینکرافت',
				'[bazzarmc]',
				'اتصال اکانت ماینکرافت به حساب کاربری فروشگاه'
			);
			if ( $page_id ) {
				BMC_Settings::set( 'page_link', $page_id );
			}
		}
	}

	private static function create_page( $title, $content, $excerpt = '' ) {
		if ( function_exists( 'get_page_by_title' ) ) {
			$existing = get_page_by_title( $title );
			if ( $existing ) {
				return (int) $existing->ID;
			}
		}

		if ( ! function_exists( 'wp_insert_post' ) ) {
			return false;
		}

		$page_id = wp_insert_post(
			array(
				'post_title'   => $title,
				'post_content' => $content,
				'post_excerpt' => $excerpt,
				'post_status'  => 'publish',
				'post_type'    => 'page',
			)
		);

		return ( is_wp_error( $page_id ) || ! $page_id ) ? false : (int) $page_id;
	}

	public static function legacy_installed() {
		return defined( 'STORELINKFORMC_LOADED' ) || file_exists( WP_PLUGIN_DIR . '/storelinkformc/storelinkformc.php' );
	}

	public static function migration_report() {
		global $wpdb;

		$report = array(
			'legacy_plugin' => self::legacy_installed(),
			'users'         => 0,
			'deliveries'    => 0,
			'legacy_table'  => false,
		);

		$report['users'] = (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(DISTINCT user_id) FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value <> ''",
				'minecraft_player'
			)
		);

		$legacy_table = $wpdb->prefix . 'pending_deliveries';
		$exists       = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $legacy_table ) );

		if ( $exists ) {
			$report['legacy_table'] = true;
			$report['deliveries']   = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$legacy_table}" );
		}

		return $report;
	}

	public static function run() {
		global $wpdb;

		$result = array(
			'users'      => 0,
			'deliveries' => 0,
			'options'    => 0,
		);

		$rows = $wpdb->get_results(
			$wpdb->prepare(
				"SELECT user_id, meta_value FROM {$wpdb->usermeta} WHERE meta_key = %s AND meta_value <> ''",
				'minecraft_player'
			)
		);

		foreach ( (array) $rows as $row ) {
			$player = sanitize_text_field( $row->meta_value );
			if ( BMC_Helpers::valid_player_name( $player ) && ! BMC_Link::is_linked( (int) $row->user_id ) ) {
				update_user_meta( (int) $row->user_id, BMC_Link::META_PLAYER, $player );
				update_user_meta( (int) $row->user_id, BMC_Link::META_CHANNEL, 'migrated' );
				update_user_meta( (int) $row->user_id, BMC_Link::META_LINKED_AT, time() );
				BMC_Link::apply_linked_role( (int) $row->user_id );
				$result['users']++;
			}
		}

		$legacy_table = $wpdb->prefix . 'pending_deliveries';
		$exists       = $wpdb->get_var( $wpdb->prepare( 'SHOW TABLES LIKE %s', $legacy_table ) );

		if ( $exists ) {
			$new_table = BMC_DB::table( 'deliveries' );
			$columns   = $wpdb->get_col( "DESCRIBE {$legacy_table}", 0 );

			$select = 'id, order_id, player, item, amount, delivered';
			foreach ( array( 'product_id', 'variation_id' ) as $col ) {
				if ( in_array( $col, $columns, true ) ) {
					$select .= ", {$col}";
				} else {
					$select .= ", 0 AS {$col}";
				}
			}

			$legacy_rows = $wpdb->get_results( "SELECT {$select} FROM {$legacy_table} LIMIT 5000" );

			foreach ( (array) $legacy_rows as $row ) {
				$dup = $wpdb->get_var(
					$wpdb->prepare(
						"SELECT id FROM {$new_table} WHERE order_id = %d AND player = %s AND product_id = %d AND item = %s LIMIT 1",
						(int) $row->order_id,
						$row->player,
						(int) $row->product_id,
						$row->item
					)
				);

				if ( $dup ) {
					continue;
				}

				$user_id = 0;
				if ( function_exists( 'wc_get_order' ) ) {
					$order = wc_get_order( (int) $row->order_id );
					if ( $order ) {
						$user_id = $order->get_user_id();
					}
				}

				$wpdb->insert(
					$new_table,
					array(
						'order_id'     => (int) $row->order_id,
						'user_id'      => $user_id,
						'player'       => sanitize_text_field( $row->player ),
						'product_id'   => (int) $row->product_id,
						'variation_id' => (int) $row->variation_id,
						'item'         => sanitize_text_field( $row->item ),
						'amount'       => max( 1, (int) $row->amount ),
						'status'       => (int) $row->delivered ? BMC_Deliveries::STATUS_DELIVERED : BMC_Deliveries::STATUS_PENDING,
						'note'         => 'مهاجرت از نسخهٔ قدیمی',
						'created_at'   => current_time( 'mysql' ),
						'expires_at'   => BMC_Helpers::expires_at( BMC_Settings::delivery_expiry_seconds() ),
					),
					array( '%d', '%d', '%s', '%d', '%d', '%s', '%d', '%d', '%s', '%s', '%s' )
				);

				$result['deliveries']++;
			}
		}

		$map = array(
			'storelinkformc_sync_products'       => 'sync_products',
			'storelinkformc_product_roles_map'   => 'product_roles',
			'storelinkformc_default_linked_role' => 'default_linked_role',
			'storelinkformc_force_link'          => 'force_link',
			'storelinkformc_username_policy'     => 'username_policy',
		);

		foreach ( $map as $old => $new ) {
			$value = get_option( $old, null );
			if ( null !== $value && '' !== $value ) {
				BMC_Settings::set( $new, $value );
				$result['options']++;
			}
		}

		BMC_Logger::add( 'migrate', 'مهاجرت انجام شد', $result, 'success' );

		return $result;
	}

	public static function ajax_run_migration() {
		self::guard();
		$result = self::run();
		wp_send_json_success(
			array(
				'message' => sprintf(
					'مهاجرت انجام شد: %d کاربر متصل، %d تحویل، %d تنظیم.',
					$result['users'],
					$result['deliveries'],
					$result['options']
				),
				'data'    => $result,
			)
		);
	}

	public static function setup_notice() {
		if ( ! current_user_can( 'manage_options' ) && ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		if ( 'yes' === BMC_Settings::get( 'install_notice_seen' ) || ! get_option( 'bmc_needs_setup' ) ) {
			return;
		}

		if ( ( class_exists( 'BMC_API' ) && method_exists( 'BMC_API', 'has_activity' ) && BMC_API::has_activity() ) || ! empty( BMC_Settings::api_token() ) ) {
			delete_option( 'bmc_needs_setup' );
			BMC_Settings::set( 'install_notice_seen', 'yes' );
			return;
		}

		$screen = function_exists( 'get_current_screen' ) ? get_current_screen() : null;
		if ( $screen && false !== strpos( (string) $screen->id, 'bazzarmc' ) ) {
			return;
		}

		$url   = admin_url( 'admin.php?page=bazzarmc&tab=server' );
		$nonce = wp_create_nonce( 'bmc_admin' );

		printf(
			'<div class="notice notice-info is-dismissible bmc-notice" data-nonce="%3$s">
				<p><strong>BazzarMc نصب شد</strong><br>
				برای شروع، توکن اتصال را در پنل تنظیمات کپی کرده و در پلاگین ماینکرافت وارد کنید.</p>
				<p><a class="button button-primary" href="%1$s">شروع راه‌اندازی</a>
				<a class="button" href="%2$s">صفحهٔ ابزارها</a></p>
				<script>
				(function(){
					document.addEventListener("click", function(e){
						var btn = e.target && e.target.closest ? e.target.closest(".bmc-notice .notice-dismiss") : null;
						if (btn) {
							var fd = new FormData();
							fd.append("action", "bmc_dismiss_notice");
							fd.append("security", "%3$s");
							if (window.ajaxurl) { fetch(window.ajaxurl, {method:"POST", body:fd}); }
						}
					});
				})();
				</script>
			</div>',
			esc_url( $url ),
			esc_url( admin_url( 'admin.php?page=bazzarmc&tab=tools' ) ),
			esc_attr( $nonce )
		);
	}

	public static function ajax_dismiss_notice() {
		self::guard( 'manage_options' );
		BMC_Settings::set( 'install_notice_seen', 'yes' );
		delete_option( 'bmc_needs_setup' );
		wp_send_json_success();
	}

	private static function guard( $cap = 'manage_woocommerce' ) {
		if ( ! current_user_can( $cap ) ) {
			wp_send_json_error( array( 'message' => 'دسترسی ندارید.' ), 403 );
		}
		check_admin_referer( 'bmc_admin', 'security' );
	}
}
