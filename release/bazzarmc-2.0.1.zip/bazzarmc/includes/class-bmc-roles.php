<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Roles {

	const META = 'bmc_role_grants';

	public static function init() {
		add_action( 'bmc_maintenance', array( __CLASS__, 'expire_due' ) );
	}

	public static function duration_days( $product_id ) {
		$durations = (array) BMC_Settings::get( 'product_role_duration', array() );
		$pid       = absint( $product_id );

		if ( $pid && isset( $durations[ $pid ] ) && '' !== $durations[ $pid ] && null !== $durations[ $pid ] ) {
			return max( 0, (int) $durations[ $pid ] );
		}

		return max( 0, (int) BMC_Settings::get( 'role_duration_default', 0 ) );
	}

	public static function role_label( $role ) {
		$role  = (string) $role;
		$names = function_exists( 'wp_roles' ) ? (array) wp_roles()->role_names : array();

		if ( isset( $names[ $role ] ) ) {
			return translate_user_role( $names[ $role ] );
		}

		return $role;
	}

	public static function protected_roles() {
		return array( 'administrator', 'shop_manager', 'editor', 'author' );
	}

	public static function grants( $user_id ) {
		$user_id = absint( $user_id );

		if ( ! $user_id ) {
			return array();
		}

		$grants = get_user_meta( $user_id, self::META, true );

		return is_array( $grants ) ? array_values( $grants ) : array();
	}

	public static function record_grant( $user_id, $role, array $args = array() ) {
		$user_id = absint( $user_id );
		$role    = sanitize_text_field( (string) $role );

		if ( ! $user_id || '' === $role || ! function_exists( 'wp_roles' ) || ! array_key_exists( $role, wp_roles()->roles ) ) {
			return null;
		}

		$product_id   = absint( isset( $args['product_id'] ) ? $args['product_id'] : 0 );
		$variation_id = absint( isset( $args['variation_id'] ) ? $args['variation_id'] : 0 );
		$order_id     = absint( isset( $args['order_id'] ) ? $args['order_id'] : 0 );
		$label        = sanitize_text_field( (string) ( isset( $args['label'] ) ? $args['label'] : '' ) );
		$source       = sanitize_key( (string) ( isset( $args['source'] ) ? $args['source'] : 'order' ) );
		$level        = isset( $args['level'] ) ? (int) $args['level'] : 0;
		$days         = isset( $args['days'] ) ? max( 0, (int) $args['days'] ) : self::duration_days( $variation_id ? $variation_id : $product_id );

		if ( '' === $label ) {
			$label = self::role_label( $role );
		}

		$grants  = self::grants( $user_id );
		$now     = BMC_Helpers::now_timestamp();
		$match   = null;
		$match_i = -1;

		foreach ( $grants as $i => $grant ) {
			if ( isset( $grant['role'] ) && $grant['role'] === $role
				&& absint( isset( $grant['product_id'] ) ? $grant['product_id'] : 0 ) === $product_id
				&& empty( $grant['revoked_at'] ) ) {
				$match   = $grant;
				$match_i = $i;
			}
		}

		$base = $now;

		if ( is_array( $match ) && ! empty( $match['expires_at'] ) ) {
			$existing = strtotime( (string) $match['expires_at'] );

			if ( $existing && $existing > $now ) {
				$base = $existing;
			}
		}

		$record = array(
			'role'         => $role,
			'product_id'   => $product_id,
			'variation_id' => $variation_id,
			'order_id'     => $order_id,
			'label'        => $label,
			'source'       => $source,
			'level'        => $level,
			'days'         => $days,
			'granted_at'   => is_array( $match ) && ! empty( $match['granted_at'] ) ? (string) $match['granted_at'] : BMC_Helpers::local_datetime( $now ),
			'expires_at'   => $days > 0 ? BMC_Helpers::local_datetime( $base + ( $days * DAY_IN_SECONDS ) ) : '',
			'revoked_at'   => '',
		);

		if ( $match_i >= 0 ) {
			$grants[ $match_i ] = $record;
		} else {
			$grants[] = $record;
		}

		update_user_meta( $user_id, self::META, $grants );

		BMC_Logger::add(
			'role',
			sprintf(
				'نقش «%s» برای کاربر #%d ثبت شد%s',
				$record['label'],
				$user_id,
				$record['expires_at'] ? ' تا ' . $record['expires_at'] : ' (دائمی)'
			),
			array( 'order_id' => $order_id, 'product_id' => $product_id ),
			'info'
		);

		return $record;
	}

	public static function active_grants( $user_id, $single_only = true ) {
		$now     = BMC_Helpers::now_timestamp();
		$out     = array();
		$changed = false;

		foreach ( self::grants( $user_id ) as $grant ) {
			if ( ! is_array( $grant ) || ! empty( $grant['revoked_at'] ) ) {
				continue;
			}

			$remaining = 0;
			$permanent = empty( $grant['expires_at'] );

			if ( ! $permanent ) {
				$expires = strtotime( (string) $grant['expires_at'] );

				if ( ! $expires ) {
					$permanent = true;
				} else {
					$remaining = $expires - $now;

					if ( $remaining <= 0 ) {
						$changed = true;
						continue;
					}
				}
			}

			$level = isset( $grant['level'] ) ? (int) $grant['level'] : 0;
			if ( $level <= 0 && class_exists( 'BMC_Ranks' ) ) {
				$level = BMC_Ranks::level_for_product(
					isset( $grant['product_id'] ) ? $grant['product_id'] : 0,
					isset( $grant['variation_id'] ) ? $grant['variation_id'] : 0
				);
			}

			$pid   = isset( $grant['product_id'] ) ? absint( $grant['product_id'] ) : 0;
			$thumb = '';
			if ( $pid && function_exists( 'get_the_post_thumbnail_url' ) ) {
				$thumb = (string) get_the_post_thumbnail_url( $pid, 'medium' );
			}

			$grant['level']           = $level;
			$grant['image']           = $thumb;
			$grant['permanent']       = $permanent;
			$grant['remaining']       = max( 0, $remaining );
			$grant['remaining_human'] = $permanent ? 'دائمی' : self::human_duration( $remaining );
			$grant['expires_jalali']  = $permanent ? '' : BMC_Jalali::format( $grant['expires_at'], false );
			$grant['role_label']      = self::role_label( isset( $grant['role'] ) ? $grant['role'] : '' );
			$grant['still_has_role']  = self::user_has_role( $user_id, isset( $grant['role'] ) ? $grant['role'] : '' );

			$out[] = $grant;
		}

		if ( $changed ) {
			self::expire_due_for_user( $user_id );
			return self::active_grants_raw( $user_id, $single_only );
		}

		usort(
			$out,
			function ( $a, $b ) {
				$la = isset( $a['level'] ) ? (int) $a['level'] : 0;
				$lb = isset( $b['level'] ) ? (int) $b['level'] : 0;
				if ( $la !== $lb ) {
					return $lb - $la;
				}

				if ( ! empty( $a['permanent'] ) && empty( $b['permanent'] ) ) {
					return -1;
				}

				if ( empty( $a['permanent'] ) && ! empty( $b['permanent'] ) ) {
					return 1;
				}

				$ra = isset( $a['remaining'] ) ? (int) $a['remaining'] : 0;
				$rb = isset( $b['remaining'] ) ? (int) $b['remaining'] : 0;
				if ( $ra !== $rb ) {
					return $rb - $ra;
				}

				$ga = isset( $a['granted_at'] ) ? strtotime( (string) $a['granted_at'] ) : 0;
				$gb = isset( $b['granted_at'] ) ? strtotime( (string) $b['granted_at'] ) : 0;
				return $gb - $ga;
			}
		);

		if ( $single_only && ! empty( $out ) ) {
			$out = array( $out[0] );
		}

		return $out;
	}

	private static function active_grants_raw( $user_id, $single_only = true ) {
		$now = BMC_Helpers::now_timestamp();
		$out = array();

		foreach ( self::grants( $user_id ) as $grant ) {
			if ( ! is_array( $grant ) || ! empty( $grant['revoked_at'] ) ) {
				continue;
			}

			$permanent = empty( $grant['expires_at'] );
			$remaining = 0;

			if ( ! $permanent ) {
				$expires = strtotime( (string) $grant['expires_at'] );

				if ( $expires ) {
					$remaining = $expires - $now;

					if ( $remaining <= 0 ) {
						continue;
					}
				} else {
					$permanent = true;
				}
			}

			$level = isset( $grant['level'] ) ? (int) $grant['level'] : 0;
			if ( $level <= 0 && class_exists( 'BMC_Ranks' ) ) {
				$level = BMC_Ranks::level_for_product(
					isset( $grant['product_id'] ) ? $grant['product_id'] : 0,
					isset( $grant['variation_id'] ) ? $grant['variation_id'] : 0
				);
			}

			$pid   = isset( $grant['product_id'] ) ? absint( $grant['product_id'] ) : 0;
			$thumb = '';
			if ( $pid && function_exists( 'get_the_post_thumbnail_url' ) ) {
				$thumb = (string) get_the_post_thumbnail_url( $pid, 'medium' );
			}

			$grant['level']           = $level;
			$grant['image']           = $thumb;
			$grant['permanent']       = $permanent;
			$grant['remaining']       = max( 0, $remaining );
			$grant['remaining_human'] = $permanent ? 'دائمی' : self::human_duration( $remaining );
			$grant['expires_jalali']  = $permanent ? '' : BMC_Jalali::format( $grant['expires_at'], false );
			$grant['role_label']      = self::role_label( isset( $grant['role'] ) ? $grant['role'] : '' );
			$grant['still_has_role']  = self::user_has_role( $user_id, isset( $grant['role'] ) ? $grant['role'] : '' );

			$out[] = $grant;
		}

		usort(
			$out,
			function ( $a, $b ) {
				$la = isset( $a['level'] ) ? (int) $a['level'] : 0;
				$lb = isset( $b['level'] ) ? (int) $b['level'] : 0;
				if ( $la !== $lb ) {
					return $lb - $la;
				}

				if ( ! empty( $a['permanent'] ) && empty( $b['permanent'] ) ) {
					return -1;
				}

				if ( empty( $a['permanent'] ) && ! empty( $b['permanent'] ) ) {
					return 1;
				}

				return (int) $b['remaining'] - (int) $a['remaining'];
			}
		);

		if ( $single_only && ! empty( $out ) ) {
			$out = array( $out[0] );
		}

		return $out;
	}

	public static function active_grant( $user_id ) {
		$grants = self::active_grants( $user_id, true );
		return ! empty( $grants ) ? $grants[0] : null;
	}

	public static function revoked_grants( $user_id ) {
		$user_id = absint( $user_id );
		if ( ! $user_id ) {
			return array();
		}

		$out = array();
		foreach ( self::grants( $user_id ) as $grant ) {
			if ( is_array( $grant ) && ! empty( $grant['revoked_at'] ) ) {
				$out[] = $grant;
			}
		}
		return $out;
	}

	public static function revoke_user_rank( $user_id, $target = '' ) {
		$user_id = absint( $user_id );
		if ( ! $user_id ) {
			return false;
		}

		$grants  = self::grants( $user_id );
		$now     = BMC_Helpers::local_datetime();
		$revoked = 0;
		$dirty   = false;
		$target  = trim( (string) $target );

		foreach ( $grants as $i => $grant ) {
			if ( ! is_array( $grant ) || ! empty( $grant['revoked_at'] ) ) {
				continue;
			}

			if ( '' !== $target ) {
				$g_key  = isset( $grant['key'] ) ? (string) $grant['key'] : '';
				$g_role = isset( $grant['role'] ) ? (string) $grant['role'] : '';
				if ( $g_key !== $target && $g_role !== $target ) {
					continue;
				}
			}

			$grants[ $i ]['revoked_at'] = $now;
			$grants[ $i ]['revoked_by'] = get_current_user_id() ? get_current_user_id() : 'admin';
			$dirty                      = true;
			$revoked                   += self::maybe_remove_role( $user_id, isset( $grant['role'] ) ? (string) $grant['role'] : '', $grants );
		}

		if ( $dirty ) {
			update_user_meta( $user_id, self::META, $grants );

			$player = class_exists( 'BMC_Link' ) ? BMC_Link::get_player( $user_id ) : '';
			BMC_Logger::add(
				'rank',
				sprintf( 'رنک کاربر #%d (%s) لغو شد.', $user_id, $player ? $player : 'بدون اکانت متصل' ),
				array(
					'user_id' => $user_id,
					'player'  => $player,
					'target'  => $target,
				),
				'warning'
			);

			do_action( 'bmc_rank_revoked', $user_id, $player, $target );
			return true;
		}

		return false;
	}

	public static function revoke_player_rank( $player, $target = '' ) {
		$player = sanitize_text_field( (string) $player );
		if ( '' === $player || ! class_exists( 'BMC_Link' ) ) {
			return false;
		}

		$user = BMC_Link::find_user_by_player( $player );
		if ( ! $user ) {
			return false;
		}

		return self::revoke_user_rank( (int) $user->ID, $target );
	}

	public static function users_with_active_grants( $limit = 50 ) {
		if ( ! class_exists( 'WP_User_Query' ) ) {
			return array();
		}

		$query = new WP_User_Query(
			array(
				'number'      => min( 200, (int) $limit ),
				'meta_key'    => self::META,
				'count_total' => false,
			)
		);

		$results = array();
		$users   = $query->get_results();

		foreach ( (array) $users as $user ) {
			if ( ! $user instanceof WP_User ) {
				continue;
			}

			$active = self::active_grants( $user->ID, true );
			if ( ! empty( $active ) ) {
				$results[] = array(
					'user_id' => $user->ID,
					'user'    => $user,
					'player'  => class_exists( 'BMC_Link' ) ? BMC_Link::get_player( $user->ID ) : '',
					'uuid'    => class_exists( 'BMC_Link' ) ? BMC_Link::get_uuid( $user->ID ) : '',
					'rank'    => $active[0],
				);
			}
		}

		return $results;
	}

	public static function user_has_role( $user_id, $role ) {
		$role = (string) $role;

		if ( '' === $role ) {
			return false;
		}

		$user = new WP_User( absint( $user_id ) );

		return $user->exists() && in_array( $role, (array) $user->roles, true );
	}

	public static function expire_due() {
		$revoked = 0;

		if ( ! class_exists( 'WP_User_Query' ) ) {
			return 0;
		}

		$query = new WP_User_Query(
			array(
				'fields'      => 'ID',
				'number'      => 500,
				'count_total' => false,
				'meta_key'    => self::META,
			)
		);

		foreach ( (array) $query->get_results() as $user_id ) {
			$revoked += self::expire_due_for_user( absint( $user_id ) );
		}

		return $revoked;
	}

	public static function expire_due_for_user( $user_id ) {
		$user_id = absint( $user_id );

		if ( ! $user_id ) {
			return 0;
		}

		$grants  = self::grants( $user_id );
		$now     = BMC_Helpers::now_timestamp();
		$revoked = 0;
		$dirty   = false;

		foreach ( $grants as $i => $grant ) {
			if ( ! is_array( $grant ) || ! empty( $grant['revoked_at'] ) || empty( $grant['expires_at'] ) ) {
				continue;
			}

			$expires = strtotime( (string) $grant['expires_at'] );

			if ( ! $expires || $expires > $now ) {
				continue;
			}

			$role = isset( $grant['role'] ) ? (string) $grant['role'] : '';

			$grants[ $i ]['revoked_at'] = BMC_Helpers::local_datetime( $now );
			$dirty                      = true;
			$revoked                   += self::maybe_remove_role( $user_id, $role, $grants );
		}

		if ( $dirty ) {
			update_user_meta( $user_id, self::META, $grants );
		}

		return $revoked;
	}

	private static function maybe_remove_role( $user_id, $role, array $grants = array() ) {
		$role = (string) $role;

		if ( '' === $role || in_array( $role, self::protected_roles(), true ) ) {
			return 0;
		}

		if ( ! self::user_has_role( $user_id, $role ) ) {
			return 0;
		}

		$now = BMC_Helpers::now_timestamp();

		foreach ( $grants as $grant ) {
			if ( ! is_array( $grant ) || ! empty( $grant['revoked_at'] ) ) {
				continue;
			}

			if ( ! isset( $grant['role'] ) || $grant['role'] !== $role ) {
				continue;
			}

			if ( empty( $grant['expires_at'] ) ) {
				return 0;
			}

			$expires = strtotime( (string) $grant['expires_at'] );

			if ( $expires && $expires > $now ) {
				return 0;
			}
		}

		$user = new WP_User( $user_id );

		if ( $user->exists() ) {
			$user->remove_role( $role );

			BMC_Logger::add(
				'role',
				sprintf( 'نقش «%s» کاربر #%d به پایان اعتبار رسید و حذف شد.', self::role_label( $role ), $user_id ),
				array(),
				'warning'
			);

			do_action( 'bmc_role_expired', $user_id, $role );

			return 1;
		}

		return 0;
	}

	public static function revoke_for_order( $order_id ) {
		$order_id = absint( $order_id );

		if ( ! $order_id || ! class_exists( 'WP_User_Query' ) ) {
			return 0;
		}

		$query = new WP_User_Query(
			array(
				'fields'      => 'ID',
				'number'      => 500,
				'count_total' => false,
				'meta_key'    => self::META,
			)
		);

		$removed = 0;

		foreach ( (array) $query->get_results() as $user_id ) {
			$user_id = absint( $user_id );
			$grants  = self::grants( $user_id );
			$dirty   = false;

			foreach ( $grants as $i => $grant ) {
				if ( ! is_array( $grant ) || ! empty( $grant['revoked_at'] ) ) {
					continue;
				}

				if ( absint( isset( $grant['order_id'] ) ? $grant['order_id'] : 0 ) !== $order_id ) {
					continue;
				}

				$grants[ $i ]['revoked_at'] = BMC_Helpers::local_datetime();
				$dirty                      = true;
				$removed                   += self::maybe_remove_role( $user_id, isset( $grant['role'] ) ? (string) $grant['role'] : '', $grants );
			}

			if ( $dirty ) {
				update_user_meta( $user_id, self::META, $grants );
			}
		}

		return $removed;
	}

	public static function upsert_external( $user_id, array $args ) {
		$user_id = absint( $user_id );
		$role    = sanitize_text_field( (string) ( isset( $args['role'] ) ? $args['role'] : '' ) );

		if ( ! $user_id ) {
			return null;
		}

		$key        = sanitize_text_field( (string) ( isset( $args['key'] ) ? $args['key'] : '' ) );
		$level      = isset( $args['level'] ) ? (int) $args['level'] : 0;
		$name       = sanitize_text_field( (string) ( isset( $args['name'] ) ? $args['name'] : '' ) );
		$days_left  = isset( $args['days_left'] ) ? (int) $args['days_left'] : 0;
		$permanent  = ! empty( $args['permanent'] );
		$product_id = absint( isset( $args['product_id'] ) ? $args['product_id'] : 0 );
		$now        = BMC_Helpers::now_timestamp();

		if ( '' === $name ) {
			$name = $role ? self::role_label( $role ) : $key;
		}

		$grants = self::grants( $user_id );
		$found  = -1;

		foreach ( $grants as $i => $grant ) {
			if ( ! is_array( $grant ) || ! empty( $grant['revoked_at'] ) ) {
				continue;
			}

			if ( 'minecraft' !== ( isset( $grant['source'] ) ? $grant['source'] : '' ) ) {
				continue;
			}

			if ( $key && ( isset( $grant['key'] ) ? $grant['key'] : '' ) === $key ) {
				$found = $i;
				break;
			}

			if ( $role && ( isset( $grant['role'] ) ? $grant['role'] : '' ) === $role ) {
				$found = $i;
				break;
			}
		}

		$record = array(
			'role'         => $role,
			'key'          => $key,
			'level'        => $level,
			'product_id'   => $product_id,
			'variation_id' => 0,
			'order_id'     => $found >= 0 && isset( $grants[ $found ]['order_id'] ) ? (int) $grants[ $found ]['order_id'] : 0,
			'label'        => $name,
			'source'       => 'minecraft',
			'days'         => $permanent ? 0 : max( 0, $days_left ),
			'granted_at'   => $found >= 0 && ! empty( $grants[ $found ]['granted_at'] ) ? (string) $grants[ $found ]['granted_at'] : BMC_Helpers::local_datetime( $now ),
			'expires_at'   => $permanent ? '' : BMC_Helpers::local_datetime( $now + ( max( 0, $days_left ) * DAY_IN_SECONDS ) ),
			'revoked_at'   => '',
		);

		if ( $found >= 0 ) {
			$grants[ $found ] = $record;
		} else {
			$grants[] = $record;
		}

		update_user_meta( $user_id, self::META, $grants );

		if ( $role && function_exists( 'wp_roles' ) && array_key_exists( $role, wp_roles()->roles ) && ! self::user_has_role( $user_id, $role ) && ! in_array( $role, self::protected_roles(), true ) ) {
			$user = new WP_User( $user_id );

			if ( $user->exists() ) {
				$user->add_role( $role );
			}
		}

		return $record;
	}

	public static function prune_external( $user_id, array $keep_keys ) {
		$user_id = absint( $user_id );

		if ( ! $user_id ) {
			return 0;
		}

		$grants  = self::grants( $user_id );
		$now     = BMC_Helpers::local_datetime();
		$removed = 0;
		$dirty   = false;

		foreach ( $grants as $i => $grant ) {
			if ( ! is_array( $grant ) || ! empty( $grant['revoked_at'] ) ) {
				continue;
			}

			if ( 'minecraft' !== ( isset( $grant['source'] ) ? $grant['source'] : '' ) ) {
				continue;
			}

			$key = isset( $grant['key'] ) ? (string) $grant['key'] : '';

			if ( in_array( $key, $keep_keys, true ) ) {
				continue;
			}

			$grants[ $i ]['revoked_at'] = $now;
			$dirty                      = true;
			$removed                   += self::maybe_remove_role( $user_id, isset( $grant['role'] ) ? (string) $grant['role'] : '', $grants );
		}

		if ( $dirty ) {
			update_user_meta( $user_id, self::META, $grants );
		}

		return $removed;
	}

	public static function human_duration( $seconds ) {
		$seconds = max( 0, (int) $seconds );
		$days    = (int) floor( $seconds / DAY_IN_SECONDS );
		$hours   = (int) floor( ( $seconds % DAY_IN_SECONDS ) / HOUR_IN_SECONDS );
		$minutes = (int) floor( ( $seconds % HOUR_IN_SECONDS ) / MINUTE_IN_SECONDS );

		$parts = array();

		if ( $days > 0 ) {
			$parts[] = BMC_Helpers::to_persian_digits( $days ) . ' روز';
		}

		if ( $hours > 0 ) {
			$parts[] = BMC_Helpers::to_persian_digits( $hours ) . ' ساعت';
		}

		if ( empty( $parts ) && $minutes > 0 ) {
			$parts[] = BMC_Helpers::to_persian_digits( $minutes ) . ' دقیقه';
		}

		if ( empty( $parts ) ) {
			$parts[] = 'کمتر از یک دقیقه';
		}

		return implode( ' و ', array_slice( $parts, 0, 2 ) );
	}
}
