<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class BMC_EL_Deliveries extends BMC_EL_Base {

	public function get_name() {
		return 'bmc-deliveries';
	}

	public function get_title() {
		return self::txt( 'Minecraft Deliveries', 'تحویل‌های ماینکرافت' );
	}

	public function get_icon() {
		return 'eicon-box';
	}

	protected function bmc_slug() {
		return 'deliveries';
	}

	protected function extra_keywords() {
		return array( 'delivery', 'deliveries', 'claim', 'تحویل', 'محرابه', 'آیتم' );
	}

	protected function content_controls() {
		$this->start_controls_section(
			'bmc_sec_content',
			array(
				'label' => 'تحویل‌ها',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'title',
			array(
				'label'   => 'عنوان',
				'type'    => Controls_Manager::TEXT,
				'default' => 'تحویل‌های من',
			)
		);

		$this->add_control(
			'title_icon',
			array(
				'label'     => 'آیکون عنوان',
				'type'      => Controls_Manager::TEXT,
				'default'   => 'inventory_2',
				'condition' => array(
					'title!' => '',
				),
			)
		);

		$this->add_control(
			'status',
			array(
				'label'   => 'وضعیت',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''          => 'همه',
					'pending'   => 'در انتظار تحویل',
					'delivered' => 'تحویل‌شده',
				),
			)
		);

		$this->add_control(
			'limit',
			array(
				'label'   => 'تعداد موارد',
				'type'    => Controls_Manager::NUMBER,
				'default' => 10,
				'min'     => 1,
				'max'     => 100,
			)
		);

		$this->add_control(
			'layout',
			array(
				'label'   => 'چیدمان',
				'type'    => Controls_Manager::SELECT,
				'default' => 'list',
				'options' => array(
					'list'  => 'کارتی',
					'table' => 'جدول',
				),
			)
		);

		$this->add_control(
			'code',
			array(
				'label'        => 'نمایش کد خرید',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'order',
			array(
				'label'        => 'نمایش شمارهٔ سفارش',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'date',
			array(
				'label'        => 'نمایش تاریخ',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'hint',
			array(
				'label'        => 'نمایش راهنمای تحویل',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'counts',
			array(
				'label'        => 'نمایش شمارندهٔ در انتظار',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'empty_text',
			array(
				'label'   => 'متن حالت خالی',
				'type'    => Controls_Manager::TEXTAREA,
				'default' => 'موردی برای نمایش وجود ندارد.',
			)
		);

		$this->end_controls_section();
	}

	protected function style_controls() {
		$this->table_style_controls( 'جدول تحویل‌ها' );

		$this->start_controls_section(
			'bmc_sec_deliv_style',
			array(
				'label' => 'کارت تحویل',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'item_typography',
				'label'    => 'تایپوگرافی نام محصول',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-deliv__body strong',
			)
		);

		$this->add_control(
			'item_bg',
			array(
				'label'     => 'پس‌زمینهٔ کارت',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-deliv__item' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'item_pending_bg',
			array(
				'label'     => 'پس‌زمینهٔ کارت در انتظار',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-deliv__item.is-pending' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'item_radius',
			array(
				'label'      => 'گردی کارت',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 32,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-deliv__item' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'item_gap',
			array(
				'label'      => 'فاصلهٔ بین کارت‌ها',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-deliv__list' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render_inner( $settings ) {
		if ( ! is_user_logged_in() ) {
			$placeholder = $this->editor_placeholder( 'فهرست تحویل‌ها فقط برای کاربر واردشده نمایش داده می‌شود.' );

			return '' !== $placeholder ? $placeholder : BMC_Public::login_notice( 'برای مشاهدهٔ تحویل‌ها وارد حساب کاربری شوید.' );
		}

		return BMC_Public::render_deliveries(
			array(
				'title'      => (string) $settings['title'],
				'title_icon' => (string) $settings['title_icon'],
				'status'     => (string) $settings['status'],
				'limit'      => (int) $settings['limit'],
				'layout'     => (string) $settings['layout'],
				'code'       => 'yes' === $settings['code'],
				'order'      => 'yes' === $settings['order'],
				'date'       => 'yes' === $settings['date'],
				'hint'       => 'yes' === $settings['hint'],
				'counts'     => 'yes' === $settings['counts'],
				'empty_text' => (string) $settings['empty_text'],
			)
		);
	}
}
