<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;
use Elementor\Repeater;

class BMC_EL_Account_Nav extends BMC_EL_Base {

	public function get_name() {
		return 'bmc-account-nav';
	}

	public function get_title() {
		return self::txt( 'Account Navigation', 'ناوبری حساب کاربری' );
	}

	public function get_icon() {
		return 'eicon-navigation-horizontal';
	}

	protected function bmc_slug() {
		return 'account-nav';
	}

	protected function extra_keywords() {
		return array( 'nav', 'menu', 'my account', 'navigation', 'منو', 'ناوبری', 'حساب کاربری', 'پیشخوان' );
	}

	protected function content_controls() {
		$this->start_controls_section(
			'bmc_sec_content',
			array(
				'label' => self::txt( 'Account Menu', 'منوی حساب کاربری' ),
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'bmc_notice',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => self::txt( 'WooCommerce account menu with BazzarMC features (Minecraft link & tickets). To customize items, select them below or switch to the Custom Menu Builder.', 'فهرست بخش‌های حساب کاربری ووکامرس به‌همراه بخش‌های BazzarMc (اتصال ماینکرافت و تیکت پشتیبانی). می‌توانید موارد را مستقیماً انتخاب یا با سازندهٔ اختصاصی مرتب کنید.' ),
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_control(
			'source_mode',
			array(
				'label'   => self::txt( 'Menu Mode', 'حالت تنظیم آیتم‌ها' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'default',
				'options' => array(
					'default' => self::txt( 'Automatic / Quick Select', 'انتخاب سریع بخش‌ها' ),
					'custom'  => self::txt( 'Custom Menu Builder (Repeater)', 'سازندهٔ سفارشی آیتم‌ها (با قابلیت جابجایی)' ),
				),
			)
		);

		$this->add_control(
			'layout',
			array(
				'label'   => self::txt( 'Layout', 'چیدمان' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'vertical',
				'options' => array(
					'vertical'   => self::txt( 'Vertical (Sidebar)', 'عمودی (ستون کناری)' ),
					'horizontal' => self::txt( 'Horizontal (Top Bar)', 'افقی (نوار بالا)' ),
					'pills'      => self::txt( 'Pills (Rounded Buttons)', 'قرصی (دکمه‌های گرد)' ),
				),
			)
		);

		$this->add_control(
			'title',
			array(
				'label'   => self::txt( 'Menu Title', 'عنوان منو' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'title_icon',
			array(
				'label'     => self::txt( 'Title Icon', 'آیکون عنوان' ),
				'type'      => Controls_Manager::TEXT,
				'default'   => 'menu_book',
				'condition' => array(
					'title!' => '',
				),
			)
		);

		$this->add_control(
			'icons',
			array(
				'label'        => self::txt( 'Show Icons', 'نمایش آیکون‌ها' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'counts',
			array(
				'label'        => self::txt( 'Show Badges & Counters', 'نمایش نشان‌ها و شمارنده' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'active_only',
			array(
				'label'        => self::txt( 'Active Item Only (Mobile Header)', 'فقط بخش فعال (برای سربرگ موبایل)' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'items',
			array(
				'label'       => self::txt( 'Displayed Items', 'بخش‌های نمایش داده‌شده' ),
				'type'        => Controls_Manager::SELECT2,
				'multiple'    => true,
				'default'     => array(),
				'options'     => $this->endpoint_options(),
				'description' => self::txt( 'Empty = All sections. Your selection and order will be applied instantly.', 'خالی = همهٔ بخش‌ها. موارد انتخاب‌شده به همان ترتیبی که برمی‌گزینید نمایش داده می‌شوند.' ),
				'condition'   => array(
					'source_mode' => 'default',
				),
			)
		);

		$item_repeater = new Repeater();

		$item_repeater->add_control(
			'endpoint',
			array(
				'label'   => self::txt( 'Item Type', 'نوع بخش' ),
				'type'    => Controls_Manager::SELECT,
				'default' => 'dashboard',
				'options' => array(
					'dashboard'       => self::txt( 'Dashboard', 'پیشخوان' ),
					'orders'          => self::txt( 'Orders', 'سفارش‌ها' ),
					'downloads'       => self::txt( 'Downloads', 'دانلودها' ),
					'edit-account'    => self::txt( 'Account Details', 'جزئیات حساب' ),
					'edit-address'    => self::txt( 'Addresses', 'آدرس‌ها' ),
					'payment-methods' => self::txt( 'Payment Methods', 'روش‌های پرداخت' ),
					'connect'         => self::txt( 'Minecraft Account', 'اتصال ماینکرافت' ),
					'tickets'         => self::txt( 'Support Tickets', 'تیکت پشتیبانی' ),
					'customer-logout' => self::txt( 'Log Out', 'خروج' ),
					'custom'          => self::txt( 'Custom Link', 'پیوند دلخواه' ),
				),
			)
		);

		$item_repeater->add_control(
			'label',
			array(
				'label'       => self::txt( 'Custom Title', 'عنوان دلخواه' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'placeholder' => self::txt( 'Leave empty for default title', 'خالی = عنوان پیش‌فرض' ),
			)
		);

		$item_repeater->add_control(
			'icon',
			array(
				'label'       => self::txt( 'Custom Icon (Material icon name)', 'آیکون دلخواه (نام آیکون متریال)' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'placeholder' => self::txt( 'e.g. dashboard, person', 'مثال: dashboard, receipt_long' ),
			)
		);

		$item_repeater->add_control(
			'url',
			array(
				'label'       => self::txt( 'Custom URL', 'نشانی پیوند' ),
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'condition'   => array(
					'endpoint' => 'custom',
				),
				'placeholder' => 'https://example.com',
			)
		);

		$item_repeater->add_control(
			'is_external',
			array(
				'label'        => self::txt( 'Open in new window', 'باز شدن در برگهٔ جدید' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'condition'    => array(
					'endpoint' => 'custom',
				),
			)
		);

		$item_repeater->add_control(
			'show_badge',
			array(
				'label'        => self::txt( 'Show Badge / Counter', 'نمایش نشان یا شمارنده' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'nav_items',
			array(
				'label'       => self::txt( 'Menu Items List', 'فهرست آیتم‌های منو' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $item_repeater->get_controls(),
				'default'     => array(
					array(
						'endpoint'   => 'dashboard',
						'label'      => '',
						'icon'       => 'dashboard',
						'show_badge' => 'yes',
					),
					array(
						'endpoint'   => 'orders',
						'label'      => '',
						'icon'       => 'receipt_long',
						'show_badge' => 'yes',
					),
					array(
						'endpoint'   => 'edit-account',
						'label'      => '',
						'icon'       => 'person',
						'show_badge' => 'yes',
					),
					array(
						'endpoint'   => 'tickets',
						'label'      => '',
						'icon'       => 'support_agent',
						'show_badge' => 'yes',
					),
					array(
						'endpoint'   => 'connect',
						'label'      => '',
						'icon'       => 'sports_esports',
						'show_badge' => 'yes',
					),
					array(
						'endpoint'   => 'customer-logout',
						'label'      => '',
						'icon'       => 'logout',
						'show_badge' => 'yes',
					),
				),
				'title_field' => '{{{ label ? label : endpoint }}}',
				'condition'   => array(
					'source_mode' => 'custom',
				),
			)
		);

		$repeater = new Repeater();

		$repeater->add_control(
			'label',
			array(
				'label'   => self::txt( 'Title', 'عنوان' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$repeater->add_control(
			'url',
			array(
				'label'   => self::txt( 'Link', 'پیوند' ),
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$repeater->add_control(
			'icon',
			array(
				'label'   => self::txt( 'Icon (Material icon name)', 'آیکون (نام آیکون متریال)' ),
				'type'    => Controls_Manager::TEXT,
				'default' => 'open_in_new',
			)
		);

		$this->add_control(
			'extra_items',
			array(
				'label'       => self::txt( 'Extra Custom Items', 'موارد دلخواه اضافی' ),
				'type'        => Controls_Manager::REPEATER,
				'fields'      => $repeater->get_controls(),
				'default'     => array(),
				'title_field' => '{{{ label }}}',
				'condition'   => array(
					'source_mode' => 'default',
				),
			)
		);

		$this->add_control(
			'mobile_heading',
			array(
				'type'  => Controls_Manager::HEADING,
				'label' => self::txt( 'Mobile Layout', 'طراحی موبایل' ),
			)
		);

		$this->add_control(
			'mobile',
			array(
				'label'       => self::txt( 'Mobile Layout', 'چیدمان موبایل' ),
				'type'        => Controls_Manager::SELECT,
				'default'     => '',
				'description' => self::txt( 'Empty = Global plugin setting. Applied only below the breakpoint width.', 'خالی = همان تنظیم کلی افزونه. این چیدمان فقط در عرض‌های کوچک‌تر از «عرض شکست» اعمال می‌شود.' ),
				'options'     => array(
					''         => self::txt( 'Plugin Default', 'پیش‌فرض افزونه' ),
					'scroll'   => self::txt( 'Horizontal Scrollable', 'افقی لغزان (یک ردیف قابل کشیدن)' ),
					'grid'     => self::txt( '3-Column Grid', 'شبکهٔ سه‌ستونی' ),
					'icons'    => self::txt( 'Compact Icons', 'آیکونی فشرده' ),
					'dropdown' => self::txt( 'Dropdown List', 'فهرست کشویی' ),
					'collapse' => self::txt( 'Collapsible Details', 'جمع‌شونده' ),
					'vertical' => self::txt( 'Vertical', 'عمودی' ),
				),
			)
		);

		$this->add_control(
			'mobile_labels',
			array(
				'label'        => self::txt( 'Item Labels on Mobile', 'برچسب آیتم‌ها در موبایل' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'description'  => self::txt( 'Disabled = Icons only (ideal for horizontal scrolling).', 'خاموش = فقط آیکون‌ها (مناسب چیدمان افقی لغزان).' ),
			)
		);

		$this->add_control(
			'mobile_sticky',
			array(
				'label'        => self::txt( 'Sticky Menu on Mobile', 'منوی چسبان در موبایل' ),
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
				'description'  => self::txt( 'Keeps navigation pinned to top during scroll.', 'هنگام اسکرول، منو در بالای نمایشگر می‌ماند.' ),
			)
		);

		$this->add_control(
			'breakpoint',
			array(
				'label'       => self::txt( 'Breakpoint (Pixels)', 'عرض شکست (پیکسل)' ),
				'type'        => Controls_Manager::NUMBER,
				'default'     => '',
				'min'         => 320,
				'max'         => 1600,
				'description' => self::txt( 'Empty = Default plugin setting (782).', 'خالی = مقدار تنظیمات افزونه (۷۸۲).' ),
			)
		);

		$this->end_controls_section();
	}

	private function endpoint_options() {
		$connect = class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::slug( 'connect' ) : 'minecraft';
		$tickets = class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::slug( 'tickets' ) : 'bmc-tickets';

		$options = array(
			'dashboard'       => self::txt( 'Dashboard', 'پیشخوان' ),
			'orders'          => self::txt( 'Orders', 'سفارش‌ها' ),
			'downloads'       => self::txt( 'Downloads', 'دانلودها' ),
			'edit-account'    => self::txt( 'Account Details', 'جزئیات حساب' ),
			'edit-address'    => self::txt( 'Addresses', 'آدرس‌ها' ),
			'payment-methods' => self::txt( 'Payment Methods', 'روش‌های پرداخت' ),
			'connect'         => self::txt( 'Minecraft Account', 'اتصال ماینکرافت' ),
			'tickets'         => self::txt( 'Support Tickets', 'تیکت پشتیبانی' ),
			'customer-logout' => self::txt( 'Log Out', 'خروج' ),
		);

		if ( function_exists( 'wc_get_account_menu_items' ) ) {
			foreach ( (array) wc_get_account_menu_items() as $endpoint => $label ) {
				$endpoint = sanitize_key( (string) $endpoint );
				if ( ! isset( $options[ $endpoint ] ) ) {
					$options[ $endpoint ] = esc_html( (string) $label );
				}
			}
		}

		return $options;
	}

	protected function style_controls() {
		$this->start_controls_section(
			'bmc_sec_nav_style',
			array(
				'label' => self::txt( 'Menu Style', 'منو' ),
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'item_typography',
				'label'    => self::txt( 'Item Typography', 'تایپوگرافی موارد' ),
				'selector' => '{{WRAPPER}} .bmc-el .bmc-nav__label',
			)
		);

		$this->add_responsive_control(
			'item_gap',
			array(
				'label'      => self::txt( 'Gap Between Items', 'فاصلهٔ بین موارد' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__list' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'item_padding',
			array(
				'label'      => self::txt( 'Item Padding', 'فاصلهٔ داخلی موارد' ),
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item a' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'item_radius',
			array(
				'label'      => self::txt( 'Item Radius', 'گردی موارد' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item a' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'icon_size',
			array(
				'label'      => self::txt( 'Icon Size', 'اندازهٔ آیکون' ),
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 12,
						'max' => 34,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__icon .bmc-ico' => 'width: {{SIZE}}{{UNIT}}; height: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->start_controls_tabs( 'bmc_nav_tabs' );

		$this->start_controls_tab(
			'bmc_nav_normal',
			array(
				'label' => self::txt( 'Normal', 'عادی' ),
			)
		);

		$this->add_control(
			'item_color',
			array(
				'label'     => self::txt( 'Text Color', 'رنگ متن' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item a' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'item_bg',
			array(
				'label'     => self::txt( 'Background', 'پس‌زمینه' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item a' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'item_border_color',
			array(
				'label'     => self::txt( 'Border Color', 'رنگ حاشیه' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item a' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'bmc_nav_hover',
			array(
				'label' => self::txt( 'Hover', 'هاور' ),
			)
		);

		$this->add_control(
			'item_hover_color',
			array(
				'label'     => self::txt( 'Text Color', 'رنگ متن' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item a:hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'item_hover_bg',
			array(
				'label'     => self::txt( 'Background', 'پس‌زمینه' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item a:hover' => 'background: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'bmc_nav_active',
			array(
				'label' => self::txt( 'Active Item', 'بخش فعال' ),
			)
		);

		$this->add_control(
			'item_active_color',
			array(
				'label'     => self::txt( 'Text Color', 'رنگ متن' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item.is-active a' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'item_active_bg',
			array(
				'label'     => self::txt( 'Background', 'پس‌زمینه' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item.is-active a' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'item_active_border',
			array(
				'label'     => self::txt( 'Border Color', 'رنگ حاشیه' ),
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-nav__item.is-active a' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'title_typography',
				'label'    => self::txt( 'Title Typography', 'تایپوگرافی عنوان منو' ),
				'selector' => '{{WRAPPER}} .bmc-el .bmc-nav__title',
			)
		);

		$this->end_controls_section();
	}

	protected function render_inner( $settings ) {
		if ( ! is_user_logged_in() ) {
			$placeholder = $this->editor_placeholder( self::txt( 'Account navigation is only displayed for logged-in users.', 'منوی حساب کاربری فقط برای کاربر واردشده نمایش داده می‌شود.' ) );

			return '' !== $placeholder ? $placeholder : BMC_Public::login_notice( self::txt( 'Please log in to view the account menu.', 'برای مشاهدهٔ منوی حساب کاربری وارد حساب شوید.' ) );
		}

		$source_mode = isset( $settings['source_mode'] ) ? (string) $settings['source_mode'] : 'default';

		$args = array(
			'source_mode' => $source_mode,
			'layout'      => isset( $settings['layout'] ) ? (string) $settings['layout'] : 'vertical',
			'icons'       => isset( $settings['icons'] ) && 'yes' === $settings['icons'],
			'counts'      => isset( $settings['counts'] ) && 'yes' === $settings['counts'],
			'active_only' => isset( $settings['active_only'] ) && 'yes' === $settings['active_only'],
			'title'       => isset( $settings['title'] ) ? (string) $settings['title'] : '',
			'title_icon'  => isset( $settings['title_icon'] ) ? (string) $settings['title_icon'] : 'menu_book',
			'items'       => isset( $settings['items'] ) ? array_map( 'sanitize_key', (array) $settings['items'] ) : array(),
			'nav_items'   => isset( $settings['nav_items'] ) ? $this->clean_nav_items( $settings['nav_items'] ) : array(),
			'extra'       => isset( $settings['extra_items'] ) ? $this->clean_extra( $settings['extra_items'] ) : array(),
			'mobile'      => isset( $settings['mobile'] ) ? sanitize_key( (string) $settings['mobile'] ) : '',
			'breakpoint'  => isset( $settings['breakpoint'] ) ? absint( $settings['breakpoint'] ) : 0,
		);

		if ( ! empty( $settings['mobile_labels'] ) ) {
			$args['mobile_labels'] = 'yes' === $settings['mobile_labels'];
		}

		if ( ! empty( $settings['mobile_sticky'] ) ) {
			$args['mobile_sticky'] = 'yes' === $settings['mobile_sticky'];
		}

		return BMC_Public::render_account_nav( $args );
	}

	private function clean_nav_items( $items ) {
		$out = array();

		foreach ( (array) $items as $item ) {
			if ( ! is_array( $item ) ) {
				continue;
			}

			$endpoint = isset( $item['endpoint'] ) ? sanitize_key( (string) $item['endpoint'] ) : 'dashboard';

			if ( '' === $endpoint ) {
				$endpoint = 'dashboard';
			}

			$out[] = array(
				'endpoint'    => $endpoint,
				'label'       => isset( $item['label'] ) ? sanitize_text_field( (string) $item['label'] ) : '',
				'icon'        => isset( $item['icon'] ) ? sanitize_key( (string) $item['icon'] ) : '',
				'url'         => isset( $item['url'] ) ? esc_url_raw( (string) $item['url'] ) : '',
				'is_external' => ! empty( $item['is_external'] ) && 'yes' === $item['is_external'],
				'show_badge'  => ! isset( $item['show_badge'] ) || 'yes' === $item['show_badge'],
			);
		}

		return $out;
	}

	private function clean_extra( $items ) {
		$out = array();

		foreach ( (array) $items as $item ) {
			if ( empty( $item['label'] ) || empty( $item['url'] ) ) {
				continue;
			}

			$out[] = array(
				'label' => sanitize_text_field( (string) $item['label'] ),
				'url'   => esc_url_raw( (string) $item['url'] ),
				'icon'  => sanitize_key( (string) ( isset( $item['icon'] ) ? $item['icon'] : '' ) ),
			);
		}

		return $out;
	}
}
