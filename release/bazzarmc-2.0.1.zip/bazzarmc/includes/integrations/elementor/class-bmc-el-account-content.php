<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class BMC_EL_Account_Content extends BMC_EL_Base {

	public function get_name() {
		return 'bmc-account-content';
	}

	public function get_title() {
		return self::txt( 'Account Content', 'محتوای حساب کاربری' );
	}

	public function get_icon() {
		return 'eicon-single-page';
	}

	protected function bmc_slug() {
		return 'account-content';
	}

	protected function extra_keywords() {
		return array( 'content', 'endpoint', 'orders', 'my account', 'محتوا', 'سفارش', 'حساب کاربری' );
	}

	protected function content_controls() {
		$this->start_controls_section(
			'bmc_sec_content',
			array(
				'label' => 'محتوای حساب کاربری',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'bmc_notice',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => 'روی «بخش جاری» محتوا بر اساس آدرس صفحهٔ حساب کاربری نمایش داده می‌شود (سفارش‌ها، آدرس‌ها، اتصال ماینکرافت، تیکت‌ها…). برای طراحی هر بخش می‌توانید آن را مستقیماً انتخاب کنید.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_control(
			'endpoint',
			array(
				'label'   => 'بخش',
				'type'    => Controls_Manager::SELECT,
				'default' => 'current',
				'options' => array(
					'current'         => 'بخش جاری (پیشنهادی)',
					'dashboard'       => 'داشبورد',
					'orders'          => 'سفارش‌ها',
					'downloads'       => 'دانلودها',
					'edit-address'    => 'آدرس‌ها',
					'payment-methods' => 'روش‌های پرداخت',
					'edit-account'    => 'جزئیات حساب',
				) + $this->bmc_endpoint_labels(),
			)
		);

		$this->add_control(
			'address',
			array(
				'label'     => 'نوع آدرس',
				'type'      => Controls_Manager::SELECT,
				'default'   => '',
				'options'   => array(
					''         => 'بر اساس آدرس صفحه',
					'billing'  => 'پرداخت',
					'shipping' => 'ارسال',
				),
				'condition' => array(
					'endpoint' => 'edit-address',
				),
			)
		);

		$this->add_control(
			'order_id',
			array(
				'label'       => 'شناسهٔ سفارش',
				'type'        => Controls_Manager::NUMBER,
				'default'     => 0,
				'description' => 'فقط برای نمایش جزئیات یک سفارش مشخص در صفحه‌ای جدا.',
				'condition'   => array(
					'endpoint' => 'view-order',
				),
			)
		);

		$this->add_control(
			'hide_notices',
			array(
				'label'        => 'پنهان‌کردن پیام‌های ووکامرس',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->add_control(
			'card_wrap',
			array(
				'label'        => 'قرار دادن محتوا در کارت BazzarMc',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->end_controls_section();
	}

	protected function style_controls() {
		$this->start_controls_section(
			'bmc_sec_content_style',
			array(
				'label' => 'محتوا',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'heading_typography',
				'label'    => 'تایپوگرافی عنوان‌ها',
				'selector' => '{{WRAPPER}} .bmc-el h1, {{WRAPPER}} .bmc-el h2, {{WRAPPER}} .bmc-el h3',
			)
		);

		$this->add_control(
			'heading_color',
			array(
				'label'     => 'رنگ عنوان‌ها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el h1, {{WRAPPER}} .bmc-el h2, {{WRAPPER}} .bmc-el h3' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'body_typography',
				'label'    => 'تایپوگرافی متن و جدول',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-content, {{WRAPPER}} .bmc-el table, {{WRAPPER}} .bmc-el p',
			)
		);

		$this->add_control(
			'link_color',
			array(
				'label'     => 'رنگ پیوندها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el a' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'table_head_bg',
			array(
				'label'     => 'پس‌زمینهٔ سرستون جدول‌ها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el thead th, {{WRAPPER}} .bmc-el table.shop_table th' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_bg',
			array(
				'label'     => 'پس‌زمینهٔ دکمه‌ها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .button, {{WRAPPER}} .bmc-el button, {{WRAPPER}} .bmc-el .woocommerce-button' => 'background-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'button_color',
			array(
				'label'     => 'رنگ متن دکمه‌ها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .button, {{WRAPPER}} .bmc-el button, {{WRAPPER}} .bmc-el .woocommerce-button' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'content_padding',
			array(
				'label'      => 'فاصلهٔ داخلی کارت',
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-content' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	private function bmc_endpoint_labels() {
		$connect = class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::slug( 'connect' ) : 'minecraft';
		$tickets = class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::slug( 'tickets' ) : 'bmc-tickets';
		$view    = class_exists( 'BMC_Tickets' ) ? BMC_Tickets::ENDPOINT_VIEW : 'bmc-ticket';

		return array(
			$connect => class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::title( 'connect' ) : 'اتصال ماینکرافت',
			$tickets => 'تیکت‌ها',
			$view    => 'گفت‌وگوی تیکت',
		);
	}

	protected function render_inner( $settings ) {
		if ( ! is_user_logged_in() ) {
			$placeholder = $this->editor_placeholder( 'محتوای حساب کاربری فقط برای کاربر واردشده نمایش داده می‌شود.' );

			return '' !== $placeholder ? $placeholder : BMC_Public::login_notice( 'برای مشاهدهٔ این بخش وارد حساب کاربری شوید.' );
		}

		if ( $this->woocommerce_missing() ) {
			return $this->notice( 'برای نمایش محتوای حساب کاربری، ووکامرس باید فعال باشد.' );
		}

		$endpoint = (string) $settings['endpoint'];

		if ( 'view-order' === $endpoint && ! (int) $settings['order_id'] ) {
			$endpoint = 'orders';
		}

		$html = BMC_Public::render_account_content(
			$endpoint,
			array(
				'hide_notices' => 'yes' === $settings['hide_notices'],
				'address'      => (string) $settings['address'],
				'order_id'     => (int) $settings['order_id'],
			)
		);

		if ( '' === trim( (string) $html ) ) {
			return $this->editor_placeholder( 'این بخش محتوایی برای نمایش ندارد.' );
		}

		if ( 'yes' === $settings['card_wrap'] ) {
			return '<div class="bmc-content">' . $html . '</div>';
		}

		return $html;
	}
}
