(function ($) {
	'use strict';

	if (typeof bmcAdmin === 'undefined') {
		return;
	}

	function toast(message, type) {
		$('.bmc-toast').remove();
		var $t = $('<div class="bmc-toast"></div>').addClass(type ? 'is-' + type : '').text(message);
		$('body').append($t);
		setTimeout(function () {
			$t.fadeOut(220, function () { $t.remove(); });
		}, 4200);
	}

	$(document).on('click', '.bmc-copy', function () {
		var text = $(this).data('copy');
		var $btn = $(this);
		var original = $btn.html();

		var done = function () {
			$btn.text(bmcAdmin.i18n.copied);
			setTimeout(function () { $btn.html(original); }, 1600);
		};

		if (navigator.clipboard && navigator.clipboard.writeText) {
			navigator.clipboard.writeText(String(text)).then(done).catch(function () { fallback(text, done); });
		} else {
			fallback(text, done);
		}
	});

	function fallback(text, cb) {
		var $tmp = $('<textarea>').val(text).css({ position: 'fixed', top: '-1000px', opacity: 0 }).appendTo('body');
		$tmp[0].select();
		try {
			document.execCommand('copy');
			cb();
		} catch (e) {
			toast('کپی ناموفق بود.', 'error');
		}
		$tmp.remove();
	}

	function syncToggle(input) {
		var $label = $(input).closest('.bmc-toggle');
		if ($label.length) {
			$label.toggleClass('is-on', !!input.checked);
		}
	}

	$(document).on('change', '.bmc-toggle input[type="checkbox"]', function () {
		syncToggle(this);
	});

	$(document).on('click', '.bmc-toggle__track, .bmc-toggle__label', function (e) {
		var $input = $(this).closest('.bmc-toggle').find('input[type="checkbox"]').first();
		if ($input.length && !$input.prop('disabled')) {
			e.preventDefault();
			$input.prop('checked', !$input.prop('checked')).trigger('change');
		}
	});

	function initModeSwitch() {
		var mode = 'simple';
		try {
			mode = localStorage.getItem('bmc_admin_mode') || 'simple';
		} catch (e) {}
		setMode(mode, false);

		$(document).on('click', '.bmc-mode-btn', function () {
			var newMode = $(this).data('mode');
			setMode(newMode, true);
		});
	}

	function setMode(mode, save) {
		var $admin = $('.bmc-admin');
		if (!$admin.length) {
			return;
		}

		$admin.removeClass('bmc--mode-simple bmc--mode-advanced').addClass('bmc--mode-' + mode);
		$('.bmc-mode-btn').removeClass('is-active').filter('[data-mode="' + mode + '"]').addClass('is-active');

		if (save) {
			try {
				localStorage.setItem('bmc_admin_mode', mode);
			} catch (e) {}

			toast(mode === 'advanced' ? 'حالت پیشرفته فعال شد — تمام فیلدها و جزئیات نمایش داده می‌شوند.' : 'حالت ساده فعال شد — فقط تنظیمات اصلی نمایش داده می‌شوند.', 'ok');
		}
	}

	$(function () {
		initModeSwitch();

		$('.bmc-toggle input[type="checkbox"]').each(function () {
			syncToggle(this);
		});
	});

	$(document).on('click', '.bmc-action', function (e) {
		e.preventDefault();

		var $btn = $(this);
		var action = $btn.data('do');

		if ($btn.data('confirm') && !window.confirm(bmcAdmin.i18n.confirm)) {
			return;
		}

		var data = { action: 'bmc_admin_action', security: bmcAdmin.nonce, 'do': action };

		if ($btn.data('id')) {
			data.id = $btn.data('id');
		}

		if ($btn.data('status')) {
			data.status = $btn.data('status');
		}

		var extra = $btn.data('extra');
		if (extra) {
			$.each(String(extra).split(','), function (i, pair) {
				var parts = pair.split(':');
				if (parts.length === 2) {
					data[parts[0]] = $(parts[1]).val();
				}
			});
		}

		var original = $btn.html();
		$btn.prop('disabled', true).html(bmcAdmin.i18n.working);

		$.post(bmcAdmin.ajaxUrl, data)
			.done(function (res) {
				if (res && res.success) {
					toast(res.data.message || bmcAdmin.i18n.done, 'ok');
					handleSpecial(action, res.data);

					if ($btn.data('remove-row')) {
						$btn.closest('tr').fadeOut(200, function () { $(this).remove(); });
					} else if ($btn.data('reload')) {
						setTimeout(function () { window.location.reload(); }, 700);
					}
				} else {
					toast((res && res.data && res.data.message) ? res.data.message : bmcAdmin.i18n.error, 'error');
				}
			})
			.fail(function (xhr) {
				var msg = (xhr.responseJSON && xhr.responseJSON.data && xhr.responseJSON.data.message) ? xhr.responseJSON.data.message : bmcAdmin.i18n.error;
				toast(msg, 'error');
			})
			.always(function () {
				$btn.prop('disabled', false).html(original);
			});
	});

	function handleSpecial(action, data) {
		if (action === 'regenerate_token' && data.token) {
			$('#bmcTokenValue, #bmcTokenField, #bmcFullToken').text(data.token);
			$('#bmcMaskedToken').text(data.token.substring(0, 4) + '••••••••••••' + data.token.substring(data.token.length - 4));
			$('.bmc-copy[data-copy]').attr('data-copy', data.token);
		}

		if (action === 'run_health' && data.checks) {
			renderHealth(data.checks);
		}
	}

	function renderHealth(checks) {
		var $box = $('#bmcHealthResult');
		if (!$box.length) {
			return;
		}

		var labels = { ok: 'سالم', warn: 'هشدار', fail: 'نیازمند اقدام', info: 'اطلاع' };
		var html = '<table class="bmc-table bmc-table--full"><thead><tr><th style="width:190px">بررسی</th><th style="width:120px">نتیجه</th><th>جزئیات</th></tr></thead><tbody>';

		$.each(checks, function (i, row) {
			html += '<tr class="bmc-health-' + row.status + '">' +
				'<td><strong>' + $('<span>').text(row.label).html() + '</strong></td>' +
				'<td><span class="bmc-pill is-' + (row.status === 'ok' ? 'done' : (row.status === 'fail' ? 'expired' : (row.status === 'warn' ? 'pending' : 'info'))) + '">' + (labels[row.status] || row.status) + '</span></td>' +
				'<td>' + row.detail + '</td></tr>';
		});

		html += '</tbody></table>';
		$box.html(html).slideDown(160);
	}

	$(document).on('click', '#bmcOpenGrantModal', function () {
		$('#bmcGrantModal').fadeIn(160);
	});

	$(document).on('click', '#bmcCloseGrantModal, #bmcCancelGrant, .bmc-modal__backdrop', function () {
		$('#bmcGrantModal').fadeOut(160);
	});

	$(document).on('click', '#bmcSubmitGrant', function () {
		var player = $.trim($('#bmcGrantPlayer').val());
		var item = $.trim($('#bmcGrantItem').val());
		var amount = parseInt($('#bmcGrantAmount').val(), 10) || 1;
		var note = $.trim($('#bmcGrantNote').val());
		var timing = $('input[name="grant_timing"]:checked').val() || 'now';

		if (!player || !item) {
			toast('نام بازیکن و آیتم پاداش الزامی هستند.', 'error');
			return;
		}

		var $btn = $(this);
		var original = $btn.html();
		$btn.prop('disabled', true).html(bmcAdmin.i18n.working);

		$.post(bmcAdmin.ajaxUrl, {
			action: 'bmc_admin_action',
			security: bmcAdmin.nonce,
			'do': 'manual_grant',
			player: player,
			item: item,
			amount: amount,
			note: note,
			timing: timing
		}).done(function (res) {
			if (res && res.success) {
				toast(res.data.message || 'پاداش با موفقیت ثبت شد.', 'ok');
				$('#bmcGrantModal').fadeOut(160);
				setTimeout(function () { window.location.reload(); }, 600);
			} else {
				toast((res && res.data && res.data.message) ? res.data.message : bmcAdmin.i18n.error, 'error');
			}
		}).fail(function () {
			toast(bmcAdmin.i18n.error, 'error');
		}).always(function () {
			$btn.prop('disabled', false).html(original);
		});
	});

	$(document).on('click', '#bmcToggleTokenReveal', function () {
		var $masked = $('#bmcMaskedToken');
		var $full = $('#bmcFullToken');
		var $btn = $(this);

		if ($full.is(':visible')) {
			$full.hide();
			$masked.show();
			$btn.text('نمایش کامل');
		} else {
			$masked.hide();
			$full.show();
			$btn.text('مخفی‌سازی');
		}
	});

	$(document).on('change', '#bmcSelectAllUsers', function () {
		$('.bmc-user-checkbox').prop('checked', $(this).prop('checked'));
	});

	$(document).on('keyup', '#bmcProductSearch', function () {
		var val = $.trim($(this).val()).toLowerCase();
		$('#bmcProductList .bmc-product').each(function () {
			var title = String($(this).data('title') || '');
			if (!val || title.indexOf(val) !== -1) {
				$(this).show();
			} else {
				$(this).hide();
			}
		});
	});

	$(document).on('click', '.bmc-delivery-action', function () {
		var $btn = $(this);
		var action = $btn.data('do');
		var id = $btn.data('id');
		var original = $btn.html();

		$btn.prop('disabled', true).html('…');

		$.post(bmcAdmin.ajaxUrl, {
			action: 'bmc_delivery_action',
			security: bmcAdmin.nonce,
			'do': action,
			id: id
		}).done(function (res) {
			if (res && res.success) {
				toast(res.data.message || 'عملیات با موفقیت انجام شد.', 'ok');
				setTimeout(function () { window.location.reload(); }, 500);
			} else {
				toast((res && res.data && res.data.message) ? res.data.message : bmcAdmin.i18n.error, 'error');
				$btn.prop('disabled', false).html(original);
			}
		}).fail(function () {
			toast(bmcAdmin.i18n.error, 'error');
			$btn.prop('disabled', false).html(original);
		});
	});

})(jQuery);
