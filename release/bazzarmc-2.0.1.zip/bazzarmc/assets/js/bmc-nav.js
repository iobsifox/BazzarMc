(function () {
	'use strict';

	function ready(fn) {
		if (document.readyState !== 'loading') {
			fn();
			return;
		}

		document.addEventListener('DOMContentLoaded', fn);
	}

	function navigate(select) {
		var url = select.value;

		if (url && url !== '#') {
			window.location.href = url;
		}
	}

	function syncActive(nav) {
		var active = nav.querySelector('.bmc-nav__item.is-active');
		var list = nav.querySelector('.bmc-nav__list');

		if (!active || !list) {
			return;
		}

		var mode = nav.getAttribute('data-bmc-mobile') || '';

		if ('scroll' !== mode) {
			return;
		}

		var target = active.offsetLeft - (list.clientWidth / 2) + (active.clientWidth / 2);

		if (target > 0) {
			list.scrollLeft = -target;
		}
	}

	function getAjaxUrl() {
		if (window.bmcFrontend && window.bmcFrontend.ajaxUrl) {
			return window.bmcFrontend.ajaxUrl;
		}
		if (window.bmcLink && window.bmcLink.ajaxUrl) {
			return window.bmcLink.ajaxUrl;
		}
		return '/wp-admin/admin-ajax.php';
	}

	function getNonce() {
		if (window.bmcFrontend && window.bmcFrontend.nonce) {
			return window.bmcFrontend.nonce;
		}
		if (window.bmcLink && window.bmcLink.publicNonce) {
			return window.bmcLink.publicNonce;
		}
		return '';
	}

	var toastTimeout = null;
	function showToast(message, isError) {
		var toast = document.getElementById('bmcToastNotification');
		if (!toast) {
			toast = document.createElement('div');
			toast.id = 'bmcToastNotification';
			toast.className = 'bmc-toast';
			toast.setAttribute('dir', 'rtl');
			document.body.appendChild(toast);
		}

		toast.className = 'bmc-toast ' + (isError ? 'bmc-toast--error' : 'bmc-toast--ok');
		var iconName = isError ? 'warning' : 'check_circle';
		toast.innerHTML = (window.bmcIcon ? window.bmcIcon(iconName, { size: 17 }) : '') + '<span>' + message + '</span>';

		if (toastTimeout) {
			clearTimeout(toastTimeout);
		}

		requestAnimationFrame(function () {
			toast.classList.add('is-show');
		});

		toastTimeout = setTimeout(function () {
			toast.classList.remove('is-show');
		}, 3600);
	}

	function ensureOrderModal() {
		var modal = document.getElementById('bmcOrderModal');
		if (modal) {
			return modal;
		}

		modal = document.createElement('div');
		modal.className = 'bmc-omodal';
		modal.id = 'bmcOrderModal';
		modal.setAttribute('dir', 'rtl');
		modal.setAttribute('role', 'dialog');
		modal.setAttribute('aria-modal', 'true');
		modal.setAttribute('aria-labelledby', 'bmcOrderModalTitle');
		modal.hidden = true;

		modal.innerHTML =
			'<div class="bmc-omodal__scrim" data-bmc-omodal-close></div>' +
			'<div class="bmc-omodal__panel">' +
				'<div class="bmc-omodal__bar">' +
					'<span class="bmc-omodal__bar-icon">' +
						(window.bmcIcon ? window.bmcIcon('receipt_long', { size: 18 }) : '') +
					'</span>' +
					'<h3 class="bmc-omodal__title" id="bmcOrderModalTitle">جزئیات سفارش</h3>' +
					'<button type="button" class="bmc-omodal__close" data-bmc-omodal-close aria-label="بستن">' +
						(window.bmcIcon ? window.bmcIcon('close', { size: 18 }) : '×') +
					'</button>' +
				'</div>' +
				'<div class="bmc-omodal__body" id="bmcOrderModalBody">' +
					'<div class="bmc-omodal__loading">' +
						'<span class="bmc-omodal__spinner"></span>' +
						'<span>در حال بارگذاری اطلاعات سفارش…</span>' +
					'</div>' +
				'</div>' +
			'</div>';

		document.body.appendChild(modal);
		return modal;
	}

	function openOrderModal(orderId) {
		var modal = ensureOrderModal();
		var titleEl = document.getElementById('bmcOrderModalTitle');
		var bodyEl = document.getElementById('bmcOrderModalBody');

		if (titleEl) {
			titleEl.textContent = 'سفارش #' + orderId;
		}

		if (bodyEl) {
			bodyEl.innerHTML =
				'<div class="bmc-omodal__loading">' +
					'<span class="bmc-omodal__spinner"></span>' +
					'<span>در حال بارگذاری اطلاعات سفارش…</span>' +
				'</div>';
		}

		modal.hidden = false;
		document.body.classList.add('bmc-omodal-lock');

		requestAnimationFrame(function () {
			modal.classList.add('is-open');
		});

		var params = new URLSearchParams();
		params.append('action', 'bmc_get_order_details');
		params.append('order_id', String(orderId));
		params.append('nonce', getNonce());

		fetch(getAjaxUrl(), {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
				'X-Requested-With': 'XMLHttpRequest'
			},
			body: params.toString(),
			credentials: 'same-origin'
		})
		.then(function (res) {
			if (!res.ok && res.status !== 400 && res.status !== 401 && res.status !== 403 && res.status !== 404) {
				throw new Error('HTTP ' + res.status);
			}
			return res.json();
		})
		.then(function (res) {
			if (res && res.success && res.data) {
				if (titleEl && res.data.title) {
					titleEl.textContent = res.data.title;
				}
				if (bodyEl && res.data.html) {
					bodyEl.innerHTML = res.data.html;
				}
			} else {
				var msg = (res && res.data && res.data.message) ? res.data.message : 'خطا در دریافت اطلاعات سفارش.';
				if (bodyEl) {
					bodyEl.innerHTML =
						'<div class="bmc-omodal__error">' +
							(window.bmcIcon ? window.bmcIcon('error', { size: 20 }) : '') +
							'<span>' + msg + '</span>' +
						'</div>';
				}
			}
		})
		.catch(function () {
			if (bodyEl) {
				bodyEl.innerHTML =
					'<div class="bmc-omodal__error">' +
						(window.bmcIcon ? window.bmcIcon('error', { size: 20 }) : '') +
						'<span>خطا در دریافت اطلاعات سفارش. لطفاً مجدداً تلاش کنید.</span>' +
					'</div>';
			}
		});
	}

	function closeOrderModal() {
		var modal = document.getElementById('bmcOrderModal');
		if (!modal) {
			return;
		}

		modal.classList.remove('is-open');
		document.body.classList.remove('bmc-omodal-lock');

		setTimeout(function () {
			modal.hidden = true;
		}, 220);
	}

	function extractOrderId(el) {
		var id = el.getAttribute('data-bmc-order-id') || el.getAttribute('data-order-id');
		if (id && !isNaN(parseInt(id, 10))) {
			return parseInt(id, 10);
		}

		var href = el.getAttribute('href') || '';
		var match = href.match(/view-order\/(\d+)/i) || href.match(/orders\/(\d+)/i) || href.match(/order-view\/(\d+)/i) || href.match(/[?&]order_id=(\d+)/i) || href.match(/[?&]view-order=(\d+)/i);
		if (match && match[1]) {
			return parseInt(match[1], 10);
		}

		var text = el.textContent || '';
		var numMatch = text.match(/#?(\d+)/);
		if (numMatch && numMatch[1] && (el.classList.contains('view') || el.closest('.woocommerce-orders-table'))) {
			return parseInt(numMatch[1], 10);
		}

		return 0;
	}

	function extractTicketId(el) {
		var id = el.getAttribute('data-bmc-ticket-id') || el.getAttribute('data-ticket-id');
		if (id && !isNaN(parseInt(id, 10))) {
			return parseInt(id, 10);
		}

		var href = el.getAttribute('href') || '';
		var match = href.match(/bmc-tickets?\/(\d+)/i) || href.match(/tickets?\/(\d+)/i) || href.match(/view-ticket\/(\d+)/i) || href.match(/[?&]ticket=(\d+)/i) || href.match(/[?&]ticket_id=(\d+)/i);
		if (match && match[1]) {
			return parseInt(match[1], 10);
		}

		return 0;
	}

	function ensureTicketNewModal() {
		var modal = document.getElementById('bmcTicketNewModal');
		if (modal) {
			return modal;
		}

		modal = document.createElement('div');
		modal.className = 'bmc-tmodal';
		modal.id = 'bmcTicketNewModal';
		modal.setAttribute('dir', 'rtl');
		modal.setAttribute('role', 'dialog');
		modal.setAttribute('aria-modal', 'true');
		modal.setAttribute('aria-labelledby', 'bmcTicketNewModalTitle');
		modal.hidden = true;

		modal.innerHTML =
			'<div class="bmc-tmodal__scrim" data-bmc-tmodal-close></div>' +
			'<div class="bmc-tmodal__panel">' +
				'<div class="bmc-tmodal__bar">' +
					'<span class="bmc-tmodal__bar-icon">' +
						(window.bmcIcon ? window.bmcIcon('note_add', { size: 18 }) : '') +
					'</span>' +
					'<h3 class="bmc-tmodal__title" id="bmcTicketNewModalTitle">ثبت تیکت پشتیبانی جدید</h3>' +
					'<button type="button" class="bmc-tmodal__close" data-bmc-tmodal-close aria-label="بستن">' +
						(window.bmcIcon ? window.bmcIcon('close', { size: 18 }) : '×') +
					'</button>' +
				'</div>' +
				'<form class="bmc-tmodal__body" id="bmcNewTicketModalForm" novalidate>' +
					'<div class="bmc-field-row">' +
						'<div class="bmc-field">' +
							'<label class="bmc-label" for="bmc-modal-ticket-category">دستهٔ درخواست <span class="bmc-req">*</span></label>' +
							'<select class="bmc-input" id="bmc-modal-ticket-category" name="ticket_category" required>' +
								'<option value="product">محصول خریداری‌شده</option>' +
								'<option value="delivery">تحویل در بازی</option>' +
								'<option value="rank">رنک و مدت اعتبار</option>' +
								'<option value="payment">پرداخت و بازگشت وجه</option>' +
								'<option value="account">حساب کاربری و اتصال</option>' +
								'<option value="other">سایر موارد</option>' +
							'</select>' +
						'</div>' +
						'<div class="bmc-field">' +
							'<label class="bmc-label" for="bmc-modal-ticket-product-order">محصول یا سفارش مرتبط</label>' +
							'<select class="bmc-input" id="bmc-modal-ticket-product-order" name="ticket_product_order">' +
								'<option value="">— موضوع عمومی (بدون سفارش خاص) —</option>' +
							'</select>' +
						'</div>' +
					'</div>' +
					'<div class="bmc-field">' +
						'<label class="bmc-label" for="bmc-modal-ticket-subject">موضوع تیکت <span class="bmc-req">*</span></label>' +
						'<input class="bmc-input" type="text" id="bmc-modal-ticket-subject" name="ticket_subject" maxlength="150" required placeholder="مثلاً: مشکل در تحویل رنک یا راهنمایی خرید" />' +
					'</div>' +
					'<div class="bmc-field">' +
						'<label class="bmc-label" for="bmc-modal-ticket-body">شرح درخواست و توضیحات <span class="bmc-req">*</span></label>' +
						'<textarea class="bmc-input" id="bmc-modal-ticket-body" name="ticket_body" rows="5" required placeholder="توضیحات کامل مشکل خود، نام کاربری ماینکرافت یا شماره سفارش را بنویسید…"></textarea>' +
					'</div>' +
					'<div class="bmc-tmodal__notice">' +
						(window.bmcIcon ? window.bmcIcon('info', { size: 15 }) : '') +
						'<span>پاسخ کارشناسان پشتیبانی در همین بخش ثبت شده و از طریق ایمیل نیز به شما اطلاع‌رسانی خواهد شد.</span>' +
					'</div>' +
					'<div class="bmc-tmodal__error-box" id="bmcNewTicketError" style="display:none;"></div>' +
					'<div class="bmc-tmodal__actions">' +
						'<button type="submit" class="bmc-btn bmc-btn-p" id="bmcNewTicketSubmitBtn">' +
							'<span class="bmc-btn__icon">' + (window.bmcIcon ? window.bmcIcon('send', { size: 16 }) : '') + '</span>' +
							'<span class="bmc-btn__text">ثبت و ارسال تیکت</span>' +
						'</button>' +
						'<button type="button" class="bmc-btn bmc-btn-o" data-bmc-tmodal-close>انصراف</button>' +
					'</div>' +
				'</form>' +
			'</div>';

		document.body.appendChild(modal);
		return modal;
	}

	function openTicketNewModal(prefill) {
		closeOrderModal();
		closeTicketViewModal();

		var modal = ensureTicketNewModal();
		var form = document.getElementById('bmcNewTicketModalForm');
		var errBox = document.getElementById('bmcNewTicketError');

		if (errBox) {
			errBox.style.display = 'none';
			errBox.textContent = '';
		}

		if (form && !prefill) {
			form.reset();
		}

		if (prefill && form) {
			if (prefill.orderId) {
				var poSelect = form.querySelector('[name="ticket_product_order"]');
				if (poSelect) {
					var opt = poSelect.querySelector('option[data-order-id="' + prefill.orderId + '"]') ||
						poSelect.querySelector('option[value*="o:' + prefill.orderId + '"]');
					if (opt) {
						poSelect.value = opt.value;
					}
				}
			}
			if (prefill.category) {
				var catSelect = form.querySelector('[name="ticket_category"]');
				if (catSelect) {
					catSelect.value = prefill.category;
				}
			}
		}

		modal.hidden = false;
		document.body.classList.add('bmc-omodal-lock');

		requestAnimationFrame(function () {
			modal.classList.add('is-open');
			var subInput = document.getElementById('bmc-modal-ticket-subject');
			if (subInput) {
				subInput.focus();
			}
		});
	}

	function closeTicketNewModal() {
		var modal = document.getElementById('bmcTicketNewModal');
		if (!modal) {
			return;
		}

		modal.classList.remove('is-open');
		if (!document.getElementById('bmcTicketViewModal.is-open') && !document.getElementById('bmcOrderModal.is-open')) {
			document.body.classList.remove('bmc-omodal-lock');
		}

		setTimeout(function () {
			modal.hidden = true;
		}, 220);
	}

	function ensureTicketViewModal() {
		var modal = document.getElementById('bmcTicketViewModal');
		if (modal) {
			return modal;
		}

		modal = document.createElement('div');
		modal.className = 'bmc-tmodal';
		modal.id = 'bmcTicketViewModal';
		modal.setAttribute('dir', 'rtl');
		modal.setAttribute('role', 'dialog');
		modal.setAttribute('aria-modal', 'true');
		modal.setAttribute('aria-labelledby', 'bmcTicketViewModalTitle');
		modal.hidden = true;

		modal.innerHTML =
			'<div class="bmc-tmodal__scrim" data-bmc-tmodal-close></div>' +
			'<div class="bmc-tmodal__panel">' +
				'<div class="bmc-tmodal__bar">' +
					'<span class="bmc-tmodal__bar-icon">' +
						(window.bmcIcon ? window.bmcIcon('forum', { size: 18 }) : '') +
					'</span>' +
					'<h3 class="bmc-tmodal__title" id="bmcTicketViewModalTitle">گفت‌وگوی تیکت</h3>' +
					'<button type="button" class="bmc-tmodal__close" data-bmc-tmodal-close aria-label="بستن">' +
						(window.bmcIcon ? window.bmcIcon('close', { size: 18 }) : '×') +
					'</button>' +
				'</div>' +
				'<div class="bmc-tmodal__body" id="bmcTicketViewModalBody">' +
					'<div class="bmc-tmodal__loading">' +
						'<span class="bmc-tmodal__spinner"></span>' +
						'<span>در حال بارگذاری گفت‌وگو…</span>' +
					'</div>' +
				'</div>' +
			'</div>';

		document.body.appendChild(modal);
		return modal;
	}

	function openTicketViewModal(ticketId, preloadedHtml) {
		closeOrderModal();
		closeTicketNewModal();

		var modal = ensureTicketViewModal();
		var titleEl = document.getElementById('bmcTicketViewModalTitle');
		var bodyEl = document.getElementById('bmcTicketViewModalBody');

		if (titleEl) {
			titleEl.textContent = 'گفت‌وگوی تیکت #' + ticketId;
		}

		modal.hidden = false;
		document.body.classList.add('bmc-omodal-lock');

		requestAnimationFrame(function () {
			modal.classList.add('is-open');
		});

		if (preloadedHtml && bodyEl) {
			bodyEl.innerHTML = preloadedHtml;
			scrollThreadToBottom();
			return;
		}

		if (bodyEl) {
			bodyEl.innerHTML =
				'<div class="bmc-tmodal__loading">' +
					'<span class="bmc-tmodal__spinner"></span>' +
					'<span>در حال بارگذاری گفت‌وگو…</span>' +
				'</div>';
		}

		var params = new URLSearchParams();
		params.append('action', 'bmc_get_ticket_details');
		params.append('ticket_id', String(ticketId));
		params.append('nonce', getNonce());

		fetch(getAjaxUrl(), {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
				'X-Requested-With': 'XMLHttpRequest'
			},
			body: params.toString(),
			credentials: 'same-origin'
		})
		.then(function (res) {
			if (!res.ok && res.status !== 400 && res.status !== 401 && res.status !== 403 && res.status !== 404) {
				throw new Error('HTTP ' + res.status);
			}
			return res.json();
		})
		.then(function (res) {
			if (res && res.success && res.data) {
				if (titleEl && res.data.title) {
					titleEl.textContent = res.data.title;
				}
				if (bodyEl && res.data.html) {
					bodyEl.innerHTML = res.data.html;
					scrollThreadToBottom();
				}
			} else {
				var msg = (res && res.data && res.data.message) ? res.data.message : 'خطا در دریافت اطلاعات تیکت.';
				if (bodyEl) {
					bodyEl.innerHTML =
						'<div class="bmc-tmodal__error">' +
							(window.bmcIcon ? window.bmcIcon('error', { size: 20 }) : '') +
							'<span>' + msg + '</span>' +
						'</div>';
				}
			}
		})
		.catch(function () {
			if (bodyEl) {
				bodyEl.innerHTML =
					'<div class="bmc-tmodal__error">' +
						(window.bmcIcon ? window.bmcIcon('error', { size: 20 }) : '') +
						'<span>خطا در دریافت اطلاعات تیکت. لطفاً مجدداً تلاش کنید.</span>' +
					'</div>';
			}
		});
	}

	function closeTicketViewModal() {
		var modal = document.getElementById('bmcTicketViewModal');
		if (!modal) {
			return;
		}

		modal.classList.remove('is-open');
		if (!document.getElementById('bmcTicketNewModal.is-open') && !document.getElementById('bmcOrderModal.is-open')) {
			document.body.classList.remove('bmc-omodal-lock');
		}

		setTimeout(function () {
			modal.hidden = true;
		}, 220);
	}

	function scrollThreadToBottom() {
		var thread = document.getElementById('bmcTicketThread');
		if (thread) {
			thread.scrollTop = thread.scrollHeight;
		}
	}

	function insertTicketIntoDOM(ticketData) {
		if (!ticketData || !ticketData.ticket_id) {
			return;
		}

		var tkList = document.querySelector('.bmc-tk-list');
		var emptyCard = document.querySelector('.bmc-tickets .bmc-empty');

		if (emptyCard) {
			emptyCard.remove();
		}

		if (!tkList) {
			var ticketsWrap = document.querySelector('.bmc-tickets');
			if (ticketsWrap) {
				tkList = document.createElement('div');
				tkList.className = 'bmc-tk-list';
				ticketsWrap.appendChild(tkList);
			}
		}

		if (tkList) {
			var existing = tkList.querySelector('[data-bmc-ticket-id="' + ticketData.ticket_id + '"]');
			if (!existing) {
				var iconHtml = window.bmcIcon ? window.bmcIcon('mark_email_unread', { size: 20 }) : '';
				var chatIcon = window.bmcIcon ? window.bmcIcon('chat', { size: 13 }) : '';
				var schedIcon = window.bmcIcon ? window.bmcIcon('schedule', { size: 13 }) : '';
				var prodIcon = window.bmcIcon ? window.bmcIcon('inventory_2', { size: 13 }) : '';

				var productHtml = ticketData.product_name ? '<span>' + prodIcon + ' ' + ticketData.product_name + '</span>' : '';

				var item = document.createElement('a');
				item.className = 'bmc-tk-item bmc-tk-item--' + (ticketData.status_tone || 'blue');
				item.href = ticketData.view_url || '#';
				item.setAttribute('data-bmc-ticket-id', String(ticketData.ticket_id));

				item.innerHTML =
					'<span class="bmc-tk-item__icon">' + iconHtml + '</span>' +
					'<span class="bmc-tk-item__body">' +
						'<span class="bmc-tk-item__title">' + ticketData.subject + '</span>' +
						'<span class="bmc-tk-item__meta">' +
							'<code>' + ticketData.reference + '</code>' +
							'<span>' + (ticketData.category_label || '') + '</span>' +
							productHtml +
							'<span>' + chatIcon + ' ۱ پیام</span>' +
							'<span>' + schedIcon + ' ' + (ticketData.date || 'هم‌اکنون') + '</span>' +
						'</span>' +
					'</span>' +
					'<span class="bmc-tk-item__status">' +
						'<span class="bmc-pill">' + (ticketData.status_label || 'باز') + '</span>' +
						'<span class="bmc-tag bmc-tag-ok">پاسخ جدید</span>' +
					'</span>';

				if (tkList.firstChild) {
					tkList.insertBefore(item, tkList.firstChild);
				} else {
					tkList.appendChild(item);
				}
			}
		}

		var ctxList = document.querySelector('.bmc-acard__box--ctx.is-tickets .bmc-ctx-list');
		var ctxHint = document.querySelector('.bmc-acard__box--ctx.is-tickets .bmc-acard__hint');

		if (ctxHint) {
			ctxHint.remove();
		}

		if (!ctxList) {
			var ctxBox = document.querySelector('.bmc-acard__box--ctx.is-tickets');
			if (ctxBox) {
				ctxList = document.createElement('ul');
				ctxList.className = 'bmc-ctx-list';
				var actions = ctxBox.querySelector('.bmc-ctx-actions');
				if (actions) {
					ctxBox.insertBefore(ctxList, actions);
				} else {
					ctxBox.appendChild(ctxList);
				}
			}
		}

		if (ctxList) {
			var existingCtx = ctxList.querySelector('[data-bmc-ticket-id="' + ticketData.ticket_id + '"]');
			if (!existingCtx) {
				var ticketIcon = window.bmcIcon ? window.bmcIcon('confirmation_number', { size: 16 }) : '';
				var li = document.createElement('li');
				li.innerHTML =
					'<a href="' + (ticketData.view_url || '#') + '" data-bmc-ticket-id="' + ticketData.ticket_id + '">' +
						'<span class="bmc-ctx-list__icon">' + ticketIcon + '</span>' +
						'<span class="bmc-ctx-list__body">' +
							'<strong>' + ticketData.subject + '</strong>' +
							'<small>' + ticketData.reference + ' • ' + (ticketData.date || 'هم‌اکنون') + '</small>' +
						'</span>' +
						'<span class="bmc-pill bmc-pill--' + (ticketData.status_tone || 'blue') + '">' +
							(ticketData.status_label || 'باز') +
						'</span>' +
					'</a>';

				if (ctxList.firstChild) {
					ctxList.insertBefore(li, ctxList.firstChild);
				} else {
					ctxList.appendChild(li);
				}
			}
		}

		var statValues = document.querySelectorAll('.bmc-tk-stat__value');
		Array.prototype.forEach.call(statValues, function (sv) {
			var cur = parseInt(sv.textContent.replace(/[۰-۹]/g, function (d) {
				return '۰۱۲۳۴۵۶۷۸۹'.indexOf(d);
			}), 10);
			if (!isNaN(cur)) {
				var next = cur + 1;
				var fa = String(next).replace(/[0-9]/g, function (d) {
					return '۰۱۲۳۴۵۶۷۸۹'[parseInt(d, 10)];
				});
				sv.textContent = fa;
			}
		});

		var chip = document.querySelector('.bmc-acard__box--ctx.is-tickets .bmc-chip');
		if (chip) {
			chip.classList.add('bmc-chip--warn');
		}
	}

	function updateTicketStatusInDOM(ticketId, status, statusLabel, tone) {
		var items = document.querySelectorAll('[data-bmc-ticket-id="' + ticketId + '"]');
		Array.prototype.forEach.call(items, function (item) {
			var pill = item.querySelector('.bmc-pill');
			if (pill) {
				pill.textContent = statusLabel;
				pill.className = 'bmc-pill bmc-pill--' + (tone || 'blue');
			}
			if (item.classList.contains('bmc-tk-item')) {
				item.className = 'bmc-tk-item bmc-tk-item--' + (tone || 'blue');
			}
		});
	}

	function handleNewTicketSubmit(form, e) {
		e.preventDefault();

		var errBox = document.getElementById('bmcNewTicketError');
		var btn = document.getElementById('bmcNewTicketSubmitBtn');
		var subInput = form.querySelector('[name="ticket_subject"]');
		var bodyInput = form.querySelector('[name="ticket_body"]');
		var catSelect = form.querySelector('[name="ticket_category"]');
		var poSelect = form.querySelector('[name="ticket_product_order"]');

		var subject = subInput ? subInput.value.trim() : '';
		var body = bodyInput ? bodyInput.value.trim() : '';
		var category = catSelect ? catSelect.value : 'other';
		var productOrder = poSelect ? poSelect.value : '';

		if (errBox) {
			errBox.style.display = 'none';
			errBox.textContent = '';
		}

		if (subject.length < 4) {
			if (errBox) {
				errBox.textContent = 'موضوع تیکت را کامل‌تر بنویسید (حداقل ۴ نویسه).';
				errBox.style.display = 'block';
			}
			if (subInput) {
				subInput.focus();
			}
			return;
		}

		if (body.length < 10) {
			if (errBox) {
				errBox.textContent = 'شرح درخواست را کامل‌تر بنویسید (حداقل ۱۰ نویسه).';
				errBox.style.display = 'block';
			}
			if (bodyInput) {
				bodyInput.focus();
			}
			return;
		}

		if (btn) {
			btn.disabled = true;
			var btnText = btn.querySelector('.bmc-btn__text');
			if (btnText) {
				btnText.textContent = 'در حال ثبت…';
			}
		}

		var params = new URLSearchParams();
		params.append('action', 'bmc_create_ticket_ajax');
		params.append('ticket_subject', subject);
		params.append('ticket_body', body);
		params.append('ticket_category', category);
		params.append('ticket_product_order', productOrder);
		params.append('nonce', getNonce());

		fetch(getAjaxUrl(), {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
				'X-Requested-With': 'XMLHttpRequest'
			},
			body: params.toString(),
			credentials: 'same-origin'
		})
		.then(function (res) {
			if (!res.ok && res.status !== 400 && res.status !== 401 && res.status !== 403 && res.status !== 404) {
				throw new Error('HTTP ' + res.status);
			}
			return res.json();
		})
		.then(function (res) {
			if (btn) {
				btn.disabled = false;
				var btnText = btn.querySelector('.bmc-btn__text');
				if (btnText) {
					btnText.textContent = 'ثبت و ارسال تیکت';
				}
			}

			if (res && res.success && res.data) {
				form.reset();
				closeTicketNewModal();
				showToast(res.data.message || 'تیکت شما با موفقیت ثبت شد.');
				insertTicketIntoDOM(res.data);
				openTicketViewModal(res.data.ticket_id, res.data.html);
			} else {
				var msg = (res && res.data && res.data.message) ? res.data.message : 'خطا در ثبت تیکت.';
				if (errBox) {
					errBox.textContent = msg;
					errBox.style.display = 'block';
				}
			}
		})
		.catch(function () {
			if (btn) {
				btn.disabled = false;
				var btnText = btn.querySelector('.bmc-btn__text');
				if (btnText) {
					btnText.textContent = 'ثبت و ارسال تیکت';
				}
			}
			if (errBox) {
				errBox.textContent = 'خطا در برقراری ارتباط با سرور. لطفاً مجدداً تلاش کنید.';
				errBox.style.display = 'block';
			}
		});
	}

	function handleReplyTicketSubmit(form, e) {
		e.preventDefault();

		var ticketIdInput = form.querySelector('[name="ticket_id"]');
		var bodyInput = form.querySelector('[name="ticket_reply_body"]') || form.querySelector('[name="ticket_body"]');
		var errBox = document.getElementById('bmcReplyTicketError');
		var btn = document.getElementById('bmcReplySubmitBtn');

		var ticketId = ticketIdInput ? parseInt(ticketIdInput.value, 10) : 0;
		var body = bodyInput ? bodyInput.value.trim() : '';

		if (errBox) {
			errBox.style.display = 'none';
			errBox.textContent = '';
		}

		if (!ticketId || !body) {
			if (errBox) {
				errBox.textContent = 'متن پاسخ نمی‌تواند خالی باشد.';
				errBox.style.display = 'block';
			}
			if (bodyInput) {
				bodyInput.focus();
			}
			return;
		}

		if (btn) {
			btn.disabled = true;
			var btnText = btn.querySelector('.bmc-btn__text');
			if (btnText) {
				btnText.textContent = 'در حال ارسال…';
			}
		}

		var params = new URLSearchParams();
		params.append('action', 'bmc_reply_ticket_ajax');
		params.append('ticket_id', String(ticketId));
		params.append('ticket_reply_body', body);
		params.append('nonce', getNonce());

		fetch(getAjaxUrl(), {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
				'X-Requested-With': 'XMLHttpRequest'
			},
			body: params.toString(),
			credentials: 'same-origin'
		})
		.then(function (res) {
			if (!res.ok && res.status !== 400 && res.status !== 401 && res.status !== 403 && res.status !== 404) {
				throw new Error('HTTP ' + res.status);
			}
			return res.json();
		})
		.then(function (res) {
			if (btn) {
				btn.disabled = false;
				var btnText = btn.querySelector('.bmc-btn__text');
				if (btnText) {
					btnText.textContent = 'ارسال پاسخ';
				}
			}

			if (res && res.success && res.data) {
				var bodyEl = document.getElementById('bmcTicketViewModalBody');
				if (bodyEl && res.data.html) {
					bodyEl.innerHTML = res.data.html;
					scrollThreadToBottom();
				}
				if (res.data.status && res.data.status_label) {
					updateTicketStatusInDOM(res.data.ticket_id, res.data.status, res.data.status_label, res.data.status_tone);
				}
				showToast(res.data.message || 'پاسخ شما با موفقیت ثبت شد.');
			} else {
				var msg = (res && res.data && res.data.message) ? res.data.message : 'خطا در ارسال پاسخ.';
				if (errBox) {
					errBox.textContent = msg;
					errBox.style.display = 'block';
				}
			}
		})
		.catch(function () {
			if (btn) {
				btn.disabled = false;
				var btnText = btn.querySelector('.bmc-btn__text');
				if (btnText) {
					btnText.textContent = 'ارسال پاسخ';
				}
			}
			if (errBox) {
				errBox.textContent = 'خطا در ارسال پاسخ. لطفاً مجدداً تلاش کنید.';
				errBox.style.display = 'block';
			}
		});
	}

	function handleCloseTicket(ticketId, btn) {
		if (!window.confirm('آیا از بستن این تیکت مطمئن هستید؟')) {
			return;
		}

		if (btn) {
			btn.disabled = true;
		}

		var params = new URLSearchParams();
		params.append('action', 'bmc_close_ticket_ajax');
		params.append('ticket_id', String(ticketId));
		params.append('action_type', 'close');
		params.append('nonce', getNonce());

		fetch(getAjaxUrl(), {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
				'X-Requested-With': 'XMLHttpRequest'
			},
			body: params.toString(),
			credentials: 'same-origin'
		})
		.then(function (res) {
			if (!res.ok && res.status !== 400 && res.status !== 401 && res.status !== 403 && res.status !== 404) {
				throw new Error('HTTP ' + res.status);
			}
			return res.json();
		})
		.then(function (res) {
			if (btn) {
				btn.disabled = false;
			}
			if (res && res.success && res.data) {
				var bodyEl = document.getElementById('bmcTicketViewModalBody');
				if (bodyEl && res.data.html) {
					bodyEl.innerHTML = res.data.html;
				}
				updateTicketStatusInDOM(ticketId, res.data.status, res.data.status_label, res.data.status_tone);
				showToast(res.data.message || 'تیکت با موفقیت بسته شد.');
			} else {
				var msg = (res && res.data && res.data.message) ? res.data.message : 'خطا در بستن تیکت.';
				showToast(msg, true);
			}
		})
		.catch(function () {
			if (btn) {
				btn.disabled = false;
			}
			showToast('خطا در بستن تیکت. لطفاً مجدداً تلاش کنید.', true);
		});
	}

	function handleReopenTicket(ticketId, btn) {
		if (btn) {
			btn.disabled = true;
		}

		var params = new URLSearchParams();
		params.append('action', 'bmc_close_ticket_ajax');
		params.append('ticket_id', String(ticketId));
		params.append('action_type', 'reopen');
		params.append('nonce', getNonce());

		fetch(getAjaxUrl(), {
			method: 'POST',
			headers: {
				'Content-Type': 'application/x-www-form-urlencoded; charset=UTF-8',
				'X-Requested-With': 'XMLHttpRequest'
			},
			body: params.toString(),
			credentials: 'same-origin'
		})
		.then(function (res) {
			if (!res.ok && res.status !== 400 && res.status !== 401 && res.status !== 403 && res.status !== 404) {
				throw new Error('HTTP ' + res.status);
			}
			return res.json();
		})
		.then(function (res) {
			if (btn) {
				btn.disabled = false;
			}
			if (res && res.success && res.data) {
				var bodyEl = document.getElementById('bmcTicketViewModalBody');
				if (bodyEl && res.data.html) {
					bodyEl.innerHTML = res.data.html;
					scrollThreadToBottom();
				}
				updateTicketStatusInDOM(ticketId, res.data.status, res.data.status_label, res.data.status_tone);
				showToast(res.data.message || 'تیکت دوباره باز شد.');
			} else {
				var msg = (res && res.data && res.data.message) ? res.data.message : 'خطا در بازکردن تیکت.';
				showToast(msg, true);
			}
		})
		.catch(function () {
			if (btn) {
				btn.disabled = false;
			}
			showToast('خطا در بازکردن تیکت. لطفاً مجدداً تلاش کنید.', true);
		});
	}

	function handleGlobalClicks(e) {
		if (e.metaKey || e.ctrlKey || e.shiftKey || e.altKey || e.button !== 0) {
			return;
		}

		var omodalClose = e.target.closest('[data-bmc-omodal-close]');
		if (omodalClose) {
			e.preventDefault();
			closeOrderModal();
			return;
		}

		var tmodalClose = e.target.closest('[data-bmc-tmodal-close]');
		if (tmodalClose) {
			e.preventDefault();
			closeTicketNewModal();
			closeTicketViewModal();
			return;
		}

		var closeTicketBtn = e.target.closest('.bmc-ticket-close-btn');
		if (closeTicketBtn) {
			e.preventDefault();
			var ticketId = closeTicketBtn.getAttribute('data-ticket-id');
			if (ticketId) {
				handleCloseTicket(parseInt(ticketId, 10), closeTicketBtn);
			}
			return;
		}

		var reopenTicketBtn = e.target.closest('.bmc-ticket-reopen-btn');
		if (reopenTicketBtn) {
			e.preventDefault();
			var reopenId = reopenTicketBtn.getAttribute('data-ticket-id');
			if (reopenId) {
				handleReopenTicket(parseInt(reopenId, 10), reopenTicketBtn);
			}
			return;
		}

		var newTicketBtn = e.target.closest('[data-bmc-ticket-new], .bmc-ticket-new-btn, a[href*="new=1"], a[href*="#bmc-new-ticket"], a[href*="ticket_new"]');
		if (newTicketBtn) {
			e.preventDefault();
			var prefill = {};
			var orderId = extractOrderId(newTicketBtn);
			if (orderId > 0) {
				prefill.orderId = orderId;
			}
			var cat = newTicketBtn.getAttribute('data-category');
			if (cat) {
				prefill.category = cat;
			}
			openTicketNewModal(prefill);
			return;
		}

		var ticketLink = e.target.closest('[data-bmc-ticket-id], .bmc-tk-item, a[href*="bmc-ticket"], a[href*="view-ticket"], .bmc-ctx-list a[href*="ticket"]');
		if (ticketLink && !ticketLink.closest('#bmcTicketNewModal') && !ticketLink.closest('#bmcTicketViewModal')) {
			var ticketId = extractTicketId(ticketLink);
			if (ticketId > 0) {
				e.preventDefault();
				openTicketViewModal(ticketId);
				return;
			}
		}

		var orderLink = e.target.closest('.bmc-order-modal-open, [data-bmc-order-id], .woocommerce-orders-table__cell-order-number a, .woocommerce-orders-table__cell-order-actions a.view, .bmc-ctx-list a[href*="view-order"]');
		if (orderLink && !orderLink.closest('#bmcOrderModal') && !orderLink.closest('#bmcTicketNewModal') && !orderLink.closest('#bmcTicketViewModal')) {
			var ordId = extractOrderId(orderLink);
			if (ordId > 0) {
				e.preventDefault();
				openOrderModal(ordId);
				return;
			}
		}
	}

	function handleGlobalSubmits(e) {
		var target = e.target;
		if (!target) {
			return;
		}

		if (target.id === 'bmcNewTicketModalForm') {
			handleNewTicketSubmit(target, e);
			return;
		}

		if (target.id === 'bmcReplyTicketModalForm') {
			handleReplyTicketSubmit(target, e);
			return;
		}
	}

	ready(function () {
		document.addEventListener('click', handleGlobalClicks);
		document.addEventListener('submit', handleGlobalSubmits);

		document.addEventListener('keydown', function (e) {
			if (e.key === 'Escape' || e.keyCode === 27) {
				closeOrderModal();
				closeTicketNewModal();
				closeTicketViewModal();
			}
		});

		var selects = document.querySelectorAll('[data-bmc-nav-select]');

		Array.prototype.forEach.call(selects, function (select) {
			if (select.getAttribute('data-bmc-bound') === '1') {
				return;
			}

			select.setAttribute('data-bmc-bound', '1');
			select.addEventListener('change', function () {
				navigate(select);
			});
		});

		var navs = document.querySelectorAll('.bmc-nav[data-bmc-mobile]');

		Array.prototype.forEach.call(navs, function (nav) {
			if (nav.getAttribute('data-bmc-synced') === '1') {
				return;
			}

			nav.setAttribute('data-bmc-synced', '1');
			syncActive(nav);

			window.addEventListener('resize', function () {
				var bp = parseInt(nav.getAttribute('data-bmc-breakpoint') || '0', 10);

				if (bp && window.innerWidth <= bp) {
					syncActive(nav);
				}
			});
		});
	});
})();
