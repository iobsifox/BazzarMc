(function () {
	'use strict';

	function ready(fn) {
		if (document.readyState !== 'loading') {
			fn();
			return;
		}

		document.addEventListener('DOMContentLoaded', fn);
	}

	function navigate(select) {
		var url = select.value;

		if (url && url !== '#') {
			window.location.href = url;
		}
	}

	function syncActive(nav) {
		var active = nav.querySelector('.bmc-nav__item.is-active');
		var list = nav.querySelector('.bmc-nav__list');

		if (!active || !list) {
			return;
		}

		var mode = nav.getAttribute('data-bmc-mobile') || '';

		if ('scroll' !== mode) {
			return;
		}

		var target = active.offsetLeft - (list.clientWidth / 2) + (active.clientWidth / 2);

		if (target > 0) {
			list.scrollLeft = -target;
		}
	}

	ready(function () {
		var selects = document.querySelectorAll('[data-bmc-nav-select]');

		Array.prototype.forEach.call(selects, function (select) {
			if (select.getAttribute('data-bmc-bound') === '1') {
				return;
			}

			select.setAttribute('data-bmc-bound', '1');
			select.addEventListener('change', function () {
				navigate(select);
			});
		});

		var navs = document.querySelectorAll('.bmc-nav[data-bmc-mobile]');

		Array.prototype.forEach.call(navs, function (nav) {
			if (nav.getAttribute('data-bmc-synced') === '1') {
				return;
			}

			nav.setAttribute('data-bmc-synced', '1');
			syncActive(nav);

			window.addEventListener('resize', function () {
				var bp = parseInt(nav.getAttribute('data-bmc-breakpoint') || '0', 10);

				if (bp && window.innerWidth <= bp) {
					syncActive(nav);
				}
			});
		});
	});
})();
