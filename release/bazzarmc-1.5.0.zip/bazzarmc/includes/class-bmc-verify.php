<?php
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Verify {

	const DASH_TRANSIENT = 'bmc_dash_codes_';

	public static function init() {
		add_action( 'wp_dashboard_setup', array( __CLASS__, 'register_dashboard_widget' ) );
		add_action( 'bmc_code_consumed', array( __CLASS__, 'on_code_consumed' ), 10, 2 );
		add_action( 'bmc_code_revoked', array( __CLASS__, 'on_code_revoked' ), 10, 2 );
	}

	public static function labels() {
		return array(
			'email'     => 'ایمیل',
			'dashboard' => 'داشبورد سایت',
		);
	}

	public static function icons() {
		return array(
			'email'     => 'mail',
			'dashboard' => 'desktop_windows',
		);
	}

	public static function enabled() {
		return BMC_Settings::verify_methods();
	}

	public static function is_enabled( $channel ) {
		return BMC_Settings::verify_enabled( $channel );
	}

	public static function resolve( $requested, $user_id = 0, $email = '' ) {
		$enabled = self::enabled();
		$requested = sanitize_key( (string) $requested );

		if ( $requested && in_array( $requested, $enabled, true ) ) {
			if ( 'dashboard' === $requested && ! absint( $user_id ) ) {
				return self::error( 'کانال «داشبورد» فقط برای کاربران واردشده قابل استفاده است.', 'CHANNEL' );
			}

			if ( 'email' === $requested && '' === trim( (string) $email ) ) {
				return self::error( 'برای دریافت کد با ایمیل، باید ایمیل حساب ثبت شده باشد.', 'CHANNEL' );
			}

			return $requested;
		}

		foreach ( array( 'email', 'dashboard' ) as $channel ) {
			if ( ! in_array( $channel, $enabled, true ) ) {
				continue;
			}

			if ( 'dashboard' === $channel && ! absint( $user_id ) ) {
				continue;
			}

			if ( 'email' === $channel && '' === trim( (string) $email ) ) {
				continue;
			}

			return $channel;
		}

		return self::error( 'هیچ روش تأییدی برای این حساب در دسترس نیست.', 'CHANNEL' );
	}

	public static function send( $type, $identifier, $code, array $context = array(), $channel = '', $user_id = 0 ) {
		$user_id = absint( $user_id );
		$email   = '';

		if ( $user_id ) {
			$user  = get_userdata( $user_id );
			$email = $user ? (string) $user->user_email : '';
		}

		if ( ! $email && isset( $context['email'] ) ) {
			$email = (string) $context['email'];
		}

		$resolved = self::resolve( $channel, $user_id, $email );

		if ( is_array( $resolved ) ) {
			return $resolved;
		}

		$context['channel'] = $resolved;

		if ( 'dashboard' === $resolved ) {
			$ttl = isset( $context['ttl'] ) ? (int) $context['ttl'] : BMC_Settings::int( 'otp_ttl', 120, 30, 900 );

			self::remember( $user_id, $type, $code, $identifier, $ttl );

			BMC_Logger::add(
				'auth',
				'کد در داشبورد کاربر نمایش داده شد',
				array(
					'type' => $type,
					'user' => $user_id,
				),
				'info'
			);

			return array(
				'success' => true,
				'channel' => 'dashboard',
				'message' => 'کد تأیید در داشبورد و پنل کاربری شما نمایش داده شد.',
				'code'    => (string) $code,
				'ttl'     => $ttl,
			);
		}

		unset( $identifier );

		$sent = self::send_email_code( $email, $code, $context );

		if ( empty( $sent['success'] ) ) {
			return self::error( $sent['message'], 'SEND_FAIL' );
		}

		return $sent;
	}

	public static function send_email_code( $email, $code, array $context = array() ) {
		$email = BMC_Helpers::sanitize_email( (string) $email );

		if ( ! $email ) {
			return array(
				'success' => false,
				'channel' => 'email',
				'message' => 'ایمیل نامعتبر است.',
			);
		}

		if ( ! BMC_Settings::bool( 'email_enabled', true ) ) {
			return array(
				'success' => false,
				'channel' => 'email',
				'message' => 'ارسال ایمیل غیرفعال است.',
			);
		}

		if ( ! isset( $context['minutes'] ) ) {
			$ttl                = BMC_Settings::int( 'otp_ttl', 120, 30, 900 );
			$context['minutes'] = BMC_Helpers::to_persian_digits( max( 1, (int) ceil( $ttl / 60 ) ) );
		}

		$repl = array_merge(
			$context,
			array(
				'{code}'   => (string) $code,
				'{player}' => isset( $context['player'] ) ? (string) $context['player'] : '',
				'{site}'   => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			)
		);

		$subject = BMC_Helpers::replace_tags( (string) BMC_Settings::get( 'email_tpl_subject' ), $repl );
		$body    = BMC_Helpers::replace_tags( (string) BMC_Settings::get( 'email_tpl_body' ), $repl );
		$site    = wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES );

		$wrapped = '<div dir="rtl" style="font-family:Tahoma,sans-serif;max-width:560px;margin:0 auto;border:1px solid #e5e7eb;border-radius:14px;overflow:hidden">'
			. '<div style="background:#0f1720;color:#fff;padding:18px 22px;font-size:15px">' . esc_html( $site ) . '</div>'
			. '<div style="padding:22px;background:#fff;color:#1f2933;font-size:14px;line-height:2">' . wp_kses_post( $body ) . '</div>'
			. '</div>';

		add_filter( 'wp_mail_content_type', array( __CLASS__, 'content_type_html' ) );
		$sent = wp_mail( $email, $subject, $wrapped );
		remove_filter( 'wp_mail_content_type', array( __CLASS__, 'content_type_html' ) );

		if ( ! $sent ) {
			BMC_Logger::add( 'auth', 'ارسال ایمیل کد به ' . $email . ' ناموفق بود', array(), 'error' );

			return array(
				'success' => false,
				'channel' => 'email',
				'message' => 'ارسال ایمیل ناموفق بود. تنظیمات SMTP هاست را بررسی کنید.',
			);
		}

		return array(
			'success' => true,
			'channel' => 'email',
			'message' => 'کد تأیید به ایمیل حساب شما ارسال شد.',
			'to'      => $email,
		);
	}

	public static function content_type_html() {
		return 'text/html';
	}

	public static function remember( $user_id, $type, $code, $identifier, $ttl ) {
		$user_id = absint( $user_id );

		if ( ! $user_id ) {
			return false;
		}

		$key   = self::DASH_TRANSIENT . $user_id;
		$codes = get_transient( $key );
		$codes = is_array( $codes ) ? $codes : array();

		$codes[ $type ] = array(
			'code'       => (string) $code,
			'identifier' => (string) $identifier,
			'created_at' => time(),
			'expires_at' => time() + max( 30, (int) $ttl ),
		);

		set_transient( $key, $codes, max( 30, (int) $ttl ) + 60 );

		return true;
	}

	public static function codes( $user_id = 0 ) {
		$user_id = $user_id ? absint( $user_id ) : get_current_user_id();

		if ( ! $user_id ) {
			return array();
		}

		$codes = get_transient( self::DASH_TRANSIENT . $user_id );

		if ( ! is_array( $codes ) || ! $codes ) {
			return array();
		}

		$now   = time();
		$valid = array();

		foreach ( $codes as $type => $row ) {
			if ( ! is_array( $row ) || empty( $row['code'] ) ) {
				continue;
			}

			if ( isset( $row['expires_at'] ) && (int) $row['expires_at'] < $now ) {
				continue;
			}

			if ( ! self::is_active_in_db( $user_id, $type, $row['code'] ) ) {
				continue;
			}

			$row['remaining'] = isset( $row['expires_at'] ) ? max( 0, (int) $row['expires_at'] - $now ) : 0;
			$valid[ $type ]   = $row;
		}

		return $valid;
	}

	public static function forget( $user_id, $type = '' ) {
		$user_id = absint( $user_id );

		if ( ! $user_id ) {
			return;
		}

		$key = self::DASH_TRANSIENT . $user_id;

		if ( '' === $type ) {
			delete_transient( $key );
			return;
		}

		$codes = get_transient( $key );

		if ( is_array( $codes ) && isset( $codes[ $type ] ) ) {
			unset( $codes[ $type ] );

			if ( $codes ) {
				set_transient( $key, $codes, HOUR_IN_SECONDS );
			} else {
				delete_transient( $key );
			}
		}
	}

	public static function on_code_consumed( $user_id, $type ) {
		self::forget( (int) $user_id, (string) $type );
	}

	public static function on_code_revoked( $user_id, $type ) {
		self::forget( (int) $user_id, (string) $type );
	}

	public static function register_dashboard_widget() {
		if ( ! BMC_Settings::verify_enabled( 'dashboard' ) || ! BMC_Settings::bool( 'otp_dashboard_widget', true ) ) {
			return;
		}

		wp_add_dashboard_widget(
			'bmc_dashboard_codes',
			'کدهای تأیید BazzarMc',
			array( __CLASS__, 'render_dashboard_widget' )
		);
	}

	public static function render_dashboard_widget() {
		$codes = self::codes();
		$labels = self::labels();

		echo '<div class="bmc-dash-codes">';

		if ( ! $codes ) {
			echo '<p style="color:#64748b;margin:6px 0">کد فعالی ندارید. هر زمان از پنل یا فرم ورود درخواست کد بدهید و کانال «داشبورد» را انتخاب کنید، کد همین‌جا نمایش داده می‌شود.</p>';
			echo '</div>';
			return;
		}

		foreach ( $codes as $type => $row ) {
			$title = isset( $labels[ $type ] ) ? $labels[ $type ] : $type;

			if ( 'otp_link' === $type ) {
				$title = 'کد اتصال به ماینکرافت';
			} elseif ( 'link' === $type ) {
				$title = 'کد اتصال پنل کاربری';
			}

			echo '<div style="border:1px solid #dcdcde;border-radius:10px;padding:12px 14px;margin:8px 0;background:#f6f7f7">';
			echo '<div style="font-size:12px;color:#50575e;margin-bottom:6px">' . esc_html( $title ) . '</div>';
			echo '<div style="font-family:Consolas,monospace;font-size:26px;font-weight:700;letter-spacing:6px;direction:ltr;text-align:left">' . esc_html( $row['code'] ) . '</div>';
			echo '<div style="font-size:12px;color:#50575e;margin-top:6px">اعتبار: ' . esc_html( BMC_Helpers::to_persian_digits( (int) ceil( $row['remaining'] / 60 ) ) ) . ' دقیقه باقی‌مانده</div>';
			echo '</div>';
		}

		echo '</div>';
	}

	public static function panel_box() {
		if ( ! BMC_Settings::verify_enabled( 'dashboard' ) || ! BMC_Settings::bool( 'otp_dashboard_box', true ) ) {
			return '';
		}

		$codes = self::codes();

		if ( ! $codes ) {
			return '';
		}

		$labels = self::labels();
		$out    = '<div class="bmc-dashbox"><div class="bmc-dashbox-title">کدهای تأیید فعال شما</div>';

		foreach ( $codes as $type => $row ) {
			$title = isset( $labels[ $type ] ) ? $labels[ $type ] : $type;

			if ( 'otp_link' === $type ) {
				$title = 'کد اتصال به ماینکرافت';
			} elseif ( 'link' === $type ) {
				$title = 'کد اتصال پنل کاربری';
			}

			$out .= '<div class="bmc-dashbox-row">';
			$out .= '<span class="bmc-dashbox-label">' . esc_html( $title ) . '</span>';
			$out .= '<span class="bmc-dashbox-code">' . esc_html( $row['code'] ) . '</span>';
			$out .= '<span class="bmc-dashbox-ttl">' . esc_html( BMC_Helpers::to_persian_digits( (int) ceil( $row['remaining'] / 60 ) ) ) . ' دقیقه</span>';
			$out .= '</div>';
		}

		$out .= '</div>';

		return $out;
	}

	public static function channel_selector( $current = '' ) {
		$enabled = self::enabled();

		if ( count( $enabled ) < 2 ) {
			return '';
		}

		if ( ! $current ) {
			$current = BMC_Settings::verify_default();
		}

		$labels = self::labels();
		$icons  = self::icons();

		$out = '<div class="bmc-channels">';

		foreach ( $enabled as $channel ) {
			$checked = ( $channel === $current ) ? ' checked="checked"' : '';
			$note    = '';

			if ( 'dashboard' === $channel ) {
				$note = is_user_logged_in() ? '' : ' (نیازمند ورود)';
			}

			$out .= '<label class="bmc-channel' . ( $channel === $current ? ' is-active' : '' ) . '">';
			$out .= '<input type="radio" name="bmc_channel" value="' . esc_attr( $channel ) . '"' . $checked . '>';
			$out .= '<span class="bmc-channel-icon">' . bmc_get_icon( isset( $icons[ $channel ] ) ? $icons[ $channel ] : 'info', array( 'size' => 18 ) ) . '</span>';
			$out .= '<span class="bmc-channel-label">' . esc_html( isset( $labels[ $channel ] ) ? $labels[ $channel ] : $channel ) . esc_html( $note ) . '</span>';
			$out .= '</label>';
		}

		$out .= '</div>';

		return $out;
	}

	private static function is_active_in_db( $user_id, $type, $code ) {
		global $wpdb;

		$table = BMC_DB::table( 'codes' );

		$row = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT user_id FROM {$table}
				 WHERE type = %s AND code_hash = %s AND status = 0 AND expires_at >= %s
				 ORDER BY id DESC LIMIT 1",
				sanitize_key( $type ),
				BMC_Helpers::hash_code( $code ),
				current_time( 'mysql' )
			)
		);

		if ( ! $row ) {
			return false;
		}

		return 0 === (int) $row->user_id || (int) $row->user_id === (int) $user_id;
	}

	private static function error( $message, $code = 'ERROR' ) {
		return array(
			'success' => false,
			'message' => $message,
			'code'    => $code,
			'channel' => '',
		);
	}
}
