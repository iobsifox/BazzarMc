<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Helpers {

	const FA_DIGITS = array( '۰', '۱', '۲', '۳', '۴', '۵', '۶', '۷', '۸', '۹', '٠', '١', '٢', '٣', '٤', '٥', '٦', '٧', '٨', '٩' );
	const EN_DIGITS = array( '0', '1', '2', '3', '4', '5', '6', '7', '8', '9' );

	public static function to_latin_digits( $string ) {
		return str_replace( self::FA_DIGITS, self::EN_DIGITS, (string) $string );
	}

	public static function to_persian_digits( $number ) {
		return str_replace( self::EN_DIGITS, self::FA_DIGITS, (string) $number );
	}

	public static function normalize_mobile( $input ) {
		$input = self::to_latin_digits( (string) $input );
		$input = preg_replace( '/[^0-9]/', '', $input );

		if ( '' === $input ) {
			return '';
		}

		if ( strlen( $input ) > 11 && strpos( $input, '98' ) === 0 ) {
			$input = substr( $input, -10 );
		} elseif ( strlen( $input ) > 11 && strpos( $input, '0098' ) === 0 ) {
			$input = substr( $input, -10 );
		}

		if ( 10 === strlen( $input ) && strpos( $input, '9' ) === 0 ) {
			$input = '0' . $input;
		}

		if ( ! preg_match( '/^09[0-9]{9}$/', $input ) ) {
			return '';
		}

		return $input;
	}

	public static function mobile_variants( $mobile ) {
		$mobile = self::normalize_mobile( $mobile );
		if ( '' === $mobile ) {
			return array();
		}

		return array_unique(
			array(
				$mobile,
				substr( $mobile, 1 ),
				'+98' . substr( $mobile, 1 ),
				'98' . substr( $mobile, 1 ),
				'0098' . substr( $mobile, 1 ),
			)
		);
	}

	public static function sanitize_email( $email ) {
		$email = sanitize_email( self::to_latin_digits( trim( (string) $email ) ) );
		return is_email( $email ) ? $email : false;
	}

	public static function random_code( $length = 8, $alphabet = 'safe' ) {
		$length = max( 4, min( 16, (int) $length ) );

		$sets = array(
			'safe'   => 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789',
			'digits' => '0123456789',
			'full'   => 'ABCDEFGHJKLMNPQRSTUVWXYZabcdefghijkmnopqrstuvwxyz23456789',
		);

		$chars = isset( $sets[ $alphabet ] ) ? $sets[ $alphabet ] : $sets['safe'];
		$max   = strlen( $chars ) - 1;
		$code  = '';

		for ( $i = 0; $i < $length; $i++ ) {
			$code .= $chars[ wp_rand( 0, $max ) ];
		}

		return $code;
	}

	public static function random_otp( $length = 5 ) {
		$length = max( 4, min( 8, (int) $length ) );
		$min    = (int) pow( 10, $length - 1 );
		$max    = (int) pow( 10, $length ) - 1;
		return (string) wp_rand( $min, $max );
	}

	public static function random_token( $bytes = 32 ) {
		try {
			return bin2hex( random_bytes( max( 16, (int) $bytes / 2 ) ) );
		} catch ( Exception $e ) {
			return wp_generate_password( max( 16, (int) $bytes ), false, false );
		}
	}

	public static function is_persian_digits_enabled() {
		return class_exists( 'BMC_Settings' ) && BMC_Settings::bool( 'persian_digits', false );
	}

	public static function local_datetime( $timestamp = null ) {
		$timestamp = null === $timestamp ? current_time( 'timestamp' ) : (int) $timestamp;

		return gmdate( 'Y-m-d H:i:s', $timestamp );
	}

	public static function expires_at( $seconds ) {
		return self::local_datetime( current_time( 'timestamp' ) + max( 1, (int) $seconds ) );
	}

	public static function now_timestamp() {
		return (int) current_time( 'timestamp' );
	}

	public static function hash_code( $code ) {
		return hash_hmac( 'sha256', strtoupper( trim( (string) $code ) ), wp_salt( 'auth' ) );
	}

	public static function equals( $a, $b ) {
		return hash_equals( (string) $a, (string) $b );
	}

	public static function client_ip() {
		$sources = array( 'HTTP_CF_CONNECTING_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_REAL_IP', 'REMOTE_ADDR' );

		foreach ( $sources as $key ) {
			if ( ! empty( $_SERVER[ $key ] ) ) {
				$value = sanitize_text_field( wp_unslash( $_SERVER[ $key ] ) );
				if ( false !== strpos( $value, ',' ) ) {
					$parts = explode( ',', $value );
					$value = trim( $parts[0] );
				}
				if ( filter_var( $value, FILTER_VALIDATE_IP ) ) {
					return $value;
				}
			}
		}

		return '0.0.0.0';
	}

	public static function ip_hash() {
		return substr( hash_hmac( 'sha256', self::client_ip(), wp_salt( 'auth' ) ), 0, 32 );
	}

	public static function valid_player_name( $player ) {
		$player = trim( (string) $player );
		return (bool) preg_match( '/^[A-Za-z0-9_]{3,16}$/', $player );
	}

	public static function normalize_uuid( $uuid ) {
		$uuid = preg_replace( '/[^a-f0-9]/i', '', (string) $uuid );
		return 32 === strlen( $uuid ) ? strtolower( $uuid ) : '';
	}

	public static function mc_head( $player, $size = 64, $type = 'avatar' ) {
		$player = $player ? rawurlencode( $player ) : 'MHF_Question';
		$size   = max( 8, min( 512, (int) $size ) );
		return sprintf( 'https://mc-heads.net/%s/%s/%d', $type, $player, $size );
	}

	public static function mojang_check( $player ) {
		$player = trim( (string) $player );

		if ( ! self::valid_player_name( $player ) ) {
			return array(
				'ok'     => false,
				'reason' => 'FORMAT',
			);
		}

		$cache_key = 'bmc_mojang_' . strtolower( $player );
		$cached    = get_transient( $cache_key );

		if ( false !== $cached && is_array( $cached ) ) {
			return $cached;
		}

		$response = wp_remote_get(
			'https://api.mojang.com/users/profiles/minecraft/' . rawurlencode( $player ),
			array(
				'timeout' => 8,
				'headers' => array( 'Accept' => 'application/json' ),
			)
		);

		if ( is_wp_error( $response ) ) {
			return array(
				'ok'     => false,
				'reason' => 'ERR',
			);
		}

		$code = (int) wp_remote_retrieve_response_code( $response );
		$body = json_decode( wp_remote_retrieve_body( $response ), true );

		if ( 200 === $code && ! empty( $body['id'] ) ) {
			$result = array(
				'ok'     => true,
				'uuid'   => self::normalize_uuid( $body['id'] ),
				'name'   => isset( $body['name'] ) ? sanitize_text_field( $body['name'] ) : $player,
				'reason' => 'OK',
			);
			set_transient( $cache_key, $result, 6 * HOUR_IN_SECONDS );
			return $result;
		}

		if ( in_array( $code, array( 204, 404 ), true ) ) {
			$result = array(
				'ok'     => false,
				'reason' => 'NF',
			);
			set_transient( $cache_key, $result, HOUR_IN_SECONDS );
			return $result;
		}

		return array(
			'ok'     => false,
			'reason' => 'ERR',
		);
	}

	public static function replace_tags( $template, array $repl = array() ) {
		$defaults = array(
			'{site}'     => wp_specialchars_decode( get_bloginfo( 'name' ), ENT_QUOTES ),
			'{site_url}' => home_url( '/' ),
			'{year}'     => wp_date( 'Y' ),
		);

		$repl = array_merge( $defaults, $repl );

		$keys   = array_keys( $repl );
		$values = array_values( $repl );

		return str_replace( $keys, $values, (string) $template );
	}

	public static function format_price( $amount, $currency = 'rial' ) {
		$amount = (float) $amount;

		if ( 'toman' === strtolower( $currency ) ) {
			$amount = $amount / 10;
		}

		$symbol = function_exists( 'get_woocommerce_currency_symbol' ) ? get_woocommerce_currency_symbol() : 'ریال';

		return self::to_persian_digits( number_format( $amount, 0 ) ) . ' ' . $symbol;
	}

	public static function human_duration( $seconds ) {
		$seconds = (int) $seconds;

		if ( $seconds < 60 ) {
			return self::to_persian_digits( $seconds ) . ' ثانیه';
		}
		if ( $seconds < 3600 ) {
			return self::to_persian_digits( (int) floor( $seconds / 60 ) ) . ' دقیقه';
		}
		if ( $seconds < 86400 ) {
			return self::to_persian_digits( (int) floor( $seconds / 3600 ) ) . ' ساعت';
		}

		return self::to_persian_digits( (int) floor( $seconds / 86400 ) ) . ' روز';
	}

	public static function duration_to_seconds( $value, $default = 300 ) {
		$units = array(
			'seconds' => 1,
			'minutes' => 60,
			'hours'   => 3600,
			'days'    => 86400,
			'weeks'   => 604800,
		);

		if ( is_array( $value ) ) {
			$num  = isset( $value['value'] ) ? (int) $value['value'] : 0;
			$unit = isset( $value['unit'] ) ? $value['unit'] : 'minutes';
			if ( ! isset( $units[ $unit ] ) ) {
				$unit = 'minutes';
			}
			return $num > 0 ? $num * $units[ $unit ] : $default;
		}

		if ( is_numeric( $value ) && (int) $value > 0 ) {
			return (int) $value;
		}

		return $default;
	}

	public static function user_agent() {
		return isset( $_SERVER['HTTP_USER_AGENT'] )
			? substr( sanitize_text_field( wp_unslash( $_SERVER['HTTP_USER_AGENT'] ) ), 0, 190 )
			: '';
	}

	public static function is_rest_request( $namespace = BMC_REST_NS ) {
		if ( defined( 'REST_REQUEST' ) && REST_REQUEST ) {
			return true;
		}
		$uri = isset( $_SERVER['REQUEST_URI'] ) ? sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ) : '';
		return false !== strpos( $uri, '/wp-json/' . $namespace );
	}
}
