<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Logger {

	const MAX_ROWS = 2000;

	public static function add( $channel, $message, array $context = array(), $level = 'info' ) {
		global $wpdb;

		if ( ! BMC_Settings::bool( 'debug_log', true ) ) {
			return;
		}

		$table = BMC_DB::table( 'logs' );

		$count = (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table}" );
		if ( $count > self::MAX_ROWS ) {
			$wpdb->query( "DELETE FROM {$table} ORDER BY id ASC LIMIT 500" );
		}

		$wpdb->insert(
			$table,
			array(
				'channel'    => sanitize_key( $channel ),
				'level'      => sanitize_key( $level ),
				'message'    => sanitize_textarea_field( $message ),
				'context'    => $context ? wp_json_encode( $context, JSON_UNESCAPED_UNICODE ) : '',
				'ip_hash'    => BMC_Helpers::ip_hash(),
				'created_at' => current_time( 'mysql' ),
			),
			array( '%s', '%s', '%s', '%s', '%s', '%s' )
		);
	}

	public static function recent( $limit = 50, $channel = '' ) {
		global $wpdb;
		$table = BMC_DB::table( 'logs' );
		$limit = max( 1, min( 500, (int) $limit ) );

		if ( $channel ) {
			$rows = $wpdb->get_results(
				$wpdb->prepare( "SELECT * FROM {$table} WHERE channel = %s ORDER BY id DESC LIMIT {$limit}", $channel )
			);
		} else {
			$rows = $wpdb->get_results( "SELECT * FROM {$table} ORDER BY id DESC LIMIT {$limit}" );
		}

		return $rows ? $rows : array();
	}

	public static function clear() {
		global $wpdb;
		$table = BMC_DB::table( 'logs' );
		return (int) $wpdb->query( "TRUNCATE TABLE {$table}" );
	}
}
