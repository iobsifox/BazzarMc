<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class BMC_EL_Link_Box extends BMC_EL_Base {

	public function get_name() {
		return 'bmc-link-box';
	}

	public function get_title() {
		return 'اتصال اکانت ماینکرافت';
	}

	public function get_icon() {
		return 'eicon-link';
	}

	protected function bmc_slug() {
		return 'link-box';
	}

	protected function extra_keywords() {
		return array( 'link', 'otp', 'connect', 'اتصال', 'کد', 'لینک' );
	}

	protected function extra_scripts() {
		return array( 'bmc-link' );
	}

	protected function content_controls() {
		$this->start_controls_section(
			'bmc_sec_content',
			array(
				'label' => 'اتصال اکانت',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'bmc_notice',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => 'گام‌های اتصال: نام کاربری ماینکرافت، دریافت کد اتصال ۵ دقیقه‌ای و واردکردن آن در بازی یا داشبورد/ایمیل. روش‌های تحویل کد از پنل BazzarMc تنظیم می‌شود.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_control(
			'title',
			array(
				'label'       => 'عنوان',
				'type'        => Controls_Manager::TEXT,
				'default'     => '',
				'description' => 'خالی بگذارید تا عنوان تنظیم‌شده در پنل افزونه نمایش داده شود.',
			)
		);

		$this->add_control(
			'narrow',
			array(
				'label'        => 'پهنای باریک (مناسب ستون کناری)',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => '',
			)
		);

		$this->end_controls_section();

		$this->start_controls_section(
			'bmc_sec_link_form',
			array(
				'label' => 'سفارشی‌سازی فرم اتصال',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'lb_hint',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => 'هر گزینه‌ای که خالی بماند، از تنظیمات عمومی افزونه (پیشخوان ← BazzarMc ← فرم اتصال) خوانده می‌شود. یعنی می‌توانید در هر صفحه نسخهٔ متفاوتی از فرم اتصال داشته باشید.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_control(
			'lb_width',
			array(
				'label'   => 'پهنای جعبه',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''       => 'پیش‌فرض (از تنظیمات افزونه)',
					'narrow' => 'باریک',
					'wide'   => 'پهن',
				),
			)
		);

		$this->add_control(
			'lb_avatar_size',
			array(
				'label'       => 'اندازهٔ آواتار ماینکرافت (پیکسل)',
				'type'        => Controls_Manager::NUMBER,
				'min'         => 0,
				'max'         => 192,
				'default'     => 0,
				'description' => 'صفر = اندازهٔ پیش‌فرض.',
			)
		);

		$this->add_control(
			'lb_steps',
			array(
				'label'   => 'نمایش راهنمای سه‌مرحله‌ای',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''    => 'پیش‌فرض (از تنظیمات افزونه)',
					'no'  => 'خیر',
					'yes' => 'بله',
				),
			)
		);

		$this->add_control(
			'lb_step_1',
			array(
				'label'   => 'متن مرحلهٔ ۱',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'lb_step_2',
			array(
				'label'   => 'متن مرحلهٔ ۲',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'lb_step_3',
			array(
				'label'   => 'متن مرحلهٔ ۳',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'lb_player_label',
			array(
				'label'   => 'برچسب فیلد نام کاربری',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'lb_player_placeholder',
			array(
				'label'   => 'placeholder نام کاربری',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'lb_submit_text',
			array(
				'label'   => 'متن دکمهٔ ساخت کد',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'lb_code_hint',
			array(
				'label'   => 'متن بالای کد',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'lb_copy_text',
			array(
				'label'   => 'متن دکمهٔ کپی',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'lb_regen_text',
			array(
				'label'   => 'متن دکمهٔ کد جدید',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'lb_otp_card',
			array(
				'label'   => 'نمایش کارت کد تأیید',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''    => 'پیش‌فرض (از تنظیمات افزونه)',
					'no'  => 'خیر',
					'yes' => 'بله',
				),
			)
		);

		$this->add_control(
			'lb_otp_title',
			array(
				'label'   => 'عنوان کارت کد تأیید',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'lb_show_uuid',
			array(
				'label'   => 'نمایش UUID در وضعیت متصل',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''    => 'پیش‌فرض (از تنظیمات افزونه)',
					'no'  => 'خیر',
					'yes' => 'بله',
				),
			)
		);

		$this->add_control(
			'lb_show_linked_at',
			array(
				'label'   => 'نمایش تاریخ اتصال',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''    => 'پیش‌فرض (از تنظیمات افزونه)',
					'no'  => 'خیر',
					'yes' => 'بله',
				),
			)
		);

		$this->add_control(
			'lb_show_shop',
			array(
				'label'   => 'نمایش دکمهٔ فروشگاه',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''    => 'پیش‌فرض (از تنظیمات افزونه)',
					'no'  => 'خیر',
					'yes' => 'بله',
				),
			)
		);

		$this->add_control(
			'lb_show_unlink',
			array(
				'label'   => 'نمایش دکمهٔ قطع اتصال',
				'type'    => Controls_Manager::SELECT,
				'default' => '',
				'options' => array(
					''    => 'پیش‌فرض (از تنظیمات افزونه)',
					'no'  => 'خیر',
					'yes' => 'بله',
				),
			)
		);

		$this->add_control(
			'lb_login_title',
			array(
				'label'   => 'عنوان کارت ورود',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
				'description' => 'برای کاربر مهمان',
			)
		);

		$this->add_control(
			'lb_login_body',
			array(
				'label'   => 'متن کارت ورود',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'lb_login_button',
			array(
				'label'   => 'متن دکمهٔ ورود',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->end_controls_section();
	}

	protected function style_controls() {
		$this->start_controls_section(
			'bmc_sec_link_style',
			array(
				'label' => 'جعبهٔ اتصال',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'card_title_typography',
				'label'    => 'تایپوگرافی عنوان کارت',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-card__title',
			)
		);

		$this->add_control(
			'card_title_color',
			array(
				'label'     => 'رنگ عنوان کارت',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-card__title' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'card_padding',
			array(
				'label'      => 'فاصلهٔ داخلی کارت',
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-card' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'card_bg',
			array(
				'label'     => 'پس‌زمینهٔ کارت',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-card' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'code_typography',
				'label'    => 'تایپوگرافی کد اتصال',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-code',
			)
		);

		$this->add_control(
			'code_bg',
			array(
				'label'     => 'پس‌زمینهٔ کد اتصال',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-code' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'code_color',
			array(
				'label'     => 'رنگ کد اتصال',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-code' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'code_letter_spacing',
			array(
				'label'      => 'فاصلهٔ حروف کد',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 20,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-code' => 'letter-spacing: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'command_typography',
				'label'    => 'تایپوگرافی دستور بازی',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-command',
			)
		);

		$this->add_control(
			'primary_button_bg',
			array(
				'label'     => 'پس‌زمینهٔ دکمهٔ اصلی',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-btn-p, {{WRAPPER}} .bmc-el .bmc-btn:not(.bmc-btn-o):not(.bmc-btn--ghost):not(.bmc-btn--danger)' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'primary_button_color',
			array(
				'label'     => 'رنگ متن دکمهٔ اصلی',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-btn-p, {{WRAPPER}} .bmc-el .bmc-btn:not(.bmc-btn-o):not(.bmc-btn--ghost):not(.bmc-btn--danger)' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'input_radius',
			array(
				'label'      => 'گردی فیلدها',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 30,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-input, {{WRAPPER}} .bmc-el input, {{WRAPPER}} .bmc-el select' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function link_atts( $settings ) {
		$atts = array( 'title' => isset( $settings['title'] ) ? (string) $settings['title'] : '' );

		$map = array(
			'lb_width'             => 'width',
			'lb_steps'             => 'steps',
			'lb_step_1'            => 'step_1',
			'lb_step_2'            => 'step_2',
			'lb_step_3'            => 'step_3',
			'lb_player_label'      => 'player_label',
			'lb_player_placeholder' => 'player_placeholder',
			'lb_submit_text'       => 'submit_text',
			'lb_code_hint'         => 'code_hint',
			'lb_copy_text'         => 'copy_text',
			'lb_regen_text'        => 'regen_text',
			'lb_otp_card'          => 'otp_card',
			'lb_otp_title'         => 'otp_title',
			'lb_show_uuid'         => 'show_uuid',
			'lb_show_linked_at'    => 'show_linked_at',
			'lb_show_shop'         => 'show_shop_button',
			'lb_show_unlink'       => 'show_unlink',
			'lb_login_title'       => 'login_title',
			'lb_login_body'        => 'login_body',
			'lb_login_button'      => 'login_button',
		);

		foreach ( $map as $control => $att ) {
			$atts[ $att ] = isset( $settings[ $control ] ) ? (string) $settings[ $control ] : '';
		}

		$atts['avatar_size'] = ! empty( $settings['lb_avatar_size'] ) ? (int) $settings['lb_avatar_size'] : '';

		return $atts;
	}

	protected function render_inner( $settings ) {
		$html = BMC_Public::shortcode_account( $this->link_atts( $settings ) );

		if ( 'yes' === $settings['narrow'] ) {
			$html = str_replace( 'bmc-container bmc-container--narrow', 'bmc-container bmc-container--narrow bmc-container--xnarrow', $html );
		}

		return $html;
	}
}
