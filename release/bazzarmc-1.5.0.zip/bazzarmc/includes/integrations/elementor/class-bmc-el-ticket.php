<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class BMC_EL_Ticket extends BMC_EL_Base {

	public function get_name() {
		return 'bmc-ticket';
	}

	public function get_title() {
		return 'گفت‌وگوی تیکت';
	}

	public function get_icon() {
		return 'eicon-chat';
	}

	protected function bmc_slug() {
		return 'ticket';
	}

	protected function extra_keywords() {
		return array( 'ticket', 'thread', 'support', 'تیکت', 'پاسخ' );
	}

	protected function content_controls() {
		$this->start_controls_section(
			'bmc_sec_content',
			array(
				'label' => 'گفت‌وگوی تیکت',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'ticket_id',
			array(
				'label'       => 'شناسهٔ تیکت',
				'type'        => Controls_Manager::NUMBER,
				'default'     => 0,
				'min'         => 0,
				'description' => 'صفر = تیکت جاری بر اساس آدرس صفحه. دسترسی فقط برای صاحب تیکت یا مدیر فروشگاه.',
			)
		);

		$this->end_controls_section();
	}

	protected function style_controls() {
		$this->field_style_controls( 'فرم پاسخ' );
		$this->button_style_controls();

		$this->start_controls_section(
			'bmc_sec_thread_style',
			array(
				'label' => 'رشتهٔ گفت‌وگو',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'bubble_user_bg',
			array(
				'label'     => 'پس‌زمینهٔ پیام کاربر',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-bubble--user' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'bubble_typography',
				'label'    => 'تایپوگرافی متن پیام',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-bubble__body',
			)
		);

		$this->add_control(
			'bubble_note_bg',
			array(
				'label'     => 'پس‌زمینهٔ یادداشت داخلی',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-bubble--note' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'bubble_staff_bg',
			array(
				'label'     => 'پس‌زمینهٔ پیام پشتیبانی',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-bubble--staff' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'bubble_radius',
			array(
				'label'      => 'گردی حباب پیام‌ها',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 32,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-bubble' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'bubble_gap',
			array(
				'label'      => 'فاصلهٔ بین پیام‌ها',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-tk-thread' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render_inner( $settings ) {
		if ( ! BMC_Tickets::enabled() ) {
			return $this->editor_placeholder( 'سامانهٔ تیکت پشتیبانی در پنل BazzarMc غیرفعال است.' );
		}

		return BMC_Tickets::shortcode_ticket(
			array(
				'id' => (int) $settings['ticket_id'],
			)
		);
	}
}
