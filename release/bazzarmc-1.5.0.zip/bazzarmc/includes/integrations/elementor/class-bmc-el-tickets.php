<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;

class BMC_EL_Tickets extends BMC_EL_Base {

	public function get_name() {
		return 'bmc-tickets';
	}

	public function get_title() {
		return 'تیکت‌های پشتیبانی';
	}

	public function get_icon() {
		return 'eicon-comments';
	}

	protected function bmc_slug() {
		return 'tickets';
	}

	protected function extra_keywords() {
		return array( 'ticket', 'support', 'تیکت', 'پشتیبانی' );
	}

	protected function content_controls() {
		$this->start_controls_section(
			'bmc_sec_content',
			array(
				'label' => 'تیکت‌ها',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'bmc_notice',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => 'فهرست تیکت‌های کاربر به‌همراه فرم ثبت تیکت جدید، فیلتر وضعیت و صفحه‌بندی. اگر سامانهٔ تیکت در پنل افزونه غیرفعال باشد، پیام آن نمایش داده می‌شود.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->end_controls_section();
	}

	protected function style_controls() {
		$this->table_style_controls( 'فهرست تیکت‌ها' );
		$this->field_style_controls( 'فرم تیکت' );
		$this->button_style_controls();

		$this->start_controls_section(
			'bmc_sec_ticket_style',
			array(
				'label' => 'تیکت',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_control(
			'pill_radius',
			array(
				'label'      => 'گردی برچسب‌های وضعیت',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 30,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-pill, {{WRAPPER}} .bmc-el .bmc-chip' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'card_bg',
			array(
				'label'     => 'پس‌زمینهٔ کارت‌ها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-card' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'item_bg',
			array(
				'label'     => 'پس‌زمینهٔ ردیف تیکت',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-tk-item' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'item_hover_bg',
			array(
				'label'     => 'پس‌زمینهٔ ردیف تیکت در هاور',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-tk-item:hover' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'item_border_color',
			array(
				'label'     => 'رنگ حاشیهٔ ردیف تیکت',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-tk-item' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'item_radius',
			array(
				'label'      => 'گردی ردیف تیکت',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 32,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-tk-item' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'item_padding',
			array(
				'label'      => 'فاصلهٔ داخلی ردیف تیکت',
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-tk-item' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render_inner( $settings ) {
		if ( ! BMC_Tickets::enabled() ) {
			return $this->editor_placeholder( 'سامانهٔ تیکت پشتیبانی در پنل BazzarMc غیرفعال است.' );
		}

		return BMC_Tickets::shortcode_tickets();
	}
}
