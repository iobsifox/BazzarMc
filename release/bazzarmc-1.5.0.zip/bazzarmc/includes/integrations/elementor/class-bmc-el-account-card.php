<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class BMC_EL_Account_Card extends BMC_EL_Base {

	public function get_name() {
		return 'bmc-account-card';
	}

	public function get_title() {
		return 'کارت حساب کاربری';
	}

	public function get_icon() {
		return 'eicon-user-circle-o';
	}

	protected function bmc_slug() {
		return 'account-card';
	}

	protected function extra_keywords() {
		return array( 'card', 'dashboard', 'my account', 'کارت', 'داشبورد', 'حساب کاربری', 'رنک' );
	}

	protected function content_controls() {
		$this->start_controls_section(
			'bmc_sec_content',
			array(
				'label' => 'کارت حساب کاربری',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'bmc_notice_wc',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => 'این ویجت همان کارتی است که در داشبورد حساب کاربری ووکامرس نمایش داده می‌شود: نام واقعی کاربر، باکس اکانت ماینکرافت و رنک‌های خریداری‌شده با زمان باقی‌مانده. اگر این ویجت را در صفحهٔ حساب کاربری گذاشتید، گزینهٔ «نمایش کارت در داشبورد» را در پنل افزونه خاموش کنید تا کارت دوبار نمایش داده نشود.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_control(
			'title',
			array(
				'label'   => 'عنوان بالای کارت',
				'type'    => Controls_Manager::TEXT,
				'default' => '',
			)
		);

		$this->add_control(
			'title_icon',
			array(
				'label'     => 'آیکون عنوان',
				'type'      => Controls_Manager::TEXT,
				'default'   => 'account_circle',
				'condition' => array(
					'title!' => '',
				),
			)
		);

		$this->add_control(
			'bmc_head_hr',
			array(
				'label' => 'سربرگ کارت',
				'type'  => Controls_Manager::HEADING,
			)
		);

		$this->add_control(
			'kicker',
			array(
				'label'        => 'نمایش پیام خوش‌آمد (صبح بخیر…)',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'kicker_text',
			array(
				'label'     => 'متن دلخواه خوش‌آمد',
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'condition' => array(
					'kicker' => 'yes',
				),
			)
		);

		$this->add_control(
			'email',
			array(
				'label'        => 'نمایش ایمیل',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'mobile',
			array(
				'label'        => 'نمایش شمارهٔ موبایل',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'orders',
			array(
				'label'        => 'نمایش تعداد سفارش‌ها',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'roles',
			array(
				'label'        => 'نمایش نقش‌های کاربر',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'avatar_size',
			array(
				'label'      => 'اندازهٔ آواتار',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 32,
						'max' => 140,
					),
				),
				'default'    => array(
					'unit' => 'px',
					'size' => 64,
				),
			)
		);

		$this->add_control(
			'bmc_boxes_hr',
			array(
				'label' => 'باکس‌ها',
				'type'  => Controls_Manager::HEADING,
			)
		);

		$this->add_control(
			'mc_box',
			array(
				'label'        => 'باکس اکانت ماینکرافت',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'ranks_box',
			array(
				'label'        => 'باکس رنک‌ها',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'layout',
			array(
				'label'   => 'چیدمان باکس‌ها',
				'type'    => Controls_Manager::SELECT,
				'default' => 'grid',
				'options' => array(
					'grid'  => 'کنار هم (شبکه)',
					'stack' => 'زیر هم',
				),
			)
		);

		$this->add_control(
			'columns',
			array(
				'label'     => 'تعداد ستون',
				'type'      => Controls_Manager::SELECT,
				'default'   => '2',
				'options'   => array(
					'1' => '۱',
					'2' => '۲',
					'3' => '۳',
					'4' => '۴',
				),
				'condition' => array(
					'layout' => 'grid',
				),
			)
		);

		$this->add_control(
			'unlinked_text',
			array(
				'label'     => 'متن حالت «متصل نیست»',
				'type'      => Controls_Manager::TEXTAREA,
				'default'   => '',
				'condition' => array(
					'mc_box' => 'yes',
				),
			)
		);

		$this->add_control(
			'connect_label',
			array(
				'label'     => 'متن دکمهٔ اتصال',
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'condition' => array(
					'mc_box' => 'yes',
				),
			)
		);

		$this->add_control(
			'manage_label',
			array(
				'label'     => 'متن دکمهٔ مدیریت اتصال',
				'type'      => Controls_Manager::TEXT,
				'default'   => '',
				'condition' => array(
					'mc_box' => 'yes',
				),
			)
		);

		$this->add_control(
			'no_ranks_text',
			array(
				'label'     => 'متن حالت «بدون رنک»',
				'type'      => Controls_Manager::TEXTAREA,
				'default'   => '',
				'condition' => array(
					'ranks_box' => 'yes',
				),
			)
		);

		$this->add_control(
			'bmc_links_hr',
			array(
				'label' => 'پیوندهای پایین کارت',
				'type'  => Controls_Manager::HEADING,
			)
		);

		$this->add_control(
			'links',
			array(
				'label'        => 'نمایش پیوندها',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'link_items',
			array(
				'label'     => 'موارد پیوند',
				'type'      => Controls_Manager::SELECT2,
				'multiple'  => true,
				'default'   => array( 'orders', 'addresses', 'details', 'cart', 'tickets', 'logout' ),
				'options'   => array(
					'orders'    => 'سفارش‌ها',
					'addresses' => 'آدرس‌ها',
					'details'   => 'جزئیات حساب',
					'cart'      => 'سبد خرید',
					'minecraft' => 'اکانت ماینکرافت',
					'tickets'   => 'پشتیبانی',
					'logout'    => 'خروج',
				),
				'condition' => array(
					'links' => 'yes',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function style_controls() {
		$this->start_controls_section(
			'bmc_sec_card_style',
			array(
				'label' => 'کارت',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_responsive_control(
			'card_padding',
			array(
				'label'      => 'فاصلهٔ داخلی کارت',
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-acard' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'card_border_width',
			array(
				'label'      => 'ضخامت حاشیهٔ کارت',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 8,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-acard' => 'border-width: {{SIZE}}{{UNIT}}; border-style: solid;',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'name_typography',
				'label'    => 'تایپوگرافی نام کاربر',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-acard__name',
			)
		);

		$this->add_control(
			'name_color',
			array(
				'label'     => 'رنگ نام کاربر',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-acard__name' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'meta_typography',
				'label'    => 'تایپوگرافی اطلاعات (ایمیل/موبایل/سفارش)',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-acard__meta, {{WRAPPER}} .bmc-el .bmc-acard__kicker',
			)
		);

		$this->add_control(
			'avatar_radius',
			array(
				'label'      => 'گردی آواتار',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px', '%' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 80,
					),
					'%'  => array(
						'min' => 0,
						'max' => 50,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-acard__avatar, {{WRAPPER}} .bmc-el .bmc-acard__avatar img' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'box_gap',
			array(
				'label'      => 'فاصلهٔ بین باکس‌ها',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 60,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-acard__grid' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'box_padding',
			array(
				'label'      => 'فاصلهٔ داخلی باکس‌ها',
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-acard__box' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_control(
			'box_bg',
			array(
				'label'     => 'پس‌زمینهٔ باکس‌ها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-acard__box' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'links_typography',
				'label'    => 'تایپوگرافی پیوندها',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-acard__links a',
			)
		);

		$this->start_controls_tabs( 'bmc_links_tabs' );

		$this->start_controls_tab(
			'bmc_links_normal',
			array(
				'label' => 'عادی',
			)
		);

		$this->add_control(
			'links_color',
			array(
				'label'     => 'رنگ پیوندها',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-acard__links a' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->start_controls_tab(
			'bmc_links_hover',
			array(
				'label' => 'هاور',
			)
		);

		$this->add_control(
			'links_hover_color',
			array(
				'label'     => 'رنگ پیوندها در هاور',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-acard__links a:hover' => 'color: {{VALUE}};',
				),
			)
		);

		$this->end_controls_tab();

		$this->end_controls_tabs();

		$this->end_controls_section();
	}

	protected function render_inner( $settings ) {
		if ( ! is_user_logged_in() ) {
			$placeholder = $this->editor_placeholder( 'کارت حساب کاربری فقط برای کاربر واردشده نمایش داده می‌شود.' );

			return '' !== $placeholder ? $placeholder : BMC_Public::login_notice( 'برای مشاهدهٔ کارت حساب کاربری وارد حساب شوید.' );
		}

		$on = static function ( $value ) {
			return 'yes' === $value;
		};

		$args = array(
			'title'         => (string) $settings['title'],
			'title_icon'    => (string) $settings['title_icon'],
			'kicker'        => $on( $settings['kicker'] ),
			'kicker_text'   => (string) $settings['kicker_text'],
			'email'         => $on( $settings['email'] ),
			'mobile'        => $on( $settings['mobile'] ),
			'orders'        => $on( $settings['orders'] ),
			'roles'         => $on( $settings['roles'] ),
			'mc_box'        => $on( $settings['mc_box'] ),
			'ranks_box'     => $on( $settings['ranks_box'] ),
			'links'         => $on( $settings['links'] ),
			'layout'        => (string) $settings['layout'],
			'columns'       => (int) $settings['columns'],
			'avatar_size'   => isset( $settings['avatar_size']['size'] ) ? (int) $settings['avatar_size']['size'] : 64,
			'unlinked_text' => (string) $settings['unlinked_text'],
			'no_ranks_text' => (string) $settings['no_ranks_text'],
			'manage_label'  => (string) $settings['manage_label'],
			'connect_label' => (string) $settings['connect_label'],
		);

		$args['link_items'] = empty( $settings['link_items'] )
			? array( 'orders', 'addresses', 'details', 'cart', 'tickets', 'logout' )
			: array_map( 'sanitize_key', (array) $settings['link_items'] );

		return BMC_Public::render_account_card( $args );
	}
}
