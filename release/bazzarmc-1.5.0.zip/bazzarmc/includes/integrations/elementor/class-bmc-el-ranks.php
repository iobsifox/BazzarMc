<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class BMC_EL_Ranks extends BMC_EL_Base {

	public function get_name() {
		return 'bmc-ranks';
	}

	public function get_title() {
		return 'رنک‌های کاربر';
	}

	public function get_icon() {
		return 'eicon-product-related';
	}

	protected function bmc_slug() {
		return 'ranks';
	}

	protected function extra_keywords() {
		return array( 'rank', 'role', 'expiry', 'رنک', 'نقش', 'اعتبار' );
	}

	protected function content_controls() {
		$this->start_controls_section(
			'bmc_sec_content',
			array(
				'label' => 'رنک‌ها',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'bmc_notice',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => 'رنک‌های فعال کاربر با زمان باقی‌مانده، نوار پیشرفت و تاریخ انقضای شمسی. رنک‌ها از خرید در سایت یا گزارش سرور ماینکرافت ساخته می‌شوند.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_control(
			'title',
			array(
				'label'   => 'عنوان',
				'type'    => Controls_Manager::TEXT,
				'default' => 'رنک‌های شما',
			)
		);

		$this->add_control(
			'title_icon',
			array(
				'label'     => 'آیکون عنوان',
				'type'      => Controls_Manager::TEXT,
				'default'   => 'workspace_premium',
				'condition' => array(
					'title!' => '',
				),
			)
		);

		$this->add_control(
			'sort',
			array(
				'label'   => 'ترتیب',
				'type'    => Controls_Manager::SELECT,
				'default' => 'expiry',
				'options' => array(
					'expiry' => 'زمان باقی‌مانده (پیش‌فرض)',
					'level'  => 'سطح رنک (بالاترین اول)',
				),
			)
		);

		$this->add_control(
			'progress',
			array(
				'label'        => 'نمایش نوار پیشرفت اعتبار',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'role',
			array(
				'label'        => 'نمایش نقش وردپرس',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'expiry',
			array(
				'label'        => 'نمایش تاریخ انقضای شمسی',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'shop_button',
			array(
				'label'        => 'نمایش دکمهٔ فروشگاه در حالت خالی',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->add_control(
			'shop_label',
			array(
				'label'     => 'متن دکمهٔ فروشگاه',
				'type'      => Controls_Manager::TEXT,
				'default'   => 'مشاهدهٔ فروشگاه',
				'condition' => array(
					'shop_button' => 'yes',
				),
			)
		);

		$this->add_control(
			'empty_text',
			array(
				'label'   => 'متن حالت خالی',
				'type'    => Controls_Manager::TEXTAREA,
				'default' => 'هنوز رنکی خریداری نکرده‌اید. با خرید رنک، نقش مربوطه به‌صورت خودکار به حساب شما اضافه می‌شود.',
			)
		);

		$this->end_controls_section();
	}

	protected function style_controls() {
		$this->start_controls_section(
			'bmc_sec_rank_style',
			array(
				'label' => 'کارت رنک',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'rank_typography',
				'label'    => 'تایپوگرافی نام رنک',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-rank__body strong',
			)
		);

		$this->add_control(
			'rank_bg',
			array(
				'label'     => 'پس‌زمینهٔ کارت رنک',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-rank' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'rank_urgent_bg',
			array(
				'label'     => 'پس‌زمینهٔ رنک در آستانهٔ انقضا',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-rank.is-urgent' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'rank_border_color',
			array(
				'label'     => 'رنگ حاشیهٔ کارت رنک',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-rank' => 'border-color: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'bar_color',
			array(
				'label'     => 'رنگ نوار پیشرفت',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-bar i' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'bar_bg',
			array(
				'label'     => 'پس‌زمینهٔ نوار پیشرفت',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-bar' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'rank_gap',
			array(
				'label'      => 'فاصلهٔ بین رنک‌ها',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-ranks' => 'gap: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'rank_padding',
			array(
				'label'      => 'فاصلهٔ داخلی کارت رنک',
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-rank' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render_inner( $settings ) {
		if ( ! is_user_logged_in() ) {
			$placeholder = $this->editor_placeholder( 'فهرست رنک‌ها فقط برای کاربر واردشده نمایش داده می‌شود.' );

			return '' !== $placeholder ? $placeholder : BMC_Public::login_notice( 'برای مشاهدهٔ رنک‌ها وارد حساب کاربری شوید.' );
		}

		return BMC_Public::render_ranks(
			array(
				'title'       => (string) $settings['title'],
				'title_icon'  => (string) $settings['title_icon'],
				'sort'        => (string) $settings['sort'],
				'progress'    => 'yes' === $settings['progress'],
				'role'        => 'yes' === $settings['role'],
				'expiry'      => 'yes' === $settings['expiry'],
				'shop_button' => 'yes' === $settings['shop_button'],
				'shop_label'  => (string) $settings['shop_label'],
				'empty_text'  => (string) $settings['empty_text'],
			)
		);
	}
}
