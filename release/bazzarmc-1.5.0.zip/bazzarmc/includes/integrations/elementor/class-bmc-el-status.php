<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

use Elementor\Controls_Manager;
use Elementor\Group_Control_Typography;

class BMC_EL_Status extends BMC_EL_Base {

	public function get_name() {
		return 'bmc-status';
	}

	public function get_title() {
		return 'وضعیت اتصال';
	}

	public function get_icon() {
		return 'eicon-info-circle-o';
	}

	protected function bmc_slug() {
		return 'status';
	}

	protected function extra_keywords() {
		return array( 'status', 'badge', 'وضعیت', 'نشان' );
	}

	protected function content_controls() {
		$this->start_controls_section(
			'bmc_sec_content',
			array(
				'label' => 'وضعیت اتصال',
				'tab'   => Controls_Manager::TAB_CONTENT,
			)
		);

		$this->add_control(
			'bmc_notice',
			array(
				'type'            => Controls_Manager::RAW_HTML,
				'raw'             => 'نشان کوچک وضعیت: نام اکانت ماینکرافت متصل‌شده به همراه تصویر سرِ بازیکن، یا پیام «متصل نیست» با پیوند اتصال.',
				'content_classes' => 'elementor-panel-alert elementor-panel-alert-info',
			)
		);

		$this->add_control(
			'show_head',
			array(
				'label'        => 'نمایش سرِ بازیکن',
				'type'         => Controls_Manager::SWITCHER,
				'return_value' => 'yes',
				'default'      => 'yes',
			)
		);

		$this->end_controls_section();
	}

	protected function style_controls() {
		$this->start_controls_section(
			'bmc_sec_status_style',
			array(
				'label' => 'نشان وضعیت',
				'tab'   => Controls_Manager::TAB_STYLE,
			)
		);

		$this->add_group_control(
			Group_Control_Typography::get_type(),
			array(
				'name'     => 'badge_typography',
				'label'    => 'تایپوگرافی',
				'selector' => '{{WRAPPER}} .bmc-el .bmc-badge',
			)
		);

		$this->add_control(
			'badge_ok_bg',
			array(
				'label'     => 'پس‌زمینهٔ حالت متصل',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-badge--ok' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'badge_warn_bg',
			array(
				'label'     => 'پس‌زمینهٔ حالت متصل نیست',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-badge--warn' => 'background: {{VALUE}};',
				),
			)
		);

		$this->add_control(
			'badge_color',
			array(
				'label'     => 'رنگ متن',
				'type'      => Controls_Manager::COLOR,
				'selectors' => array(
					'{{WRAPPER}} .bmc-el .bmc-badge' => 'color: {{VALUE}};',
				),
			)
		);

		$this->add_responsive_control(
			'badge_padding',
			array(
				'label'      => 'فاصلهٔ داخلی',
				'type'       => Controls_Manager::DIMENSIONS,
				'size_units' => array( 'px', '%', 'rem' ),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-badge' => 'padding: {{TOP}}{{UNIT}} {{RIGHT}}{{UNIT}} {{BOTTOM}}{{UNIT}} {{LEFT}}{{UNIT}};',
				),
			)
		);

		$this->add_responsive_control(
			'badge_radius',
			array(
				'label'      => 'گردی',
				'type'       => Controls_Manager::SLIDER,
				'size_units' => array( 'px' ),
				'range'      => array(
					'px' => array(
						'min' => 0,
						'max' => 40,
					),
				),
				'selectors'  => array(
					'{{WRAPPER}} .bmc-el .bmc-badge' => 'border-radius: {{SIZE}}{{UNIT}};',
				),
			)
		);

		$this->end_controls_section();
	}

	protected function render_inner( $settings ) {
		$html = (string) BMC_Public::shortcode_status();

		if ( 'yes' !== $settings['show_head'] ) {
			$html = (string) preg_replace( '/<img[^>]*>/', '', $html );
		}

		return $html;
	}
}
