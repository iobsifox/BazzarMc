<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Link {

	const META_PLAYER   = 'bmc_mc_player';
	const META_UUID     = 'bmc_mc_uuid';
	const META_LINKED_AT = 'bmc_linked_at';
	const META_CHANNEL  = 'bmc_link_channel';
	const META_LEGACY   = 'minecraft_player';

	const CODE_ACTIVE   = 0;
	const CODE_CONSUMED = 1;
	const CODE_REVOKED  = 2;

	public static function init() {
		add_action( 'wp_ajax_bmc_generate_code', array( __CLASS__, 'ajax_generate_code' ) );
		add_action( 'wp_ajax_bmc_code_state', array( __CLASS__, 'ajax_code_state' ) );
		add_action( 'wp_ajax_bmc_revoke_code', array( __CLASS__, 'ajax_revoke_code' ) );
		add_action( 'wp_ajax_bmc_unlink', array( __CLASS__, 'ajax_unlink' ) );
		add_action( 'wp_ajax_bmc_request_link_otp', array( __CLASS__, 'ajax_request_link_otp' ) );
		add_action( 'wp_ajax_bmc_verify_link_otp', array( __CLASS__, 'ajax_verify_link_otp' ) );
	}

	public static function form_defaults() {
		return array(
			'title'            => (string) BMC_Settings::get( 'txt_link_title', 'اتصال اکانت ماینکرافت' ),
			'server'           => (string) BMC_Settings::get( 'server_name', 'سرور ماینکرافت' ),
			'theme'            => 'light' === (string) BMC_Settings::get( 'checkout_theme' ) ? 'light' : 'dark',
			'width'            => (string) BMC_Settings::get( 'link_width', 'narrow' ),
			'accent'           => (string) BMC_Settings::get( 'checkout_accent', '#3ddc84' ),
			'steps_on'         => BMC_Settings::bool( 'link_show_steps', true ),
			'step_1'           => (string) BMC_Settings::get( 'link_step_1' ),
			'step_2'           => (string) BMC_Settings::get( 'link_step_2' ),
			'step_3'           => (string) BMC_Settings::get( 'link_step_3' ),
			'player_label'     => (string) BMC_Settings::get( 'link_player_label', 'نام کاربری ماینکرافت' ),
			'player_placeholder' => (string) BMC_Settings::get( 'link_player_placeholder', 'Notch' ),
			'submit_text'      => (string) BMC_Settings::get( 'link_submit_text', 'ساخت کد اتصال' ),
			'code_hint'        => (string) BMC_Settings::get( 'link_code_hint', 'این کد را در بازی وارد کنید:' ),
			'copy_text'        => (string) BMC_Settings::get( 'link_copy_text', 'کپی کد' ),
			'regen_text'       => (string) BMC_Settings::get( 'link_regen_text', 'کد جدید' ),
			'otp_card_on'      => BMC_Settings::bool( 'link_show_otp_card', true ),
			'otp_title'        => (string) BMC_Settings::get( 'link_otp_title', 'روش جایگزین: کد تأیید' ),
			'show_uuid'        => BMC_Settings::bool( 'link_show_uuid', true ),
			'show_linked_at'   => BMC_Settings::bool( 'link_show_linked_at', true ),
			'show_shop_button' => BMC_Settings::bool( 'link_show_shop_button', true ),
			'show_unlink'      => BMC_Settings::bool( 'link_show_unlink', true ) && BMC_Settings::bool( 'unlink_allowed', true ),
			'avatar_size'      => BMC_Settings::int( 'link_avatar_size', 96, 32, 192 ),
			'login_title'      => (string) BMC_Settings::get( 'link_login_title', 'ابتدا وارد حساب کاربری شوید' ),
			'login_body'       => (string) BMC_Settings::get( 'link_login_body' ),
			'login_button'     => (string) BMC_Settings::get( 'link_login_button', 'ورود / عضویت' ),
			'policy'           => (string) BMC_Settings::get( 'username_policy', 'premium' ),
			'command_hint'     => (string) BMC_Settings::get( 'code_command_hint', '/mclink {code}' ),
			'otp_methods'      => array_values( (array) BMC_Settings::get( 'verify_methods', array( 'dashboard', 'email' ) ) ),
		);
	}

	public static function form_config( $overrides = array() ) {
		$config = self::form_defaults();

		if ( ! is_array( $overrides ) ) {
			return $config;
		}

		$bools  = array( 'steps_on', 'otp_card_on', 'show_uuid', 'show_linked_at', 'show_shop_button', 'show_unlink' );
		$texts  = array( 'title', 'player_label', 'player_placeholder', 'submit_text', 'code_hint', 'copy_text', 'regen_text', 'otp_title', 'login_title', 'login_body', 'login_button', 'step_1', 'step_2', 'step_3' );

		foreach ( $overrides as $key => $value ) {
			if ( ! array_key_exists( $key, $config ) ) {
				continue;
			}

			if ( in_array( $key, $bools, true ) ) {
				if ( '' === $value || null === $value ) {
					continue;
				}

				$config[ $key ] = BMC_Settings::normalize_yesno( $value ) === 'yes';
				continue;
			}

			if ( in_array( $key, $texts, true ) ) {
				if ( '' === trim( (string) $value ) ) {
					continue;
				}

				$config[ $key ] = sanitize_text_field( (string) $value );
				continue;
			}

			if ( 'avatar_size' === $key ) {
				if ( '' === $value || null === $value ) {
					continue;
				}

				$config[ $key ] = max( 32, min( 192, (int) $value ) );
				continue;
			}

			if ( 'theme' === $key ) {
				$config[ $key ] = in_array( $value, array( 'light', 'dark' ), true ) ? $value : $config[ $key ];
				continue;
			}

			if ( 'width' === $key ) {
				$config[ $key ] = in_array( $value, array( 'narrow', 'wide' ), true ) ? $value : $config[ $key ];
			}
		}

		return apply_filters( 'bmc_link_form_config', $config, $overrides );
	}

	public static function get_linked_player( $user_id ) {
		$user_id = (int) $user_id;
		if ( ! $user_id ) {
			return '';
		}

		$player = (string) get_user_meta( $user_id, self::META_PLAYER, true );

		if ( ! $player ) {

			$player = (string) get_user_meta( $user_id, self::META_LEGACY, true );
		}

		return $player ? sanitize_text_field( $player ) : '';
	}

	public static function get_linked_uuid( $user_id ) {
		return (string) get_user_meta( (int) $user_id, self::META_UUID, true );
	}

	public static function is_linked( $user_id ) {
		return '' !== self::get_linked_player( $user_id );
	}

	public static function find_user_by_player( $player ) {
		$player = sanitize_text_field( (string) $player );
		if ( ! $player ) {
			return null;
		}

		$users = get_users(
			array(
				'meta_query' => array(
					'relation' => 'OR',
					array(
						'key'     => self::META_PLAYER,
						'value'   => $player,
						'compare' => '=',
					),
					array(
						'key'     => self::META_LEGACY,
						'value'   => $player,
						'compare' => '=',
					),
				),
				'number'     => 1,
				'fields'     => 'all',
			)
		);

		return ! empty( $users ) ? $users[0] : null;
	}

	public static function link_user( $user_id, $player, $uuid = '', $channel = 'panel' ) {
		$user_id = (int) $user_id;
		$player  = sanitize_text_field( trim( (string) $player ) );
		$uuid    = BMC_Helpers::normalize_uuid( $uuid );

		if ( ! $user_id || ! BMC_Helpers::valid_player_name( $player ) ) {
			return array(
				'success' => false,
				'message' => 'اطلاعات واردشده معتبر نیست.',
			);
		}

		$user = get_userdata( $user_id );
		if ( ! $user ) {
			return array(
				'success' => false,
				'message' => 'کاربر یافت نشد.',
			);
		}

		$existing_owner = self::find_user_by_player( $player );
		if ( $existing_owner && (int) $existing_owner->ID !== $user_id ) {
			return array(
				'success' => false,
				'message' => 'این نام کاربری ماینکرافت قبلاً به حساب دیگری متصل شده است.',
				'code'    => 'PLAYER_TAKEN',
			);
		}

		$current = self::get_linked_player( $user_id );
		if ( $current && strtolower( $current ) !== strtolower( $player ) ) {
			return array(
				'success' => false,
				'message' => 'حساب شما قبلاً به «' . $current . '» متصل است. ابتدا اتصال قبلی را قطع کنید.',
				'code'    => 'ALREADY_LINKED',
			);
		}

		update_user_meta( $user_id, self::META_PLAYER, $player );
		update_user_meta( $user_id, self::META_LEGACY, $player );

		if ( $uuid ) {
			update_user_meta( $user_id, self::META_UUID, $uuid );
		}

		update_user_meta( $user_id, self::META_LINKED_AT, time() );
		update_user_meta( $user_id, self::META_CHANNEL, sanitize_key( $channel ) );

		self::apply_linked_role( $user_id );

		BMC_Logger::add(
			'link',
			sprintf( 'کاربر #%d به بازیکن %s متصل شد (%s)', $user_id, $player, $channel ),
			array(
				'user_id' => $user_id,
				'player'  => $player,
				'uuid'    => $uuid,
			),
			'success'
		);

		do_action( 'bmc_user_linked', $user_id, $player, $channel );

		return array(
			'success' => true,
			'message' => sprintf( 'اکانت %s با موفقیت متصل شد.', $player ),
			'player'  => $player,
		);
	}

	public static function unlink_user( $user_id ) {
		$user_id = (int) $user_id;
		if ( ! $user_id ) {
			return false;
		}

		$player = self::get_linked_player( $user_id );

		delete_user_meta( $user_id, self::META_PLAYER );
		delete_user_meta( $user_id, self::META_UUID );
		delete_user_meta( $user_id, self::META_LINKED_AT );
		delete_user_meta( $user_id, self::META_CHANNEL );
		delete_user_meta( $user_id, self::META_LEGACY );

		$role = BMC_Settings::get( 'default_linked_role' );
		if ( $role && user_can( $user_id, $role ) && ! in_array( $role, array( 'administrator' ), true ) ) {
			$user = new WP_User( $user_id );
			$user->remove_role( $role );
		}

		BMC_Logger::add( 'link', sprintf( 'اتصال کاربر #%d (%s) قطع شد', $user_id, $player ), array(), 'warning' );

		do_action( 'bmc_user_unlinked', $user_id, $player );

		return true;
	}

	public static function apply_linked_role( $user_id ) {
		$role = (string) BMC_Settings::get( 'default_linked_role' );

		if ( ! $role || ! array_key_exists( $role, wp_roles()->roles ) ) {
			return;
		}

		$user = new WP_User( (int) $user_id );
		if ( $user->exists() && ! $user->has_cap( 'manage_options' ) && ! in_array( $role, $user->roles, true ) ) {
			$user->add_role( $role );
		}
	}

	public static function create_panel_code( $user_id, $player ) {
		$user_id = (int) $user_id;
		$player  = sanitize_text_field( trim( (string) $player ) );

		if ( ! $user_id ) {
			return self::error( 'برای ساخت کد اتصال باید وارد حساب کاربری خود شوید.', 'AUTH' );
		}

		if ( ! BMC_Settings::panel_code_enabled() ) {
			return self::error( 'روش اتصال از طریق پنل توسط مدیر سایت غیرفعال شده است.', 'DISABLED' );
		}

		if ( ! BMC_Helpers::valid_player_name( $player ) ) {
			return self::error( 'نام کاربری ماینکرافت نامعتبر است (۳ تا ۱۶ کاراکتر انگلیسی، عدد و _).', 'FORMAT' );
		}

		if ( self::is_linked( $user_id ) ) {
			return self::error( 'حساب شما قبلاً متصل شده است.', 'ALREADY_LINKED' );
		}

		$owner = self::find_user_by_player( $player );
		if ( $owner ) {
			return self::error( 'این نام کاربری ماینکرافت قبلاً به حساب دیگری متصل شده است.', 'PLAYER_TAKEN' );
		}

		if ( 'premium' === BMC_Settings::get( 'username_policy' ) && BMC_Settings::bool( 'mojang_check', true ) ) {
			$check = BMC_Helpers::mojang_check( $player );
			if ( ! $check['ok'] ) {
				return self::error(
					'ERR' === $check['reason']
						? 'سرویس بررسی موجانگ در دسترس نیست؛ کمی بعد دوباره تلاش کنید.'
						: 'این سایت فقط نام‌های کاربری اصلی (پرمیوم) را می‌پذیرد.',
					'POLICY'
				);
			}
			$player = $check['name'];
		}

		$rl_key = 'bmc_rl_code_' . $user_id;
		if ( get_transient( $rl_key ) ) {
			return self::error( 'کمی صبر کنید؛ به‌تازگی یک کد ساخته‌اید.', 'RATE' );
		}

		$ttl = BMC_Settings::int( 'code_ttl', 300, 60, 3600 );

		self::revoke_user_codes( $user_id, 'link' );

		$code = BMC_Helpers::random_code(
			BMC_Settings::int( 'code_length', 8, 4, 16 ),
			(string) BMC_Settings::get( 'code_alphabet', 'safe' )
		);

		$inserted = self::insert_code(
			array(
				'type'       => 'link',
				'user_id'    => $user_id,
				'identifier' => 'user:' . $user_id,
				'player'     => $player,
				'code'       => $code,
				'ttl'        => $ttl,
				'channel'    => 'panel',
			)
		);

		if ( ! $inserted ) {
			return self::error( 'ذخیرهٔ کد ناموفق بود. دوباره تلاش کنید.', 'DB' );
		}

		set_transient( $rl_key, 1, 20 );

		set_transient( 'bmc_plain_code_' . $user_id, $code, $ttl );

		BMC_Logger::add(
			'link',
			sprintf( 'کد اتصال برای کاربر #%d و بازیکن %s ساخته شد', $user_id, $player ),
			array( 'ttl' => $ttl ),
			'info'
		);

		return array(
			'success'    => true,
			'code'       => $code,
			'player'     => $player,
			'ttl'        => $ttl,
			'expires_at' => $inserted['expires_at'],
			'expires_in' => $ttl,
			'command'    => BMC_Helpers::replace_tags(
				(string) BMC_Settings::get( 'code_command_hint' ),
				array(
					'{code}'   => $code,
					'{player}' => $player,
				)
			),
		);
	}

	public static function redeem_panel_code( $code, $player, $uuid = '' ) {
		$code   = strtoupper( preg_replace( '/[^A-Za-z0-9]/', '', BMC_Helpers::to_latin_digits( (string) $code ) ) );
		$player = sanitize_text_field( trim( (string) $player ) );
		$uuid   = BMC_Helpers::normalize_uuid( $uuid );

		if ( '' === $code || ! BMC_Helpers::valid_player_name( $player ) ) {
			return self::error( 'کد یا نام کاربری نامعتبر است.', 'FORMAT' );
		}

		$row = self::find_code( 'link', $code );

		if ( ! $row ) {
			return self::error( 'کد واردشده معتبر نیست یا منقضی شده است.', 'INVALID' );
		}

		if ( (int) $row->status !== self::CODE_ACTIVE ) {
			return self::error( 'این کد قبلاً استفاده شده است.', 'USED' );
		}

		if ( strtotime( $row->expires_at ) < BMC_Helpers::now_timestamp() ) {
			self::mark_code_expired( (int) $row->id );
			return self::error( 'اعتبار کد تمام شده است. از پنل کاربری کد جدید بسازید.', 'EXPIRED' );
		}

		self::bump_attempts( (int) $row->id );

		$user_id = (int) $row->user_id;

		if ( $row->player && strtolower( $row->player ) !== strtolower( $player ) ) {
			$policy = BMC_Settings::get( 'username_policy' );
			if ( 'premium' === $policy ) {
				return self::error(
					sprintf( 'این کد برای نام کاربری %s ساخته شده است. با همان نام وارد شوید.', $row->player ),
					'MISMATCH'
				);
			}
		}

		if ( 'premium' === BMC_Settings::get( 'username_policy' ) && BMC_Settings::bool( 'mojang_check', true ) ) {
			$check = BMC_Helpers::mojang_check( $player );
			if ( ! $check['ok'] ) {
				return self::error(
					'ERR' === $check['reason']
						? 'بررسی موجانگ موقتاً ممکن نیست. دوباره تلاش کنید.'
						: 'این سایت فقط نام‌های کاربری اصلی (پرمیوم) را می‌پذیرد.',
					'POLICY'
				);
			}
			$player = $check['name'];
			if ( ! $uuid && ! empty( $check['uuid'] ) ) {
				$uuid = $check['uuid'];
			}
		}

		if ( self::is_linked( $user_id ) ) {
			self::consume_code( (int) $row->id );
			$current = self::get_linked_player( $user_id );
			if ( strtolower( $current ) === strtolower( $player ) ) {
				return array(
					'success' => true,
					'message' => sprintf( 'حساب شما از قبل به %s متصل است.', $player ),
					'player'  => $player,
					'user_id' => $user_id,
				);
			}
			return self::error( 'حساب وب‌سایت این کد قبلاً به نام دیگری متصل شده است.', 'ALREADY_LINKED' );
		}

		$result = self::link_user( $user_id, $player, $uuid, 'panel' );

		if ( ! empty( $result['success'] ) ) {
			self::consume_code( (int) $row->id );
			delete_transient( 'bmc_plain_code_' . $user_id );
			$result['user_id']      = $user_id;
			$result['display_name'] = self::display_name( $user_id );
		}

		return $result;
	}

	public static function get_active_code( $user_id ) {
		global $wpdb;

		$table = BMC_DB::table( 'codes' );
		$row   = $wpdb->get_row(
			$wpdb->prepare(
				"SELECT id, player, status, created_at, expires_at, attempts FROM {$table}
				 WHERE type = %s AND user_id = %d AND status = %d
				 ORDER BY id DESC LIMIT 1",
				'link',
				(int) $user_id,
				self::CODE_ACTIVE
			)
		);

		if ( ! $row ) {
			return null;
		}

		$expires = strtotime( $row->expires_at );
		$left    = $expires - BMC_Helpers::now_timestamp();

		if ( $left <= 0 ) {
			self::mark_code_expired( (int) $row->id );
			return null;
		}

		$plain = get_transient( 'bmc_plain_code_' . (int) $user_id );

		return array(
			'id'         => (int) $row->id,
			'player'     => $row->player,
			'status'     => (int) $row->status,
			'expires_at' => $row->expires_at,
			'expires_in' => max( 0, $left ),
			'attempts'   => (int) $row->attempts,
			'code_plain' => is_string( $plain ) ? $plain : '',
		);
	}

	public static function code_state( $user_id ) {
		if ( self::is_linked( $user_id ) ) {
			return array(
				'state'  => 'linked',
				'player' => self::get_linked_player( $user_id ),
				'head'   => BMC_Helpers::mc_head( self::get_linked_player( $user_id ), 96 ),
			);
		}

		$active = self::get_active_code( $user_id );

		if ( ! $active ) {
			return array( 'state' => 'none' );
		}

		return array(
			'state'      => 'waiting',
			'expires_in' => $active['expires_in'],
			'player'     => $active['player'],
		);
	}

	public static function request_link_otp( $identifier_type, $identifier_value, $player, $channel = '' ) {
		$player = sanitize_text_field( trim( (string) $player ) );

		if ( ! BMC_Settings::mc_request_enabled() ) {
			return self::error( 'اتصال از داخل بازی غیرفعال است.', 'DISABLED' );
		}

		if ( ! BMC_Helpers::valid_player_name( $player ) ) {
			return self::error( 'نام کاربری ماینکرافت نامعتبر است.', 'FORMAT' );
		}

		if ( self::find_user_by_player( $player ) ) {
			return self::error( 'این نام کاربری قبلاً متصل شده است.', 'PLAYER_TAKEN' );
		}

		$identifier_type = 'email';

		$email = BMC_Helpers::sanitize_email( $identifier_value );

		if ( ! $email ) {
			return self::error( 'ایمیل نامعتبر است.', 'FORMAT' );
		}

		$user             = get_user_by( 'email', $email );
		$identifier_value = $email;

		if ( ! $user ) {
			return self::error( 'حسابی با این مشخصات در سایت یافت نشد. ابتدا ثبت‌نام کنید.', 'NO_USER' );
		}

		if ( self::is_linked( $user->ID ) ) {
			return self::error( 'حساب کاربری شما قبلاً به یک اکانت ماینکرافت متصل شده است.', 'ALREADY_LINKED' );
		}

		$rl = 'bmc_rl_otp_link_' . md5( $identifier_type . ':' . $identifier_value );
		if ( get_transient( $rl ) ) {
			return self::error( 'برای درخواست کد جدید کمی صبر کنید.', 'RATE' );
		}

		if ( 'premium' === BMC_Settings::get( 'username_policy' ) && BMC_Settings::bool( 'mojang_check', true ) ) {
			$check = BMC_Helpers::mojang_check( $player );
			if ( ! $check['ok'] ) {
				return self::error(
					'ERR' === $check['reason'] ? 'سرویس موجانگ در دسترس نیست.' : 'فقط نام کاربری اصلی (پرمیوم) پذیرفته می‌شود.',
					'POLICY'
				);
			}
			$player = $check['name'];
		}

		$ttl  = BMC_Settings::int( 'otp_ttl', 120, 30, 900 );
		$code = BMC_Helpers::random_otp( BMC_Settings::int( 'otp_length', 5, 4, 8 ) );

		self::revoke_identifier_codes( 'otp_link', $identifier_type . ':' . $identifier_value );

		$inserted = self::insert_code(
			array(
				'type'       => 'otp_link',
				'user_id'    => $user->ID,
				'identifier' => $identifier_type . ':' . $identifier_value,
				'player'     => $player,
				'code'       => $code,
				'ttl'        => $ttl,
				'channel'    => $identifier_type,
			)
		);

		if ( ! $inserted ) {
			return self::error( 'ذخیرهٔ کد ناموفق بود.', 'DB' );
		}

		$sent = BMC_Verify::send(
			'otp_link',
			$identifier_value,
			$code,
			array(
				'player'   => $player,
				'ttl'      => $ttl,
				'minutes'  => BMC_Helpers::to_persian_digits( (int) ceil( $ttl / 60 ) ),
				'type'     => 'link',
				'user'     => $user,
				'email'    => $user->user_email,
			),
			$channel,
			$user->ID
		);

		if ( empty( $sent['success'] ) ) {
			self::mark_code_expired( (int) $inserted['id'] );
			return self::error(
				isset( $sent['message'] ) ? $sent['message'] : 'ارسال کد ناموفق بود.',
				isset( $sent['code'] ) ? $sent['code'] : 'SEND_FAIL'
			);
		}

		set_transient( $rl, 1, BMC_Settings::int( 'otp_rate_limit', 120, 10, 3600 ) );

		$response = array(
			'success'    => true,
			'message'    => isset( $sent['message'] ) ? $sent['message'] : 'کد تأیید ارسال شد.',
			'channel'    => isset( $sent['channel'] ) ? $sent['channel'] : $identifier_type,
			'expires_in' => $ttl,
		);

		if ( ! empty( $sent['code'] ) ) {
			$response['code'] = $sent['code'];
		}

		return $response;
	}

	public static function verify_link_otp( $identifier_type, $identifier_value, $code ) {
		unset( $identifier_type );

		$identifier_type  = 'email';
		$identifier_value = BMC_Helpers::sanitize_email( $identifier_value );

		if ( ! $identifier_value ) {
			return self::error( 'مشخصات نامعتبر است.', 'FORMAT' );
		}

		$identifier = $identifier_type . ':' . $identifier_value;
		$row        = self::find_code( 'otp_link', $code, $identifier );

		if ( ! $row ) {
			return self::error( 'کد تأیید نامعتبر یا منقضی است.', 'INVALID' );
		}

		if ( (int) $row->status !== self::CODE_ACTIVE ) {
			return self::error( 'این کد قبلاً استفاده شده است.', 'USED' );
		}

		if ( strtotime( $row->expires_at ) < BMC_Helpers::now_timestamp() ) {
			self::mark_code_expired( (int) $row->id );
			return self::error( 'اعتبار کد تمام شده است.', 'EXPIRED' );
		}

		if ( (int) $row->attempts >= BMC_Settings::int( 'otp_max_attempts', 5, 1, 20 ) ) {
			self::revoke_code( (int) $row->id );
			return self::error( 'تعداد تلاش‌های ناموفق بیش از حد مجاز است. کد جدید درخواست دهید.', 'LOCKED' );
		}

		self::bump_attempts( (int) $row->id );

		$result = self::link_user( (int) $row->user_id, $row->player, '', $identifier_type );

		if ( ! empty( $result['success'] ) ) {
			self::consume_code( (int) $row->id );
		}

		return $result;
	}

	private static function insert_code( array $args ) {
		global $wpdb;

		$table = BMC_DB::table( 'codes' );

		$now     = current_time( 'mysql' );
		$expires = BMC_Helpers::expires_at( $args['ttl'] );

		$data = array(
			'type'       => sanitize_key( $args['type'] ),
			'user_id'    => (int) $args['user_id'],
			'identifier' => sanitize_text_field( $args['identifier'] ),
			'player'     => sanitize_text_field( $args['player'] ),
			'code_hash'  => BMC_Helpers::hash_code( $args['code'] ),
			'attempts'   => 0,
			'status'     => self::CODE_ACTIVE,
			'ip_hash'    => BMC_Helpers::ip_hash(),
			'channel'    => sanitize_key( $args['channel'] ),
			'created_at' => $now,
			'expires_at' => $expires,
		);

		$ok = $wpdb->insert( $table, $data, array( '%s', '%d', '%s', '%s', '%s', '%d', '%d', '%s', '%s', '%s', '%s' ) );

		if ( false === $ok ) {
			return false;
		}

		$data['id'] = (int) $wpdb->insert_id;

		return $data;
	}

	private static function find_code( $type, $code, $identifier = '' ) {
		global $wpdb;

		$table = BMC_DB::table( 'codes' );
		$hash  = BMC_Helpers::hash_code( $code );

		if ( $identifier ) {
			return $wpdb->get_row(
				$wpdb->prepare(
					"SELECT * FROM {$table} WHERE type = %s AND code_hash = %s AND identifier = %s LIMIT 1",
					sanitize_key( $type ),
					$hash,
					$identifier
				)
			);
		}

		return $wpdb->get_row(
			$wpdb->prepare(
				"SELECT * FROM {$table} WHERE type = %s AND code_hash = %s LIMIT 1",
				sanitize_key( $type ),
				$hash
			)
		);
	}

	private static function consume_code( $id ) {
		global $wpdb;
		$table = BMC_DB::table( 'codes' );
		$wpdb->update(
			$table,
			array(
				'status'      => self::CODE_CONSUMED,
				'consumed_at' => current_time( 'mysql' ),
			),
			array( 'id' => (int) $id ),
			array( '%d', '%s' ),
			array( '%d' )
		);
	}

	public static function revoke_code( $id ) {
		global $wpdb;
		$table = BMC_DB::table( 'codes' );
		$wpdb->update( $table, array( 'status' => self::CODE_REVOKED ), array( 'id' => (int) $id ), array( '%d' ), array( '%d' ) );
	}

	private static function mark_code_expired( $id ) {
		self::revoke_code( $id );
	}

	private static function bump_attempts( $id ) {
		global $wpdb;
		$table = BMC_DB::table( 'codes' );
		$wpdb->query( $wpdb->prepare( "UPDATE {$table} SET attempts = attempts + 1 WHERE id = %d", (int) $id ) );
	}

	public static function revoke_user_codes( $user_id, $type = 'link' ) {
		global $wpdb;
		delete_transient( 'bmc_plain_code_' . (int) $user_id );
		$table = BMC_DB::table( 'codes' );
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET status = %d WHERE user_id = %d AND type = %s AND status = %d",
				self::CODE_REVOKED,
				(int) $user_id,
				sanitize_key( $type ),
				self::CODE_ACTIVE
			)
		);
	}

	private static function revoke_identifier_codes( $type, $identifier ) {
		global $wpdb;
		$table = BMC_DB::table( 'codes' );
		$wpdb->query(
			$wpdb->prepare(
				"UPDATE {$table} SET status = %d WHERE type = %s AND identifier = %s AND status = %d",
				self::CODE_REVOKED,
				sanitize_key( $type ),
				$identifier,
				self::CODE_ACTIVE
			)
		);
	}

	public static function ajax_generate_code() {
		self::check_nonce();

		$user_id = get_current_user_id();
		$player  = isset( $_POST['player'] ) ? sanitize_text_field( wp_unslash( $_POST['player'] ) ) : '';

		$result = self::create_panel_code( $user_id, $player );

		if ( empty( $result['success'] ) ) {
			wp_send_json_error( $result, 400 );
		}

		wp_send_json_success( $result );
	}

	public static function ajax_code_state() {
		self::check_nonce();

		wp_send_json_success( self::code_state( get_current_user_id() ) );
	}

	public static function ajax_revoke_code() {
		self::check_nonce();

		$user_id = get_current_user_id();
		$active  = self::get_active_code( $user_id );

		if ( $active ) {
			self::revoke_code( $active['id'] );
			delete_transient( 'bmc_plain_code_' . $user_id );
		}

		wp_send_json_success( array( 'message' => 'کد باطل شد.' ) );
	}

	public static function ajax_unlink() {
		self::check_nonce();

		if ( ! BMC_Settings::bool( 'unlink_allowed', true ) ) {
			wp_send_json_error( array( 'message' => 'قطع اتصال توسط مدیر سایت غیرفعال شده است. با پشتیبانی تماس بگیرید.' ), 403 );
		}

		$user_id = get_current_user_id();
		self::unlink_user( $user_id );

		wp_send_json_success(
			array(
				'message' => 'اتصال اکانت ماینکرافت قطع شد.',
				'reload'  => true,
			)
		);
	}

	public static function ajax_request_link_otp() {
		self::check_nonce();

		$user_id = get_current_user_id();
		$player  = isset( $_POST['player'] ) ? sanitize_text_field( wp_unslash( $_POST['player'] ) ) : '';
		$channel = isset( $_POST['channel'] ) ? sanitize_key( wp_unslash( $_POST['channel'] ) ) : '';

		if ( ! $user_id ) {
			wp_send_json_error( array( 'message' => 'ابتدا وارد حساب کاربری شوید.' ), 401 );
		}

		$user  = wp_get_current_user();
		$value = (string) $user->user_email;

		if ( ! $value ) {
			wp_send_json_error( array( 'message' => 'ایمیلی در حساب شما ثبت نشده است. روش «داشبورد» را انتخاب کنید یا ایمیل را در «جزئیات حساب» ثبت کنید.' ), 400 );
		}

		$result = self::request_link_otp( 'email', $value, $player, $channel );

		if ( empty( $result['success'] ) ) {
			wp_send_json_error( $result, 400 );
		}

		$result['masked'] = BMC_Auth::mask_email( $value );

		wp_send_json_success( $result );
	}

	public static function ajax_verify_link_otp() {
		self::check_nonce();

		$user_id = get_current_user_id();
		$code    = isset( $_POST['code'] ) ? sanitize_text_field( wp_unslash( $_POST['code'] ) ) : '';

		if ( ! $user_id ) {
			wp_send_json_error( array( 'message' => 'ابتدا وارد حساب کاربری شوید.' ), 401 );
		}

		$user   = wp_get_current_user();
		$result = self::verify_link_otp( 'email', (string) $user->user_email, $code );

		if ( empty( $result['success'] ) ) {
			wp_send_json_error( $result, 400 );
		}

		wp_send_json_success(
			array(
				'message' => $result['message'],
				'player'  => self::get_linked_player( $user_id ),
				'reload'  => true,
			)
		);
	}

	private static function check_nonce() {
		$nonce = isset( $_REQUEST['security'] ) ? sanitize_text_field( wp_unslash( $_REQUEST['security'] ) ) : '';

		if ( ! wp_verify_nonce( $nonce, 'bmc_frontend' ) ) {
			wp_send_json_error( array( 'message' => 'نشست شما منقضی شده است. صفحه را تازه کنید.' ), 403 );
		}

		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => 'ابتدا وارد حساب کاربری شوید.' ), 401 );
		}
	}

	private static function error( $message, $code = 'ERROR' ) {
		return array(
			'success' => false,
			'message' => $message,
			'code'    => $code,
		);
	}

	public static function display_name( $user_id ) {
		$user = get_userdata( (int) $user_id );
		if ( ! $user ) {
			return '';
		}
		$name = trim( $user->display_name );
		return $name ? $name : $user->user_login;
	}
}
