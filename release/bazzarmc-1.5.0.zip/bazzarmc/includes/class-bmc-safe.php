<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Safe {

	const STATE_OPTION  = 'bmc_crash_state';
	const NOTICE_OPTION = 'bmc_safe_notified';

	private static $booted    = false;
	private static $override  = null;
	private static $errors    = array();
	private static $timers    = array();
	private static $recovered = false;

	public static function boot() {
		if ( self::$booted ) {
			return;
		}

		self::$booted = true;

		try {
			if ( defined( 'BMC_SAFE_MODE' ) && BMC_SAFE_MODE ) {
				self::$override = true;
			}

			if ( self::setting( 'safe_guard', true ) ) {
				register_shutdown_function( array( __CLASS__, 'shutdown' ) );
			}

			add_action( 'init', array( __CLASS__, 'read_request_override' ), 1 );
			add_action( 'admin_notices', array( __CLASS__, 'admin_notice' ), 5 );
			add_action( 'admin_init', array( __CLASS__, 'handle_admin_action' ), 5 );
		} catch ( \Throwable $e ) {
			self::collect( 'boot', $e );
		}
	}

	public static function booted() {
		return self::$booted;
	}

	public static function setting( $key, $default = null ) {
		if ( ! class_exists( 'BMC_Settings' ) ) {
			return $default;
		}

		try {
			return BMC_Settings::get( $key, $default );
		} catch ( \Throwable $e ) {
			self::collect( 'settings:' . $key, $e );
			return $default;
		}
	}

	public static function flag( $key, $default = false ) {
		if ( ! class_exists( 'BMC_Settings' ) ) {
			return (bool) $default;
		}

		try {
			return BMC_Settings::bool( $key, $default );
		} catch ( \Throwable $e ) {
			self::collect( 'settings:' . $key, $e );
			return (bool) $default;
		}
	}

	public static function guard( $label, callable $callback, $fallback = null ) {
		try {
			return $callback();
		} catch ( \Throwable $e ) {
			self::collect( $label, $e );
			return $fallback;
		}
	}

	public static function start( $label ) {
		self::$timers[ $label ] = microtime( true );
	}

	public static function stop( $label ) {
		if ( ! isset( self::$timers[ $label ] ) ) {
			return 0;
		}

		$took = microtime( true ) - self::$timers[ $label ];
		unset( self::$timers[ $label ] );

		return round( $took * 1000, 2 );
	}

	public static function collect( $label, $error ) {
		$message = ( $error instanceof \Throwable ) ? $error->getMessage() : (string) $error;
		$file    = ( $error instanceof \Throwable ) ? $error->getFile() : '';
		$line    = ( $error instanceof \Throwable ) ? $error->getLine() : 0;

		self::$errors[] = array(
			'label'   => (string) $label,
			'message' => $message,
			'file'    => $file,
			'line'    => $line,
			'time'    => time(),
		);

		if ( count( self::$errors ) > 40 ) {
			array_shift( self::$errors );
		}

		if ( class_exists( 'BMC_Logger' ) && self::flag( 'debug_log', true ) ) {
			try {
				BMC_Logger::add(
					'safe',
					'خطای مهارشده در ' . $label . ': ' . $message,
					array(
						'file' => $file ? str_replace( (string) BMC_PATH, '', $file ) : '',
						'line' => $line,
					),
					'error'
				);
			} catch ( \Throwable $e ) {
				unset( $e );
			}
		}
	}

	public static function errors() {
		return self::$errors;
	}

	public static function shutdown() {
		try {
			$error = function_exists( 'error_get_last' ) ? error_get_last() : null;

			if ( ! $error || empty( $error['type'] ) ) {
				return;
			}

			$fatal = array( E_ERROR, E_PARSE, E_CORE_ERROR, E_COMPILE_ERROR, E_USER_ERROR, E_RECOVERABLE_ERROR );

			if ( ! in_array( (int) $error['type'], $fatal, true ) ) {
				return;
			}

			if ( ! self::is_ours( $error ) ) {
				return;
			}

			self::record_fatal( $error );
		} catch ( \Throwable $e ) {
			unset( $e );
		}
	}

	public static function is_ours( $error ) {
		$file = isset( $error['file'] ) ? str_replace( '\\', '/', (string) $error['file'] ) : '';
		$base = str_replace( '\\', '/', (string) BMC_PATH );

		if ( $file && $base && 0 === strpos( $file, $base ) ) {
			return true;
		}

		$message = isset( $error['message'] ) ? (string) $error['message'] : '';

		return (bool) preg_match( '/\bBMC_[A-Za-z_]+|bazzarmc|bmc_/i', $message );
	}

	public static function record_fatal( array $error ) {
		if ( ! function_exists( 'get_option' ) || ! function_exists( 'update_option' ) ) {
			return;
		}

		$now   = time();
		$state = get_option( self::STATE_OPTION, array() );

		if ( ! is_array( $state ) ) {
			$state = array();
		}

		if ( empty( $state['first'] ) || ( $now - (int) $state['first'] ) > 600 ) {
			$state['first'] = $now;
			$state['count'] = 0;
		}

		$state['count']   = isset( $state['count'] ) ? (int) $state['count'] + 1 : 1;
		$state['last']    = $now;
		$state['file']    = isset( $error['file'] ) ? str_replace( (string) BMC_PATH, '', (string) $error['file'] ) : '';
		$state['line']    = isset( $error['line'] ) ? (int) $error['line'] : 0;
		$state['message'] = isset( $error['message'] ) ? substr( (string) $error['message'], 0, 500 ) : '';
		$state['url']     = isset( $_SERVER['REQUEST_URI'] ) ? substr( sanitize_text_field( wp_unslash( $_SERVER['REQUEST_URI'] ) ), 0, 200 ) : '';
		$state['php']     = PHP_VERSION;

		update_option( self::STATE_OPTION, $state, false );

		$limit = (int) self::setting( 'safe_crash_limit', 2 );

		if ( $state['count'] >= max( 1, $limit ) && self::flag( 'safe_autorecover', true ) && ! self::safe_mode() ) {
			self::activate( 'auto' );
			self::recover();
			self::notify_admin( $state );
		}
	}

	public static function state() {
		if ( ! function_exists( 'get_option' ) ) {
			return array( 'count' => 0 );
		}

		$state = get_option( self::STATE_OPTION, array() );

		return is_array( $state ) ? $state : array( 'count' => 0 );
	}

	public static function reset() {
		if ( function_exists( 'delete_option' ) ) {
			delete_option( self::STATE_OPTION );
			delete_option( self::NOTICE_OPTION );
		}

		self::$recovered = false;
	}

	public static function activate( $mode = 'on' ) {
		if ( ! class_exists( 'BMC_Settings' ) ) {
			return false;
		}

		$mode = 'auto' === $mode ? 'auto' : 'on';

		BMC_Settings::save( array( 'safe_mode' => $mode ) );

		self::$override = true;

		return true;
	}

	public static function deactivate() {
		if ( ! class_exists( 'BMC_Settings' ) ) {
			return false;
		}

		BMC_Settings::save( array( 'safe_mode' => 'off' ) );

		self::$override = false;
		self::reset();

		return true;
	}

	public static function safe_mode() {
		if ( null !== self::$override ) {
			return (bool) self::$override;
		}

		if ( defined( 'BMC_SAFE_MODE' ) && BMC_SAFE_MODE ) {
			return true;
		}

		$mode = (string) self::setting( 'safe_mode', 'off' );

		return in_array( $mode, array( 'on', 'auto' ), true );
	}

	public static function safe_mode_reason() {
		if ( defined( 'BMC_SAFE_MODE' ) && BMC_SAFE_MODE ) {
			return 'constant';
		}

		if ( true === self::$override ) {
			return 'request';
		}

		$mode = (string) self::setting( 'safe_mode', 'off' );

		if ( 'auto' === $mode ) {
			return 'auto';
		}

		return 'on' === $mode ? 'manual' : '';
	}

	public static function read_request_override() {
		if ( ! isset( $_GET['bmc_safe'] ) ) {
			return;
		}

		if ( ! function_exists( 'current_user_can' ) || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		self::$override = ! empty( $_GET['bmc_safe'] ) && '0' !== (string) $_GET['bmc_safe'];
	}

	public static function recover() {
		if ( self::$recovered || ! class_exists( 'BMC_Settings' ) ) {
			return false;
		}

		self::$recovered = true;

		try {
			BMC_Settings::save(
				array(
					'elementor_enabled'    => 'no',
					'checkout_mode'        => 'wc',
					'cart_mode'            => 'wc',
					'cart_inline_checkout' => 'no',
					'myaccount_card'       => 'no',
					'blocks_checkout'      => 'notice',
				)
			);

			if ( class_exists( 'BMC_Logger' ) ) {
				BMC_Logger::add( 'safe', 'حالت ایمن فعال شد و بخش‌های پرخطر خاموش شدند تا سایت در دسترس بماند.', array(), 'warning' );
			}
		} catch ( \Throwable $e ) {
			self::collect( 'recover', $e );
			return false;
		}

		return true;
	}

	public static function notify_admin( array $state ) {
		if ( ! function_exists( 'get_option' ) || ! function_exists( 'wp_mail' ) ) {
			return false;
		}

		if ( get_option( self::NOTICE_OPTION ) ) {
			return false;
		}

		update_option( self::NOTICE_OPTION, time(), false );

		$emails = array_filter( array_map( 'trim', explode( ',', (string) self::setting( 'safe_notify_email', '' ) ) ) );

		if ( ! $emails ) {
			$emails = array( (string) get_option( 'admin_email' ) );
		}

		$subject = 'BazzarMc: حالت ایمن به‌صورت خودکار فعال شد';
		$body    = "خطای فاحش در افزونهٔ BazzarMc ثبت شد و برای اینکه سایت از دسترس خارج نماند، حالت ایمن فعال شد.\n\n"
			. 'تعداد خطا: ' . ( isset( $state['count'] ) ? (int) $state['count'] : 0 ) . "\n"
			. 'فایل: ' . ( isset( $state['file'] ) ? $state['file'] : '—' ) . "\n"
			. 'پیام: ' . ( isset( $state['message'] ) ? $state['message'] : '—' ) . "\n"
			. 'آدرس: ' . ( isset( $state['url'] ) ? $state['url'] : '—' ) . "\n\n"
			. 'برای بررسی و بازگردانی: پیشخوان وردپرس ← BazzarMc ← ابزارها ← «محافظ پایداری و حالت ایمن».';

		foreach ( $emails as $email ) {
			wp_mail( $email, $subject, $body );
		}

		return true;
	}

	public static function admin_notice() {
		if ( ! function_exists( 'current_user_can' ) || ! current_user_can( 'manage_woocommerce' ) ) {
			return;
		}

		if ( ! self::safe_mode() ) {
			$state = self::state();

			if ( empty( $state['count'] ) ) {
				return;
			}

			echo '<div class="notice notice-warning is-dismissible"><p><strong>BazzarMc:</strong> '
				. esc_html( 'خطای فاحش مهار و ثبت شد (' . (int) $state['count'] . ' بار). سایت در دسترس ماند. ' )
				. '<a href="' . esc_url( admin_url( 'admin.php?page=bazzarmc&tab=tools' ) ) . '">بررسی گزارش</a></p></div>';

			return;
		}

		$url   = admin_url( 'admin.php?page=bazzarmc&tab=tools' );
		$exit  = wp_nonce_url( add_query_arg( array( 'bmc_safe_action' => 'off' ), admin_url( 'admin.php?page=bazzarmc&tab=tools' ) ), 'bmc_safe', 'bmc_safe_nonce' );
		$state = self::state();

		echo '<div class="notice notice-error"><p><strong>BazzarMc — حالت ایمن فعال است.</strong> '
			. esc_html( 'بخش‌های پرخطر افزونه موقتاً خاموش شده‌اند تا سایت بالا بماند.' )
			. ( empty( $state['message'] ) ? '' : ' <code dir="ltr">' . esc_html( substr( (string) $state['message'], 0, 160 ) ) . '</code>' )
			. ' <a href="' . esc_url( $url ) . '">گزارش و آزمون سلامت</a> | <a href="' . esc_url( $exit ) . '">خروج از حالت ایمن</a></p></div>';
	}

	public static function handle_admin_action() {
		if ( empty( $_GET['bmc_safe_action'] ) ) {
			return;
		}

		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}

		check_admin_referer( 'bmc_safe', 'bmc_safe_nonce' );

		$action = sanitize_key( wp_unslash( $_GET['bmc_safe_action'] ) );

		if ( 'on' === $action ) {
			self::activate( 'on' );
		} elseif ( 'off' === $action ) {
			self::deactivate();
		} elseif ( 'reset' === $action ) {
			self::reset();
		} elseif ( 'recover' === $action ) {
			self::recover();
		}

		wp_safe_redirect( admin_url( 'admin.php?page=bazzarmc&tab=tools&bmc_safe_done=' . rawurlencode( $action ) ) );
		exit;
	}

	public static function details_allowed() {
		return self::flag( 'safe_debug_display', false ) && function_exists( 'current_user_can' ) && current_user_can( 'manage_woocommerce' );
	}

	public static function blocked_box( $title = 'این بخش موقتاً غیرفعال است' ) {
		if ( ! function_exists( 'current_user_can' ) || ! current_user_can( 'manage_woocommerce' ) ) {
			return '';
		}

		return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">'
			. '<strong>' . esc_html( $title ) . '</strong> '
			. 'حالت ایمن BazzarMc فعال است. برای بازگردانی به پیشخوان ← BazzarMc ← ابزارها بروید.'
			. '</div></div>';
	}

	public static function health() {
		$checks = array();

		$checks[] = self::check_php();
		$checks[] = self::check_wordpress();
		$checks[] = self::check_woocommerce();
		$checks[] = self::check_elementor();
		$checks   = array_merge( $checks, self::check_files() );
		$checks   = array_merge( $checks, self::check_database() );
		$checks[] = self::check_pages();
		$checks[] = self::check_checkout();
		$checks[] = self::check_cron();
		$checks[] = self::check_server();
		$checks[] = self::check_blocks();
		$checks[] = self::check_php_limits();
		$checks[] = self::check_safety();

		$checks = array_values( array_filter( $checks ) );

		return apply_filters( 'bmc_health_checks', $checks );
	}

	private static function check_php() {
		$status = 'ok';
		$detail = 'نسخهٔ PHP ' . PHP_VERSION;

		if ( version_compare( PHP_VERSION, '7.4', '<' ) ) {
			$status  = 'fail';
			$detail .= ' — افزونه به PHP ۷.۴ یا جدیدتر نیاز دارد و در این نسخه ممکن است خطا بدهد.';
		} elseif ( version_compare( PHP_VERSION, '8.0', '<' ) ) {
			$status  = 'warn';
			$detail .= ' — پشتیبانی می‌شود اما PHP ۸.۱ به بالا توصیه می‌شود.';
		}

		return array(
			'key'    => 'php',
			'label'  => 'نسخهٔ PHP',
			'status' => $status,
			'detail' => $detail,
		);
	}

	private static function check_wordpress() {
		global $wp_version;

		$version = isset( $wp_version ) ? (string) $wp_version : get_bloginfo( 'version' );
		$status  = version_compare( $version, '6.0', '>=' ) ? 'ok' : 'warn';

		return array(
			'key'    => 'wp',
			'label'  => 'نسخهٔ وردپرس',
			'status' => $status,
			'detail' => 'نسخهٔ ' . $version . ( 'ok' === $status ? '' : ' — وردپرس ۶.۰ یا جدیدتر توصیه می‌شود.' ),
		);
	}

	private static function check_woocommerce() {
		if ( ! class_exists( 'WooCommerce' ) ) {
			return array(
				'key'    => 'woocommerce',
				'label'  => 'ووکامرس',
				'status' => 'fail',
				'detail' => 'ووکامرس فعال نیست؛ سبد، چک‌اوت و تحویل‌ها کار نمی‌کنند اما سایت بالا می‌ماند.',
			);
		}

		$version = defined( 'WC_VERSION' ) ? (string) WC_VERSION : '';
		$hpos    = 'نامشخص';

		if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) && method_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil', 'custom_orders_table_usage_is_enabled' ) ) {
			$hpos = \Automattic\WooCommerce\Utilities\FeaturesUtil::custom_orders_table_usage_is_enabled() ? 'فعال (سازگار با افزونه)' : 'غیرفعال';
		}

		return array(
			'key'    => 'woocommerce',
			'label'  => 'ووکامرس',
			'status' => 'ok',
			'detail' => 'نسخهٔ ' . $version . ' — جدول سفارش‌ها (HPOS): ' . $hpos,
		);
	}

	private static function check_elementor() {
		if ( ! class_exists( 'BMC_Elementor' ) ) {
			return array(
				'key'    => 'elementor',
				'label'  => 'المنتور',
				'status' => 'info',
				'detail' => 'کلاس یکپارچه‌سازی بارگذاری نشده است.',
			);
		}

		if ( ! BMC_Elementor::is_active() ) {
			return array(
				'key'    => 'elementor',
				'label'  => 'المنتور',
				'status' => 'info',
				'detail' => 'المنتور نصب یا فعال نیست — ویجت‌ها بارگذاری نشده‌اند و هیچ خطایی تولید نمی‌شود.',
			);
		}

		$version = BMC_Elementor::version();

		if ( ! BMC_Elementor::is_supported() ) {
			return array(
				'key'    => 'elementor',
				'label'  => 'المنتور',
				'status' => 'warn',
				'detail' => 'نسخهٔ ' . $version . ' قدیمی است (حداقل ۳.۱ لازم است) — ویجت‌ها ثبت نمی‌شوند تا خطایی رخ ندهد.',
			);
		}

		if ( ! BMC_Elementor::enabled() ) {
			return array(
				'key'    => 'elementor',
				'label'  => 'المنتور',
				'status' => 'warn',
				'detail' => 'نسخهٔ ' . $version . ' سازگار است اما ثبت ویجت‌ها در تنظیمات خاموش شده است.',
			);
		}

		$loaded = method_exists( 'BMC_Elementor', 'files_loaded' ) && BMC_Elementor::files_loaded();
		$count  = method_exists( 'BMC_Elementor', 'widget_names' ) ? count( BMC_Elementor::widget_names() ) : 0;

		if ( $loaded ) {
			$state = 'ثبت شده (' . BMC_Helpers::to_persian_digits( $count ) . ' ویجت)';
		} elseif ( BMC_Elementor::booted() ) {
			$state = 'در انتظار آماده‌شدن کلاس‌های المنتور — در هوک ثبت ویجت‌ها بارگذاری می‌شوند';
		} else {
			$state = 'ثبت نشده (هوک بارگذاری هنوز اجرا نشده)';
		}

		return array(
			'key'    => 'elementor',
			'label'  => 'المنتور',
			'status' => $loaded ? 'ok' : 'warn',
			'detail' => 'نسخهٔ ' . $version . ' — ویجت‌ها: ' . $state,
		);
	}

	private static function check_checkout() {
		if ( ! class_exists( 'BMC_Checkout' ) ) {
			return array(
				'key'    => 'checkout',
				'label'  => 'فرم خرید',
				'status' => 'info',
				'detail' => 'کلاس چک‌اوت بارگذاری نشده است.',
			);
		}

		$custom = BMC_Settings::custom_checkout();
		$detail = 'حالت فرم خرید: ' . ( $custom ? 'اختصاصی BazzarMc' : 'استاندارد ووکامرس' );

		if ( ! class_exists( 'BMC_Checkout_Fields' ) ) {
			return array(
				'key'    => 'checkout',
				'label'  => 'فرم خرید',
				'status' => 'info',
				'detail' => $detail . ' — کلاس فیلدهای دلخواه بارگذاری نشده است.',
			);
		}

		$total  = count( BMC_Checkout_Fields::custom_fields() );
		$active = count( BMC_Checkout_Fields::active_fields() );

		if ( $total ) {
			$detail .= ' — فیلدهای دلخواه: ' . BMC_Helpers::to_persian_digits( $active ) . ' فعال از ' . BMC_Helpers::to_persian_digits( $total ) . ' تعریف‌شده';
		} else {
			$detail .= ' — فیلد دلخواهی ساخته نشده است';
		}

		if ( $total && ! $custom ) {
			return array(
				'key'    => 'checkout',
				'label'  => 'فرم خرید',
				'status' => 'warn',
				'detail' => $detail . ' — در حالت «استاندارد ووکامرس» فیلدهای دلخواه نمایش داده نمی‌شوند؛ فرم خرید را به حالت اختصاصی برگردانید.',
			);
		}

		if ( $total && ! BMC_Settings::bool( 'checkout_custom_enabled', true ) ) {
			return array(
				'key'    => 'checkout',
				'label'  => 'فرم خرید',
				'status' => 'warn',
				'detail' => $detail . ' — کلید «فعال‌سازی فیلدهای دلخواه» در تب پرداخت خاموش است.',
			);
		}

		if ( $total && $active < $total ) {
			$detail .= ' (برخی فیلدها خاموش یا محدود به کاربر/آیتم ماینکرافت هستند)';
		}

		return array(
			'key'    => 'checkout',
			'label'  => 'فرم خرید',
			'status' => 'ok',
			'detail' => $detail,
		);
	}

	private static function check_files() {
		$out      = array();
		$includes = array(
			'includes/class-bmc-icons.php',
			'includes/class-bmc-roles.php',
			'includes/class-bmc-ranks.php',
			'includes/class-bmc-tickets.php',
			'includes/class-bmc-helpers.php',
			'includes/class-bmc-jalali.php',
			'includes/class-bmc-logger.php',
			'includes/class-bmc-settings.php',
			'includes/class-bmc-safe.php',
			'includes/class-bmc-forms.php',
			'includes/class-bmc-checkout-fields.php',
			'includes/class-bmc-db.php',
			'includes/class-bmc-link.php',
			'includes/integrations/class-bmc-ezlogin.php',
			'includes/integrations/class-bmc-elementor.php',
			'includes/class-bmc-verify.php',
			'includes/class-bmc-fields.php',
			'includes/class-bmc-cache.php',
			'includes/class-bmc-api.php',
			'includes/class-bmc-deliveries.php',
			'includes/class-bmc-auth.php',
			'includes/class-bmc-checkout.php',
			'includes/class-bmc-cron.php',
			'includes/class-bmc-public.php',
			'includes/class-bmc-admin.php',
			'includes/class-bmc-migrate.php',
		);

		$missing = array();

		foreach ( $includes as $file ) {
			if ( ! file_exists( BMC_PATH . $file ) ) {
				$missing[] = $file;
			}
		}

		$out[] = array(
			'key'    => 'includes',
			'label'  => 'فایل‌های هسته',
			'status' => $missing ? 'fail' : 'ok',
			'detail' => $missing ? 'فایل‌های گمشده: ' . implode( ', ', $missing ) : 'هر ' . count( $includes ) . ' فایل کلاس موجود است.',
		);

		$templates = array( 'account-card', 'account-nav', 'cart', 'checkout', 'deliveries', 'form', 'gate', 'link-box', 'ranks', 'ticket-view', 'tickets', 'wc-dashboard' );
		$missing_t = array();

		foreach ( $templates as $tpl ) {
			if ( ! is_readable( BMC_PATH . 'public/templates/' . $tpl . '.php' ) ) {
				$missing_t[] = $tpl . '.php';
			}
		}

		$out[] = array(
			'key'    => 'templates',
			'label'  => 'قالب‌های نمایشی',
			'status' => $missing_t ? 'fail' : 'ok',
			'detail' => $missing_t ? 'قالب‌های گمشده: ' . implode( ', ', $missing_t ) : 'هر ' . count( $templates ) . ' قالب موجود و خوانا است.',
		);

		$assets = array(
			'assets/css/bmc-public.css',
			'assets/css/bmc-elementor.css',
			'assets/css/bmc-admin.css',
			'assets/js/bmc-icons.js',
			'assets/js/bmc-link.js',
			'assets/js/bmc-checkout.js',
			'assets/js/bmc-form.js',
			'assets/js/bmc-admin.js',
		);
		$missing_a = array();

		foreach ( $assets as $asset ) {
			if ( ! is_readable( BMC_PATH . $asset ) ) {
				$missing_a[] = $asset;
			}
		}

		$out[] = array(
			'key'    => 'assets',
			'label'  => 'فایل‌های استایل و اسکریپت',
			'status' => $missing_a ? 'fail' : 'ok',
			'detail' => $missing_a ? 'گمشده: ' . implode( ', ', $missing_a ) : 'هر ' . count( $assets ) . ' فایل موجود است.',
		);

		return $out;
	}

	private static function check_database() {
		global $wpdb;

		$out    = array();
		$status = 'ok';

		if ( ! class_exists( 'BMC_DB' ) ) {
			return array( array( 'key' => 'db', 'label' => 'جدول‌های دیتابیس', 'status' => 'fail', 'detail' => 'کلاس دیتابیس بارگذاری نشده است.' ) );
		}

		try {
			$tables = BMC_DB::table_status();
		} catch ( \Throwable $e ) {
			self::collect( 'health:db', $e );

			return array( array( 'key' => 'db', 'label' => 'جدول‌های دیتابیس', 'status' => 'fail', 'detail' => 'خطا در خواندن وضعیت جدول‌ها: ' . $e->getMessage() ) );
		}

		$missing = array();
		$rows    = array();

		foreach ( $tables as $name => $info ) {
			if ( empty( $info['exists'] ) ) {
				$missing[] = $name;
			} else {
				$rows[] = $name . ': ' . (int) $info['rows'];
			}
		}

		if ( $missing ) {
			$status = 'fail';
		}

		$out[] = array(
			'key'    => 'db',
			'label'  => 'جدول‌های دیتابیس',
			'status' => $status,
			'detail' => $missing ? 'جدول‌های ساخته‌نشده: ' . implode( ', ', $missing ) . ' — دکمهٔ «بازسازی جدول‌ها» را بزنید.' : implode( ' | ', $rows ),
		);

		$version = function_exists( 'get_option' ) ? (string) get_option( 'bmc_db_version', '' ) : '';

		$out[] = array(
			'key'    => 'db_version',
			'label'  => 'نسخهٔ ساختار دیتابیس',
			'status' => ( $version && defined( 'BMC_DB_VERSION' ) && version_compare( $version, BMC_DB_VERSION, '<' ) ) ? 'warn' : 'ok',
			'detail' => 'نصب‌شده: ' . ( $version ? $version : '—' ) . ' | موردنیاز: ' . ( defined( 'BMC_DB_VERSION' ) ? BMC_DB_VERSION : '—' ),
		);

		unset( $wpdb );

		return $out;
	}

	private static function check_pages() {
		$labels = array(
			'page_link'     => 'صفحهٔ اتصال اکانت',
			'page_cart'     => 'صفحهٔ سبد خرید',
			'page_checkout' => 'صفحهٔ پرداخت',
			'page_tickets'  => 'صفحهٔ تیکت‌ها',
		);

		$missing = array();

		foreach ( $labels as $key => $label ) {
			$id = (int) self::setting( $key, 0 );

			if ( ! $id || 'publish' !== get_post_status( $id ) ) {
				$missing[] = $label;
			}
		}

		return array(
			'key'    => 'pages',
			'label'  => 'صفحه‌های افزونه',
			'status' => $missing ? 'warn' : 'ok',
			'detail' => $missing ? 'تنظیم نشده یا منتشر نشده: ' . implode( '، ', $missing ) : 'هر چهار صفحه تنظیم و منتشر شده‌اند.',
		);
	}

	private static function check_cron() {
		$next = function_exists( 'wp_next_scheduled' ) ? wp_next_scheduled( 'bmc_hourly_maintenance' ) : false;

		return array(
			'key'    => 'cron',
			'label'  => 'زمان‌بندی نگهداری',
			'status' => $next ? 'ok' : 'warn',
			'detail' => $next ? 'اجرای بعدی: ' . ( function_exists( 'wp_date' ) ? wp_date( 'Y-m-d H:i', $next ) : gmdate( 'Y-m-d H:i', (int) $next ) ) : 'زمان‌بندی ثبت نشده — از دکمهٔ «اجرای دستی نگهداری» استفاده کنید.',
		);
	}

	private static function check_server() {
		$token = (string) self::setting( 'api_token', '' );
		$ping  = function_exists( 'rest_url' ) ? rest_url( 'bazzarmc/v1/ping' ) : '';

		if ( ! $ping ) {
			return array(
				'key'    => 'server',
				'label'  => 'مسیر REST پلاگین ماینکرافت',
				'status' => 'warn',
				'detail' => 'rest_url در دسترس نیست.',
			);
		}

		$timeout = (int) apply_filters( 'bmc_http_timeout', 8 );
		$status  = 'ok';
		$detail  = '';

		try {
			$response = wp_remote_get(
				$ping,
				array(
					'timeout'     => min( 8, max( 3, $timeout ) ),
					'redirection' => 0,
					'headers'     => array( 'X-BMC-Token' => $token ),
					'sslverify'   => self::flag( 'ssl_verify', true ),
				)
			);

			if ( is_wp_error( $response ) ) {
				$status = 'warn';
				$detail = 'پینگ داخلی خطا داد: ' . $response->get_error_message();
			} else {
				$code = (int) wp_remote_retrieve_response_code( $response );
				$body = json_decode( (string) wp_remote_retrieve_body( $response ), true );

				if ( 200 === $code && is_array( $body ) && ( ! empty( $body['ok'] ) || ! empty( $body['success'] ) ) ) {
					$detail = 'مسیر <code dir="ltr">bazzarmc/v1/ping</code> سالم پاسخ داد (کد ۲۰۰).';
				} else {
					$status = 'warn';
					$detail = 'پینگ پاسخ غیرمنتظره داد (کد ' . $code . ').';
					if ( is_array( $body ) && ! empty( $body['message'] ) ) {
						$detail .= ' پیام: ' . sanitize_text_field( (string) $body['message'] );
					}
				}
			}
		} catch ( \Throwable $e ) {
			self::collect( 'health:ping', $e );
			$status = 'warn';
			$detail = 'پینگ با خطا مواجه شد: ' . $e->getMessage();
		}

		if ( ! $token ) {
			$status = 'fail';
			$detail = 'توکن API ساخته نشده است؛ پلاگین ماینکرافت نمی‌تواند متصل شود.';
		}

		if ( self::flag( 'mojang_check', true ) ) {
			try {
				$mojang = wp_remote_get( 'https://api.mojang.com/users/profiles/minecraft/Notch', array( 'timeout' => 6 ) );
				$detail .= is_wp_error( $mojang )
					? ' | بررسی نام کاربری موجانگ: در دسترس نیست (' . $mojang->get_error_message() . ')'
					: ' | بررسی نام کاربری موجانگ: در دسترس (کد ' . (int) wp_remote_retrieve_response_code( $mojang ) . ')';
			} catch ( \Throwable $e ) {
				self::collect( 'health:mojang', $e );
				$detail .= ' | بررسی موجانگ با خطا مواجه شد.';
			}
		}

		$detail .= ' | مهلت همهٔ درخواست‌های خروجی محدود است؛ در دسترس نبودن سرور یا موجانگ سایت را از کار نمی‌اندازد.';

		return array(
			'key'    => 'server',
			'label'  => 'اتصال و REST',
			'status' => $status,
			'detail' => $detail,
		);
	}

	private static function check_blocks() {
		if ( ! function_exists( 'wc_get_page_id' ) ) {
			return array(
				'key'    => 'blocks',
				'label'  => 'بلاک‌های چک‌اوت',
				'status' => 'info',
				'detail' => 'ووکامرس فعال نیست تا صفحه‌ها بررسی شوند.',
			);
		}

		$mode  = (string) self::setting( 'blocks_checkout', 'force_classic' );
		$found = array();

		foreach ( array( 'cart', 'checkout' ) as $which ) {
			$id = (int) wc_get_page_id( $which );

			if ( ! $id ) {
				continue;
			}

			$content = (string) get_post_field( 'post_content', $id );

			if ( false !== strpos( $content, 'wp:woocommerce/' . $which ) || false !== strpos( $content, 'woocommerce/' . $which . '-block' ) ) {
				$found[] = 'cart' === $which ? 'سبد' : 'پرداخت';
			}
		}

		if ( ! $found ) {
			return array(
				'key'    => 'blocks',
				'label'  => 'بلاک‌های چک‌اوت',
				'status' => 'ok',
				'detail' => 'صفحه‌های سبد و پرداخت از بلاک‌های گوتنبرگ ووکامرس استفاده نمی‌کنند.',
			);
		}

		return array(
			'key'    => 'blocks',
			'label'  => 'بلاک‌های چک‌اوت',
			'status' => 'force_classic' === $mode ? 'ok' : 'warn',
			'detail' => 'بلاک ووکامرس در صفحهٔ ' . implode( ' و ', $found ) . ' پیدا شد — تنظیمات افزونه روی «' . $mode . '» است.',
		);
	}

	private static function check_php_limits() {
		$memory  = (string) ini_get( 'memory_limit' );
		$maxexec = (int) ini_get( 'max_execution_time' );
		$display = (string) ini_get( 'display_errors' );
		$warn    = array();
		$status  = 'ok';

		if ( $display && '0' !== $display && 'off' !== strtolower( $display ) ) {
			$status  = 'warn';
			$warn[]  = 'display_errors روشن است (خطاهای PHP به بازدیدکننده نشان داده می‌شود)';
		}

		if ( $maxexec && $maxexec < 30 ) {
			$status = 'warn';
			$warn[] = 'max_execution_time کمتر از ۳۰ ثانیه';
		}

		$detail = 'memory_limit=' . ( $memory ? $memory : '—' ) . ' | max_execution_time=' . ( $maxexec ? $maxexec : '0' );

		if ( $warn ) {
			$detail .= ' — هشدار: ' . implode( '، ', $warn );
		}

		return array(
			'key'    => 'php_limits',
			'label'  => 'محدودیت‌های PHP',
			'status' => $status,
			'detail' => $detail,
		);
	}

	private static function check_safety() {
		$state  = self::state();
		$count  = isset( $state['count'] ) ? (int) $state['count'] : 0;
		$detail = 'واچ‌داگ خطای فاحش: ' . ( self::flag( 'safe_guard', true ) ? 'روشن' : 'خاموش' )
			. ' | حد فعال‌سازی خودکار: ' . (int) self::setting( 'safe_crash_limit', 2 ) . ' خطا در ۱۰ دقیقه'
			. ' | خطاهای ثبت‌شدهٔ اخیر: ' . $count;

		if ( $count && ! empty( $state['message'] ) ) {
			$detail .= ' — آخرین خطا: ' . substr( (string) $state['message'], 0, 160 );
		}

		if ( self::$errors ) {
			$detail .= ' | خطاهای مهارشده در همین درخواست: ' . count( self::$errors );
		}

		return array(
			'key'    => 'safety',
			'label'  => 'محافظ پایداری',
			'status' => self::safe_mode() ? 'warn' : ( $count ? 'warn' : 'ok' ),
			'detail' => $detail,
		);
	}

	public static function status_labels() {
		return array(
			'ok'   => 'سالم',
			'warn' => 'هشدار',
			'fail' => 'نیازمند اقدام',
			'info' => 'اطلاع',
		);
	}
}
