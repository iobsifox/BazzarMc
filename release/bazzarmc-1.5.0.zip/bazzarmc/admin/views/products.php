<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$synced       = array_map( 'absint', (array) $settings['sync_products'] );
$product_role = (array) $settings['product_roles'];
$product_keys = (array) $settings['product_keys'];
$product_duration = (array) $settings['product_role_duration'];
$role_default_duration = (int) $settings['role_duration_default'];
$rank_levels           = (array) $settings['rank_levels'];
$bmc_rank_defs         = BMC_Ranks::definitions();
$bmc_rank_status       = BMC_Ranks::status();

$bmc_key_options = array(
	'name'   => 'نام محصول (نام ووکامرس)',
	'id'     => 'شناسهٔ محصول (ID)',
	'slug'   => 'نامک / slug',
	'custom' => 'دلخواه (متن دستی)',
	'sku'    => 'کد کالا (SKU)',
);
$products     = array();

if ( function_exists( 'wc_get_products' ) ) {
	$products = wc_get_products(
		array(
			'limit'   => 500,
			'status'  => array( 'publish', 'private', 'draft' ),
			'orderby' => 'title',
			'order'   => 'ASC',
			'return'  => 'objects',
		)
	);
}

BMC_Admin::form_open( 'products' );

BMC_Admin::section_open(
	'محصولات همگام‌شده',
	'محصولاتی که بعد از پرداخت باید در بازی تحویل داده شوند را انتخاب کنید. برای هر محصول می‌توانید «شناسهٔ تحویل» را تعیین کنید؛ پلاگین سمت ماینکرافت با همین شناسه محصول را پیدا می‌کند.'
);

BMC_Admin::row(
	'شناسهٔ پیش‌فرض',
	BMC_Admin::select( 'product_key_default', $settings['product_key_default'], array(
		'name'   => 'نام محصول',
		'id'     => 'شناسهٔ محصول (ID)',
		'slug'   => 'نامک / slug',
		'sku'    => 'کد کالا (SKU)',
	) ),
	'برای محصولاتی که شناسهٔ اختصاصی تعیین نکرده‌اید، همین گزینه استفاده می‌شود. ترتیب تطبیق در پلاگین ماینکرافت: کلید سفارش ← نام ← شناسه ← نامک ← SKU.'
);

BMC_Admin::row(
	'اعتبار پیش‌فرض رنک',
	BMC_Admin::input( 'role_duration_default', $role_default_duration, array( 'type' => 'number', 'min' => 0, 'max' => 36500, 'class' => 'small-text' ) ) . '<span class="bmc-unit">روز</span>',
	'مدت فعال ماندن نقش پس از خرید. عدد <strong>۰</strong> یعنی دائمی. برای هر محصول می‌توانید اعتبار جداگانه تعیین کنید و پس از پایان اعتبار، نقش به‌صورت خودکار (هر ساعت) از کاربر گرفته می‌شود.'
);

BMC_Admin::row(
	'جلوگیری از خرید رنک پایین‌تر',
	BMC_Admin::toggle( 'rank_guard', $settings['rank_guard'], 'کاربری که رنک بالاتر دارد نتواند رنک پایین‌تر بخرد' ),
	'اگر آیتم رنک پایین‌تر در سبد باشد، <strong>پرداخت مسدود می‌شود</strong> و پیام راهنما نمایش داده می‌شود. سطح هر رنک از پلاگین ماینکرافت همگام می‌شود و در همین تب هم قابل تعیین است.'
);

BMC_Admin::row(
	'پنهان‌کردن رنک‌های پایین‌تر',
	BMC_Admin::toggle( 'rank_hide_lower', $settings['rank_hide_lower'], 'رنک پایین‌تر در فروشگاه و صفحهٔ محصول به کاربر نشان داده نشود' ),
	'کاربر دارای رنک سطح بالاتر، محصولات رنک پایین‌تر را در فهرست فروشگاه نمی‌بیند و دکمهٔ خریدشان غیرفعال است.'
);

BMC_Admin::row(
	'بازپس‌گیری نقش‌ها',
	BMC_Admin::toggle( 'revoke_roles_on_refund', $settings['revoke_roles_on_refund'], 'با استرداد یا لغو سفارش، نقش‌های داده‌شده از کاربر گرفته شود' ),
	'نقش‌های محافظت‌شده (مدیر، ویرایشگر، نویسنده، مدیر فروشگاه) هرگز گرفته نمی‌شوند.'
);
?>

<div class="bmc-toolbar">
	<input type="search" class="bmc-input" id="bmcProductSearch" placeholder="جست‌وجوی محصول…" />
	<span class="bmc-count">
		<strong id="bmcSelectedCount"><?php echo esc_html( BMC_Helpers::to_persian_digits( count( $synced ) ) ); ?></strong> محصول انتخاب شده
	</span>
</div>

<?php if ( empty( $products ) ) : ?>
	<p class="bmc-empty">محصولی یافت نشد. ابتدا در ووکامرس محصول بسازید.</p>
<?php else : ?>
	<div class="bmc-product-list" id="bmcProductList">
		<?php foreach ( $products as $product ) : ?>
			<?php
			$pid      = $product->get_id();
			$checked  = in_array( $pid, $synced, true );
			$title    = $product->get_name();
			$price    = wc_price( $product->get_price() );
			$image_id = $product->get_image_id();
			$variations = array();

			if ( $product->is_type( 'variable' ) ) {
				$variations = $product->get_children();
			}
			?>
			<div class="bmc-product<?php echo $checked ? ' is-checked' : ''; ?>" data-title="<?php echo esc_attr( mb_strtolower( $title ) ); ?>">
				<label class="bmc-product__main">
				<span class="bmc-product__check">
					<input type="checkbox" name="sync_products[]" value="<?php echo esc_attr( $pid ); ?>" <?php checked( $checked ); ?> />
				</span>
				<span class="bmc-product__thumb">
					<?php echo $image_id ? wp_get_attachment_image( $image_id, array( 44, 44 ) ) : '<span class="bmc-thumb-fallback">' . bmc_get_icon( 'inventory_2', array( 'size' => 20 ) ) . '</span>'; ?>
				</span>
				<span class="bmc-product__info">
					<strong><?php echo esc_html( $title ); ?></strong>
					<small><?php echo wp_kses_post( $price ); ?> • <?php echo esc_html( $product->get_type() ); ?><?php echo $variations ? ' • ' . esc_html( BMC_Helpers::to_persian_digits( count( $variations ) ) ) . ' variation' : ''; ?></small>
					<code class="bmc-product__key">کلید تطبیق پیش‌فرض: <?php echo esc_html( mb_strtolower( trim( $title ) ) ); ?></code>
				</span>
				</label>
				<span class="bmc-product__key-field">
					<small>شناسهٔ تحویل</small>
					<?php echo BMC_Admin::select( 'product_key_type[' . $pid . ']', isset( $product_keys[ $pid ]['type'] ) ? $product_keys[ $pid ]['type'] : 'name', $bmc_key_options ); ?>
					<?php echo BMC_Admin::input( 'product_key_value[' . $pid . ']', isset( $product_keys[ $pid ]['value'] ) ? $product_keys[ $pid ]['value'] : '', array( 'dir' => 'ltr', 'placeholder' => 'gold_pack_2' ) ); ?>
					<code>نام: <?php echo esc_html( $title ); ?> • شناسه: <?php echo esc_html( BMC_Helpers::to_persian_digits( $pid ) ); ?> • نامک: <?php echo esc_html( $product->get_slug() ); ?><?php echo $product->get_sku() ? ' • SKU: ' . esc_html( $product->get_sku() ) : ''; ?></code>
				</span>
				<span class="bmc-product__role">
					<small>نقش خودکار پس از خرید • سطح رنک</small>
					<?php echo BMC_Admin::role_select( 'product_role[' . $pid . ']', isset( $product_role[ $pid ] ) ? $product_role[ $pid ] : '' ); ?>
					<span class="bmc-product__duration">
						<small>اعتبار (روز)</small>
						<?php echo BMC_Admin::input( 'product_role_duration[' . $pid . ']', isset( $product_duration[ $pid ] ) ? (int) $product_duration[ $pid ] : '', array( 'type' => 'number', 'min' => 0, 'max' => 36500, 'placeholder' => $role_default_duration ? BMC_Helpers::to_persian_digits( $role_default_duration ) : 'دائمی', 'class' => 'bmc-days' ) ); ?>
						<small>سطح</small>
						<?php echo BMC_Admin::input( 'rank_level[' . $pid . ']', isset( $rank_levels[ $pid ] ) ? (int) $rank_levels[ $pid ] : '', array( 'type' => 'number', 'min' => 0, 'max' => 9999, 'placeholder' => BMC_Helpers::to_persian_digits( BMC_Ranks::level_for_product( $pid ) ), 'class' => 'bmc-days' ) ); ?>
					</span>
				</span>
			</div>

			<?php if ( $variations ) : ?>
				<div class="bmc-variations" data-parent="<?php echo esc_attr( $pid ); ?>">
					<?php foreach ( $variations as $variation_id ) : ?>
						<?php
						$variation = wc_get_product( $variation_id );
						if ( ! $variation ) {
							continue;
						}
						$v_checked = in_array( (int) $variation_id, $synced, true );
						$v_name    = $variation->get_name();
						?>
						<div class="bmc-product bmc-product--variation<?php echo $v_checked ? ' is-checked' : ''; ?>" data-title="<?php echo esc_attr( mb_strtolower( $v_name ) ); ?>">
							<label class="bmc-product__main">
							<span class="bmc-product__check">
								<input type="checkbox" name="sync_products[]" value="<?php echo esc_attr( $variation_id ); ?>" <?php checked( $v_checked ); ?> />
							</span>
							<span class="bmc-product__info">
								<strong><?php echo esc_html( $v_name ); ?></strong>
								<code class="bmc-product__key">کلید تطبیق پیش‌فرض: <?php echo esc_html( mb_strtolower( trim( $v_name ) ) ); ?></code>
							</span>
							</label>
							<span class="bmc-product__key-field">
								<small>شناسهٔ تحویل</small>
								<?php echo BMC_Admin::select( 'product_key_type[' . $variation_id . ']', isset( $product_keys[ $variation_id ]['type'] ) ? $product_keys[ $variation_id ]['type'] : 'name', $bmc_key_options ); ?>
								<?php echo BMC_Admin::input( 'product_key_value[' . $variation_id . ']', isset( $product_keys[ $variation_id ]['value'] ) ? $product_keys[ $variation_id ]['value'] : '', array( 'dir' => 'ltr', 'placeholder' => 'gold_pack_2' ) ); ?>
								<code>نامک: <?php echo esc_html( $variation->get_slug() ); ?><?php echo $variation->get_sku() ? ' • SKU: ' . esc_html( $variation->get_sku() ) : ''; ?></code>
							</span>
							<span class="bmc-product__role">
								<small>نقش</small>
								<?php echo BMC_Admin::role_select( 'product_role[' . $variation_id . ']', isset( $product_role[ $variation_id ] ) ? $product_role[ $variation_id ] : '' ); ?>
								<span class="bmc-product__duration">
									<small>اعتبار (روز)</small>
									<?php echo BMC_Admin::input( 'product_role_duration[' . $variation_id . ']', isset( $product_duration[ $variation_id ] ) ? (int) $product_duration[ $variation_id ] : '', array( 'type' => 'number', 'min' => 0, 'max' => 36500, 'placeholder' => $role_default_duration ? BMC_Helpers::to_persian_digits( $role_default_duration ) : 'دائمی', 'class' => 'bmc-days' ) ); ?>
									<small>سطح</small>
									<?php echo BMC_Admin::input( 'rank_level[' . $variation_id . ']', isset( $rank_levels[ $variation_id ] ) ? (int) $rank_levels[ $variation_id ] : '', array( 'type' => 'number', 'min' => 0, 'max' => 9999, 'placeholder' => BMC_Helpers::to_persian_digits( BMC_Ranks::level_for_product( $pid, $variation_id ) ), 'class' => 'bmc-days' ) ); ?>
								</span>
							</span>
						</div>
					<?php endforeach; ?>
				</div>
			<?php endif; ?>
		<?php endforeach; ?>
	</div>
<?php endif; ?>

<?php
BMC_Admin::section_close();

BMC_Admin::section_open(
	'رنک‌های تعریف‌شده در پلاگین ماینکرافت',
	'منبع اصلی تعریف رنک‌ها <code>config.yml</code> پلاگین ماینکرافت است (بخش <code>ranks.list</code>). پلاگین به‌صورت دوره‌ای این تعریف‌ها را به سایت می‌فرستد و سایت بر اساس آن، سطح رنک هر محصول، نقش و مدت اعتبار را می‌شناسد.'
);

echo '<div class="bmc-rank-status">';
printf(
	'<span class="bmc-status-pill">%s تعریف‌های دریافتی: <strong>%s</strong></span>',
	bmc_get_icon( 'cloud_done', array( 'size' => 15 ) ),
	esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_rank_status['definitions'] ) )
);
printf(
	'<span class="bmc-status-pill">%s آخرین همگام‌سازی: <strong>%s</strong></span>',
	bmc_get_icon( 'sync', array( 'size' => 15 ) ),
	$bmc_rank_status['synced_at'] ? esc_html( BMC_Jalali::format( $bmc_rank_status['synced_at'] ) ) : 'هنوز انجام نشده'
);
printf(
	'<span class="bmc-status-pill">%s آخرین گزارش رنک بازیکنان: <strong>%s</strong></span>',
	bmc_get_icon( 'monitoring', array( 'size' => 15 ) ),
	$bmc_rank_status['reported_at'] ? esc_html( BMC_Jalali::format( $bmc_rank_status['reported_at'] ) ) : 'هنوز انجام نشده'
);
echo '</div>';

if ( $bmc_rank_defs ) {
	echo '<table class="bmc-table bmc-table--full"><thead><tr><th>کلید</th><th>نام رنک</th><th>سطح</th><th>نقش</th><th>اعتبار (روز)</th></tr></thead><tbody>';

	foreach ( $bmc_rank_defs as $bmc_def ) {
		printf(
			'<tr><td><code dir="ltr">%1$s</code></td><td>%2$s</td><td>%3$s</td><td><code dir="ltr">%4$s</code></td><td>%5$s</td></tr>',
			esc_html( $bmc_def['key'] ),
			esc_html( '' !== $bmc_def['name'] ? $bmc_def['name'] : '—' ),
			esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_def['level'] ) ),
			esc_html( '' !== $bmc_def['role'] ? $bmc_def['role'] : '—' ),
			$bmc_def['days'] > 0 ? esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_def['days'] ) ) : 'دائمی'
		);
	}

	echo '</tbody></table>';
	echo '<p class="bmc-hint">سطح بزرگ‌تر = رنک بالاتر. کاربری که رنک سطح بالاتر دارد، نمی‌تواند رنک سطح پایین‌تر را بخرد (در سبد هم پرداختش مسدود می‌شود).</p>';
} else {
	echo '<div class="bmc-note">' . bmc_get_icon( 'info', array( 'size' => 16 ) ) . ' هنوز رنکی از سمت ماینکرافت دریافت نشده است. بخش <code>ranks.list</code> را در <code>config.yml</code> پلاگین پر کنید و <code>bmc reload</code> را بزنید؛ یا به‌صورت دستی در فیلد «سطح» هر محصول بالا، عدد تعیین کنید.</div>';
}

BMC_Admin::section_close();

BMC_Admin::form_close();
