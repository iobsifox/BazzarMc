<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$stats    = BMC_Deliveries::stats();
$report   = BMC_Migrate::migration_report();
$recent   = BMC_Deliveries::query( array( 'per_page' => 8, 'paged' => 1 ) );
$logs     = BMC_Logger::recent( 8 );
$integr   = BMC_Auth::detected_integrations();

$checklist = array(
	array(
		'done'  => ! empty( $settings['api_token'] ),
		'label' => 'توکن اتصال ساخته شد',
		'url'   => admin_url( 'admin.php?page=bazzarmc&tab=server' ),
	),
	array(
		'done'  => ! empty( $settings['verify_methods'] ),
		'label' => 'روش تأیید کد اتصال انتخاب شد',
		'url'   => admin_url( 'admin.php?page=bazzarmc&tab=login' ),
	),
	array(
		'done'  => ! empty( $settings['sync_products'] ),
		'label' => 'حداقل یک محصول برای تحویل در بازی انتخاب شد',
		'url'   => admin_url( 'admin.php?page=bazzarmc&tab=products' ),
	),
	array(
		'done'  => (int) $settings['page_link'] > 0,
		'label' => 'صفحهٔ اتصال اکانت ساخته شد',
		'url'   => admin_url( 'admin.php?page=bazzarmc&tab=login' ),
	),
	array(
		'done'  => 'custom' === $settings['checkout_mode'] && BMC_Settings::bool( 'gate_enabled', true ),
		'label' => 'چک‌اوت اختصاصی و گیت اتصال فعال شد',
		'url'   => admin_url( 'admin.php?page=bazzarmc&tab=checkout' ),
	),
	array(
		'done'  => false,
		'label' => 'پلاگین ماینکرافت روی سرور نصب و توکن وارد شد',
		'url'   => admin_url( 'admin.php?page=bazzarmc&tab=tools' ),
	),
);

$done_count = 0;
foreach ( $checklist as $item ) {
	if ( $item['done'] ) {
		$done_count++;
	}
}
?>
<section class="bmc-box bmc-box--hero">
	<div class="bmc-box__body">
		<div class="bmc-hero">
			<div>
				<h2>سلام! <?php bmc_icon( 'waving_hand', array( 'size' => 22 ) ); ?> فروشگاه شما آمادهٔ اتصال به ماینکرافت است.</h2>
				<p>
					راه‌اندازی <strong><?php echo esc_html( BMC_Helpers::to_persian_digits( $done_count ) ); ?> از <?php echo esc_html( BMC_Helpers::to_persian_digits( count( $checklist ) ) ); ?></strong> مرحله کامل شده.
					پلاگین سمت سرور (فایل <code>.jar</code>) را در پوشهٔ <code>plugins</code> سرور ماینکرافت قرار دهید و توکن را در <code>config.yml</code> وارد کنید.
				</p>
			</div>
			<div class="bmc-hero__progress">
				<div class="bmc-progress"><span style="width:<?php echo esc_attr( round( $done_count / max( 1, count( $checklist ) ) * 100 ) ); ?>%"></span></div>
				<small><?php echo esc_html( BMC_Helpers::to_persian_digits( round( $done_count / max( 1, count( $checklist ) ) * 100 ) ) ); ?>٪ آماده</small>
			</div>
		</div>

		<ul class="bmc-checklist">
			<?php foreach ( $checklist as $item ) : ?>
				<li class="<?php echo $item['done'] ? 'is-done' : ''; ?>">
					<span class="bmc-checklist__mark"><?php echo $item['done'] ? bmc_get_icon( 'check', array( 'size' => 14 ) ) : bmc_get_icon( 'radio_button_unchecked', array( 'size' => 14 ) ); ?></span>
					<span><?php echo esc_html( $item['label'] ); ?></span>
					<?php if ( ! $item['done'] ) : ?>
						<a href="<?php echo esc_url( $item['url'] ); ?>">انجام شود ←</a>
					<?php endif; ?>
				</li>
			<?php endforeach; ?>
		</ul>
	</div>
</section>

<div class="bmc-stats">
	<div class="bmc-stat">
		<span class="bmc-stat__value"><?php echo esc_html( BMC_Helpers::to_persian_digits( $stats['pending'] ) ); ?></span>
		<span class="bmc-stat__label">در انتظار تحویل</span>
	</div>
	<div class="bmc-stat">
		<span class="bmc-stat__value"><?php echo esc_html( BMC_Helpers::to_persian_digits( $stats['delivered'] ) ); ?></span>
		<span class="bmc-stat__label">تحویل‌شده</span>
	</div>
	<div class="bmc-stat">
		<span class="bmc-stat__value"><?php echo esc_html( BMC_Helpers::to_persian_digits( $stats['linked_users'] ) ); ?></span>
		<span class="bmc-stat__label">کاربر متصل</span>
	</div>
	<div class="bmc-stat">
		<span class="bmc-stat__value"><?php echo esc_html( BMC_Helpers::to_persian_digits( $stats['expired'] ) ); ?></span>
		<span class="bmc-stat__label">منقضی</span>
	</div>
</div>

<div class="bmc-cols">
	<section class="bmc-box">
		<div class="bmc-box__head">
			<h2>آخرین تحویل‌ها</h2>
			<a class="button button-small" href="<?php echo esc_url( admin_url( 'admin.php?page=bazzarmc&tab=deliveries' ) ); ?>">همه</a>
		</div>
		<div class="bmc-box__body bmc-box__body--flush">
			<?php if ( empty( $recent['items'] ) ) : ?>
				<p class="bmc-empty">هنوز تحویلی ثبت نشده است.</p>
			<?php else : ?>
				<table class="bmc-table">
					<thead>
						<tr><th>#</th><th>سفارش</th><th>بازیکن</th><th>آیتم</th><th>وضعیت</th></tr>
					</thead>
					<tbody>
						<?php foreach ( $recent['items'] as $row ) : ?>
							<tr>
								<td><?php echo esc_html( BMC_Helpers::to_persian_digits( $row->id ) ); ?></td>
								<td>
									<?php if ( $row->order_id ) : ?>
										<a href="<?php echo esc_url( admin_url( 'post.php?post=' . (int) $row->order_id . '&action=edit' ) ); ?>">#<?php echo esc_html( BMC_Helpers::to_persian_digits( $row->order_id ) ); ?></a>
									<?php else : ?>—<?php endif; ?>
								</td>
								<td class="bmc-mono"><?php echo esc_html( $row->player ); ?></td>
								<td><?php echo esc_html( $row->item ); ?> ×<?php echo esc_html( BMC_Helpers::to_persian_digits( $row->amount ) ); ?></td>
								<td><span class="bmc-pill <?php echo esc_attr( BMC_Deliveries::status_class( $row->status ) ); ?>"><?php echo esc_html( BMC_Deliveries::status_label( $row->status ) ); ?></span></td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>
			<?php endif; ?>
		</div>
	</section>

	<section class="bmc-box">
		<div class="bmc-box__head">
			<h2>رویدادهای اخیر</h2>
			<button type="button" class="button button-small bmc-action" data-do="clear_logs">پاک‌سازی لاگ</button>
		</div>
		<div class="bmc-box__body">
			<?php if ( empty( $logs ) ) : ?>
				<p class="bmc-empty">رویدادی ثبت نشده است.</p>
			<?php else : ?>
				<ul class="bmc-loglist">
					<?php foreach ( $logs as $log ) : ?>
						<li class="bmc-log bmc-log--<?php echo esc_attr( $log->level ); ?>">
							<span class="bmc-log__time"><?php echo esc_html( BMC_Jalali::format( $log->created_at ) ); ?></span>
							<span class="bmc-log__channel"><?php echo esc_html( $log->channel ); ?></span>
							<span class="bmc-log__msg"><?php echo esc_html( $log->message ); ?></span>
						</li>
					<?php endforeach; ?>
				</ul>
			<?php endif; ?>
		</div>
	</section>
</div>

<?php if ( $integr || $report['legacy_plugin'] || $report['users'] ) : ?>
	<section class="bmc-box">
		<div class="bmc-box__head"><h2>سازگاری‌های شناسایی‌شده</h2></div>
		<div class="bmc-box__body">
			<?php if ( $integr ) : ?>
				<p>
					افزونه‌های شناسایی‌شده (منبع شمارهٔ موبایل کاربران):
					<strong><?php echo esc_html( implode( '، ', array_keys( $integr ) ) ); ?></strong>
					— شمارهٔ موبایل کاربران از همین افزونه‌ها خوانده می‌شود.
				</p>
			<?php endif; ?>

			<?php if ( $report['legacy_plugin'] || $report['users'] || $report['deliveries'] ) : ?>
				<p>
					داده‌های نسخهٔ قدیمی BazzarMc:
					<?php echo esc_html( BMC_Helpers::to_persian_digits( $report['users'] ) ); ?> کاربر متصل،
					<?php echo esc_html( BMC_Helpers::to_persian_digits( $report['deliveries'] ) ); ?> تحویل.
					<a href="<?php echo esc_url( admin_url( 'admin.php?page=bazzarmc&tab=tools' ) ); ?>">مهاجرت از بخش ابزارها</a>
				</p>
			<?php endif; ?>
		</div>
	</section>
<?php endif; ?>
