<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$filter_status = isset( $_GET['status'] ) ? sanitize_text_field( wp_unslash( $_GET['status'] ) ) : '';
$filter_search = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : '';
$filter_order  = isset( $_GET['order_id'] ) ? (int) $_GET['order_id'] : 0;
$paged         = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1;

$result = BMC_Deliveries::query(
	array(
		'status'   => $filter_status,
		'search'   => $filter_search,
		'order_id' => $filter_order,
		'paged'    => $paged,
		'per_page' => 25,
	)
);

$stats = BMC_Deliveries::stats();

$base_url = admin_url( 'admin.php?page=bazzarmc&tab=deliveries' );

$status_tabs = array(
	''  => 'همه',
	'0' => 'در انتظار',
	'1' => 'تحویل‌شده',
	'2' => 'منقضی',
	'3' => 'لغوشده',
);
?>
<section class="bmc-box">
	<div class="bmc-box__head">
		<h2>صف تحویل آیتم‌ها</h2>
		<div class="bmc-inline">
			<button type="button" class="button bmc-action" data-do="run_cron">اجرای نگهداری</button>
			<a class="button" href="<?php echo esc_url( wp_nonce_url( add_query_arg( 'bmc_export', '1', $base_url ), 'bmc_export', 'bmc_nonce' ) ); ?>">خروجی CSV</a>
		</div>
	</div>

	<div class="bmc-box__body">
		<ul class="bmc-filters">
			<?php foreach ( $status_tabs as $key => $label ) : ?>
				<li>
					<a class="<?php echo (string) $filter_status === (string) $key ? 'is-active' : ''; ?>"
						href="<?php echo esc_url( add_query_arg( 'status', $key, $base_url ) ); ?>">
						<?php echo esc_html( $label ); ?>
					</a>
				</li>
			<?php endforeach; ?>
		</ul>

		<form method="get" class="bmc-toolbar">
			<input type="hidden" name="page" value="bazzarmc" />
			<input type="hidden" name="tab" value="deliveries" />
			<input type="search" class="bmc-input" name="s" value="<?php echo esc_attr( $filter_search ); ?>" placeholder="جست‌وجوی بازیکن، آیتم یا شمارهٔ سفارش…" />
			<input type="number" class="bmc-input bmc-input--sm" name="order_id" value="<?php echo esc_attr( $filter_order ? $filter_order : '' ); ?>" placeholder="شمارهٔ سفارش" />
			<button type="submit" class="button button-primary">اعمال فیلتر</button>
		</form>

		<?php if ( empty( $result['items'] ) ) : ?>
			<p class="bmc-empty">موردی یافت نشد.</p>
		<?php else : ?>
			<table class="bmc-table bmc-table--full">
				<thead>
					<tr>
						<th>#</th>
						<th>سفارش</th>
						<th>بازیکن</th>
						<th>آیتم</th>
						<th>تعداد</th>
						<th>ثبت</th>
						<th>وضعیت</th>
						<th>عملیات</th>
					</tr>
				</thead>
				<tbody>
					<?php foreach ( $result['items'] as $row ) : ?>
						<tr data-id="<?php echo esc_attr( $row->id ); ?>">
							<td><?php echo esc_html( BMC_Helpers::to_persian_digits( $row->id ) ); ?></td>
							<td>
								<?php if ( $row->order_id ) : ?>
									<a href="<?php echo esc_url( admin_url( 'post.php?post=' . (int) $row->order_id . '&action=edit' ) ); ?>">#<?php echo esc_html( BMC_Helpers::to_persian_digits( $row->order_id ) ); ?></a>
								<?php else : ?>—<?php endif; ?>
							</td>
							<td class="bmc-mono">
								<span class="bmc-player-cell">
									<img src="<?php echo esc_url( BMC_Helpers::mc_head( $row->player, 24 ) ); ?>" width="24" height="24" alt="" />
									<?php echo esc_html( $row->player ); ?>
								</span>
							</td>
							<td>
								<?php echo esc_html( $row->item ); ?>
								<?php if ( $row->product_id ) : ?>
									<small class="bmc-dim">(ID: <?php echo esc_html( BMC_Helpers::to_persian_digits( $row->product_id ) ); ?>)</small>
								<?php endif; ?>
							</td>
							<td><?php echo esc_html( BMC_Helpers::to_persian_digits( $row->amount ) ); ?></td>
							<td class="bmc-dim"><?php echo esc_html( BMC_Jalali::format( $row->created_at ) ); ?></td>
							<td>
								<span class="bmc-pill <?php echo esc_attr( BMC_Deliveries::status_class( $row->status ) ); ?>">
									<?php echo esc_html( BMC_Deliveries::status_label( $row->status ) ); ?>
								</span>
							</td>
							<td>
								<div class="bmc-row-actions">
									<?php if ( (int) $row->status !== BMC_Deliveries::STATUS_DELIVERED ) : ?>
										<button type="button" class="button button-small bmc-delivery-action" data-do="delivered" data-id="<?php echo esc_attr( $row->id ); ?>">تحویل شد</button>
									<?php else : ?>
										<button type="button" class="button button-small bmc-delivery-action" data-do="pending" data-id="<?php echo esc_attr( $row->id ); ?>">بازگشت به صف</button>
									<?php endif; ?>
									<button type="button" class="button button-small button-link-delete bmc-delivery-action" data-do="delete" data-id="<?php echo esc_attr( $row->id ); ?>">حذف</button>
								</div>
							</td>
						</tr>
					<?php endforeach; ?>
				</tbody>
			</table>

			<?php if ( $result['pages'] > 1 ) : ?>
				<div class="bmc-pagination">
					<?php
					echo wp_kses_post(
						paginate_links(
							array(
								'base'      => add_query_arg( 'paged', '%#%' ),
								'format'    => '',
								'current'   => $result['paged'],
								'total'     => $result['pages'],
								'prev_text' => '→',
								'next_text' => '←',
							)
						)
					);
					?>
				</div>
			<?php endif; ?>
		<?php endif; ?>
	</div>
</section>

<div class="bmc-stats">
	<div class="bmc-stat"><span class="bmc-stat__value"><?php echo esc_html( BMC_Helpers::to_persian_digits( $stats['total'] ) ); ?></span><span class="bmc-stat__label">کل رکوردها</span></div>
	<div class="bmc-stat"><span class="bmc-stat__value"><?php echo esc_html( BMC_Helpers::to_persian_digits( $stats['pending'] ) ); ?></span><span class="bmc-stat__label">در انتظار</span></div>
	<div class="bmc-stat"><span class="bmc-stat__value"><?php echo esc_html( BMC_Helpers::to_persian_digits( $stats['delivered'] ) ); ?></span><span class="bmc-stat__label">تحویل‌شده</span></div>
	<div class="bmc-stat"><span class="bmc-stat__value"><?php echo esc_html( BMC_Helpers::to_persian_digits( $stats['expired'] ) ); ?></span><span class="bmc-stat__label">منقضی</span></div>
</div>
