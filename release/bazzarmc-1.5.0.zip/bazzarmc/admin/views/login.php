<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$integrations = BMC_Auth::detected_integrations();

BMC_Admin::form_open( 'login' );

BMC_Admin::section_open(
	'روش‌های تأیید برای اتصال اکانت',
	'این کدها فقط برای <strong>لینک‌کردن حساب سایت به اکانت ماینکرافت</strong> استفاده می‌شوند (ورود به سایت بر عهدهٔ افزونهٔ ورودِ خودِ سایت است).'
);

$bmc_verify_methods = (array) $settings['verify_methods'];
?>
<div class="bmc-checklist bmc-checklist--inline">
	<label class="bmc-check"><input type="checkbox" name="verify_methods[]" value="dashboard" <?php checked( in_array( 'dashboard', $bmc_verify_methods, true ) ); ?> /> <span><?php echo bmc_get_icon( 'desktop_windows', array( 'size' => 15 ) ); ?> داشبورد / پنل کاربری (رایگان)</span></label>
	<label class="bmc-check"><input type="checkbox" name="verify_methods[]" value="email" <?php checked( in_array( 'email', $bmc_verify_methods, true ) ); ?> /> <span><?php echo bmc_get_icon( 'mail', array( 'size' => 15 ) ); ?> ایمیل</span></label>
</div>
<p class="bmc-hint">حداقل یک روش باید فعال باشد. روش «داشبورد» همیشه رایگان است و کد در همان صفحهٔ اتصال (و برای مدیر در ویجت پیشخوان) نمایش داده می‌شود.</p>
<?php

BMC_Admin::row(
	'روش پیش‌فرض',
	BMC_Admin::select(
		'verify_default',
		$settings['verify_default'],
		array(
			'dashboard' => 'داشبورد سایت',
			'email'     => 'ایمیل',
		)
	),
	'اگر روش پیش‌فرض فعال نباشد، افزونه به اولین روش فعال برمی‌گردد.'
);

BMC_Admin::row( 'ویجت پیشخوان مدیر', BMC_Admin::toggle( 'otp_dashboard_widget', $settings['otp_dashboard_widget'], 'کدهای فعال در پیشخوان مدیر نمایش داده شود' ), 'برای پشتیبانی سریع کاربران بدون هیچ هزینهٔ ارسال.' );
BMC_Admin::row( 'جعبهٔ کد در پنل کاربری', BMC_Admin::toggle( 'otp_dashboard_box', $settings['otp_dashboard_box'], 'کد در کارت حساب کاربری هم نمایش داده شود' ), 'خودِ کاربر کد را در همان صفحه می‌بیند و نیازی به ایمیل نیست.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'تنظیمات کد تأیید', 'این مقدارها برای کد لینک‌کردن اکانت (روش داشبورد و ایمیل) استفاده می‌شوند.' );

BMC_Admin::row( 'طول کد', '<input type="number" class="bmc-input bmc-input--sm" name="otp_length" min="4" max="8" value="' . esc_attr( (int) $settings['otp_length'] ) . '" />', 'بین ۴ تا ۸ رقم.' );
BMC_Admin::row( 'اعتبار کد (ثانیه)', '<input type="number" class="bmc-input bmc-input--sm" name="otp_ttl" min="30" max="900" value="' . esc_attr( (int) $settings['otp_ttl'] ) . '" />', 'پیش‌فرض ۱۲۰ ثانیه (۲ دقیقه).' );
BMC_Admin::row( 'فاصلهٔ حداقلی بین دو درخواست (ثانیه)', '<input type="number" class="bmc-input bmc-input--sm" name="otp_rate_limit" min="10" max="3600" value="' . esc_attr( (int) $settings['otp_rate_limit'] ) . '" />', 'محدودیت نرخ برای جلوگیری از درخواست پشت‌سرهم.' );
BMC_Admin::row( 'حداکثر تلاش ناموفق', '<input type="number" class="bmc-input bmc-input--sm" name="otp_max_attempts" min="1" max="20" value="' . esc_attr( (int) $settings['otp_max_attempts'] ) . '" />', 'پس از این تعداد تلاش ناموفق، کد باطل می‌شود.' );
BMC_Admin::row( 'حداکثر ارسال مجدد', '<input type="number" class="bmc-input bmc-input--sm" name="otp_resend_limit" min="1" max="20" value="' . esc_attr( (int) $settings['otp_resend_limit'] ) . '" />', 'تعداد مجاز «ارسال مجدد» برای هر کد.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'کانال ایمیل', 'کد تأیید و اطلاع‌رسانی‌ها با تابع <code>wp_mail()</code> وردپرس ارسال می‌شوند.' );

BMC_Admin::row( 'ارسال ایمیل', BMC_Admin::toggle( 'email_enabled', $settings['email_enabled'], 'کانال ایمیل فعال باشد' ), 'اگر خاموش باشد، فقط روش «داشبورد» در دسترس است.' );
BMC_Admin::row( 'موضوع ایمیل کد', '<input class="bmc-input" type="text" name="email_tpl_subject" value="' . esc_attr( (string) $settings['email_tpl_subject'] ) . '" />', 'متغیرها: <code>{site}</code> <code>{code}</code> <code>{player}</code> <code>{minutes}</code>' );
BMC_Admin::row( 'متن ایمیل کد', BMC_Admin::textarea( 'email_tpl_body', (string) $settings['email_tpl_body'], 6 ), 'متغیرها: <code>{site}</code> <code>{code}</code> <code>{player}</code> <code>{minutes}</code> — HTML مجاز است.' );

BMC_Admin::row(
	'تست ارسال ایمیل',
	'<div class="bmc-inline">'
		. '<input class="bmc-input" type="email" id="bmcTestEmail" dir="ltr" placeholder="you@example.com" style="max-width:240px" />'
		. '<button type="button" class="button button-secondary bmc-action" data-do="test_email" data-extra="to:#bmcTestEmail">'
		. bmc_get_icon( 'mark_email_unread', array( 'size' => 16 ) )
		. '<span>ارسال ایمیل تست</span></button>'
		. '</div>',
	'یک کد نمونه به این ایمیل ارسال می‌شود تا مسیر ارسال (SMTP هاست) بررسی شود.'
);

BMC_Admin::section_close();

BMC_Admin::section_open( 'شمارهٔ موبایل کاربران', 'شمارهٔ موبایل فقط برای <strong>تکمیل خودکار فیلد تلفن در چک‌اوت</strong> و نمایش در کارت حساب کاربری خوانده می‌شود.' );

if ( $integrations ) {
	echo '<div class="bmc-note bmc-note--ok">' . bmc_get_icon( 'check_circle', array( 'size' => 16 ) ) . ' افزونه‌های شناسایی‌شده: <strong>' . esc_html( implode( '، ', array_keys( $integrations ) ) ) . '</strong></div>';
} else {
	echo '<div class="bmc-note">' . bmc_get_icon( 'info', array( 'size' => 16 ) ) . ' افزونهٔ دیگری شناسایی نشد؛ شماره از متای <code>billing_phone</code> ووکامرس خوانده می‌شود.</div>';
}

BMC_Admin::row(
	'همگام‌سازی شماره با EZ-Login',
	BMC_Admin::toggle( 'ezlogin_sync_phone', $settings['ezlogin_sync_phone'], 'شمارهٔ یافت‌شده در متای <code>ez_phone</code> هم ذخیره شود' ),
	'بدون دست‌کاری افزونهٔ EZ-Login؛ فقط در صورت فعال بودن آن افزونه.'
);

BMC_Admin::row(
	'کلیدهای متای شمارهٔ موبایل',
	'<input class="bmc-input" type="text" name="mobile_meta_keys" value="' . esc_attr( implode( ',', (array) $settings['mobile_meta_keys'] ) ) . '" dir="ltr" />'
		. '<div class="bmc-inline" style="margin-top:8px">'
		. '<button type="button" class="button bmc-action" data-do="detect_mobile_keys" data-target="#bmcDetectedKeys">شناسایی خودکار کلیدها</button>'
		. '<button type="button" class="button bmc-action" data-do="sync_mobiles">یکسان‌سازی شمارهٔ همهٔ کاربران</button>'
		. '</div>'
		. '<div id="bmcDetectedKeys" class="bmc-detect"></div>',
	'با کاما جدا کنید. کلیدهای شناخته‌شده به‌صورت خودکار هم بررسی می‌شوند: <code>digits_number</code>، <code>easylogin_mobile</code>، <code>bilacell_mobile</code>، <code>wp_sms_mobile</code>، <code>darvaze_mobile</code>.'
);

BMC_Admin::section_close();

BMC_Admin::section_open( 'پنل حساب کاربری (حساب من)', 'کارت اختصاصی BazzarMc جای متن پیش‌فرض ووکامرس در داشبورد «حساب کاربری» را می‌گیرد و بقیهٔ بخش‌های داشبورد دست‌نخورده می‌مانند.' );

BMC_Admin::row(
	'کارت حساب کاربری',
	BMC_Admin::toggle( 'myaccount_card', $settings['myaccount_card'], 'نمایش کارت BazzarMc در داشبورد حساب کاربری ووکامرس' ),
	'این کارت نام واقعی کاربر، جعبهٔ اکانت ماینکرافت (با دکمهٔ اتصال در صورت متصل نبودن)، رنک‌های خریداری‌شده با زمان باقی‌مانده و میان‌بر تیکت پشتیبانی را نشان می‌دهد.'
);

BMC_Admin::section_close();

BMC_Admin::section_open( 'فرم اتصال اکانت (فرم دلخواه)', 'ظاهر و متن‌های جعبهٔ اتصال اکانت ماینکرافت. هر ویجت المنتور یا شورت‌کد می‌تواند این مقدارها را برای خودش override کند.' );

BMC_Admin::row( 'پهنای جعبه', BMC_Admin::select( 'link_width', $settings['link_width'], array( 'narrow' => 'باریک (پیشنهادی)', 'wide' => 'پهن' ) ) );
BMC_Admin::row( 'اندازهٔ آواتار', '<input type="number" class="bmc-input bmc-input--sm" name="link_avatar_size" min="32" max="192" value="' . esc_attr( (int) $settings['link_avatar_size'] ) . '" />', 'بین ۳۲ تا ۱۹۲ پیکسل.' );
BMC_Admin::row( 'راهنمای سه‌مرحله‌ای', BMC_Admin::toggle( 'link_show_steps', $settings['link_show_steps'], 'نمایش سه گام بالای فرم' ) );
BMC_Admin::row( 'متن مرحلهٔ ۱', BMC_Admin::textarea( 'link_step_1', (string) $settings['link_step_1'], 2 ) );
BMC_Admin::row( 'متن مرحلهٔ ۲', BMC_Admin::textarea( 'link_step_2', (string) $settings['link_step_2'], 2 ) );
BMC_Admin::row( 'متن مرحلهٔ ۳', BMC_Admin::textarea( 'link_step_3', (string) $settings['link_step_3'], 2 ) );
BMC_Admin::row( 'برچسب فیلد نام کاربری', BMC_Admin::input( 'link_player_label', $settings['link_player_label'] ) );
BMC_Admin::row( 'placeholder نام کاربری', BMC_Admin::input( 'link_player_placeholder', $settings['link_player_placeholder'] ) );
BMC_Admin::row( 'متن دکمهٔ ساخت کد', BMC_Admin::input( 'link_submit_text', $settings['link_submit_text'] ) );
BMC_Admin::row( 'متن بالای کد', BMC_Admin::textarea( 'link_code_hint', (string) $settings['link_code_hint'], 2 ) );
BMC_Admin::row( 'متن دکمهٔ کپی', BMC_Admin::input( 'link_copy_text', $settings['link_copy_text'] ) );
BMC_Admin::row( 'متن دکمهٔ کد جدید', BMC_Admin::input( 'link_regen_text', $settings['link_regen_text'] ) );
BMC_Admin::row( 'کارت کد تأیید', BMC_Admin::toggle( 'link_show_otp_card', $settings['link_show_otp_card'], 'کارت «روش جایگزین: کد تأیید» نمایش داده شود' ) );
BMC_Admin::row( 'عنوان کارت کد تأیید', BMC_Admin::input( 'link_otp_title', $settings['link_otp_title'] ) );
BMC_Admin::row( 'نمایش UUID', BMC_Admin::toggle( 'link_show_uuid', $settings['link_show_uuid'], 'در وضعیت «متصل است» UUID اکانت نمایش داده شود' ) );
BMC_Admin::row( 'نمایش تاریخ اتصال', BMC_Admin::toggle( 'link_show_linked_at', $settings['link_show_linked_at'], 'تاریخ شمسی اتصال نمایش داده شود' ) );
BMC_Admin::row( 'دکمهٔ فروشگاه', BMC_Admin::toggle( 'link_show_shop_button', $settings['link_show_shop_button'], 'در وضعیت متصل، دکمهٔ «رفتن به فروشگاه» نمایش داده شود' ) );
BMC_Admin::row( 'دکمهٔ قطع اتصال', BMC_Admin::toggle( 'link_show_unlink', $settings['link_show_unlink'], 'کاربر بتواند اتصال را قطع کند' ) );
BMC_Admin::row( 'عنوان کارت ورود', BMC_Admin::input( 'link_login_title', $settings['link_login_title'] ), 'برای کاربری که وارد سایت نشده است.' );
BMC_Admin::row( 'متن کارت ورود', BMC_Admin::textarea( 'link_login_body', (string) $settings['link_login_body'], 3 ) );
BMC_Admin::row( 'متن دکمهٔ ورود', BMC_Admin::input( 'link_login_button', $settings['link_login_button'] ) );

BMC_Admin::section_close();

BMC_Admin::section_open( 'صفحه‌های افزونه' );

BMC_Admin::row( 'صفحهٔ اتصال اکانت', BMC_Admin::page_select( 'page_link', (int) $settings['page_link'] ), 'شورت‌کد: <code>[bazzarmc]</code>' );
BMC_Admin::row( 'صفحهٔ سبد خرید', BMC_Admin::page_select( 'page_cart', (int) $settings['page_cart'] ), 'شورت‌کد: <code>[bazzarmc_cart]</code>' );
BMC_Admin::row( 'صفحهٔ پرداخت', BMC_Admin::page_select( 'page_checkout', (int) $settings['page_checkout'] ), 'شورت‌کد: <code>[bazzarmc_checkout]</code>' );

echo '<div class="bmc-inline" style="margin-top:10px"><button type="button" class="button bmc-action" data-do="create_pages">ساخت خودکار صفحه‌ها</button></div>';

BMC_Admin::section_close();

BMC_Admin::form_close();
