<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_atts      = isset( $bmc_atts ) ? (array) $bmc_atts : array();
$bmc_cfg       = BMC_Link::form_config( $bmc_atts );
$bmc_logged_in = is_user_logged_in();
$bmc_user_id   = get_current_user_id();
$bmc_linked    = $bmc_logged_in && BMC_Link::is_linked( $bmc_user_id );
$bmc_player    = $bmc_logged_in ? BMC_Link::get_linked_player( $bmc_user_id ) : '';
$bmc_active    = $bmc_logged_in && ! $bmc_linked ? BMC_Link::get_active_code( $bmc_user_id ) : null;
$bmc_uuid      = $bmc_logged_in ? BMC_Link::get_linked_uuid( $bmc_user_id ) : '';
$bmc_linked_at = $bmc_logged_in ? (int) get_user_meta( $bmc_user_id, BMC_Link::META_LINKED_AT, true ) : 0;
$bmc_theme     = 'light' === $bmc_cfg['theme'] ? ' bmc-theme-light' : '';
$bmc_width     = 'wide' === $bmc_cfg['width'] ? 'bmc-container--wide' : 'bmc-container--narrow';
$bmc_size      = (int) $bmc_cfg['avatar_size'];
$bmc_steps     = array_filter( array( $bmc_cfg['step_1'], $bmc_cfg['step_2'], $bmc_cfg['step_3'] ) );
$bmc_otp_ready = BMC_Settings::mc_request_enabled() && ( BMC_Settings::bool( 'email_enabled', true ) || BMC_Settings::verify_enabled( 'dashboard' ) );
?>
<div class="bmc-wrap<?php echo esc_attr( $bmc_theme ); ?> bmc-linkbox" id="bmcLinkBox" data-linked="<?php echo $bmc_linked ? '1' : '0'; ?>"
	style="--bmc-accent:<?php echo esc_attr( $bmc_cfg['accent'] ); ?>">
	<div class="bmc-container <?php echo esc_attr( $bmc_width ); ?>">

		<div class="bmc-head bmc-card__head" style="border:0;padding:0;margin-bottom:14px">
			<div>
				<span class="bmc-kicker">
					<?php bmc_icon( 'link', array( 'size' => 14 ) ); ?>
					<?php echo esc_html( $bmc_cfg['server'] ); ?>
				</span>
				<h2 class="bmc-title"><?php echo esc_html( $bmc_cfg['title'] ); ?></h2>
			</div>
		</div>

		<?php if ( ! $bmc_logged_in ) : ?>

			<div class="bmc-card bmc-card--center">
				<div class="bmc-avatar bmc-avatar--lg" style="margin:0 auto 16px;width:<?php echo esc_attr( $bmc_size ); ?>px;height:<?php echo esc_attr( $bmc_size ); ?>px">
					<img src="<?php echo esc_url( BMC_Helpers::mc_head( 'MHF_Question', $bmc_size ) ); ?>" alt="" />
				</div>
				<h3 class="bmc-title" style="font-size:19px"><?php echo esc_html( $bmc_cfg['login_title'] ); ?></h3>
				<p class="bmc-subtitle"><?php echo esc_html( $bmc_cfg['login_body'] ); ?></p>
				<div class="bmc-gate__actions">
					<a class="bmc-btn" href="<?php echo esc_url( BMC_Auth::login_url() ); ?>"><?php echo esc_html( $bmc_cfg['login_button'] ); ?></a>
				</div>
			</div>

		<?php elseif ( $bmc_linked ) : ?>

			<div class="bmc-card bmc-fade" id="bmcLinkedCard">
				<div class="bmc-status">
					<div class="bmc-avatar bmc-avatar--lg" style="width:<?php echo esc_attr( $bmc_size ); ?>px;height:<?php echo esc_attr( $bmc_size ); ?>px">
						<img src="<?php echo esc_url( BMC_Helpers::mc_head( $bmc_player, $bmc_size ) ); ?>" alt="<?php echo esc_attr( $bmc_player ); ?>" />
					</div>
					<div style="flex:1;min-width:200px">
						<span class="bmc-badge bmc-badge--ok"><?php bmc_icon( 'check', array( 'size' => 14 ) ); ?> متصل است</span>
						<h3 class="bmc-player-name"><?php echo esc_html( $bmc_player ); ?></h3>
						<ul class="bmc-meta-list">
							<?php if ( $bmc_cfg['show_linked_at'] && $bmc_linked_at ) : ?>
								<li><?php bmc_icon( 'calendar_month', array( 'size' => 15 ) ); ?> تاریخ اتصال: <?php echo esc_html( BMC_Jalali::format( $bmc_linked_at, false ) ); ?></li>
							<?php endif; ?>
							<?php if ( $bmc_cfg['show_uuid'] && $bmc_uuid ) : ?>
								<li style="direction:ltr;justify-content:flex-end;font-family:monospace;font-size:11px">UUID: <?php echo esc_html( $bmc_uuid ); ?></li>
							<?php endif; ?>
							<li><?php bmc_icon( 'sports_esports', array( 'size' => 15 ) ); ?> آیتم‌های خریداری‌شده در اولین ورود به سرور تحویل داده می‌شود.</li>
						</ul>
					</div>
				</div>

				<div class="bmc-alert bmc-alert--ok" style="margin-top:18px;margin-bottom:0">
					<span class="bmc-alert__icon"><?php bmc_icon( 'shopping_cart', array( 'size' => 18 ) ); ?></span>
					<div>حساب شما آمادهٔ خرید است. اکنون می‌توانید وارد صفحهٔ خرید شوید و پرداخت را انجام دهید.</div>
				</div>

				<div class="bmc-code-actions" style="margin-top:18px">
					<?php if ( $bmc_cfg['show_shop_button'] && function_exists( 'wc_get_page_permalink' ) ) : ?>
						<a class="bmc-btn" href="<?php echo esc_url( wc_get_page_permalink( 'shop' ) ); ?>">رفتن به فروشگاه</a>
					<?php endif; ?>
					<?php if ( $bmc_cfg['show_unlink'] ) : ?>
						<button type="button" class="bmc-btn bmc-btn--danger" id="bmcUnlinkBtn">قطع اتصال</button>
					<?php endif; ?>
				</div>
			</div>

		<?php else : ?>

			<div class="bmc-card">
				<?php if ( $bmc_cfg['steps_on'] && $bmc_steps ) : ?>
					<div class="bmc-steps">
						<?php $bmc_step_num = 1; ?>
						<?php foreach ( $bmc_steps as $bmc_step_text ) : ?>
							<div class="bmc-step"><strong><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_step_num ) ); ?>.</strong> <?php echo esc_html( $bmc_step_text ); ?></div>
							<?php $bmc_step_num++; ?>
						<?php endforeach; ?>
					</div>
				<?php endif; ?>

				<div id="bmcLinkAlert"></div>

				<form id="bmcLinkForm" autocomplete="off">
					<div class="bmc-field">
						<label class="bmc-label" for="bmcPlayerInput">
							<?php echo esc_html( $bmc_cfg['player_label'] ); ?> <span class="req">*</span>
						</label>
						<div class="bmc-link-player">
							<div class="bmc-avatar bmc-avatar--sm" style="width:48px;height:48px">
								<img id="bmcHeadPreview" src="<?php echo esc_url( BMC_Helpers::mc_head( 'MHF_Question', 48 ) ); ?>" alt="" />
							</div>
							<input class="bmc-input" id="bmcPlayerInput" name="player" type="text" dir="ltr"
								placeholder="<?php echo esc_attr( $bmc_cfg['player_placeholder'] ); ?>" maxlength="16"
								style="text-align:left;font-family:Consolas,monospace;letter-spacing:1px" />
						</div>
						<p class="bmc-hint">
							<?php if ( 'premium' === $bmc_cfg['policy'] ) : ?>
								فقط نام‌های کاربری اصلی (پرمیوم) موجانگ پذیرفته می‌شود.
							<?php else : ?>
								همهٔ نام‌های کاربری (پرمیوم و کرک) پذیرفته می‌شود.
							<?php endif; ?>
						</p>
					</div>

					<button type="submit" class="bmc-btn bmc-btn--block" id="bmcGenerateBtn">
						<span class="bmc-spin"></span>
						<span><?php echo esc_html( $bmc_cfg['submit_text'] ); ?></span>
					</button>
				</form>

				<div id="bmcCodePanel" class="bmc-code-panel<?php echo $bmc_active ? '' : ' bmc-hidden'; ?>">
					<p class="bmc-subtitle" style="margin:6px 0 14px"><?php echo esc_html( $bmc_cfg['code_hint'] ); ?></p>

					<div class="bmc-command">
						<span id="bmcCommandText"><code><?php echo esc_html( $bmc_active ? str_replace( '{code}', ( $bmc_active['code_plain'] ? $bmc_active['code_plain'] : 'CODE' ), $bmc_cfg['command_hint'] ) : $bmc_cfg['command_hint'] ); ?></code></span>
					</div>

					<div class="bmc-code" id="bmcCodeValue" style="margin-top:16px">
						<span id="bmcCodeText"><?php echo $bmc_active ? esc_html( $bmc_active['code_plain'] ? $bmc_active['code_plain'] : 'کد فعال' ) : ''; ?></span>
					</div>

					<div class="bmc-code-actions">
						<button type="button" class="bmc-btn bmc-btn--ghost" id="bmcCopyBtn"><?php bmc_icon( 'content_paste', array( 'size' => 16 ) ); ?> <?php echo esc_html( $bmc_cfg['copy_text'] ); ?></button>
						<button type="button" class="bmc-btn bmc-btn--ghost" id="bmcRegenerateBtn"><?php bmc_icon( 'sync', array( 'size' => 16 ) ); ?> <?php echo esc_html( $bmc_cfg['regen_text'] ); ?></button>
					</div>

					<div class="bmc-timer" id="bmcTimer">
						<?php bmc_icon( 'timer', array( 'size' => 15 ) ); ?> <span>اعتبار کد:</span> <strong id="bmcTimerValue">00:00</strong>
					</div>

					<div class="bmc-progress"><span id="bmcProgressBar"></span></div>

					<p class="bmc-hint" style="margin-top:14px">
						به محض واردکردن کد در بازی، این صفحه به‌صورت خودکار به وضعیت «متصل شد» تغییر می‌کند.
					</p>
				</div>
			</div>

			<?php if ( $bmc_cfg['otp_card_on'] && $bmc_otp_ready ) : ?>
				<div class="bmc-card">
					<div class="bmc-card__head" style="margin-bottom:12px">
						<h3 class="bmc-card__title"><span class="bmc-dot"></span> <?php echo esc_html( $bmc_cfg['otp_title'] ); ?></h3>
					</div>
					<p class="bmc-subtitle" style="font-size:13px">
						اگر ترجیح می‌دهید، کد تأیید را روی ایمیل ثبت‌شده در حساب خود دریافت کنید (یا همان‌جا در داشبورد ببینید) و آن را در بازی وارد کنید.
					</p>

					<?php $bmc_dashbox = BMC_Verify::panel_box(); ?>
					<?php if ( $bmc_dashbox ) : ?>
						<?php echo $bmc_dashbox; // phpcs:ignore WordPress.Security.EscapeOutput ?>
					<?php endif; ?>

					<form id="bmcOtpLinkForm" autocomplete="off" style="margin-top:14px">
						<div class="bmc-field">
							<label class="bmc-label"><?php echo esc_html( $bmc_cfg['player_label'] ); ?></label>
							<input class="bmc-input" id="bmcOtpPlayer" name="player" type="text" dir="ltr" placeholder="<?php echo esc_attr( $bmc_cfg['player_placeholder'] ); ?>" maxlength="16" />
						</div>

						<div class="bmc-field-row">
							<?php if ( in_array( 'email', $bmc_cfg['otp_methods'], true ) ) : ?>
								<button type="button" class="bmc-btn bmc-btn--ghost bmc-otp-channel" data-channel="email" data-delivery="email"><?php bmc_icon( 'mail', array( 'size' => 16 ) ); ?> ارسال به ایمیل</button>
							<?php endif; ?>
							<?php if ( in_array( 'dashboard', $bmc_cfg['otp_methods'], true ) && BMC_Settings::verify_enabled( 'dashboard' ) ) : ?>
								<button type="button" class="bmc-btn bmc-btn--ghost bmc-otp-channel" data-channel="auto" data-delivery="dashboard"><?php bmc_icon( 'desktop_windows', array( 'size' => 16 ) ); ?> نمایش کد در داشبورد</button>
							<?php endif; ?>
						</div>

						<div id="bmcOtpCodeField" class="bmc-field bmc-hidden" style="margin-top:14px">
							<label class="bmc-label" for="bmcOtpCode">کد دریافتی</label>
							<input class="bmc-input bmc-input--code" id="bmcOtpCode" name="code" type="text" inputmode="numeric" maxlength="8" placeholder="•••••" />
							<p class="bmc-hint" id="bmcOtpHint"></p>
						</div>

						<button type="submit" class="bmc-btn bmc-btn--block bmc-hidden" id="bmcOtpSubmit" style="margin-top:10px">
							<span class="bmc-spin"></span><span>تأیید و اتصال</span>
						</button>
					</form>

					<div id="bmcOtpAlert"></div>
				</div>
			<?php endif; ?>

		<?php endif; ?>

	</div>
</div>

<script>
	window.bmcLinkState = {
		active: <?php echo $bmc_active ? wp_json_encode( array( 'expires_in' => (int) $bmc_active['expires_in'], 'player' => $bmc_active['player'], 'code_plain' => isset( $bmc_active['code_plain'] ) ? $bmc_active['code_plain'] : '' ) ) : 'null'; ?>,
		commandTemplate: <?php echo wp_json_encode( $bmc_cfg['command_hint'] ); ?>
	};
</script>
