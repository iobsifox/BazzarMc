<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( ! function_exists( 'wc_get_account_menu_items' ) ) {
	return;
}

$bmc_nav = ( isset( $bmc_nav ) && is_array( $bmc_nav ) ) ? $bmc_nav : array();

$bmc_nav = array_merge(
	array(
		'layout'      => 'vertical',
		'icons'       => true,
		'counts'      => true,
		'items'       => array(),
		'extra'       => array(),
		'title'       => '',
		'title_icon'  => 'menu_book',
		'active_only' => false,
	),
	$bmc_nav
);

$bmc_icons = array(
	'dashboard'       => 'dashboard',
	'orders'          => 'receipt_long',
	'view-order'      => 'description',
	'downloads'       => 'download',
	'edit-address'    => 'location_on',
	'payment-methods' => 'account_balance_wallet',
	'edit-account'    => 'person',
	'customer-logout' => 'logout',
	'minecraft'       => 'sports_esports',
	'bmc-tickets'     => 'support_agent',
	'bmc-ticket'      => 'forum',
	'lost-password'   => 'lock',
);

$bmc_icons  = apply_filters( 'bmc_account_nav_icons', $bmc_icons );
$bmc_items  = (array) wc_get_account_menu_items();
$bmc_only   = array_values( array_filter( (array) $bmc_nav['items'] ) );
$bmc_layout = in_array( $bmc_nav['layout'], array( 'vertical', 'horizontal', 'pills' ), true ) ? $bmc_nav['layout'] : 'vertical';

$bmc_current = '';

if ( function_exists( 'WC' ) && WC() && isset( WC()->query ) && method_exists( WC()->query, 'get_current_endpoint' ) ) {
	$bmc_current = (string) WC()->query->get_current_endpoint();
}

if ( '' === $bmc_current && function_exists( 'is_wc_endpoint_url' ) ) {
	foreach ( array_keys( $bmc_items ) as $bmc_key ) {
		if ( $bmc_key && is_wc_endpoint_url( $bmc_key ) ) {
			$bmc_current = (string) $bmc_key;
			break;
		}
	}
}

$bmc_open_tickets = ( $bmc_nav['counts'] && BMC_Tickets::enabled() && is_user_logged_in() )
	? (int) BMC_Tickets::open_tickets_note( get_current_user_id() )
	: 0;

$bmc_unread = ( $bmc_nav['counts'] && BMC_Tickets::enabled() && is_user_logged_in() )
	? (int) BMC_Tickets::unread_for_user( get_current_user_id() )
	: 0;

$bmc_rows = array();

foreach ( $bmc_items as $bmc_endpoint => $bmc_label ) {
	if ( $bmc_only && ! in_array( $bmc_endpoint, $bmc_only, true ) ) {
		continue;
	}

	if ( 'bmc-ticket' === $bmc_endpoint ) {
		continue;
	}

	$bmc_url = function_exists( 'wc_get_account_endpoint_url' ) ? (string) wc_get_account_endpoint_url( $bmc_endpoint ) : '#';

	if ( 'bmc-tickets' === $bmc_endpoint && BMC_Tickets::enabled() ) {
		$bmc_url = (string) BMC_Tickets::url();
	}

	$bmc_active = ( '' === $bmc_current && 'dashboard' === $bmc_endpoint ) || $bmc_current === $bmc_endpoint;

	if ( $bmc_nav['active_only'] && ! $bmc_active ) {
		continue;
	}

	$bmc_rows[] = array(
		'endpoint' => (string) $bmc_endpoint,
		'url'      => $bmc_url,
		'label'    => (string) $bmc_label,
		'icon'     => isset( $bmc_icons[ $bmc_endpoint ] ) ? $bmc_icons[ $bmc_endpoint ] : 'keyboard_arrow_left',
		'active'   => $bmc_active,
		'count'  => ( 'bmc-tickets' === $bmc_endpoint && $bmc_open_tickets > 0 ) ? $bmc_open_tickets : 0,
		'dot'    => ( 'bmc-tickets' === $bmc_endpoint && $bmc_unread > 0 ),
	);
}

if ( $bmc_only ) {
	$bmc_sorted = array();

	foreach ( $bmc_only as $bmc_wanted ) {
		foreach ( $bmc_rows as $bmc_row ) {
			if ( isset( $bmc_row['endpoint'] ) && $bmc_row['endpoint'] === $bmc_wanted ) {
				$bmc_sorted[] = $bmc_row;
			}
		}
	}

	if ( $bmc_sorted ) {
		$bmc_rows = $bmc_sorted;
	}
}

foreach ( (array) $bmc_nav['extra'] as $bmc_extra ) {
	if ( empty( $bmc_extra['label'] ) || empty( $bmc_extra['url'] ) ) {
		continue;
	}

	$bmc_rows[] = array(
		'endpoint' => '',
		'url'      => (string) $bmc_extra['url'],
		'label'    => (string) $bmc_extra['label'],
		'icon'     => ! empty( $bmc_extra['icon'] ) ? (string) $bmc_extra['icon'] : 'open_in_new',
		'active'   => false,
		'count'  => 0,
		'dot'    => false,
	);
}

if ( ! $bmc_rows ) {
	return;
}
?>
<div class="bmc-nav bmc-nav--<?php echo esc_attr( $bmc_layout ); ?>">
	<?php if ( '' !== trim( (string) $bmc_nav['title'] ) ) : ?>
		<header class="bmc-nav__title">
			<?php if ( $bmc_nav['title_icon'] ) : ?>
				<?php bmc_icon( $bmc_nav['title_icon'], array( 'size' => 17 ) ); ?>
			<?php endif; ?>
			<span><?php echo esc_html( $bmc_nav['title'] ); ?></span>
		</header>
	<?php endif; ?>

	<ul class="bmc-nav__list">
		<?php foreach ( $bmc_rows as $bmc_row ) : ?>
			<li class="bmc-nav__item<?php echo $bmc_row['active'] ? ' is-active' : ''; ?>">
				<a href="<?php echo esc_url( $bmc_row['url'] ); ?>">
					<?php if ( $bmc_nav['icons'] ) : ?>
						<span class="bmc-nav__icon"><?php bmc_icon( $bmc_row['icon'], array( 'size' => 17 ) ); ?></span>
					<?php endif; ?>
					<span class="bmc-nav__label"><?php echo esc_html( $bmc_row['label'] ); ?></span>
					<?php if ( $bmc_row['dot'] ) : ?>
						<span class="bmc-nav__dot"></span>
					<?php endif; ?>
					<?php if ( $bmc_row['count'] > 0 ) : ?>
						<span class="bmc-nav__count"><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_row['count'] ) ); ?></span>
					<?php endif; ?>
				</a>
			</li>
		<?php endforeach; ?>
	</ul>
</div>
