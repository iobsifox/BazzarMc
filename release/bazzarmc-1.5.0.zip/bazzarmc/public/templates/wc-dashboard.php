<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_user = wp_get_current_user();

$bmc_allowed_html = array(
	'a' => array(
		'href' => array(),
	),
);
?>

<p>
	<?php
	printf(
		wp_kses( __( 'Hello %1$s (not %1$s? <a href="%2$s">Log out</a>)', 'woocommerce' ), $bmc_allowed_html ),
		'<strong>' . esc_html( $bmc_user->display_name ) . '</strong>',
		esc_url( wp_logout_url( home_url( '/' ) ) )
	);
	?>
</p>

<?php
echo BMC_Public::render_account_card();

do_action( 'woocommerce_account_dashboard' );
do_action( 'woocommerce_before_my_account' );
do_action( 'woocommerce_after_my_account' );
