<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_card = ( isset( $bmc_card ) && is_array( $bmc_card ) ) ? $bmc_card : array();

$bmc_card = array_merge(
	array(
		'user_id'       => get_current_user_id(),
		'title'         => '',
		'title_icon'    => 'account_circle',
		'layout'        => 'grid',
		'columns'       => 2,
		'kicker'        => true,
		'kicker_text'   => '',
		'email'         => true,
		'mobile'        => true,
		'orders'        => true,
		'roles'         => true,
		'mc_box'        => true,
		'ranks_box'     => true,
		'links'         => true,
		'link_items'    => array( 'orders', 'addresses', 'details', 'cart', 'tickets', 'logout' ),
		'unlinked_text' => '',
		'no_ranks_text' => '',
		'manage_label'  => '',
		'connect_label' => '',
		'avatar_size'   => 64,
	),
	$bmc_card
);

$bmc_uid   = (int) $bmc_card['user_id'];
$bmc_user  = get_userdata( $bmc_uid );

if ( ! $bmc_user ) {
	return;
}

$bmc_first = trim( (string) get_user_meta( $bmc_uid, 'first_name', true ) );
$bmc_last  = trim( (string) get_user_meta( $bmc_uid, 'last_name', true ) );

if ( '' === $bmc_first && '' === $bmc_last ) {
	$bmc_first = trim( (string) get_user_meta( $bmc_uid, 'billing_first_name', true ) );
	$bmc_last  = trim( (string) get_user_meta( $bmc_uid, 'billing_last_name', true ) );
}

$bmc_realname = trim( $bmc_first . ' ' . $bmc_last );

if ( '' === $bmc_realname ) {
	$bmc_realname = (string) $bmc_user->display_name;
}

$bmc_email   = (string) $bmc_user->user_email;
$bmc_mobile  = $bmc_card['mobile'] ? (string) BMC_Auth::get_user_mobile( $bmc_uid ) : '';
$bmc_player  = (string) BMC_Link::get_linked_player( $bmc_uid );
$bmc_linked  = BMC_Link::is_linked( $bmc_uid );
$bmc_uuid    = (string) BMC_Link::get_linked_uuid( $bmc_uid );
$bmc_link_at = (int) get_user_meta( $bmc_uid, BMC_Link::META_LINKED_AT, true );
$bmc_grants  = $bmc_card['ranks_box'] ? BMC_Roles::active_grants( $bmc_uid ) : array();
$bmc_connect = BMC_Checkout::connect_url();
$bmc_manage  = function_exists( 'wc_get_account_endpoint_url' ) ? wc_get_account_endpoint_url( BMC_Public::ENDPOINT ) : $bmc_connect;
$bmc_initial = function_exists( 'mb_substr' ) ? mb_substr( $bmc_realname, 0, 1 ) : substr( $bmc_realname, 0, 1 );
$bmc_avatar  = max( 24, min( 160, (int) $bmc_card['avatar_size'] ) );

$bmc_orders_count = 0;
$bmc_orders_url   = function_exists( 'wc_get_account_endpoint_url' ) ? wc_get_account_endpoint_url( 'orders' ) : '#';

if ( $bmc_card['orders'] && function_exists( 'wc_get_orders' ) ) {
	$bmc_orders_count = count(
		wc_get_orders(
			array(
				'customer' => $bmc_uid,
				'limit'    => -1,
				'return'   => 'ids',
			)
		)
	);
}

$bmc_role_labels = array();

if ( $bmc_card['roles'] ) {
	foreach ( (array) $bmc_user->roles as $bmc_role_slug ) {
		if ( in_array( $bmc_role_slug, array( 'customer', 'subscriber' ), true ) ) {
			continue;
		}

		$bmc_role_labels[] = BMC_Roles::role_label( $bmc_role_slug );
	}
}

$bmc_addresses_url = function_exists( 'wc_get_account_endpoint_url' ) ? wc_get_account_endpoint_url( 'edit-address' ) : '#';
$bmc_details_url   = function_exists( 'wc_get_account_endpoint_url' ) ? wc_get_account_endpoint_url( 'edit-account' ) : '#';
$bmc_cart_url      = function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/' );
$bmc_shop_url      = function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' );
$bmc_logout_url    = wp_logout_url( home_url( '/' ) );

$bmc_tickets_enabled = BMC_Tickets::enabled();
$bmc_tickets_url     = $bmc_tickets_enabled ? BMC_Tickets::url() : '#';
$bmc_tickets_open    = $bmc_tickets_enabled ? (int) BMC_Tickets::open_tickets_note( $bmc_uid ) : 0;
$bmc_tickets_new     = $bmc_tickets_enabled ? (int) BMC_Tickets::unread_for_user( $bmc_uid ) : 0;

$bmc_link_items = array_values( array_filter( (array) $bmc_card['link_items'] ) );

$bmc_hour = (int) gmdate( 'G', BMC_Helpers::now_timestamp() );

if ( '' !== trim( (string) $bmc_card['kicker_text'] ) ) {
	$bmc_kicker = (string) $bmc_card['kicker_text'];
} else {
	$bmc_kicker = $bmc_hour < 12 ? 'صبح بخیر' : ( $bmc_hour < 17 ? 'ظهر بخیر' : 'وقت بخیر' );
}

$bmc_unlinked = '' !== trim( (string) $bmc_card['unlinked_text'] )
	? (string) $bmc_card['unlinked_text']
	: 'حساب شما هنوز به اکانت ماینکرافت متصل نیست. برای دریافت آیتم‌های خریداری‌شده در بازی، اکانت خود را متصل کنید.';

$bmc_no_ranks = '' !== trim( (string) $bmc_card['no_ranks_text'] )
	? (string) $bmc_card['no_ranks_text']
	: 'هنوز رنکی خریداری نکرده‌اید. با خرید رنک، نقش مربوطه به‌صورت خودکار به حساب شما اضافه می‌شود.';

$bmc_manage_label  = '' !== trim( (string) $bmc_card['manage_label'] ) ? (string) $bmc_card['manage_label'] : 'مدیریت اتصال';
$bmc_connect_label = '' !== trim( (string) $bmc_card['connect_label'] ) ? (string) $bmc_card['connect_label'] : 'اتصال اکانت ماینکرافت';

$bmc_grid_class = 'stack' === $bmc_card['layout'] ? ' bmc-acard__grid--stack' : '';
$bmc_grid_style = '';

if ( 'grid' === $bmc_card['layout'] && (int) $bmc_card['columns'] > 0 ) {
	$bmc_cols       = max( 1, min( 4, (int) $bmc_card['columns'] ) );
	$bmc_grid_style = ' style="grid-template-columns:repeat(' . esc_attr( $bmc_cols ) . ',minmax(0,1fr))"';
}
?>
<?php if ( '' !== trim( (string) $bmc_card['title'] ) ) : ?>
	<header class="bmc-acard-title">
		<?php if ( $bmc_card['title_icon'] ) : ?>
			<?php bmc_icon( $bmc_card['title_icon'], array( 'size' => 19 ) ); ?>
		<?php endif; ?>
		<span><?php echo esc_html( $bmc_card['title'] ); ?></span>
	</header>
<?php endif; ?>

<div class="bmc-acard">
	<div class="bmc-acard__head">
		<div class="bmc-acard__avatar" style="width:<?php echo esc_attr( $bmc_avatar ); ?>px;height:<?php echo esc_attr( $bmc_avatar ); ?>px;">
			<?php if ( $bmc_linked && $bmc_player ) : ?>
				<img src="<?php echo esc_url( BMC_Helpers::mc_head( $bmc_player, 96 ) ); ?>" alt="" width="<?php echo esc_attr( $bmc_avatar ); ?>" height="<?php echo esc_attr( $bmc_avatar ); ?>" />
			<?php else : ?>
				<span><?php echo esc_html( $bmc_initial ); ?></span>
			<?php endif; ?>
		</div>

		<div class="bmc-acard__id">
			<?php if ( $bmc_card['kicker'] ) : ?>
				<span class="bmc-acard__kicker"><?php bmc_icon( 'waving_hand', array( 'size' => 15 ) ); ?> <?php echo esc_html( $bmc_kicker ); ?></span>
			<?php endif; ?>
			<h2 class="bmc-acard__name"><?php echo esc_html( $bmc_realname ); ?></h2>
			<div class="bmc-acard__meta">
				<?php if ( $bmc_card['email'] && $bmc_email ) : ?>
					<span><?php bmc_icon( 'mail', array( 'size' => 14 ) ); ?> <?php echo esc_html( $bmc_email ); ?></span>
				<?php endif; ?>
				<?php if ( $bmc_mobile ) : ?>
					<span dir="ltr"><?php bmc_icon( 'smartphone', array( 'size' => 14 ) ); ?> <?php echo esc_html( $bmc_mobile ); ?></span>
				<?php endif; ?>
				<?php if ( $bmc_card['orders'] ) : ?>
					<span><?php bmc_icon( 'receipt_long', array( 'size' => 14 ) ); ?> <?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_orders_count ) ); ?> سفارش</span>
				<?php endif; ?>
				<?php if ( $bmc_role_labels ) : ?>
					<span class="bmc-acard__role"><?php bmc_icon( 'workspace_premium', array( 'size' => 14 ) ); ?> <?php echo esc_html( implode( '، ', $bmc_role_labels ) ); ?></span>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<div class="bmc-acard__grid<?php echo esc_attr( $bmc_grid_class ); ?>"<?php echo $bmc_grid_style; // phpcs:ignore WordPress.Security.EscapeOutput ?>>
		<?php if ( $bmc_card['mc_box'] ) : ?>
			<section class="bmc-acard__box<?php echo $bmc_linked ? ' is-on' : ' is-off'; ?>">
				<header class="bmc-acard__boxlabel">
					<?php bmc_icon( 'sports_esports', array( 'size' => 16 ) ); ?>
					اکانت ماینکرافت
					<?php if ( $bmc_linked ) : ?>
						<span class="bmc-chip bmc-chip--ok"><?php bmc_icon( 'verified', array( 'size' => 13 ) ); ?> متصل</span>
					<?php else : ?>
						<span class="bmc-chip bmc-chip--off"><?php bmc_icon( 'link_off', array( 'size' => 13 ) ); ?> متصل نیست</span>
					<?php endif; ?>
				</header>

				<?php if ( $bmc_linked && $bmc_player ) : ?>
					<div class="bmc-mc">
						<img class="bmc-mc__head" src="<?php echo esc_url( BMC_Helpers::mc_head( $bmc_player, 64 ) ); ?>" alt="" width="44" height="44" />
						<div class="bmc-mc__body">
							<strong dir="ltr"><?php echo esc_html( $bmc_player ); ?></strong>
							<?php if ( $bmc_uuid ) : ?>
								<small dir="ltr"><?php echo esc_html( $bmc_uuid ); ?></small>
							<?php endif; ?>
						</div>
					</div>

					<ul class="bmc-acard__facts">
						<?php if ( $bmc_link_at ) : ?>
							<li><?php bmc_icon( 'calendar_month', array( 'size' => 14 ) ); ?> تاریخ اتصال: <?php echo esc_html( BMC_Jalali::format( $bmc_link_at, false ) ); ?></li>
						<?php endif; ?>
						<li><?php bmc_icon( 'inventory', array( 'size' => 14 ) ); ?> آیتم‌های خریداری‌شده در اولین ورود به سرور تحویل می‌شود.</li>
					</ul>

					<a class="bmc-btn bmc-btn-o bmc-btn-sm" href="<?php echo esc_url( $bmc_manage ); ?>"><?php bmc_icon( 'settings', array( 'size' => 15 ) ); ?> <?php echo esc_html( $bmc_manage_label ); ?></a>
				<?php else : ?>
					<p class="bmc-acard__hint"><?php echo esc_html( $bmc_unlinked ); ?></p>
					<a class="bmc-btn bmc-btn-p bmc-btn-sm" href="<?php echo esc_url( $bmc_connect ); ?>"><?php bmc_icon( 'link', array( 'size' => 15 ) ); ?> <?php echo esc_html( $bmc_connect_label ); ?></a>
				<?php endif; ?>
			</section>
		<?php endif; ?>

		<?php if ( $bmc_card['ranks_box'] ) : ?>
			<section class="bmc-acard__box bmc-acard__box--rank">
				<header class="bmc-acard__boxlabel">
					<?php bmc_icon( 'workspace_premium', array( 'size' => 16 ) ); ?>
					رنک‌های شما
					<span class="bmc-chip"><?php bmc_icon( 'category', array( 'size' => 13 ) ); ?> <?php echo esc_html( BMC_Helpers::to_persian_digits( count( $bmc_grants ) ) ); ?> مورد</span>
				</header>

				<?php if ( $bmc_grants ) : ?>
					<div class="bmc-ranks">
						<?php foreach ( $bmc_grants as $bmc_grant ) : ?>
							<?php
							$bmc_days   = max( 1, (int) ( isset( $bmc_grant['days'] ) ? $bmc_grant['days'] : 0 ) );
							$bmc_pct    = empty( $bmc_grant['permanent'] ) ? max( 2, min( 100, (int) round( ( (int) $bmc_grant['remaining'] / ( $bmc_days * DAY_IN_SECONDS ) ) * 100 ) ) ) : 100;
							$bmc_urgent = ! empty( $bmc_grant['permanent'] ) ? false : (int) $bmc_grant['remaining'] < ( 3 * DAY_IN_SECONDS );
							?>
							<article class="bmc-rank<?php echo $bmc_urgent ? ' is-urgent' : ''; ?>">
								<span class="bmc-rank__icon"><?php bmc_icon( $bmc_urgent ? 'hourglass_bottom' : 'trophy', array( 'size' => 18 ) ); ?></span>
								<div class="bmc-rank__body">
									<strong><?php echo esc_html( $bmc_grant['label'] ? $bmc_grant['label'] : $bmc_grant['role_label'] ); ?></strong>
									<small><?php bmc_icon( 'badge', array( 'size' => 12 ) ); ?> نقش: <?php echo esc_html( $bmc_grant['role_label'] ); ?><?php echo empty( $bmc_grant['still_has_role'] ) ? ' — در انتظار اعمال' : ''; ?></small>
								</div>
								<div class="bmc-rank__time">
									<span class="bmc-pill<?php echo $bmc_urgent ? ' bmc-pill--warn' : ''; ?>">
										<?php bmc_icon( empty( $bmc_grant['permanent'] ) ? 'timer' : 'all_inclusive', array( 'size' => 13 ) ); ?>
										<?php echo esc_html( $bmc_grant['remaining_human'] ); ?>
										<?php echo empty( $bmc_grant['permanent'] ) ? ' باقی مانده' : ''; ?>
									</span>
									<?php if ( empty( $bmc_grant['permanent'] ) && ! empty( $bmc_grant['expires_jalali'] ) ) : ?>
										<small><?php bmc_icon( 'calendar_month', array( 'size' => 12 ) ); ?> تا <?php echo esc_html( $bmc_grant['expires_jalali'] ); ?></small>
										<span class="bmc-bar"><i style="width:<?php echo esc_attr( $bmc_pct ); ?>%"></i></span>
									<?php endif; ?>
								</div>
							</article>
						<?php endforeach; ?>
					</div>
				<?php else : ?>
					<p class="bmc-acard__hint"><?php echo esc_html( $bmc_no_ranks ); ?></p>
					<a class="bmc-btn bmc-btn-o bmc-btn-sm" href="<?php echo esc_url( $bmc_shop_url ); ?>"><?php bmc_icon( 'storefront', array( 'size' => 15 ) ); ?> مشاهدهٔ فروشگاه</a>
				<?php endif; ?>
			</section>
		<?php endif; ?>
	</div>

	<?php if ( $bmc_card['links'] && $bmc_link_items ) : ?>
		<nav class="bmc-acard__links">
			<?php foreach ( $bmc_link_items as $bmc_item ) : ?>
				<?php if ( 'orders' === $bmc_item ) : ?>
					<a href="<?php echo esc_url( $bmc_orders_url ); ?>"><?php bmc_icon( 'receipt_long', array( 'size' => 15 ) ); ?> سفارش‌ها</a>
				<?php elseif ( 'addresses' === $bmc_item ) : ?>
					<a href="<?php echo esc_url( $bmc_addresses_url ); ?>"><?php bmc_icon( 'location_on', array( 'size' => 15 ) ); ?> آدرس‌ها</a>
				<?php elseif ( 'details' === $bmc_item ) : ?>
					<a href="<?php echo esc_url( $bmc_details_url ); ?>"><?php bmc_icon( 'person', array( 'size' => 15 ) ); ?> جزئیات حساب</a>
				<?php elseif ( 'cart' === $bmc_item ) : ?>
					<a href="<?php echo esc_url( $bmc_cart_url ); ?>"><?php bmc_icon( 'shopping_cart', array( 'size' => 15 ) ); ?> سبد خرید</a>
				<?php elseif ( 'tickets' === $bmc_item && $bmc_tickets_enabled ) : ?>
					<a href="<?php echo esc_url( $bmc_tickets_url ); ?>">
						<?php bmc_icon( 'support_agent', array( 'size' => 15 ) ); ?> پشتیبانی
						<?php if ( $bmc_tickets_open > 0 ) : ?>
							<span class="bmc-acard__count"><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_tickets_open ) ); ?></span>
						<?php endif; ?>
						<?php if ( $bmc_tickets_new > 0 ) : ?>
							<span class="bmc-acard__new">پاسخ جدید</span>
						<?php endif; ?>
					</a>
				<?php elseif ( 'minecraft' === $bmc_item ) : ?>
					<a href="<?php echo esc_url( $bmc_manage ); ?>"><?php bmc_icon( 'sports_esports', array( 'size' => 15 ) ); ?> اکانت ماینکرافت</a>
				<?php elseif ( 'logout' === $bmc_item ) : ?>
					<a class="bmc-acard__logout" href="<?php echo esc_url( $bmc_logout_url ); ?>"><?php bmc_icon( 'logout', array( 'size' => 15 ) ); ?> خروج</a>
				<?php endif; ?>
			<?php endforeach; ?>
		</nav>
	<?php endif; ?>
</div>
