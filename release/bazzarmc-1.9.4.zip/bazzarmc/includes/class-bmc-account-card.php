<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Account_Card {

	private static $rendered = false;

	public static function init() {
		add_action( 'wp', array( __CLASS__, 'register_injections' ) );
	}

	public static function register_injections() {
		self::$rendered = false;

		if ( ! BMC_Settings::bool( 'card_inject', false ) ) {
			return;
		}

		if ( ! BMC_Settings::bool( 'myaccount_card', true ) ) {
			return;
		}

		if ( 'auto' !== self::mode() ) {
			return;
		}

		if ( class_exists( 'BMC_Safe' ) && BMC_Safe::safe_mode() ) {
			return;
		}

		if ( ! is_user_logged_in() || ! function_exists( 'is_account_page' ) || ! is_account_page() ) {
			return;
		}

		foreach ( self::injections() as $endpoint ) {
			add_action( 'woocommerce_account_' . $endpoint . '_endpoint', array( __CLASS__, 'inject' ), 4 );
		}
	}

	public static function injections() {
		if ( ! BMC_Settings::bool( 'card_inject', false ) ) {
			return array();
		}

		if ( ! BMC_Settings::bool( 'myaccount_card', true ) ) {
			return array();
		}

		if ( 'auto' !== self::mode() ) {
			return array();
		}

		$out = array();

		if ( BMC_Settings::bool( 'card_context_orders', true ) ) {
			$out[] = 'orders';
			$out[] = 'downloads';
		}

		if ( BMC_Settings::bool( 'card_context_profile', true ) ) {
			$out[] = 'edit-account';
			$out[] = 'edit-address';
			$out[] = 'payment-methods';
		}

		if ( BMC_Settings::bool( 'card_context_minecraft', true ) && class_exists( 'BMC_Account_Endpoints' ) ) {
			$out[] = BMC_Account_Endpoints::slug( 'connect' );
			$out   = array_merge( $out, BMC_Account_Endpoints::connect_aliases() );
		}

		if ( BMC_Settings::bool( 'card_context_tickets', true ) && class_exists( 'BMC_Account_Endpoints' ) && class_exists( 'BMC_Tickets' ) && BMC_Tickets::enabled() ) {
			$out[] = BMC_Account_Endpoints::slug( 'tickets' );
			$out   = array_merge( $out, BMC_Account_Endpoints::tickets_aliases() );
		}

		return array_values( array_unique( array_filter( array_map( 'strval', $out ) ) ) );
	}

	public static function inject() {
		if ( self::$rendered || ! is_user_logged_in() ) {
			return;
		}

		self::$rendered = true;

		echo '<div class="bmc-acard-inject">' . BMC_Public::render_account_card( array( 'context' => 'auto' ) ) . '</div>';
	}

	public static function rendered() {
		return self::$rendered;
	}

	public static function context_preset( $context ) {
		$context = (string) $context;

		if ( 'dashboard' === $context ) {
			return array(
				'kicker'      => true,
				'email'       => true,
				'mobile'      => true,
				'orders'      => true,
				'roles'       => true,
				'mc_box'      => true,
				'ranks_box'   => true,
				'links'       => true,
				'context_box' => false,
				'compact'     => false,
			);
		}

		if ( 'minecraft' === $context ) {
			return array(
				'kicker'      => false,
				'email'       => false,
				'mobile'      => false,
				'orders'      => false,
				'roles'       => false,
				'mc_box'      => true,
				'ranks_box'   => false,
				'links'       => false,
				'context_box' => true,
				'compact'     => true,
			);
		}

		if ( in_array( $context, array( 'tickets', 'orders', 'downloads', 'profile' ), true ) ) {
			return array(
				'kicker'      => false,
				'email'       => false,
				'mobile'      => false,
				'orders'      => false,
				'roles'       => false,
				'mc_box'      => false,
				'ranks_box'   => false,
				'links'       => false,
				'context_box' => true,
				'compact'     => true,
			);
		}

		return array(
			'kicker'      => false,
			'email'       => false,
			'mobile'      => false,
			'orders'      => false,
			'roles'       => false,
			'mc_box'      => false,
			'ranks_box'   => false,
			'links'       => false,
			'context_box' => false,
			'compact'     => true,
		);
	}

	public static function mode() {
		$mode = (string) BMC_Settings::get( 'card_context', 'auto' );

		return in_array( $mode, array( 'auto', 'dashboard' ), true ) ? $mode : 'auto';
	}

	private static function safe_rows( $label, callable $callback ) {
		try {
			$rows = $callback();

			return is_array( $rows ) ? $rows : array();
		} catch ( \Throwable $error ) {
			if ( class_exists( 'BMC_Safe' ) ) {
				BMC_Safe::collect( $label, $error );
			}

			return array();
		}
	}

	public static function context( $requested = '' ) {
		$requested = sanitize_key( (string) $requested );

		$allowed = array( 'auto', 'dashboard', 'minecraft', 'tickets', 'orders', 'downloads', 'profile' );

		if ( '' !== $requested && in_array( $requested, $allowed, true ) && 'auto' !== $requested ) {
			return $requested;
		}

		if ( 'dashboard' === self::mode() && 'auto' === $requested ) {
			return 'dashboard';
		}

		if ( '' !== $requested && 'auto' !== $requested ) {
			return 'dashboard';
		}

		$current = class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::context() : 'other';

		if ( 'other' === $current ) {
			return 'endpoint';
		}

		if ( 'tickets' === $current && ! BMC_Settings::bool( 'card_context_tickets', true ) ) {
			return 'dashboard';
		}

		if ( in_array( $current, array( 'orders', 'downloads' ), true ) && ! BMC_Settings::bool( 'card_context_orders', true ) ) {
			return 'dashboard';
		}

		if ( 'profile' === $current && ! BMC_Settings::bool( 'card_context_profile', true ) ) {
			return 'dashboard';
		}

		if ( 'minecraft' === $current && ! BMC_Settings::bool( 'card_context_minecraft', true ) ) {
			return 'dashboard';
		}

		return $current;
	}

	public static function labels() {
		return array(
			'dashboard' => 'داشبورد حساب',
			'minecraft' => 'اکانت ماینکرافت',
			'tickets'   => 'پشتیبانی و تیکت‌ها',
			'orders'    => 'سفارش‌ها و تحویل‌ها',
			'downloads' => 'دانلودها و تحویل‌ها',
			'profile'   => 'مشخصات حساب',
		);
	}

	public static function icons() {
		return array(
			'dashboard' => 'dashboard',
			'minecraft' => 'sports_esports',
			'tickets'   => 'support_agent',
			'orders'    => 'receipt_long',
			'downloads' => 'download',
			'profile'   => 'badge',
		);
	}

	public static function limit() {
		return BMC_Settings::int( 'card_context_limit', 3, 1, 10 );
	}

	public static function tickets( $user_id, $limit = 3 ) {
		return self::safe_rows( 'card:tickets', function () use ( $user_id, $limit ) {
			return self::tickets_rows( $user_id, $limit );
		} );
	}

	private static function tickets_rows( $user_id, $limit = 3 ) {
		$user_id = absint( $user_id );
		$limit   = max( 1, min( 10, (int) $limit ) );

		if ( ! $user_id || ! class_exists( 'BMC_Tickets' ) || ! BMC_Tickets::enabled() ) {
			return array();
		}

		$rows = BMC_Tickets::query(
			array(
				'user_id'  => $user_id,
				'page'     => 1,
				'per_page' => $limit,
				'orderby'  => 'updated_at',
				'order'    => 'DESC',
			)
		);

		$out = array();

		$items = isset( $rows['items'] ) && is_array( $rows['items'] ) ? $rows['items'] : (array) $rows;

		foreach ( $items as $row ) {
			$row = is_object( $row ) ? get_object_vars( $row ) : (array) $row;

			if ( empty( $row['id'] ) ) {
				continue;
			}

			$status = isset( $row['status'] ) ? (string) $row['status'] : 'open';

			$out[] = array(
				'id'        => isset( $row['id'] ) ? (int) $row['id'] : 0,
				'reference' => isset( $row['id'] ) ? BMC_Tickets::reference( (int) $row['id'] ) : '',
				'subject'   => isset( $row['subject'] ) ? (string) $row['subject'] : '',
				'status'    => $status,
				'label'     => BMC_Tickets::status_label( $status ),
				'meta'      => BMC_Tickets::status_meta( $status ),
				'updated'   => isset( $row['updated_at'] ) ? (string) $row['updated_at'] : '',
				'url'       => isset( $row['id'] ) ? BMC_Tickets::url( (int) $row['id'] ) : BMC_Tickets::url(),
			);
		}

		return $out;
	}

	public static function orders( $user_id, $limit = 3 ) {
		return self::safe_rows( 'card:orders', function () use ( $user_id, $limit ) {
			return self::orders_rows( $user_id, $limit );
		} );
	}

	private static function orders_rows( $user_id, $limit = 3 ) {
		$user_id = absint( $user_id );
		$limit   = max( 1, min( 10, (int) $limit ) );

		if ( ! $user_id || ! function_exists( 'wc_get_orders' ) ) {
			return array();
		}

		$orders = wc_get_orders(
			array(
				'customer' => $user_id,
				'limit'    => $limit,
				'orderby'  => 'date',
				'order'    => 'DESC',
				'return'   => 'objects',
			)
		);

		$out = array();

		foreach ( (array) $orders as $order ) {
			if ( ! is_object( $order ) || ! method_exists( $order, 'get_id' ) ) {
				continue;
			}

			$status = method_exists( $order, 'get_status' ) ? (string) $order->get_status() : '';
			$date   = method_exists( $order, 'get_date_created' ) ? $order->get_date_created() : null;
			$stamp  = $date && method_exists( $date, 'getTimestamp' ) ? (int) $date->getTimestamp() : 0;

			$out[] = array(
				'id'      => (int) $order->get_id(),
				'number'  => method_exists( $order, 'get_order_number' ) ? (string) $order->get_order_number() : (string) $order->get_id(),
				'status'  => $status,
				'label'   => function_exists( 'wc_get_order_status_name' ) ? wc_get_order_status_name( $status ) : $status,
				'total'   => method_exists( $order, 'get_formatted_order_total' ) ? wp_strip_all_tags( (string) $order->get_formatted_order_total() ) : '',
				'date'    => $stamp,
				'url'     => method_exists( $order, 'get_view_order_url' ) ? (string) $order->get_view_order_url() : '#',
			);
		}

		return $out;
	}

	public static function deliveries( $user_id, $limit = 3 ) {
		return self::safe_rows( 'card:deliveries', function () use ( $user_id, $limit ) {
			return self::deliveries_rows( $user_id, $limit );
		} );
	}

	private static function deliveries_rows( $user_id, $limit = 3 ) {
		$user_id = absint( $user_id );
		$limit   = max( 1, min( 10, (int) $limit ) );

		if ( ! $user_id || ! class_exists( 'BMC_Deliveries' ) ) {
			return array();
		}

		$rows = BMC_Deliveries::for_user(
			$user_id,
			array(
				'status' => '',
				'limit'  => $limit,
			)
		);

		$out = array();

		foreach ( (array) $rows as $row ) {
			$row = is_object( $row ) ? get_object_vars( $row ) : (array) $row;

			if ( empty( $row['id'] ) ) {
				continue;
			}

			$out[] = array(
				'id'     => (int) $row['id'],
				'item'   => isset( $row['item'] ) ? (string) $row['item'] : '',
				'code'   => isset( $row['id'] ) && class_exists( 'BMC_API' ) ? BMC_API::purchase_code( (object) $row ) : '',
				'status' => isset( $row['status'] ) ? (int) $row['status'] : 0,
				'label'  => isset( $row['status'] ) ? BMC_Deliveries::status_label( (int) $row['status'] ) : '',
				'note'   => isset( $row['note'] ) ? (string) $row['note'] : '',
			);
		}

		return $out;
	}

	public static function profile( $user_id ) {
		return self::safe_rows( 'card:profile', function () use ( $user_id ) {
			return self::profile_rows( $user_id );
		} );
	}

	private static function profile_rows( $user_id ) {
		$user_id = absint( $user_id );
		$user    = $user_id ? get_userdata( $user_id ) : false;

		if ( ! $user ) {
			return array();
		}

		$registered = ! empty( $user->user_registered ) ? strtotime( (string) $user->user_registered ) : 0;

		return array(
			'username'   => (string) $user->user_login,
			'email'      => (string) $user->user_email,
			'mobile'     => class_exists( 'BMC_Auth' ) ? (string) BMC_Auth::get_user_mobile( $user_id ) : '',
			'registered' => $registered,
			'player'     => (string) BMC_Link::get_linked_player( $user_id ),
			'linked'     => (bool) BMC_Link::is_linked( $user_id ),
			'roles'      => array_values( array_filter( (array) $user->roles ) ),
		);
	}

	public static function urls() {
		try {
			return self::urls_rows();
		} catch ( \Throwable $error ) {
			if ( class_exists( 'BMC_Safe' ) ) {
				BMC_Safe::collect( 'card:urls', $error );
			}

			return array();
		}
	}

	private static function urls_rows() {
		$urls = array(
			'tickets'    => class_exists( 'BMC_Tickets' ) && BMC_Tickets::enabled() ? BMC_Tickets::url() : '',
			'ticket_new' => class_exists( 'BMC_Tickets' ) && BMC_Tickets::enabled() ? add_query_arg( 'bmc_new', '1', BMC_Tickets::url() ) : '',
			'orders'     => function_exists( 'wc_get_account_endpoint_url' ) ? (string) wc_get_account_endpoint_url( 'orders' ) : '',
			'profile'    => function_exists( 'wc_get_account_endpoint_url' ) ? (string) wc_get_account_endpoint_url( 'edit-account' ) : '',
			'addresses'  => function_exists( 'wc_get_account_endpoint_url' ) ? (string) wc_get_account_endpoint_url( 'edit-address' ) : '',
			'downloads'  => function_exists( 'wc_get_account_endpoint_url' ) ? (string) wc_get_account_endpoint_url( 'downloads' ) : '',
			'minecraft'  => class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::url( 'connect' ) : '',
			'deliveries' => function_exists( 'wc_get_account_endpoint_url' ) ? (string) wc_get_account_endpoint_url( 'bmc-deliveries' ) : '',
			'shop'       => function_exists( 'wc_get_page_permalink' ) ? (string) wc_get_page_permalink( 'shop' ) : '',
		);

		return $urls;
	}
}
