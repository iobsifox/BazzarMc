<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_meta     = BMC_Tickets::status_meta( $bmc_ticket->status );
$bmc_product  = BMC_Tickets::ticket_product_name( $bmc_ticket );
$bmc_is_staff = current_user_can( 'manage_woocommerce' );
$bmc_self_url = remove_query_arg( array( 'bmc_ticket_msg', 'bmc_ticket_error' ) );
$bmc_closed   = 'closed' === $bmc_ticket->status;
$bmc_can_close = $bmc_is_staff || BMC_Settings::bool( 'tickets_user_close', true );
?>
<div class="bmc-wrap bmc-ticket" dir="rtl">
	<a class="bmc-tk-back" href="<?php echo esc_url( BMC_Tickets::url() ); ?>">
		<?php echo bmc_get_icon( 'keyboard_arrow_right', array( 'size' => 18 ) ); ?> همهٔ تیکت‌ها
	</a>

	<?php foreach ( BMC_Tickets::flash() as $bmc_notice ) : ?>
		<div class="bmc-notice <?php echo 'error' === $bmc_notice['type'] ? 'bmc-notice-warn' : 'bmc-notice-ok'; ?>">
			<?php echo bmc_get_icon( 'error' === $bmc_notice['type'] ? 'warning' : 'check_circle', array( 'size' => 17 ) ); ?>
			<span><?php echo esc_html( $bmc_notice['text'] ); ?></span>
		</div>
	<?php endforeach; ?>

	<div class="bmc-card bmc-tk-head-card">
		<div class="bmc-tk-head">
			<div>
				<span class="bmc-kicker"><code><?php echo esc_html( BMC_Tickets::reference( $bmc_ticket->id ) ); ?></code></span>
				<h2 class="bmc-title"><?php echo esc_html( $bmc_ticket->subject ); ?></h2>
			</div>

			<span class="bmc-tk-badges">
				<span class="bmc-pill bmc-pill--<?php echo esc_attr( $bmc_meta['tone'] ); ?>">
					<?php echo bmc_get_icon( $bmc_meta['icon'], array( 'size' => 14 ) ); ?> <?php echo esc_html( $bmc_meta['label'] ); ?>
				</span>
				<span class="bmc-pill">اولویت: <?php echo esc_html( BMC_Tickets::priority_label( $bmc_ticket->priority ) ); ?></span>
			</span>
		</div>

		<ul class="bmc-meta-list">
			<li>
				<span><?php echo bmc_get_icon( 'category', array( 'size' => 15 ) ); ?> دسته</span>
				<strong><?php echo esc_html( BMC_Tickets::category_label( $bmc_ticket->category ) ); ?></strong>
			</li>
			<li>
				<span><?php echo bmc_get_icon( 'inventory_2', array( 'size' => 15 ) ); ?> محصول</span>
				<strong><?php echo $bmc_product ? esc_html( $bmc_product ) : 'موضوع عمومی'; ?></strong>
			</li>
			<?php if ( (int) $bmc_ticket->order_id ) : ?>
				<li>
					<span><?php echo bmc_get_icon( 'receipt_long', array( 'size' => 15 ) ); ?> سفارش</span>
					<strong>#<?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_ticket->order_id ) ); ?></strong>
				</li>
			<?php endif; ?>
			<li>
				<span><?php echo bmc_get_icon( 'calendar_month', array( 'size' => 15 ) ); ?> ثبت</span>
				<strong><?php echo esc_html( BMC_Jalali::format( $bmc_ticket->created_at ) ); ?></strong>
			</li>
			<li>
				<span><?php echo bmc_get_icon( 'update', array( 'size' => 15 ) ); ?> آخرین پاسخ</span>
				<strong><?php echo esc_html( BMC_Jalali::format( $bmc_ticket->updated_at ) ); ?></strong>
			</li>
		</ul>
	</div>

	<div class="bmc-tk-thread">
		<?php if ( empty( $bmc_messages ) ) : ?>
			<p class="bmc-hint">پیامی ثبت نشده است.</p>
		<?php else : ?>
			<?php foreach ( $bmc_messages as $bmc_message ) : ?>
				<?php
				$bmc_is_note  = ! empty( $bmc_message->is_note );
				$bmc_is_staff_msg = ! empty( $bmc_message->is_staff );
				$bmc_class    = $bmc_is_note ? 'bmc-bubble bmc-bubble--note' : ( $bmc_is_staff_msg ? 'bmc-bubble bmc-bubble--staff' : 'bmc-bubble bmc-bubble--user' );
				?>
				<div class="<?php echo esc_attr( $bmc_class ); ?>">
					<div class="bmc-bubble__head">
						<strong><?php echo esc_html( '' !== $bmc_message->author ? $bmc_message->author : ( $bmc_is_staff_msg ? 'پشتیبانی' : 'شما' ) ); ?></strong>
						<?php if ( $bmc_is_note ) : ?>
							<span class="bmc-tag"><?php echo bmc_get_icon( 'visibility', array( 'size' => 13 ) ); ?> یادداشت داخلی</span>
						<?php elseif ( $bmc_is_staff_msg ) : ?>
							<span class="bmc-tag bmc-tag-ok"><?php echo bmc_get_icon( 'support_agent', array( 'size' => 13 ) ); ?> پشتیبانی</span>
						<?php endif; ?>
						<time><?php echo esc_html( BMC_Jalali::format( $bmc_message->created_at ) ); ?></time>
					</div>
					<div class="bmc-bubble__body"><?php echo wp_kses_post( nl2br( esc_html( (string) $bmc_message->body ) ) ); ?></div>
				</div>
			<?php endforeach; ?>
		<?php endif; ?>
	</div>

	<?php if ( $bmc_closed && ! $bmc_is_staff && ! BMC_Settings::bool( 'tickets_user_reopen', true ) ) : ?>
		<div class="bmc-alert bmc-alert--info">
			<?php echo bmc_get_icon( 'lock', array( 'size' => 18 ) ); ?>
			این تیکت بسته شده است. برای پیگیری مجدد، تیکت جدیدی ثبت کنید.
		</div>
	<?php else : ?>
		<form method="post" action="<?php echo esc_url( $bmc_self_url ); ?>" class="bmc-card bmc-tk-reply">
			<?php wp_nonce_field( BMC_Tickets::NONCE, 'bmc_ticket_nonce' ); ?>
			<input type="hidden" name="bmc_ticket_action" value="reply" />
			<input type="hidden" name="ticket_id" value="<?php echo esc_attr( (int) $bmc_ticket->id ); ?>" />

			<h3 class="bmc-card__title"><?php echo bmc_get_icon( 'reply', array( 'size' => 18 ) ); ?> <?php echo $bmc_is_staff ? 'پاسخ پشتیبانی' : 'پاسخ شما'; ?></h3>

			<div class="bmc-field">
				<textarea class="bmc-input" name="ticket_body" rows="5" required placeholder="متن پاسخ خود را بنویسید…"></textarea>
			</div>

			<?php if ( $bmc_is_staff ) : ?>
				<label class="bmc-check">
					<input type="checkbox" name="as_staff" value="1" checked />
					<span>از طرف پشتیبانی ارسال شود</span>
				</label>
			<?php endif; ?>

			<div class="bmc-tk-reply__foot">
				<button type="submit" class="bmc-btn"><?php echo bmc_get_icon( 'send', array( 'size' => 17 ) ); ?> ارسال پاسخ</button>
			</div>
		</form>

		<?php if ( $bmc_can_close ) : ?>
			<form method="post" action="<?php echo esc_url( $bmc_self_url ); ?>" class="bmc-tk-close" onsubmit="return 'reopen' === this.bmc_ticket_action.value || window.confirm('آیا از بستن این تیکت مطمئن هستید؟');">
				<?php wp_nonce_field( BMC_Tickets::NONCE, 'bmc_ticket_nonce' ); ?>
				<input type="hidden" name="bmc_ticket_action" value="<?php echo $bmc_closed ? 'reopen' : 'close'; ?>" />
				<input type="hidden" name="ticket_id" value="<?php echo esc_attr( (int) $bmc_ticket->id ); ?>" />

				<button type="submit" class="bmc-btn bmc-btn--ghost bmc-btn--sm">
					<?php echo $bmc_closed
						? bmc_get_icon( 'refresh', array( 'size' => 16 ) ) . ' بازکردن دوبارهٔ تیکت'
						: bmc_get_icon( 'lock', array( 'size' => 16 ) ) . ' بستن تیکت'; ?>
				</button>
			</form>
		<?php endif; ?>
	<?php endif; ?>
</div>
