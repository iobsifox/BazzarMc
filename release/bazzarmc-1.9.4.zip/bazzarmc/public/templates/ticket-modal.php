<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$user_id = get_current_user_id();
if ( ! $user_id ) {
	return;
}

$theme_class = 'light' === BMC_Settings::get( 'checkout_theme' ) ? ' bmc-tmodal--light' : '';

if ( ! empty( $modal_root ) ) :
	$categories       = class_exists( 'BMC_Tickets' ) ? BMC_Tickets::categories() : array();
	$order_products   = class_exists( 'BMC_Tickets' ) && method_exists( 'BMC_Tickets', 'user_order_product_choices' )
		? BMC_Tickets::user_order_product_choices( $user_id )
		: array();
	$general_products = class_exists( 'BMC_Tickets' ) ? BMC_Tickets::product_choices( $user_id, false ) : array();
	?>
	<div class="bmc-tmodal<?php echo esc_attr( $theme_class ); ?>" id="bmcTicketNewModal" dir="rtl" role="dialog" aria-modal="true" aria-labelledby="bmcTicketNewModalTitle" hidden>
		<div class="bmc-tmodal__scrim" data-bmc-tmodal-close></div>
		<div class="bmc-tmodal__panel">
			<div class="bmc-tmodal__bar">
				<span class="bmc-tmodal__bar-icon"><?php bmc_icon( 'note_add', array( 'size' => 18 ) ); ?></span>
				<h3 class="bmc-tmodal__title" id="bmcTicketNewModalTitle">ثبت تیکت پشتیبانی جدید</h3>
				<button type="button" class="bmc-tmodal__close" data-bmc-tmodal-close aria-label="بستن">
					<?php bmc_icon( 'close', array( 'size' => 18 ) ); ?>
				</button>
			</div>

			<form class="bmc-tmodal__body" id="bmcNewTicketModalForm" novalidate>
				<div class="bmc-field-row">
					<div class="bmc-field">
						<label class="bmc-label" for="bmc-modal-ticket-category">دستهٔ درخواست <span class="bmc-req">*</span></label>
						<select class="bmc-input" id="bmc-modal-ticket-category" name="ticket_category" required>
							<?php foreach ( $categories as $cat_k => $cat_m ) : ?>
								<option value="<?php echo esc_attr( $cat_k ); ?>"><?php echo esc_html( $cat_m['label'] ); ?></option>
							<?php endforeach; ?>
						</select>
					</div>

					<div class="bmc-field">
						<label class="bmc-label" for="bmc-modal-ticket-product-order">محصول یا سفارش مرتبط</label>
						<select class="bmc-input" id="bmc-modal-ticket-product-order" name="ticket_product_order">
							<option value="">— موضوع عمومی (بدون سفارش خاص) —</option>
							<?php if ( ! empty( $order_products ) ) : ?>
								<optgroup label="خریدهای قبلی شما">
									<?php foreach ( $order_products as $op_row ) : ?>
										<option value="<?php echo esc_attr( $op_row['key'] ); ?>" data-order-id="<?php echo esc_attr( $op_row['order_id'] ); ?>">
											<?php echo esc_html( $op_row['label'] ); ?>
										</option>
									<?php endforeach; ?>
								</optgroup>
							<?php endif; ?>
							<?php if ( ! empty( $general_products ) ) : ?>
								<optgroup label="سایر محصولات فروشگاه">
									<?php foreach ( $general_products as $gp_id => $gp_name ) : ?>
										<option value="<?php echo esc_attr( 'p:' . $gp_id ); ?>">
											<?php echo esc_html( $gp_name ); ?>
										</option>
									<?php endforeach; ?>
								</optgroup>
							<?php endif; ?>
						</select>
					</div>
				</div>

				<div class="bmc-field">
					<label class="bmc-label" for="bmc-modal-ticket-subject">موضوع تیکت <span class="bmc-req">*</span></label>
					<input class="bmc-input" type="text" id="bmc-modal-ticket-subject" name="ticket_subject" maxlength="150" required placeholder="مثلاً: مشکل در تحویل رنک یا راهنمایی خرید" />
				</div>

				<div class="bmc-field">
					<label class="bmc-label" for="bmc-modal-ticket-body">شرح درخواست و توضیحات <span class="bmc-req">*</span></label>
					<textarea class="bmc-input" id="bmc-modal-ticket-body" name="ticket_body" rows="5" required placeholder="توضیحات کامل مشکل خود، نام کاربری ماینکرافت یا شماره سفارش را بنویسید…"></textarea>
				</div>

				<div class="bmc-tmodal__notice">
					<?php bmc_icon( 'info', array( 'size' => 15 ) ); ?>
					<span>پاسخ کارشناسان پشتیبانی در همین بخش ثبت شده و از طریق ایمیل نیز به شما اطلاع‌رسانی خواهد شد.</span>
				</div>

				<div class="bmc-tmodal__error-box" id="bmcNewTicketError" style="display:none;"></div>

				<div class="bmc-tmodal__actions">
					<button type="submit" class="bmc-btn bmc-btn-p" id="bmcNewTicketSubmitBtn">
						<span class="bmc-btn__icon"><?php bmc_icon( 'send', array( 'size' => 16 ) ); ?></span>
						<span class="bmc-btn__text">ثبت و ارسال تیکت</span>
					</button>
					<button type="button" class="bmc-btn bmc-btn-o" data-bmc-tmodal-close>
						انصراف
					</button>
				</div>
			</form>
		</div>
	</div>

	<div class="bmc-tmodal<?php echo esc_attr( $theme_class ); ?>" id="bmcTicketViewModal" dir="rtl" role="dialog" aria-modal="true" aria-labelledby="bmcTicketViewModalTitle" hidden>
		<div class="bmc-tmodal__scrim" data-bmc-tmodal-close></div>
		<div class="bmc-tmodal__panel">
			<div class="bmc-tmodal__bar">
				<span class="bmc-tmodal__bar-icon"><?php bmc_icon( 'forum', array( 'size' => 18 ) ); ?></span>
				<h3 class="bmc-tmodal__title" id="bmcTicketViewModalTitle">گفت‌وگوی تیکت</h3>
				<button type="button" class="bmc-tmodal__close" data-bmc-tmodal-close aria-label="بستن">
					<?php bmc_icon( 'close', array( 'size' => 18 ) ); ?>
				</button>
			</div>

			<div class="bmc-tmodal__body" id="bmcTicketViewModalBody">
				<div class="bmc-tmodal__loading">
					<span class="bmc-tmodal__spinner"></span>
					<span>در حال بارگذاری گفت‌وگو…</span>
				</div>
			</div>
		</div>
	</div>
	<?php
	return;
endif;

if ( empty( $ticket ) || ! is_object( $ticket ) ) :
	?>
	<div class="bmc-tmodal__error">
		<?php bmc_icon( 'error', array( 'size' => 20 ) ); ?>
		<span>تیکت مورد نظر یافت نشد یا دسترسی به آن ندارید.</span>
	</div>
	<?php
	return;
endif;

$ticket_id    = (int) $ticket->id;
$status_meta  = BMC_Tickets::status_meta( $ticket->status );
$product_name = BMC_Tickets::ticket_product_name( $ticket );
$is_closed    = 'closed' === $ticket->status;
$can_close    = current_user_can( 'manage_woocommerce' ) || BMC_Settings::bool( 'tickets_user_close', true );
$can_reopen   = current_user_can( 'manage_woocommerce' ) || BMC_Settings::bool( 'tickets_user_reopen', true );
?>

<div class="bmc-tmodal__grid-meta">
	<div class="bmc-tmodal__meta-card">
		<small><?php bmc_icon( 'tag', array( 'size' => 14 ) ); ?> کد پیگیری</small>
		<strong><code><?php echo esc_html( BMC_Tickets::reference( $ticket_id ) ); ?></code></strong>
	</div>

	<div class="bmc-tmodal__meta-card">
		<small><?php bmc_icon( 'schedule', array( 'size' => 14 ) ); ?> وضعیت تیکت</small>
		<div>
			<span class="bmc-pill bmc-pill--<?php echo esc_attr( isset( $status_meta['tone'] ) ? $status_meta['tone'] : 'blue' ); ?>" id="bmcTicketStatusBadge">
				<?php bmc_icon( $status_meta['icon'], array( 'size' => 13 ) ); ?>
				<?php echo esc_html( $status_meta['label'] ); ?>
			</span>
		</div>
	</div>

	<div class="bmc-tmodal__meta-card">
		<small><?php bmc_icon( 'category', array( 'size' => 14 ) ); ?> دستهٔ درخواست</small>
		<strong><?php echo esc_html( BMC_Tickets::category_label( $ticket->category ) ); ?></strong>
	</div>

	<div class="bmc-tmodal__meta-card">
		<small><?php bmc_icon( 'inventory_2', array( 'size' => 14 ) ); ?> محصول / سفارش</small>
		<strong>
			<?php
			if ( $product_name ) {
				echo esc_html( $product_name );
				if ( (int) $ticket->order_id ) {
					echo ' (#' . esc_html( BMC_Helpers::to_persian_digits( (int) $ticket->order_id ) ) . ')';
				}
			} elseif ( (int) $ticket->order_id ) {
				echo 'سفارش #' . esc_html( BMC_Helpers::to_persian_digits( (int) $ticket->order_id ) );
			} else {
				echo 'موضوع عمومی';
			}
			?>
		</strong>
	</div>
</div>

<div class="bmc-tmodal__box">
	<h4 class="bmc-tmodal__box-title">
		<?php bmc_icon( 'subject', array( 'size' => 16 ) ); ?>
		<?php echo esc_html( $ticket->subject ); ?>
	</h4>
	<div class="bmc-tmodal__meta-dates">
		<span><?php bmc_icon( 'calendar_month', array( 'size' => 13 ) ); ?> ثبت: <?php echo esc_html( BMC_Jalali::format( $ticket->created_at, true ) ); ?></span>
		<span><?php bmc_icon( 'update', array( 'size' => 13 ) ); ?> آخرین به‌روزرسانی: <?php echo esc_html( BMC_Jalali::format( $ticket->updated_at, true ) ); ?></span>
	</div>
</div>

<div class="bmc-tk-thread" id="bmcTicketThread">
	<?php if ( empty( $messages ) ) : ?>
		<p class="bmc-hint">پیامی ثبت نشده است.</p>
	<?php else : ?>
		<?php foreach ( (array) $messages as $msg ) : ?>
			<?php
			$is_note      = ! empty( $msg->is_note );
			$is_staff_msg = ! empty( $msg->is_staff );
			$bubble_class = $is_note ? 'bmc-bubble bmc-bubble--note' : ( $is_staff_msg ? 'bmc-bubble bmc-bubble--staff' : 'bmc-bubble bmc-bubble--user' );
			?>
			<div class="<?php echo esc_attr( $bubble_class ); ?>">
				<div class="bmc-bubble__head">
					<strong><?php echo esc_html( '' !== $msg->author ? $msg->author : ( $is_staff_msg ? 'پشتیبانی' : 'شما' ) ); ?></strong>
					<?php if ( $is_note ) : ?>
						<span class="bmc-tag"><?php bmc_icon( 'visibility', array( 'size' => 13 ) ); ?> یادداشت داخلی</span>
					<?php elseif ( $is_staff_msg ) : ?>
						<span class="bmc-tag bmc-tag-ok"><?php bmc_icon( 'support_agent', array( 'size' => 13 ) ); ?> پشتیبانی</span>
					<?php endif; ?>
					<time><?php echo esc_html( BMC_Jalali::format( $msg->created_at, true ) ); ?></time>
				</div>
				<div class="bmc-bubble__body"><?php echo wp_kses_post( nl2br( esc_html( (string) $msg->body ) ) ); ?></div>
			</div>
		<?php endforeach; ?>
	<?php endif; ?>
</div>

<div class="bmc-tmodal__reply-section" id="bmcTicketReplySection">
	<?php if ( $is_closed ) : ?>
		<div class="bmc-alert bmc-alert--info" style="margin-bottom:12px;">
			<?php bmc_icon( 'lock', array( 'size' => 18 ) ); ?>
			این تیکت بسته شده است.
		</div>

		<?php if ( $can_reopen ) : ?>
			<div class="bmc-tmodal__actions">
				<button type="button" class="bmc-btn bmc-btn-o bmc-ticket-reopen-btn" data-ticket-id="<?php echo esc_attr( $ticket_id ); ?>">
					<?php bmc_icon( 'refresh', array( 'size' => 15 ) ); ?>
					بازکردن دوبارهٔ تیکت
				</button>
			</div>
		<?php endif; ?>
	<?php else : ?>
		<form class="bmc-card bmc-tk-reply" id="bmcReplyTicketModalForm" style="margin:0;">
			<input type="hidden" name="ticket_id" value="<?php echo esc_attr( $ticket_id ); ?>" />

			<h4 class="bmc-card__title" style="margin-bottom:10px;">
				<?php bmc_icon( 'reply', array( 'size' => 17 ) ); ?>
				ادامهٔ گفت‌وگو و ارسال پاسخ
			</h4>

			<div class="bmc-field">
				<textarea class="bmc-input" name="ticket_reply_body" id="bmcTicketReplyBody" rows="4" required placeholder="پاسخ خود را اینجا بنویسید…"></textarea>
			</div>

			<div class="bmc-tmodal__error-box" id="bmcReplyTicketError" style="display:none;"></div>

			<div class="bmc-tk-reply__foot" style="display:flex;align-items:center;gap:10px;justify-content:space-between;flex-wrap:wrap;">
				<button type="submit" class="bmc-btn bmc-btn-p" id="bmcReplySubmitBtn">
					<span class="bmc-btn__icon"><?php bmc_icon( 'send', array( 'size' => 16 ) ); ?></span>
					<span class="bmc-btn__text">ارسال پاسخ</span>
				</button>

				<?php if ( $can_close ) : ?>
					<button type="button" class="bmc-btn bmc-btn-o bmc-btn-danger bmc-ticket-close-btn" data-ticket-id="<?php echo esc_attr( $ticket_id ); ?>">
						<?php bmc_icon( 'lock', array( 'size' => 15 ) ); ?>
						بستن تیکت
					</button>
				<?php endif; ?>
			</div>
		</form>
	<?php endif; ?>
</div>
