<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Public {

	const ENDPOINT = 'minecraft';

	public static function init() {
		add_shortcode( 'bazzarmc', array( __CLASS__, 'shortcode_account' ) );
		add_shortcode( 'bazzarmc_account', array( __CLASS__, 'shortcode_account' ) );
		add_shortcode( 'bazzarmc_link', array( __CLASS__, 'shortcode_account' ) );
		add_shortcode( 'bazzarmc_status', array( __CLASS__, 'shortcode_status' ) );
		add_shortcode( 'bazzarmc_card', array( __CLASS__, 'shortcode_card' ) );
		add_shortcode( 'bazzarmc_nav', array( __CLASS__, 'shortcode_nav' ) );
		add_shortcode( 'bazzarmc_ranks', array( __CLASS__, 'shortcode_ranks' ) );
		add_shortcode( 'bazzarmc_deliveries', array( __CLASS__, 'shortcode_deliveries' ) );

		add_filter( 'woocommerce_locate_template', array( __CLASS__, 'locate_dashboard_template' ), 20, 3 );
		add_filter( 'woocommerce_locate_template', array( __CLASS__, 'locate_navigation_template' ), 20, 3 );

		add_action( 'wp_enqueue_scripts', array( __CLASS__, 'enqueue_assets' ), 15 );
	}

	public static function shortcode_account( $atts = array() ) {
		$bmc_blocked = self::blocked( 'بخش حساب کاربری موقتاً غیرفعال است' );

		if ( null !== $bmc_blocked ) {
			return $bmc_blocked;
		}

		$atts = shortcode_atts(
			array(
				'title'              => '',
				'steps'              => '',
				'step_1'             => '',
				'step_2'             => '',
				'step_3'             => '',
				'player_label'       => '',
				'player_placeholder' => '',
				'submit_text'        => '',
				'code_hint'          => '',
				'copy_text'          => '',
				'regen_text'         => '',
				'otp_card'           => '',
				'otp_title'          => '',
				'show_uuid'          => '',
				'show_linked_at'     => '',
				'show_shop_button'   => '',
				'show_unlink'        => '',
				'avatar_size'        => '',
				'width'              => '',
				'theme'              => '',
				'login_title'        => '',
				'login_body'         => '',
				'login_button'       => '',
			),
			$atts,
			'bazzarmc'
		);

		$bmc_map = array(
			'steps'    => 'steps_on',
			'otp_card' => 'otp_card_on',
		);

		foreach ( $bmc_map as $from => $to ) {
			if ( '' !== $atts[ $from ] ) {
				$atts[ $to ] = $atts[ $from ];
			}

			unset( $atts[ $from ] );
		}

		self::enqueue_base_assets();
		self::enqueue_link_assets();

		ob_start();
		$template = BMC_PATH . 'public/templates/link-box.php';

		if ( file_exists( $template ) ) {
			$bmc_atts = $atts;
			include $template;
		}

		return (string) ob_get_clean();
	}

	public static function shortcode_status( $atts = array() ) {
		$bmc_blocked = self::blocked( 'وضعیت اکانت موقتاً غیرفعال است' );

		if ( null !== $bmc_blocked ) {
			return $bmc_blocked;
		}

		self::enqueue_base_assets();

		if ( ! is_user_logged_in() ) {
			return '<div class="bmc-badge bmc-badge--warn" dir="rtl">برای مشاهدهٔ وضعیت اتصال وارد حساب شوید.</div>';
		}

		$player = BMC_Link::get_linked_player( get_current_user_id() );

		if ( ! $player ) {
			return '<div class="bmc-badge bmc-badge--warn" dir="rtl">اکانت ماینکرافت متصل نیست — <a href="' . esc_url( self::link_page_url() ) . '">اتصال</a></div>';
		}

		return '<div class="bmc-badge bmc-badge--ok" dir="rtl">'
			. '<img src="' . esc_url( BMC_Helpers::mc_head( $player, 24 ) ) . '" alt="" width="24" height="24" /> '
			. 'متصل به <strong>' . esc_html( $player ) . '</strong>'
			. '</div>';
	}

	public static function blocked( $title = 'این بخش موقتاً غیرفعال است' ) {
		if ( class_exists( 'BMC_Safe' ) && BMC_Safe::safe_mode() ) {
			return class_exists( 'BMC_Safe' ) ? BMC_Safe::blocked_box( $title ) : '';
		}

		return null;
	}

	public static function add_my_account_endpoint() {
		if ( class_exists( 'BMC_Account_Endpoints' ) ) {
			BMC_Account_Endpoints::register_endpoints();
		}
	}

	public static function my_account_menu( $items ) {
		if ( class_exists( 'BMC_Account_Endpoints' ) ) {
			return BMC_Account_Endpoints::menu_items( $items );
		}

		return $items;
	}

	public static function connect_endpoint() {
		return class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::slug( 'connect' ) : self::ENDPOINT;
	}

	public static function connect_title() {
		return class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::title( 'connect' ) : 'اتصال ماینکرافت';
	}

	public static function my_account_content() {
		echo self::guard_render(
			'account:connect',
			function () {
				return self::shortcode_account(
					array(
						'title' => '',
						'width' => 'full',
					)
				);
			},
			function () {
				return self::section_error( 'بخش اتصال اکانت ماینکرافت' );
			}
		);
	}

	public static function guard_render( $label, callable $callback, $fallback = '' ) {
		try {
			return (string) $callback();
		} catch ( \Throwable $error ) {
			if ( class_exists( 'BMC_Safe' ) ) {
				BMC_Safe::collect( $label, $error );
			}

			if ( class_exists( 'BMC_Logger' ) ) {
				BMC_Logger::add( 'public', 'خطای مهارشده در ' . $label . ': ' . $error->getMessage(), array( 'line' => $error->getLine() ), 'error' );
			}

			if ( is_callable( $fallback ) ) {
				try {
					$fallback = (string) $fallback();
				} catch ( \Throwable $inner ) {
					unset( $inner );
					$fallback = '';
				}
			}

			return (string) $fallback;
		}
	}

	public static function section_error( $section = 'این بخش' ) {
		return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">'
			. bmc_get_icon( 'warning', array( 'size' => 18 ) )
			. ' ' . esc_html( $section ) . ' در این درخواست نمایش داده نشد. لطفاً صفحه را تازه کنید؛ اگر مشکل ماند، مدیر سایت از بخش «ابزارها» گزارش خطا را ببیند.'
			. '</div></div>';
	}

	public static function link_page_url() {
		if ( class_exists( 'BMC_Account_Endpoints' ) ) {
			$url = (string) BMC_Account_Endpoints::url( 'connect' );

			if ( '' !== $url && false === strpos( $url, 'wc_get_account_endpoint_url' ) ) {
				return $url;
			}
		}

		$page_id = (int) BMC_Settings::get( 'page_link', 0 );

		if ( $page_id ) {
			return (string) get_permalink( $page_id );
		}

		return function_exists( 'wc_get_page_permalink' ) ? (string) wc_get_page_permalink( 'myaccount' ) : home_url( '/' );
	}

	public static function template( $name, array $vars = array() ) {
		$path = BMC_PATH . 'public/templates/' . $name . '.php';

		if ( ! file_exists( $path ) ) {
			return '';
		}

		ob_start();

		foreach ( $vars as $bmc_key => $bmc_value ) {
			$$bmc_key = $bmc_value;
		}

		include $path;

		return (string) ob_get_clean();
	}

	public static function render_account_card( array $args = array() ) {
		if ( ! is_user_logged_in() ) {
			return self::login_notice( 'برای مشاهدهٔ کارت حساب کاربری وارد حساب شوید.' );
		}

		self::enqueue_base_assets();

		return self::guard_render(
			'account:card',
			function () use ( $args ) {
				return self::template( 'account-card', array( 'bmc_card' => $args ) );
			}
		);
	}

	public static function render_account_nav( array $args = array() ) {
		if ( ! function_exists( 'wc_get_account_menu_items' ) ) {
			return '<div class="bmc-alert bmc-alert--warn">برای نمایش منوی حساب کاربری، ووکامرس باید فعال باشد.</div>';
		}

		if ( ! is_user_logged_in() ) {
			return self::login_notice( 'برای مشاهدهٔ منوی حساب کاربری وارد حساب شوید.' );
		}

		self::enqueue_base_assets();

		return self::guard_render(
			'account:nav',
			function () use ( $args ) {
				return self::template( 'account-nav', array( 'bmc_nav' => $args ) );
			},
			function () {
				return self::core_navigation_fallback();
			}
		);
	}

	public static function core_navigation_fallback() {
		if ( ! function_exists( 'wc_get_account_menu_items' ) ) {
			return '';
		}

		$html = '<nav class="woocommerce-MyAccount-navigation"><ul>';

		foreach ( (array) wc_get_account_menu_items() as $endpoint => $label ) {
			$html .= '<li><a href="' . esc_url( (string) wc_get_account_endpoint_url( $endpoint ) ) . '">' . esc_html( (string) $label ) . '</a></li>';
		}

		return $html . '</ul></nav>';
	}

	public static function render_account_content( $endpoint = 'current', array $args = array() ) {
		if ( ! is_user_logged_in() ) {
			return self::login_notice( 'برای مشاهدهٔ این بخش وارد حساب کاربری شوید.' );
		}

		return self::guard_render(
			'account:content:' . sanitize_key( (string) $endpoint ),
			function () use ( $endpoint, $args ) {
				return self::account_content_html( $endpoint, $args );
			},
			function () {
				return self::section_error( 'این بخش' );
			}
		);
	}

	private static function account_content_html( $endpoint = 'current', array $args = array() ) {
		self::enqueue_base_assets();

		$notices = '';

		if ( empty( $args['hide_notices'] ) ) {
			ob_start();
			do_action( 'woocommerce_output_all_notices' );
			$notices = (string) ob_get_clean();
		}

		$endpoint = '' === $endpoint ? 'current' : sanitize_key( (string) $endpoint );

		if ( 'current' === $endpoint ) {
			ob_start();

			if ( function_exists( 'woocommerce_account_content' ) ) {
				woocommerce_account_content();
			} else {
				do_action( 'woocommerce_account_content' );
			}

			return $notices . (string) ob_get_clean();
		}

		if ( 'dashboard' === $endpoint ) {
			ob_start();

			if ( function_exists( 'wc_get_template' ) ) {
				wc_get_template(
					'myaccount/dashboard.php',
					array(
						'current_user' => get_user_by( 'id', get_current_user_id() ),
					)
				);
			} else {
				do_action( 'woocommerce_account_content' );
			}

			return $notices . (string) ob_get_clean();
		}

		$value = get_query_var( $endpoint );

		if ( 'edit-address' === $endpoint && ! empty( $args['address'] ) ) {
			$value = sanitize_key( (string) $args['address'] );
		}

		if ( 'view-order' === $endpoint && ! empty( $args['order_id'] ) ) {
			$value = (int) $args['order_id'];
		}

		if ( in_array( $endpoint, array( 'connect', 'minecraft', 'mclink', 'mc-link' ), true ) ) {
			return $notices . self::shortcode_account( array( 'title' => '', 'width' => 'full' ) );
		}

		if ( has_action( 'woocommerce_account_' . $endpoint . '_endpoint' ) ) {
			ob_start();
			do_action( 'woocommerce_account_' . $endpoint . '_endpoint', $value );

			return $notices . (string) ob_get_clean();
		}

		if ( 'orders' === $endpoint ) {
			ob_start();
			if ( function_exists( 'woocommerce_account_orders' ) ) {
				woocommerce_account_orders( 1 );
			} elseif ( function_exists( 'wc_get_template' ) ) {
				wc_get_template( 'myaccount/orders.php', array( 'current_page' => 1 ) );
			}
			return $notices . (string) ob_get_clean();
		}

		if ( 'downloads' === $endpoint ) {
			ob_start();
			if ( function_exists( 'woocommerce_account_downloads' ) ) {
				woocommerce_account_downloads();
			} elseif ( function_exists( 'wc_get_template' ) ) {
				wc_get_template( 'myaccount/downloads.php' );
			}
			return $notices . (string) ob_get_clean();
		}

		if ( 'edit-account' === $endpoint ) {
			ob_start();
			if ( function_exists( 'woocommerce_account_edit_account' ) ) {
				woocommerce_account_edit_account();
			} elseif ( function_exists( 'wc_get_template' ) ) {
				wc_get_template( 'myaccount/form-edit-account.php' );
			}
			return $notices . (string) ob_get_clean();
		}

		if ( 'edit-address' === $endpoint ) {
			ob_start();
			if ( function_exists( 'woocommerce_account_edit_address' ) ) {
				woocommerce_account_edit_address( $value );
			} elseif ( function_exists( 'wc_get_template' ) ) {
				wc_get_template( 'myaccount/my-address.php', array( 'type' => $value ) );
			}
			return $notices . (string) ob_get_clean();
		}

		if ( 'payment-methods' === $endpoint ) {
			ob_start();
			if ( function_exists( 'woocommerce_account_payment_methods' ) ) {
				woocommerce_account_payment_methods();
			} elseif ( function_exists( 'wc_get_template' ) ) {
				wc_get_template( 'myaccount/payment-methods.php' );
			}
			return $notices . (string) ob_get_clean();
		}

		return $notices . '<div class="bmc-alert bmc-alert--warn">' . bmc_get_icon( 'warning', array( 'size' => 18 ) ) . ' بخش انتخاب‌شده در ووکامرس ثبت نشده است.</div>';
	}

	public static function render_ranks( array $args = array() ) {
		if ( ! is_user_logged_in() ) {
			return self::login_notice( 'برای مشاهدهٔ رنک‌ها وارد حساب کاربری شوید.' );
		}

		self::enqueue_base_assets();

		return self::template( 'ranks', array( 'bmc_ranks' => $args ) );
	}

	public static function render_deliveries( array $args = array() ) {
		if ( ! is_user_logged_in() ) {
			return self::login_notice( 'برای مشاهدهٔ تحویل‌ها وارد حساب کاربری شوید.' );
		}

		self::enqueue_base_assets();

		return self::template( 'deliveries', array( 'bmc_deliveries' => $args ) );
	}

	public static function login_notice( $text = '' ) {
		$login = function_exists( 'wc_get_page_permalink' ) ? (string) wc_get_page_permalink( 'myaccount' ) : (string) wp_login_url();
		$text  = '' === $text ? 'برای مشاهدهٔ این بخش وارد حساب کاربری شوید.' : (string) $text;

		return '<div class="bmc-alert bmc-alert--warn">'
			. bmc_get_icon( 'lock', array( 'size' => 18 ) )
			. ' ' . esc_html( $text )
			. ' <a href="' . esc_url( $login ) . '">ورود / ثبت‌نام</a></div>';
	}

	public static function shortcode_card( $atts = array() ) {
		$bmc_blocked = self::blocked( 'کارت حساب کاربری موقتاً غیرفعال است' );

		if ( null !== $bmc_blocked ) {
			return $bmc_blocked;
		}

		$atts = shortcode_atts(
			array(
				'title'   => '',
				'links'   => '',
				'layout'  => '',
				'context' => '',
				'box'     => '',
			),
			$atts,
			'bazzarmc_card'
		);

		$args = array();

		if ( '' !== trim( (string) $atts['title'] ) ) {
			$args['title'] = (string) $atts['title'];
		}

		if ( '' !== trim( (string) $atts['links'] ) ) {
			$args['link_items'] = array_map( 'sanitize_key', explode( ',', (string) $atts['links'] ) );
		}

		if ( in_array( $atts['layout'], array( 'grid', 'stack' ), true ) ) {
			$args['layout'] = $atts['layout'];
		}

		if ( '' !== trim( (string) $atts['context'] ) ) {
			$args['context'] = sanitize_key( (string) $atts['context'] );
		}

		if ( '' !== trim( (string) $atts['box'] ) ) {
			$args['context_box'] = ! in_array( strtolower( trim( (string) $atts['box'] ) ), array( 'no', 'false', '0', 'off' ), true );
		}

		return '<div class="bmc-wrap bmc-wrap--card" dir="rtl"><div class="bmc-container">' . self::render_account_card( $args ) . '</div></div>';
	}

	public static function shortcode_nav( $atts = array() ) {
		$bmc_blocked = self::blocked( 'منوی حساب کاربری موقتاً غیرفعال است' );

		if ( null !== $bmc_blocked ) {
			return $bmc_blocked;
		}

		$atts = shortcode_atts(
			array(
				'layout'     => 'vertical',
				'title'      => '',
				'mobile'     => '',
				'labels'     => '',
				'sticky'     => '',
				'breakpoint' => '',
			),
			$atts,
			'bazzarmc_nav'
		);

		$bmc_nav_args = array(
			'layout' => (string) $atts['layout'],
			'title'  => (string) $atts['title'],
		);

		if ( '' !== trim( (string) $atts['mobile'] ) ) {
			$bmc_nav_args['mobile'] = sanitize_key( (string) $atts['mobile'] );
		}

		if ( '' !== trim( (string) $atts['labels'] ) ) {
			$bmc_nav_args['mobile_labels'] = ! in_array( strtolower( trim( (string) $atts['labels'] ) ), array( 'no', 'false', '0', 'off' ), true );
		}

		if ( '' !== trim( (string) $atts['sticky'] ) ) {
			$bmc_nav_args['mobile_sticky'] = ! in_array( strtolower( trim( (string) $atts['sticky'] ) ), array( 'no', 'false', '0', 'off' ), true );
		}

		if ( '' !== trim( (string) $atts['breakpoint'] ) ) {
			$bmc_nav_args['breakpoint'] = absint( $atts['breakpoint'] );
		}

		return '<div class="bmc-wrap bmc-wrap--nav" dir="rtl"><div class="bmc-container bmc-container--narrow">'
			. self::render_account_nav( $bmc_nav_args ) . '</div></div>';
	}

	public static function shortcode_ranks( $atts = array() ) {
		$bmc_blocked = self::blocked( 'لیست رنک‌ها موقتاً غیرفعال است' );

		if ( null !== $bmc_blocked ) {
			return $bmc_blocked;
		}

		$atts = shortcode_atts( array( 'title' => '' ), $atts, 'bazzarmc_ranks' );

		return '<div class="bmc-wrap" dir="rtl"><div class="bmc-container">'
			. self::render_ranks( array( 'title' => (string) $atts['title'] ) ) . '</div></div>';
	}

	public static function shortcode_deliveries( $atts = array() ) {
		$bmc_blocked = self::blocked( 'صف تحویل موقتاً غیرفعال است' );

		if ( null !== $bmc_blocked ) {
			return $bmc_blocked;
		}

		$atts = shortcode_atts(
			array(
				'title'  => '',
				'status' => '',
				'limit'  => 10,
				'layout' => 'list',
			),
			$atts,
			'bazzarmc_deliveries'
		);

		return '<div class="bmc-wrap" dir="rtl"><div class="bmc-container">'
			. self::render_deliveries(
				array(
					'title'  => (string) $atts['title'],
					'status' => (string) $atts['status'],
					'limit'  => (int) $atts['limit'],
					'layout' => (string) $atts['layout'],
				)
			) . '</div></div>';
	}

	public static function enqueue_base_assets() {
		self::ensure_style( 'bmc-public', BMC_URL . 'assets/css/bmc-public.css', BMC_VERSION );
		self::ensure_script( 'bmc-icons', BMC_URL . 'assets/js/bmc-icons.js', array() );
		self::ensure_script( 'bmc-nav', BMC_URL . 'assets/js/bmc-nav.js', array( 'bmc-icons' ) );

		$frontend_data = array(
			'ajaxUrl'  => admin_url( 'admin-ajax.php' ),
			'nonce'    => wp_create_nonce( 'bmc_public' ),
			'loggedIn' => is_user_logged_in(),
		);
		self::localize( 'bmc-nav', 'bmcFrontend', $frontend_data );

		if ( BMC_Settings::bool( 'font_cdn', true ) ) {
			self::ensure_style( 'bmc-vazir', 'https://cdn.jsdelivr.net/gh/rastikerdar/vazirmatn@v33.003/Vazirmatn-font-face.css', '33.003' );
		}
	}

	private static function ensure_style( $handle, $src, $ver ) {
		if ( wp_style_is( $handle, 'done' ) || wp_style_is( $handle, 'enqueued' ) ) {
			return;
		}

		if ( ! did_action( 'wp_head' ) ) {
			wp_enqueue_style( $handle, $src, array(), $ver );
			return;
		}

		printf(
			'<link rel="stylesheet" id="%1$s-css" href="%2$s" media="all" />',
			esc_attr( $handle ),
			esc_url( $src )
		);
	}

	private static function ensure_script( $handle, $src, array $deps = array( 'jquery' ) ) {
		if ( wp_script_is( $handle, 'done' ) || wp_script_is( $handle, 'enqueued' ) ) {
			return;
		}

		if ( ! did_action( 'wp_footer' ) ) {
			wp_enqueue_script( $handle, $src, $deps, BMC_VERSION, true );
			return;
		}

		printf(
			'<script src="%1$s" id="%2$s-js" defer></script>',
			esc_url( $src ),
			esc_attr( $handle )
		);
	}

	public static function enqueue_link_assets() {
		self::ensure_script( 'bmc-link', BMC_URL . 'assets/js/bmc-link.js', array( 'jquery', 'bmc-icons' ) );

		$data = array(
			'ajaxUrl'     => admin_url( 'admin-ajax.php' ),
			'nonce'       => wp_create_nonce( 'bmc_frontend' ),
			'publicNonce' => wp_create_nonce( 'bmc_public' ),
			'loggedIn'    => is_user_logged_in(),
			'headUrl'     => BMC_Helpers::mc_head( '', 64 ),
			'i18n'        => array(
				'copied'        => 'کد کپی شد!',
				'copyError'     => 'کپی نشد؛ کد را دستی انتخاب کنید.',
				'expired'       => 'اعتبار کد تمام شد.',
				'connected'     => 'متصل شد!',
				'waiting'       => 'در انتظار ورود به بازی…',
				'confirmUnlink' => 'مطمئنید می‌خواهید اتصال اکانت ماینکرافت را قطع کنید؟',
			),
		);

		self::localize( 'bmc-link', 'bmcLink', $data );
	}

	private static function localize( $handle, $object, array $data ) {
		if ( function_exists( 'wp_localize_script' ) ) {
			wp_localize_script( $handle, $object, $data );
			return;
		}

		$json = function_exists( 'wp_json_encode' ) ? wp_json_encode( $data ) : json_encode( $data );

		if ( did_action( 'wp_head' ) || did_action( 'wp_footer' ) ) {
			printf(
				'<script>var %1$s = %2$s;</script>',
				esc_js( $object ),
				$json
			);
		}
	}

	public static function enqueue_assets() {
		$page_link = (int) BMC_Settings::get( 'page_link', 0 );
		$is_acct   = function_exists( 'is_account_page' ) && is_account_page();
		$need_link = ( $page_link && is_page( $page_link ) ) || $is_acct || ( class_exists( 'BMC_Account_Endpoints' ) && BMC_Account_Endpoints::is_current( 'connect' ) );
		$need_card = $is_acct && BMC_Settings::bool( 'myaccount_card', true );

		if ( is_singular() ) {
			$content = (string) get_post_field( 'post_content', get_the_ID() );

			foreach ( array( 'bazzarmc', 'bazzarmc_account', 'bazzarmc_link', 'bazzarmc_status' ) as $sc ) {
				if ( has_shortcode( $content, $sc ) ) {
					$need_link = true;
					break;
				}
			}
		}

		if ( $need_link ) {
			self::enqueue_base_assets();
			self::enqueue_link_assets();
		}

		if ( $need_card ) {
			self::enqueue_base_assets();
		}
	}

	public static function locate_navigation_template( $template, $template_name, $template_path = '' ) {
		unset( $template_path );

		if ( 'myaccount/navigation.php' !== $template_name ) {
			return $template;
		}

		if ( ! BMC_Settings::bool( 'nav_override', true ) ) {
			return $template;
		}

		if ( ! is_user_logged_in() ) {
			return $template;
		}

		$custom = BMC_PATH . 'public/templates/wc-navigation.php';

		return file_exists( $custom ) ? $custom : $template;
	}

	public static function locate_dashboard_template( $template, $template_name, $template_path = '' ) {
		if ( 'myaccount/dashboard.php' !== $template_name ) {
			return $template;
		}

		if ( ! BMC_Settings::bool( 'myaccount_card', true ) ) {
			return $template;
		}

		$custom = BMC_PATH . 'public/templates/wc-dashboard.php';

		return file_exists( $custom ) ? $custom : $template;
	}
}
