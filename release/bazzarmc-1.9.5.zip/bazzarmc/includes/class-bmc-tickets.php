<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Tickets {

	const ENDPOINT_LIST = 'bmc-tickets';
	const ENDPOINT_VIEW = 'bmc-ticket';
	const NONCE         = 'bmc_ticket_nonce';

	public static function init() {
		add_shortcode( 'bazzarmc_tickets', array( __CLASS__, 'shortcode_tickets' ) );
		add_shortcode( 'bazzarmc_ticket', array( __CLASS__, 'shortcode_ticket' ) );

		add_action( 'init', array( __CLASS__, 'handle_request' ), 20 );

		add_action( 'admin_post_bmc_ticket', array( __CLASS__, 'handle_admin_post' ) );

		add_action( 'wp_ajax_bmc_get_ticket_details', array( __CLASS__, 'ajax_get_ticket_details' ) );
		add_action( 'wp_ajax_bmc_create_ticket_ajax', array( __CLASS__, 'ajax_create_ticket' ) );
		add_action( 'wp_ajax_bmc_reply_ticket_ajax', array( __CLASS__, 'ajax_reply_ticket' ) );
		add_action( 'wp_ajax_bmc_close_ticket_ajax', array( __CLASS__, 'ajax_close_ticket' ) );
	}

	public static function enabled() {
		return (bool) BMC_Settings::bool( 'tickets_enabled', true );
	}

	public static function per_page() {
		return max( 5, min( 50, (int) BMC_Settings::get( 'tickets_per_page', 10 ) ) );
	}

	public static function statuses() {
		return array(
			'open'     => array( 'label' => 'باز', 'icon' => 'mark_email_unread', 'tone' => 'blue' ),
			'answered' => array( 'label' => 'پاسخ داده شد', 'icon' => 'mark_chat_read', 'tone' => 'green' ),
			'pending'  => array( 'label' => 'در انتظار شما', 'icon' => 'hourglass_top', 'tone' => 'amber' ),
			'closed'   => array( 'label' => 'بسته شده', 'icon' => 'lock', 'tone' => 'gray' ),
		);
	}

	public static function priorities() {
		return array(
			'low'    => array( 'label' => 'کم', 'icon' => 'trending_down', 'tone' => 'gray' ),
			'normal' => array( 'label' => 'معمولی', 'icon' => 'info', 'tone' => 'blue' ),
			'high'   => array( 'label' => 'زیاد', 'icon' => 'priority_high', 'tone' => 'amber' ),
			'urgent' => array( 'label' => 'فوری', 'icon' => 'flag', 'tone' => 'red' ),
		);
	}

	public static function categories() {
		return array(
			'product'  => array( 'label' => 'محصول خریداری‌شده', 'icon' => 'inventory_2' ),
			'delivery' => array( 'label' => 'تحویل در بازی', 'icon' => 'local_shipping' ),
			'rank'     => array( 'label' => 'رنک و مدت اعتبار', 'icon' => 'military_tech' ),
			'payment'  => array( 'label' => 'پرداخت و بازگشت وجه', 'icon' => 'payments' ),
			'account'  => array( 'label' => 'حساب کاربری و اتصال', 'icon' => 'badge' ),
			'other'    => array( 'label' => 'سایر موارد', 'icon' => 'help' ),
		);
	}

	public static function status_meta( $status ) {
		$all = self::statuses();

		return isset( $all[ $status ] ) ? $all[ $status ] : $all['open'];
	}

	public static function status_label( $status ) {
		$meta = self::status_meta( $status );

		return $meta['label'];
	}

	public static function priority_label( $priority ) {
		$all = self::priorities();

		return isset( $all[ $priority ] ) ? $all[ $priority ]['label'] : $all['normal']['label'];
	}

	public static function category_label( $category ) {
		$all = self::categories();

		return isset( $all[ $category ] ) ? $all[ $category ]['label'] : $all['other']['label'];
	}

	public static function table() {
		return BMC_DB::table( 'tickets' );
	}

	public static function messages_table() {
		return BMC_DB::table( 'ticket_messages' );
	}

	public static function reference( $id ) {
		return 'BMC-' . str_pad( (string) absint( $id ), 5, '0', STR_PAD_LEFT );
	}

	public static function get( $id ) {
		global $wpdb;

		$id = absint( $id );

		if ( ! $id ) {
			return null;
		}

		$table = self::table();

		return $wpdb->get_row( $wpdb->prepare( "SELECT * FROM {$table} WHERE id = %d", $id ) );
	}

	public static function messages( $ticket_id, $with_notes = true ) {
		global $wpdb;

		$ticket_id = absint( $ticket_id );
		$table     = self::messages_table();

		if ( ! $ticket_id ) {
			return array();
		}

		if ( $with_notes ) {
			return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE ticket_id = %d ORDER BY id ASC", $ticket_id ) );
		}

		return (array) $wpdb->get_results( $wpdb->prepare( "SELECT * FROM {$table} WHERE ticket_id = %d AND is_note = 0 ORDER BY id ASC", $ticket_id ) );
	}

	public static function can_access( $ticket, $user_id = null ) {
		if ( ! $ticket ) {
			return false;
		}

		$user_id = null === $user_id ? get_current_user_id() : absint( $user_id );

		if ( current_user_can( 'manage_woocommerce' ) ) {
			return true;
		}

		return $user_id && (int) $ticket->user_id === $user_id;
	}

	public static function parse_product_order_key( $key ) {
		$out = array(
			'product_id'   => 0,
			'variation_id' => 0,
			'order_id'     => 0,
		);

		$key = trim( (string) $key );

		if ( '' === $key ) {
			return $out;
		}

		if ( preg_match( '/p:(\d+)/', $key, $m ) ) {
			$out['product_id'] = (int) $m[1];
		}

		if ( preg_match( '/v:(\d+)/', $key, $m ) ) {
			$out['variation_id'] = (int) $m[1];
		}

		if ( preg_match( '/o:(\d+)/', $key, $m ) ) {
			$out['order_id'] = (int) $m[1];
		}

		if ( ! $out['product_id'] && ! $out['order_id'] && is_numeric( $key ) ) {
			$out['product_id'] = absint( $key );
		}

		return $out;
	}

	public static function create( array $args ) {
		global $wpdb;

		if ( ! self::enabled() ) {
			return new WP_Error( 'disabled', 'سامانهٔ تیکت غیرفعال است.' );
		}

		$user_id = absint( isset( $args['user_id'] ) ? $args['user_id'] : get_current_user_id() );

		if ( ! $user_id ) {
			return new WP_Error( 'login', 'برای ثبت تیکت وارد حساب کاربری شوید.' );
		}

		$subject = sanitize_text_field( (string) ( isset( $args['subject'] ) ? $args['subject'] : '' ) );
		$body    = sanitize_textarea_field( (string) ( isset( $args['body'] ) ? $args['body'] : '' ) );

		if ( function_exists( 'mb_strlen' ) ) {
			$subject_len = mb_strlen( $subject );
			$body_len    = mb_strlen( $body );
		} else {
			$subject_len = strlen( $subject );
			$body_len    = strlen( $body );
		}

		if ( $subject_len < 4 ) {
			return new WP_Error( 'subject', 'موضوع تیکت را کامل‌تر بنویسید (حداقل ۴ نویسه).' );
		}

		if ( $body_len < 10 ) {
			return new WP_Error( 'body', 'شرح درخواست را کامل‌تر بنویسید (حداقل ۱۰ نویسه).' );
		}

		$category          = sanitize_key( (string) ( isset( $args['category'] ) ? $args['category'] : 'other' ) );
		$product_order_str = isset( $args['product_order'] ) ? sanitize_text_field( (string) $args['product_order'] ) : '';
		$parsed_po         = self::parse_product_order_key( $product_order_str );

		$product_id = isset( $args['product_id'] ) && (int) $args['product_id'] ? absint( $args['product_id'] ) : $parsed_po['product_id'];
		$variation  = isset( $args['variation_id'] ) && (int) $args['variation_id'] ? absint( $args['variation_id'] ) : $parsed_po['variation_id'];
		$order_id   = isset( $args['order_id'] ) && (int) $args['order_id'] ? absint( $args['order_id'] ) : $parsed_po['order_id'];

		if ( $product_id && ! $order_id ) {
			$found = self::product_order_for( $user_id, $product_id );
			if ( $found ) {
				$order_id  = (int) $found['order_id'];
				$variation = (int) $found['variation_id'];
			}
		}

		if ( ! array_key_exists( $category, self::categories() ) ) {
			$category = 'other';
		}

		if ( BMC_Settings::bool( 'tickets_require_product', false ) && ! $product_id && 'product' === $category ) {
			return new WP_Error( 'product', 'محصول موردنظر را انتخاب کنید.' );
		}

		$max_open = (int) BMC_Settings::get( 'tickets_max_open', 0 );

		if ( $max_open > 0 ) {
			$open = self::counts( $user_id );
			$live = (int) $open['open'] + (int) $open['answered'] + (int) $open['pending'];

			if ( $live >= $max_open ) {
				return new WP_Error( 'limit', sprintf( 'حداکثر %s تیکت باز می‌توانید داشته باشید.', BMC_Helpers::to_persian_digits( $max_open ) ) );
			}
		}

		$now   = BMC_Helpers::local_datetime();
		$table = self::table();

		$inserted = $wpdb->insert(
			$table,
			array(
				'user_id'       => $user_id,
				'product_id'    => $product_id,
				'variation_id'  => $variation,
				'order_id'      => $order_id,
				'subject'       => $subject,
				'category'      => $category,
				'priority'      => 'normal',
				'status'        => 'open',
				'last_reply_by' => 'user',
				'replies'       => 1,
				'created_at'    => $now,
				'updated_at'    => $now,
			),
			array( '%d', '%d', '%d', '%d', '%s', '%s', '%s', '%s', '%s', '%d', '%s', '%s' )
		);

		if ( false === $inserted ) {
			return new WP_Error( 'db', 'ثبت تیکت ناموفق بود.' );
		}

		$ticket_id = (int) $wpdb->insert_id;

		$wpdb->update( $table, array( 'reference' => self::reference( $ticket_id ) ), array( 'id' => $ticket_id ) );

		self::insert_message(
			$ticket_id,
			array(
				'user_id'  => $user_id,
				'author'   => self::display_name( $user_id ),
				'is_staff' => 0,
				'is_note'  => 0,
				'body'     => $body,
			)
		);

		BMC_Logger::add( 'ticket', sprintf( 'تیکت %s توسط کاربر #%d ثبت شد.', self::reference( $ticket_id ), $user_id ), array( 'user' => $user_id ), 'info' );

		do_action( 'bmc_ticket_created', $ticket_id, $user_id );

		if ( BMC_Settings::bool( 'tickets_email_admin', true ) ) {
			self::mail_admin_new( $ticket_id );
		}

		return $ticket_id;
	}

	public static function insert_message( $ticket_id, array $args ) {
		global $wpdb;

		$ticket_id = absint( $ticket_id );

		if ( ! $ticket_id ) {
			return 0;
		}

		$body = sanitize_textarea_field( (string) ( isset( $args['body'] ) ? $args['body'] : '' ) );

		if ( '' === trim( $body ) ) {
			return 0;
		}

		$inserted = $wpdb->insert(
			self::messages_table(),
			array(
				'ticket_id'  => $ticket_id,
				'user_id'    => absint( isset( $args['user_id'] ) ? $args['user_id'] : 0 ),
				'author'     => sanitize_text_field( (string) ( isset( $args['author'] ) ? $args['author'] : '' ) ),
				'is_staff'   => empty( $args['is_staff'] ) ? 0 : 1,
				'is_note'    => empty( $args['is_note'] ) ? 0 : 1,
				'body'       => $body,
				'created_at' => BMC_Helpers::local_datetime(),
			),
			array( '%d', '%d', '%s', '%d', '%d', '%s', '%s' )
		);

		return false === $inserted ? 0 : (int) $wpdb->insert_id;
	}

	public static function add_message( $ticket_id, array $args ) {
		$ticket = self::get( $ticket_id );

		if ( ! $ticket ) {
			return new WP_Error( 'notfound', 'تیکت یافت نشد.' );
		}

		$is_staff   = ! empty( $args['is_staff'] );
		$is_note    = ! empty( $args['is_note'] );
		$message_id = self::insert_message( $ticket_id, $args );

		if ( ! $message_id ) {
			return new WP_Error( 'empty', 'متن پیام خالی است.' );
		}

		$table  = self::table();
		$update = array( 'updated_at' => BMC_Helpers::local_datetime() );

		if ( ! $is_note ) {
			$update['replies']       = (int) $ticket->replies + 1;
			$update['last_reply_by'] = $is_staff ? 'staff' : 'user';
		}

		if ( $is_staff && ! $is_note ) {
			$update['status'] = 'answered';
		} elseif ( ! $is_staff && 'closed' === $ticket->status && BMC_Settings::bool( 'tickets_user_reopen', true ) ) {
			$update['status'] = 'open';
		} elseif ( ! $is_staff && 'answered' === $ticket->status ) {
			$update['status'] = 'open';
		}

		if ( 'closed' === ( isset( $update['status'] ) ? $update['status'] : $ticket->status ) ) {
			$update['closed_at'] = BMC_Helpers::local_datetime();
		} elseif ( isset( $update['status'] ) ) {
			$update['closed_at'] = null;
		}

		self::update_row( (int) $ticket->id, $update );

		do_action( 'bmc_ticket_reply', (int) $ticket->id, $message_id, $is_staff, $is_note );

		if ( ! $is_note ) {
			if ( $is_staff && BMC_Settings::bool( 'tickets_email_user', true ) ) {
				self::mail_user_reply( (int) $ticket->id, $message_id );
			}

			if ( ! $is_staff && BMC_Settings::bool( 'tickets_email_admin', true ) ) {
				self::mail_admin_reply( (int) $ticket->id, $message_id );
			}
		}

		return $message_id;
	}

	private static function update_row( $ticket_id, array $data ) {
		global $wpdb;

		$formats = array();

		foreach ( array_keys( $data ) as $column ) {
			$formats[] = in_array( $column, array( 'replies', 'user_id', 'product_id', 'variation_id', 'order_id' ), true ) ? '%d' : '%s';
		}

		$wpdb->update( self::table(), $data, array( 'id' => absint( $ticket_id ) ), $formats, array( '%d' ) );
	}

	public static function set_status( $ticket_id, $status ) {
		$status = sanitize_key( (string) $status );

		if ( ! array_key_exists( $status, self::statuses() ) ) {
			return false;
		}

		$data = array(
			'status'     => $status,
			'updated_at' => BMC_Helpers::local_datetime(),
			'closed_at'  => 'closed' === $status ? BMC_Helpers::local_datetime() : null,
		);

		self::update_row( $ticket_id, $data );

		do_action( 'bmc_ticket_status', absint( $ticket_id ), $status );

		if ( 'closed' === $status && BMC_Settings::bool( 'tickets_email_user', true ) ) {
			self::mail_user_closed( absint( $ticket_id ) );
		}

		return true;
	}

	public static function set_priority( $ticket_id, $priority ) {
		$priority = sanitize_key( (string) $priority );

		if ( ! array_key_exists( $priority, self::priorities() ) ) {
			return false;
		}

		self::update_row(
			$ticket_id,
			array(
				'priority'   => $priority,
				'updated_at' => BMC_Helpers::local_datetime(),
			)
		);

		return true;
	}

	public static function set_product( $ticket_id, $product_id, $order_id = 0 ) {
		self::update_row(
			$ticket_id,
			array(
				'product_id' => absint( $product_id ),
				'order_id'   => absint( $order_id ),
				'updated_at' => BMC_Helpers::local_datetime(),
			)
		);

		return true;
	}

	public static function delete( $ticket_id ) {
		global $wpdb;

		$ticket_id = absint( $ticket_id );

		if ( ! $ticket_id ) {
			return false;
		}

		$wpdb->delete( self::messages_table(), array( 'ticket_id' => $ticket_id ), array( '%d' ) );
		$deleted = $wpdb->delete( self::table(), array( 'id' => $ticket_id ), array( '%d' ) );

		BMC_Logger::add( 'ticket', sprintf( 'تیکت #%d حذف شد.', $ticket_id ), array(), 'warning' );

		return (bool) $deleted;
	}

	public static function query( array $args = array() ) {
		global $wpdb;

		$defaults = array(
			'user_id'    => 0,
			'status'     => '',
			'category'   => '',
			'product_id' => 0,
			'search'     => '',
			'page'       => 1,
			'per_page'   => self::per_page(),
			'orderby'    => 'updated_at',
			'order'      => 'DESC',
		);

		$args   = wp_parse_args( $args, $defaults );
		$table  = self::table();
		$where  = array( '1=1' );
		$params = array();

		if ( $args['user_id'] ) {
			$where[]  = 'user_id = %d';
			$params[] = absint( $args['user_id'] );
		}

		if ( '' !== $args['status'] && array_key_exists( $args['status'], self::statuses() ) ) {
			$where[]  = 'status = %s';
			$params[] = $args['status'];
		}

		if ( '' !== $args['category'] && array_key_exists( $args['category'], self::categories() ) ) {
			$where[]  = 'category = %s';
			$params[] = $args['category'];
		}

		if ( $args['product_id'] ) {
			$where[]  = 'product_id = %d';
			$params[] = absint( $args['product_id'] );
		}

		if ( '' !== trim( (string) $args['search'] ) ) {
			$like     = '%' . $wpdb->esc_like( trim( (string) $args['search'] ) ) . '%';
			$where[]  = '(subject LIKE %s OR reference LIKE %s)';
			$params[] = $like;
			$params[] = $like;
		}

		$allowed_order = array( 'updated_at', 'created_at', 'id', 'status', 'priority' );
		$orderby       = in_array( $args['orderby'], $allowed_order, true ) ? $args['orderby'] : 'updated_at';
		$order         = 'ASC' === strtoupper( (string) $args['order'] ) ? 'ASC' : 'DESC';

		$per_page = max( 1, min( 100, (int) $args['per_page'] ) );
		$page     = max( 1, (int) $args['page'] );
		$offset   = ( $page - 1 ) * $per_page;

		$count_sql    = "SELECT COUNT(*) FROM {$table} WHERE " . implode( ' AND ', $where );
		$count_params = $params;
		$total        = ! empty( $count_params ) ? (int) $wpdb->get_var( $wpdb->prepare( $count_sql, $count_params ) ) : (int) $wpdb->get_var( $count_sql );

		$params[] = $per_page;
		$params[] = $offset;

		$sql  = "SELECT * FROM {$table} WHERE " . implode( ' AND ', $where ) . " ORDER BY {$orderby} {$order} LIMIT %d OFFSET %d";
		$rows = (array) $wpdb->get_results( $wpdb->prepare( $sql, $params ) );

		return array(
			'items'    => $rows,
			'total'    => $total,
			'page'     => $page,
			'pages'    => $per_page ? (int) ceil( $total / $per_page ) : 1,
			'per_page' => $per_page,
		);
	}

	public static function counts( $user_id = 0 ) {
		global $wpdb;

		$table  = self::table();
		$out    = array(
			'open'     => 0,
			'answered' => 0,
			'pending'  => 0,
			'closed'   => 0,
			'total'    => 0,
		);

		$user_id = absint( $user_id );
		$sql     = "SELECT status, COUNT(*) AS total FROM {$table}";
		$params  = array();

		if ( $user_id ) {
			$sql     .= ' WHERE user_id = %d GROUP BY status';
			$params[] = $user_id;
		} else {
			$sql .= ' GROUP BY status';
		}

		$rows = $params ? $wpdb->get_results( $wpdb->prepare( $sql, $params ) ) : $wpdb->get_results( $sql );

		foreach ( (array) $rows as $row ) {
			$row = (array) $row;

			if ( ! isset( $row['status'] ) ) {
				continue;
			}

			$status = (string) $row['status'];
			$count  = isset( $row['total'] ) ? (int) $row['total'] : 0;

			if ( isset( $out[ $status ] ) ) {
				$out[ $status ] = $count;
			}

			$out['total'] += $count;
		}

		return $out;
	}

	public static function unread_for_user( $user_id ) {
		global $wpdb;

		$user_id = absint( $user_id );

		if ( ! $user_id ) {
			return 0;
		}

		$table = self::table();

		return (int) $wpdb->get_var(
			$wpdb->prepare(
				"SELECT COUNT(*) FROM {$table} WHERE user_id = %d AND status IN ('answered','pending') AND last_reply_by = 'staff'",
				$user_id
			)
		);
	}

	public static function display_name( $user_id ) {
		$user = get_userdata( absint( $user_id ) );

		if ( ! $user ) {
			return 'کاربر';
		}

		$name = trim( $user->display_name );

		return '' !== $name ? $name : $user->user_login;
	}

	public static function user_products( $user_id ) {
		$user_id = absint( $user_id );
		$out     = array();
		$seen    = array();

		if ( ! $user_id || ! function_exists( 'wc_get_orders' ) ) {
			return $out;
		}

		$orders = wc_get_orders(
			array(
				'customer_id' => $user_id,
				'limit'       => 60,
				'status'      => array( 'completed', 'processing', 'on-hold' ),
				'orderby'     => 'date',
				'order'       => 'DESC',
			)
		);

		foreach ( (array) $orders as $order ) {
			foreach ( $order->get_items() as $item ) {
				$product_id   = (int) $item->get_product_id();
				$variation_id = (int) $item->get_variation_id();

				if ( ! $product_id ) {
					continue;
				}

				$key = $product_id . '-' . $variation_id;

				if ( isset( $seen[ $key ] ) ) {
					continue;
				}

				$seen[ $key ] = true;

				$out[] = array(
					'product_id'   => $product_id,
					'variation_id' => $variation_id,
					'order_id'     => (int) $order->get_id(),
					'order_number' => (string) $order->get_order_number(),
					'name'         => (string) $item->get_name(),
				);
			}
		}

		return $out;
	}

	public static function user_order_product_choices( $user_id ) {
		$user_id = absint( $user_id );
		$choices = array();

		if ( ! $user_id || ! function_exists( 'wc_get_orders' ) ) {
			return $choices;
		}

		$orders = wc_get_orders(
			array(
				'customer_id' => $user_id,
				'limit'       => 50,
				'status'      => array( 'completed', 'processing', 'on-hold' ),
				'orderby'     => 'date',
				'order'       => 'DESC',
			)
		);

		foreach ( (array) $orders as $order ) {
			if ( ! is_object( $order ) ) {
				continue;
			}
			$order_id     = (int) $order->get_id();
			$order_num    = method_exists( $order, 'get_order_number' ) ? $order->get_order_number() : $order_id;
			$date_created = method_exists( $order, 'get_date_created' ) ? $order->get_date_created() : null;
			$date_str     = ( $date_created && method_exists( $date_created, 'getTimestamp' ) ) ? BMC_Jalali::format( $date_created->getTimestamp(), false ) : '';

			$items = method_exists( $order, 'get_items' ) ? $order->get_items() : array();
			if ( empty( $items ) ) {
				$choices[] = array(
					'key'          => 'o:' . $order_id,
					'product_id'   => 0,
					'variation_id' => 0,
					'order_id'     => $order_id,
					'label'        => sprintf( 'سفارش #%s%s', BMC_Helpers::to_persian_digits( $order_num ), $date_str ? ' (' . $date_str . ')' : '' ),
				);
				continue;
			}

			foreach ( $items as $item ) {
				if ( ! is_object( $item ) ) {
					continue;
				}
				$pid  = method_exists( $item, 'get_product_id' ) ? (int) $item->get_product_id() : 0;
				$vid  = method_exists( $item, 'get_variation_id' ) ? (int) $item->get_variation_id() : 0;
				$name = method_exists( $item, 'get_name' ) ? (string) $item->get_name() : 'محصول';

				$choices[] = array(
					'key'          => 'p:' . $pid . '|v:' . $vid . '|o:' . $order_id,
					'product_id'   => $pid,
					'variation_id' => $vid,
					'order_id'     => $order_id,
					'label'        => sprintf( 'سفارش #%s — %s%s', BMC_Helpers::to_persian_digits( $order_num ), $name, $date_str ? ' (' . $date_str . ')' : '' ),
				);
			}
		}

		return $choices;
	}

	public static function product_choices( $user_id, $include_general = true ) {
		$choices = array();

		if ( $include_general ) {
			$choices[0] = 'موضوع عمومی (بدون محصول خاص)';
		}

		foreach ( self::user_products( $user_id ) as $row ) {
			$choices[ $row['product_id'] ] = sprintf(
				'%s%s',
				$row['name'],
				$row['order_number'] ? ' — سفارش ' . $row['order_number'] : ''
			);
		}

		if ( function_exists( 'wc_get_products' ) ) {
			$synced = array_map( 'absint', (array) BMC_Settings::get( 'sync_products', array() ) );

			foreach ( $synced as $pid ) {
				if ( ! $pid || isset( $choices[ $pid ] ) ) {
					continue;
				}

				$product = wc_get_product( $pid );

				if ( $product ) {
					$choices[ $pid ] = (string) $product->get_name();
				}
			}
		}

		return $choices;
	}

	public static function product_order_for( $user_id, $product_id ) {
		foreach ( self::user_products( $user_id ) as $row ) {
			if ( (int) $row['product_id'] === absint( $product_id ) ) {
				return $row;
			}
		}

		return null;
	}

	public static function url( $ticket_id = 0 ) {
		if ( class_exists( 'BMC_Account_Endpoints' ) ) {
			$url = (string) BMC_Account_Endpoints::view_url( $ticket_id );

			if ( $url ) {
				return $url;
			}
		}

		$page_id = (int) BMC_Settings::get( 'page_tickets', 0 );

		if ( $page_id ) {
			$url = (string) get_permalink( $page_id );

			return $ticket_id ? add_query_arg( 'ticket', absint( $ticket_id ), $url ) : $url;
		}

		return (string) wp_login_url();
	}

	public static function admin_url( $ticket_id = 0 ) {
		$args = array(
			'page' => 'bazzarmc',
			'tab'  => 'tickets',
		);

		if ( $ticket_id ) {
			$args['ticket'] = absint( $ticket_id );
		}

		return add_query_arg( $args, admin_url( 'admin.php' ) );
	}

	public static function add_endpoints() {
		if ( class_exists( 'BMC_Account_Endpoints' ) ) {
			BMC_Account_Endpoints::register_endpoints();
		}
	}

	public static function query_vars( $vars ) {
		if ( class_exists( 'BMC_Account_Endpoints' ) ) {
			return BMC_Account_Endpoints::query_vars( $vars );
		}

		$vars[] = self::ENDPOINT_LIST;
		$vars[] = self::ENDPOINT_VIEW;

		return $vars;
	}

	public static function endpoint_slug() {
		return class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::slug( 'tickets' ) : self::ENDPOINT_LIST;
	}

	public static function endpoint_title() {
		return class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::title( 'tickets' ) : 'تیکت پشتیبانی';
	}

	public static function menu_items( $items ) {
		if ( class_exists( 'BMC_Account_Endpoints' ) ) {
			return BMC_Account_Endpoints::menu_items( $items );
		}

		return $items;
	}

	public static function current_ticket_id() {
		$id = (int) get_query_var( self::ENDPOINT_VIEW );

		if ( $id ) {
			return $id;
		}

		return isset( $_GET['ticket'] ) ? absint( wp_unslash( $_GET['ticket'] ) ) : 0;
	}

	public static function render_list_endpoint() {
		echo self::guarded_render( 'tickets:list', 'shortcode_tickets' );
	}

	public static function render_view_endpoint() {
		echo self::guarded_render( 'tickets:view', 'shortcode_ticket' );
	}

	private static function guarded_render( $label, $method ) {
		try {
			return (string) self::$method();
		} catch ( \Throwable $error ) {
			if ( class_exists( 'BMC_Safe' ) ) {
				BMC_Safe::collect( $label, $error );
			}

			if ( class_exists( 'BMC_Logger' ) ) {
				BMC_Logger::add( 'tickets', 'خطای مهارشده در ' . $label . ': ' . $error->getMessage(), array( 'line' => $error->getLine() ), 'error' );
			}

			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">'
				. bmc_get_icon( 'warning', array( 'size' => 18 ) )
				. ' نمایش بخش تیکت در این درخواست ممکن نشد. لطفاً صفحه را تازه کنید.'
				. '</div></div>';
		}
	}

	public static function shortcode_tickets( $atts = array() ) {
		BMC_Public::enqueue_base_assets();

		if ( ! self::enabled() ) {
			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">سامانهٔ تیکت پشتیبانی غیرفعال است.</div></div>';
		}

		if ( ! is_user_logged_in() ) {
			$login = function_exists( 'wc_get_page_permalink' ) ? (string) wc_get_page_permalink( 'myaccount' ) : (string) wp_login_url();

			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">'
				. bmc_get_icon( 'lock', array( 'size' => 18 ) )
				. ' برای ثبت و پیگیری تیکت، ابتدا <a href="' . esc_url( $login ) . '">وارد حساب کاربری</a> شوید.</div></div>';
		}

		$id = self::current_ticket_id();

		if ( $id ) {
			return self::render_view( $id );
		}

		ob_start();

		$template = BMC_PATH . 'public/templates/tickets.php';

		if ( file_exists( $template ) ) {
			include $template;
		}

		return (string) ob_get_clean();
	}

	public static function shortcode_ticket( $atts = array() ) {
		BMC_Public::enqueue_base_assets();

		if ( ! self::enabled() ) {
			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">سامانهٔ تیکت پشتیبانی غیرفعال است.</div></div>';
		}

		if ( ! is_user_logged_in() ) {
			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">برای مشاهدهٔ تیکت وارد حساب کاربری شوید.</div></div>';
		}

		$atts = shortcode_atts( array( 'id' => 0 ), $atts, 'bazzarmc_ticket' );

		$id = absint( $atts['id'] );

		if ( ! $id ) {
			$id = self::current_ticket_id();
		}

		if ( ! $id ) {
			return self::shortcode_tickets();
		}

		return self::render_view( $id );
	}

	public static function render_view( $ticket_id ) {
		$ticket = self::get( $ticket_id );

		if ( ! $ticket || ! self::can_access( $ticket ) ) {
			return '<div class="bmc-wrap" dir="rtl"><div class="bmc-alert bmc-alert--warn">'
				. bmc_get_icon( 'warning', array( 'size' => 18 ) )
				. ' تیکت موردنظر یافت نشد یا دسترسی به آن ندارید.'
				. ' <a href="' . esc_url( self::url() ) . '">بازگشت به فهرست تیکت‌ها</a></div></div>';
		}

		ob_start();

		$bmc_ticket   = $ticket;
		$bmc_messages = self::messages( (int) $ticket->id, current_user_can( 'manage_woocommerce' ) );
		$template     = BMC_PATH . 'public/templates/ticket-view.php';

		if ( file_exists( $template ) ) {
			include $template;
		}

		return (string) ob_get_clean();
	}

	public static function ajax_get_ticket_details() {
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';

		if ( '' !== $nonce && ! wp_verify_nonce( $nonce, 'bmc_public' ) && ! wp_verify_nonce( $nonce, 'bmc_frontend' ) ) {
			wp_send_json_error( array( 'message' => 'اعتبار نشست کاربری منقضی شده است. لطفاً صفحه را تازه‌سازی کنید.' ), 403 );
		}

		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => 'لطفاً ابتدا وارد حساب کاربری خود شوید.' ), 401 );
		}

		$ticket_id = isset( $_POST['ticket_id'] ) ? absint( $_POST['ticket_id'] ) : 0;

		if ( ! $ticket_id ) {
			wp_send_json_error( array( 'message' => 'شناسه تیکت نامعتبر است.' ), 400 );
		}

		$ticket = self::get( $ticket_id );

		if ( ! $ticket || ! self::can_access( $ticket ) ) {
			wp_send_json_error( array( 'message' => 'تیکت مورد نظر یافت نشد یا دسترسی به آن ندارید.' ), 403 );
		}

		$messages = self::messages( $ticket_id, current_user_can( 'manage_woocommerce' ) );

		$html = BMC_Public::template(
			'ticket-modal',
			array(
				'ticket'   => $ticket,
				'messages' => $messages,
			)
		);

		$status_meta = self::status_meta( $ticket->status );

		wp_send_json_success(
			array(
				'html'         => $html,
				'ticket_id'    => $ticket_id,
				'reference'    => self::reference( $ticket_id ),
				'title'        => 'گفت‌وگوی تیکت ' . self::reference( $ticket_id ),
				'status'       => $ticket->status,
				'status_label' => $status_meta['label'],
				'status_tone'  => $status_meta['tone'],
			)
		);
	}

	public static function ajax_create_ticket() {
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';

		if ( '' !== $nonce && ! wp_verify_nonce( $nonce, 'bmc_public' ) && ! wp_verify_nonce( $nonce, 'bmc_frontend' ) ) {
			wp_send_json_error( array( 'message' => 'اعتبار نشست کاربری منقضی شده است. لطفاً صفحه را تازه‌سازی کنید.' ), 403 );
		}

		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => 'لطفاً ابتدا وارد حساب کاربری خود شوید.' ), 401 );
		}

		$subject       = isset( $_POST['ticket_subject'] ) ? sanitize_text_field( wp_unslash( $_POST['ticket_subject'] ) ) : '';
		$body          = isset( $_POST['ticket_body'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ticket_body'] ) ) : '';
		$category      = isset( $_POST['ticket_category'] ) ? sanitize_key( wp_unslash( $_POST['ticket_category'] ) ) : 'other';
		$product_order = isset( $_POST['ticket_product_order'] ) ? sanitize_text_field( wp_unslash( $_POST['ticket_product_order'] ) ) : '';
		$order_id      = isset( $_POST['ticket_order_id'] ) ? absint( $_POST['ticket_order_id'] ) : 0;
		$product_id    = isset( $_POST['ticket_product_id'] ) ? absint( $_POST['ticket_product_id'] ) : 0;

		$created = self::create(
			array(
				'user_id'       => get_current_user_id(),
				'subject'       => $subject,
				'body'          => $body,
				'category'      => $category,
				'product_order' => $product_order,
				'order_id'      => $order_id,
				'product_id'    => $product_id,
			)
		);

		if ( is_wp_error( $created ) ) {
			wp_send_json_error( array( 'message' => $created->get_error_message() ), 400 );
		}

		$ticket_id = (int) $created;
		$ticket    = self::get( $ticket_id );
		$messages  = self::messages( $ticket_id, current_user_can( 'manage_woocommerce' ) );

		$html = BMC_Public::template(
			'ticket-modal',
			array(
				'ticket'   => $ticket,
				'messages' => $messages,
			)
		);

		$status_meta  = self::status_meta( $ticket->status );
		$product_name = self::ticket_product_name( $ticket );
		$created_date = BMC_Jalali::format( $ticket->created_at, false );

		wp_send_json_success(
			array(
				'message'        => 'تیکت شما با موفقیت ثبت شد.',
				'ticket_id'      => $ticket_id,
				'reference'      => self::reference( $ticket_id ),
				'subject'        => $ticket->subject,
				'category'       => $ticket->category,
				'category_label' => self::category_label( $ticket->category ),
				'product_name'   => $product_name,
				'date'           => $created_date,
				'title'          => 'گفت‌وگوی تیکت ' . self::reference( $ticket_id ),
				'view_url'       => self::url( $ticket_id ),
				'html'           => $html,
				'status'         => $ticket->status,
				'status_label'   => $status_meta['label'],
				'status_tone'    => $status_meta['tone'],
			)
		);
	}

	public static function ajax_reply_ticket() {
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';

		if ( '' !== $nonce && ! wp_verify_nonce( $nonce, 'bmc_public' ) && ! wp_verify_nonce( $nonce, 'bmc_frontend' ) ) {
			wp_send_json_error( array( 'message' => 'اعتبار نشست کاربری منقضی شده است. لطفاً صفحه را تازه‌سازی کنید.' ), 403 );
		}

		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => 'لطفاً ابتدا وارد حساب کاربری خود شوید.' ), 401 );
		}

		$ticket_id = isset( $_POST['ticket_id'] ) ? absint( $_POST['ticket_id'] ) : 0;
		$body      = isset( $_POST['ticket_reply_body'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ticket_reply_body'] ) ) : '';

		if ( ! $ticket_id ) {
			wp_send_json_error( array( 'message' => 'شناسه تیکت نامعتبر است.' ), 400 );
		}

		$ticket = self::get( $ticket_id );

		if ( ! $ticket || ! self::can_access( $ticket ) ) {
			wp_send_json_error( array( 'message' => 'تیکت مورد نظر یافت نشد یا دسترسی به آن ندارید.' ), 403 );
		}

		$is_staff = current_user_can( 'manage_woocommerce' );

		if ( 'closed' === $ticket->status && ! $is_staff && ! BMC_Settings::bool( 'tickets_user_reopen', true ) ) {
			wp_send_json_error( array( 'message' => 'این تیکت بسته شده است و امکان ارسال پاسخ وجود ندارد.' ), 400 );
		}

		$added = self::add_message(
			$ticket_id,
			array(
				'user_id'  => get_current_user_id(),
				'author'   => self::display_name( get_current_user_id() ),
				'is_staff' => $is_staff ? 1 : 0,
				'body'     => $body,
			)
		);

		if ( is_wp_error( $added ) ) {
			wp_send_json_error( array( 'message' => $added->get_error_message() ), 400 );
		}

		$ticket   = self::get( $ticket_id );
		$messages = self::messages( $ticket_id, $is_staff );

		$html = BMC_Public::template(
			'ticket-modal',
			array(
				'ticket'   => $ticket,
				'messages' => $messages,
			)
		);

		$status_meta = self::status_meta( $ticket->status );

		wp_send_json_success(
			array(
				'message'      => 'پاسخ شما با موفقیت ثبت شد.',
				'ticket_id'    => $ticket_id,
				'html'         => $html,
				'status'       => $ticket->status,
				'status_label' => $status_meta['label'],
				'status_tone'  => $status_meta['tone'],
			)
		);
	}

	public static function ajax_close_ticket() {
		$nonce = isset( $_POST['nonce'] ) ? sanitize_text_field( wp_unslash( $_POST['nonce'] ) ) : '';

		if ( '' !== $nonce && ! wp_verify_nonce( $nonce, 'bmc_public' ) && ! wp_verify_nonce( $nonce, 'bmc_frontend' ) ) {
			wp_send_json_error( array( 'message' => 'اعتبار نشست کاربری منقضی شده است. لطفاً صفحه را تازه‌سازی کنید.' ), 403 );
		}

		if ( ! is_user_logged_in() ) {
			wp_send_json_error( array( 'message' => 'لطفاً ابتدا وارد حساب کاربری خود شوید.' ), 401 );
		}

		$ticket_id   = isset( $_POST['ticket_id'] ) ? absint( $_POST['ticket_id'] ) : 0;
		$action_type = isset( $_POST['action_type'] ) ? sanitize_key( wp_unslash( $_POST['action_type'] ) ) : 'close';

		if ( ! $ticket_id ) {
			wp_send_json_error( array( 'message' => 'شناسه تیکت نامعتبر است.' ), 400 );
		}

		$ticket = self::get( $ticket_id );

		if ( ! $ticket || ! self::can_access( $ticket ) ) {
			wp_send_json_error( array( 'message' => 'تیکت مورد نظر یافت نشد یا دسترسی به آن ندارید.' ), 403 );
		}

		$is_staff = current_user_can( 'manage_woocommerce' );

		if ( 'close' === $action_type ) {
			if ( ! $is_staff && ! BMC_Settings::bool( 'tickets_user_close', true ) ) {
				wp_send_json_error( array( 'message' => 'امکان بستن تیکت توسط کاربر فعال نیست.' ), 403 );
			}
			self::set_status( $ticket_id, 'closed' );
			$msg = 'تیکت با موفقیت بسته شد.';
		} else {
			if ( ! $is_staff && ! BMC_Settings::bool( 'tickets_user_reopen', true ) ) {
				wp_send_json_error( array( 'message' => 'امکان بازکردن مجدد تیکت فعال نیست.' ), 403 );
			}
			self::set_status( $ticket_id, 'open' );
			$msg = 'تیکت دوباره باز شد.';
		}

		$ticket   = self::get( $ticket_id );
		$messages = self::messages( $ticket_id, $is_staff );

		$html = BMC_Public::template(
			'ticket-modal',
			array(
				'ticket'   => $ticket,
				'messages' => $messages,
			)
		);

		$status_meta = self::status_meta( $ticket->status );

		wp_send_json_success(
			array(
				'message'      => $msg,
				'ticket_id'    => $ticket_id,
				'html'         => $html,
				'status'       => $ticket->status,
				'status_label' => $status_meta['label'],
				'status_tone'  => $status_meta['tone'],
			)
		);
	}

	public static function handle_request() {
		if ( empty( $_POST['bmc_ticket_nonce'] ) ) {
			return;
		}

		if ( ! is_user_logged_in() ) {
			return;
		}

		check_admin_referer( self::NONCE, 'bmc_ticket_nonce' );

		$action = isset( $_POST['bmc_ticket_action'] ) ? sanitize_key( wp_unslash( $_POST['bmc_ticket_action'] ) ) : '';
		$result = '';
		$error  = '';
		$target = self::url();

		if ( 'create' === $action ) {
			$product_id = isset( $_POST['ticket_product'] ) ? absint( wp_unslash( $_POST['ticket_product'] ) ) : 0;
			$order      = self::product_order_for( get_current_user_id(), $product_id );

			$created = self::create(
				array(
					'user_id'      => get_current_user_id(),
					'subject'      => isset( $_POST['ticket_subject'] ) ? sanitize_text_field( wp_unslash( $_POST['ticket_subject'] ) ) : '',
					'body'         => isset( $_POST['ticket_body'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ticket_body'] ) ) : '',
					'category'     => isset( $_POST['ticket_category'] ) ? sanitize_key( wp_unslash( $_POST['ticket_category'] ) ) : 'other',
					'product_id'   => $product_id,
					'variation_id' => $order ? (int) $order['variation_id'] : 0,
					'order_id'     => isset( $_POST['ticket_order'] ) ? absint( wp_unslash( $_POST['ticket_order'] ) ) : ( $order ? (int) $order['order_id'] : 0 ),
				)
			);

			if ( is_wp_error( $created ) ) {
				$error = $created->get_error_message();
			} else {
				$result = 'created';
				$target = self::url( $created );
			}
		} elseif ( 'reply' === $action ) {
			$ticket_id = isset( $_POST['ticket_id'] ) ? absint( wp_unslash( $_POST['ticket_id'] ) ) : 0;
			$ticket    = self::get( $ticket_id );

			if ( ! $ticket || ! self::can_access( $ticket ) ) {
				$error = 'تیکت یافت نشد.';
			} else {
				$added = self::add_message(
					$ticket_id,
					array(
						'user_id'  => get_current_user_id(),
						'author'   => self::display_name( get_current_user_id() ),
						'is_staff' => current_user_can( 'manage_woocommerce' ) && ! empty( $_POST['as_staff'] ) ? 1 : 0,
						'body'     => isset( $_POST['ticket_body'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ticket_body'] ) ) : '',
					)
				);

				if ( is_wp_error( $added ) ) {
					$error = $added->get_error_message();
				} else {
					$result = 'replied';
				}
			}

			$target = self::url( $ticket_id );
		} elseif ( 'close' === $action || 'reopen' === $action ) {
			$ticket_id = isset( $_POST['ticket_id'] ) ? absint( wp_unslash( $_POST['ticket_id'] ) ) : 0;
			$ticket    = self::get( $ticket_id );

			if ( ! $ticket || ! self::can_access( $ticket ) ) {
				$error = 'تیکت یافت نشد.';
			} elseif ( ! current_user_can( 'manage_woocommerce' ) && ! BMC_Settings::bool( 'tickets_user_close', true ) ) {
				$error = 'امکان بستن تیکت توسط کاربر وجود ندارد.';
			} else {
				self::set_status( $ticket_id, 'close' === $action ? 'closed' : 'open' );
				$result = 'close' === $action ? 'closed' : 'reopened';
			}

			$target = self::url( $ticket_id );
		}

		if ( $error ) {
			$target = add_query_arg( 'bmc_ticket_error', rawurlencode( $error ), $target );
		} elseif ( $result ) {
			$target = add_query_arg( 'bmc_ticket_msg', $result, $target );
		}

		wp_safe_redirect( $target );
		exit;
	}

	public static function handle_admin_post() {
		if ( ! current_user_can( 'manage_woocommerce' ) ) {
			wp_die( 'دسترسی ندارید.' );
		}

		check_admin_referer( self::NONCE, 'bmc_ticket_nonce' );

		$action    = isset( $_POST['ticket_action'] ) ? sanitize_key( wp_unslash( $_POST['ticket_action'] ) ) : '';
		$ticket_id = isset( $_POST['ticket_id'] ) ? absint( wp_unslash( $_POST['ticket_id'] ) ) : 0;
		$message   = '';

		if ( 'reply' === $action && $ticket_id ) {
			$body = isset( $_POST['ticket_body'] ) ? sanitize_textarea_field( wp_unslash( $_POST['ticket_body'] ) ) : '';
			$note = ! empty( $_POST['is_note'] ) ? 1 : 0;

			$added = self::add_message(
				$ticket_id,
				array(
					'user_id'  => get_current_user_id(),
					'author'   => self::display_name( get_current_user_id() ),
					'is_staff' => 1,
					'is_note'  => $note,
					'body'     => $body,
				)
			);

			$message = is_wp_error( $added ) ? 'error' : ( $note ? 'note_added' : 'replied' );
		} elseif ( 'status' === $action && $ticket_id ) {
			$status  = isset( $_POST['ticket_status'] ) ? sanitize_key( wp_unslash( $_POST['ticket_status'] ) ) : '';
			$updated = self::set_status( $ticket_id, $status );
			$message = $updated ? 'status_updated' : 'error';
		} elseif ( 'priority' === $action && $ticket_id ) {
			$priority = isset( $_POST['ticket_priority'] ) ? sanitize_key( wp_unslash( $_POST['ticket_priority'] ) ) : '';
			$updated  = self::set_priority( $ticket_id, $priority );
			$message  = $updated ? 'priority_updated' : 'error';
		} elseif ( 'delete' === $action && $ticket_id ) {
			self::delete( $ticket_id );
			wp_safe_redirect( add_query_arg( array( 'page' => 'bazzarmc', 'tab' => 'tickets', 'bmc_msg' => 'deleted' ), admin_url( 'admin.php' ) ) );
			exit;
		}

		wp_safe_redirect( add_query_arg( array( 'bmc_msg' => $message ), self::admin_url( $ticket_id ) ) );
		exit;
	}

	public static function admin_email() {
		$email = sanitize_email( (string) BMC_Settings::get( 'tickets_admin_email', '' ) );

		if ( $email && is_email( $email ) ) {
			return $email;
		}

		return (string) get_option( 'admin_email' );
	}

	public static function mail( $to, $subject, $html ) {
		if ( ! is_email( $to ) ) {
			return false;
		}

		add_filter( 'wp_mail_content_type', array( __CLASS__, 'content_type_html' ) );

		$sent = wp_mail( $to, $subject, $html );

		remove_filter( 'wp_mail_content_type', array( __CLASS__, 'content_type_html' ) );

		return (bool) $sent;
	}

	public static function content_type_html() {
		return 'text/html';
	}

	public static function ticket_product_name( $ticket ) {
		if ( ! $ticket || ! (int) $ticket->product_id ) {
			return '';
		}

		if ( function_exists( 'wc_get_product' ) ) {
			$product = wc_get_product( (int) $ticket->variation_id ? (int) $ticket->variation_id : (int) $ticket->product_id );

			if ( $product ) {
				return (string) $product->get_name();
			}
		}

		return '';
	}

	public static function mail_admin_new( $ticket_id ) {
		$ticket = self::get( $ticket_id );

		if ( ! $ticket ) {
			return false;
		}

		$messages = self::messages( (int) $ticket->id, false );
		$first    = $messages ? (string) $messages[0]->body : '';
		$product  = self::ticket_product_name( $ticket );

		return self::mail(
			self::admin_email(),
			sprintf( 'تیکت جدید %s | %s', self::reference( $ticket->id ), get_bloginfo( 'name' ) ),
			self::mail_wrap(
				'تیکت پشتیبانی جدید ثبت شد',
				array(
					'<strong>کد تیکت:</strong> ' . esc_html( self::reference( $ticket->id ) ),
					'<strong>کاربر:</strong> ' . esc_html( self::display_name( (int) $ticket->user_id ) ) . ' (' . esc_html( get_userdata( (int) $ticket->user_id ) ? get_userdata( (int) $ticket->user_id )->user_email : '' ) . ')',
					'<strong>موضوع:</strong> ' . esc_html( $ticket->subject ),
					'<strong>دسته:</strong> ' . esc_html( self::category_label( $ticket->category ) ) . ( $product ? ' — محصول: ' . esc_html( $product ) : '' ),
					'<strong>متن:</strong><br />' . nl2br( esc_html( $first ) ),
				),
				self::admin_url( (int) $ticket->id ),
				'پاسخ در پیشخوان'
			)
		);
	}

	public static function mail_admin_reply( $ticket_id, $message_id ) {
		$ticket = self::get( $ticket_id );

		if ( ! $ticket ) {
			return false;
		}

		$body = self::message_body( $message_id );

		return self::mail(
			self::admin_email(),
			sprintf( 'پاسخ کاربر به تیکت %s | %s', self::reference( $ticket->id ), get_bloginfo( 'name' ) ),
			self::mail_wrap(
				'پاسخ جدید از طرف کاربر',
				array(
					'<strong>کد تیکت:</strong> ' . esc_html( self::reference( $ticket->id ) ),
					'<strong>کاربر:</strong> ' . esc_html( self::display_name( (int) $ticket->user_id ) ),
					'<strong>موضوع:</strong> ' . esc_html( $ticket->subject ),
					'<strong>پاسخ کاربر:</strong><br />' . nl2br( esc_html( $body ) ),
				),
				self::admin_url( (int) $ticket->id ),
				'مشاهده و پاسخ'
			)
		);
	}

	public static function mail_user_reply( $ticket_id, $message_id ) {
		$ticket = self::get( $ticket_id );

		if ( ! $ticket ) {
			return false;
		}

		$user = get_userdata( (int) $ticket->user_id );

		if ( ! $user || ! $user->user_email ) {
			return false;
		}

		$body = self::message_body( $message_id );

		return self::mail(
			$user->user_email,
			sprintf( 'پاسخ جدید به تیکت %s | %s', self::reference( $ticket->id ), get_bloginfo( 'name' ) ),
			self::mail_wrap(
				'پاسخ جدید از پشتیبانی دریافت شد',
				array(
					'سلام ' . esc_html( self::display_name( (int) $ticket->user_id ) ) . '،',
					'کارشناس پشتیبانی به تیکت شما پاسخ داد:',
					'<strong>کد تیکت:</strong> ' . esc_html( self::reference( $ticket->id ) ),
					'<strong>موضوع:</strong> ' . esc_html( $ticket->subject ),
					'<strong>متن پاسخ:</strong><br />' . nl2br( esc_html( $body ) ),
				),
				self::url( (int) $ticket->id ),
				'مشاهدهٔ پاسخ در سایت'
			)
		);
	}

	public static function mail_user_closed( $ticket_id ) {
		$ticket = self::get( $ticket_id );

		if ( ! $ticket ) {
			return false;
		}

		$user = get_userdata( (int) $ticket->user_id );

		if ( ! $user || ! $user->user_email ) {
			return false;
		}

		return self::mail(
			$user->user_email,
			sprintf( 'تیکت %s بسته شد | %s', self::reference( $ticket->id ), get_bloginfo( 'name' ) ),
			self::mail_wrap(
				'تیکت شما بسته شد',
				array(
					'سلام ' . esc_html( self::display_name( (int) $ticket->user_id ) ) . '،',
					'<strong>کد تیکت:</strong> ' . esc_html( self::reference( $ticket->id ) ),
					'<strong>موضوع:</strong> ' . esc_html( $ticket->subject ),
					'تیکت شما بسته شد. در صورت نیاز می‌توانید آن را دوباره باز کنید یا تیکت جدیدی ثبت کنید.',
				),
				self::url( (int) $ticket->id ),
				'مشاهدهٔ تیکت'
			)
		);
	}

	public static function message_body( $message_id ) {
		global $wpdb;

		$message_id = absint( $message_id );

		if ( ! $message_id ) {
			return '';
		}

		$table = self::messages_table();

		return (string) $wpdb->get_var( $wpdb->prepare( "SELECT body FROM {$table} WHERE id = %d", $message_id ) );
	}

	public static function flash() {
		$notices = array();

		if ( isset( $_GET['bmc_ticket_msg'] ) ) {
			$key  = sanitize_key( wp_unslash( $_GET['bmc_ticket_msg'] ) );
			$maps = array(
				'created'  => 'تیکت شما با موفقیت ثبت شد. به‌زودی پاسخ می‌دهیم.',
				'replied'  => 'پاسخ شما ثبت شد.',
				'closed'   => 'تیکت بسته شد.',
				'reopened' => 'تیکت دوباره باز شد.',
			);

			if ( isset( $maps[ $key ] ) ) {
				$notices[] = array( 'type' => 'ok', 'text' => $maps[ $key ] );
			}
		}

		if ( isset( $_GET['bmc_ticket_error'] ) ) {
			$notices[] = array( 'type' => 'error', 'text' => sanitize_text_field( rawurldecode( wp_unslash( $_GET['bmc_ticket_error'] ) ) ) );
		}

		return $notices;
	}

	public static function needs_attention() {
		global $wpdb;

		if ( ! self::enabled() ) {
			return 0;
		}

		$table = self::table();

		return (int) $wpdb->get_var( "SELECT COUNT(*) FROM {$table} WHERE status <> 'closed' AND last_reply_by = 'user'" );
	}

	public static function open_tickets_note( $user_id ) {
		$counts = self::counts( $user_id );
		$live   = (int) $counts['open'] + (int) $counts['answered'] + (int) $counts['pending'];

		return $live;
	}

	private static function mail_wrap( $title, array $lines, $cta_url = '', $cta_text = '' ) {
		$accent = (string) BMC_Settings::get( 'checkout_accent', '#3ddc84' );
		$name   = get_bloginfo( 'name' );

		ob_start();
		?>
		<!DOCTYPE html>
		<html dir="rtl" lang="fa">
		<head>
			<meta charset="utf-8">
			<title><?php echo esc_html( $title ); ?></title>
			<style>
				body { font-family: Tahoma, Arial, sans-serif; background: #0e141b; color: #e9eefb; margin: 0; padding: 24px; direction: rtl; }
				.card { max-width: 580px; margin: 0 auto; background: #161e29; border: 1px solid rgba(255,255,255,0.08); border-radius: 14px; padding: 28px; }
				.head { border-bottom: 1px solid rgba(255,255,255,0.08); padding-bottom: 16px; margin-bottom: 20px; }
				.head h1 { margin: 0; font-size: 18px; color: <?php echo esc_attr( $accent ); ?>; }
				.head small { color: #8c9ba5; font-size: 12px; }
				.line { margin: 10px 0; line-height: 1.8; font-size: 14px; color: #d0d7de; }
				.cta { margin-top: 24px; text-align: center; }
				.btn { display: inline-block; padding: 10px 22px; background: <?php echo esc_attr( $accent ); ?>; color: #000 !important; font-weight: bold; border-radius: 8px; text-decoration: none; }
			</style>
		</head>
		<body>
			<div class="card">
				<div class="head">
					<h1><?php echo esc_html( $title ); ?></h1>
					<small><?php echo esc_html( $name ); ?></small>
				</div>
				<?php foreach ( $lines as $line ) : ?>
					<div class="line"><?php echo wp_kses_post( $line ); ?></div>
				<?php endforeach; ?>
				<?php if ( $cta_url && $cta_text ) : ?>
					<div class="cta">
						<a class="btn" href="<?php echo esc_url( $cta_url ); ?>"><?php echo esc_html( $cta_text ); ?></a>
					</div>
				<?php endif; ?>
			</div>
		</body>
		</html>
		<?php
		return (string) ob_get_clean();
	}
}
