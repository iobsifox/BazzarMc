<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

final class BMC_Account_Endpoints {

	const FLUSH_OPTION  = 'bmc_flush_permalinks';
	const FLUSH_NOTICE  = 'bmc_flush_notice';

	const WC_OPTION_MAP = array(
		'connect' => 'woocommerce_bmc_minecraft_endpoint',
		'tickets' => 'woocommerce_bmc_tickets_endpoint',
	);

	private static $snapshot = null;
	private static $syncing  = false;

	private static function sanitize_slug( $value ) {
		if ( function_exists( 'sanitize_title' ) ) {
			return (string) sanitize_title( $value );
		}

		return (string) preg_replace( '/[^a-z0-9_\-]/i', '', strtolower( (string) $value ) );
	}

	private static function sanitize_key_fallback( $value ) {
		if ( function_exists( 'sanitize_key' ) ) {
			return (string) sanitize_key( $value );
		}

		return (string) preg_replace( '/[^a-z0-9_\-]/i', '', strtolower( (string) $value ) );
	}

		private static function parse_path( $url ) {
		if ( function_exists( 'wp_parse_url' ) ) {
			return (string) wp_parse_url( (string) $url, PHP_URL_PATH );
		}

		return (string) parse_url( (string) $url, PHP_URL_PATH );
	}

	private static function sanitize_text_fallback( $value ) {
		if ( function_exists( 'sanitize_text_field' ) ) {
			return (string) sanitize_text_field( $value );
		}

		return trim( strip_tags( (string) $value ) );
	}

	public static function init() {
		add_action( 'init', array( __CLASS__, 'register_endpoints' ) );
		add_filter( 'query_vars', array( __CLASS__, 'query_vars' ) );
		add_filter( 'woocommerce_get_query_vars', array( __CLASS__, 'wc_query_vars' ), 20 );
		add_filter( 'woocommerce_account_menu_items', array( __CLASS__, 'menu_items' ), 40 );

		$connect_aliases = self::connect_aliases();

		foreach ( $connect_aliases as $alias ) {
			add_action( 'woocommerce_account_' . $alias . '_endpoint', array( 'BMC_Public', 'my_account_content' ) );
		}

		$tickets_aliases = self::tickets_aliases();

		foreach ( $tickets_aliases as $alias ) {
			add_action( 'woocommerce_account_' . $alias . '_endpoint', array( 'BMC_Tickets', 'render_list_endpoint' ) );
		}

		add_action( 'woocommerce_account_' . BMC_Tickets::ENDPOINT_VIEW . '_endpoint', array( 'BMC_Tickets', 'render_view_endpoint' ) );

		add_action( 'pre_get_posts', array( __CLASS__, 'rescue_request' ), 4 );
		add_action( 'wp_loaded', array( __CLASS__, 'maybe_flush' ) );

		add_action( 'admin_init', array( __CLASS__, 'maybe_flush' ) );
		add_action( 'admin_notices', array( __CLASS__, 'flush_notice' ) );

		add_filter( 'woocommerce_get_settings_advanced', array( __CLASS__, 'wc_settings_fields' ), 20, 2 );
		add_filter( 'woocommerce_settings_pages', array( __CLASS__, 'wc_settings_fields' ), 20, 1 );
		add_action( 'admin_init', array( __CLASS__, 'mirror_to_wc' ), 5 );

		foreach ( self::keys() as $key ) {
			add_action( 'update_option_' . self::wc_option_key( $key ), array( __CLASS__, 'adopt_from_wc' ), 10, 3 );
			add_action( 'add_option_' . self::wc_option_key( $key ), array( __CLASS__, 'adopt_from_wc' ), 10, 2 );
		}
	}

	public static function connect_aliases() {
		$list = array(
			self::slug( 'connect' ),
			self::default_slug( 'connect' ),
			'minecraft',
			'connect',
			'mclink',
			'mc-link',
		);

		return array_values( array_unique( array_filter( array_map( 'strval', $list ) ) ) );
	}

	public static function tickets_aliases() {
		$list = array(
			self::slug( 'tickets' ),
			self::default_slug( 'tickets' ),
			'tickets',
			'bmc-tickets',
			'ticket',
		);

		return array_values( array_unique( array_filter( array_map( 'strval', $list ) ) ) );
	}

	public static function wc_option_key( $key ) {
		return isset( self::WC_OPTION_MAP[ $key ] ) ? self::WC_OPTION_MAP[ $key ] : '';
	}

	public static function wc_option_keys() {
		$out = array();

		foreach ( self::keys() as $key ) {
			$out[ $key ] = self::wc_option_key( $key );
		}

		return $out;
	}

	public static function wc_settings_fields( $settings, $section = '' ) {
		unset( $section );

		if ( ! is_array( $settings ) ) {
			return $settings;
		}

		$has_accounts = false;
		$already      = false;
		$index        = null;

		foreach ( $settings as $i => $field ) {
			if ( ! is_array( $field ) || ! isset( $field['id'] ) ) {
				continue;
			}

			if ( 'woocommerce_myaccount_orders_endpoint' === $field['id'] ) {
				$has_accounts = true;
			}

			if ( in_array( $field['id'], self::WC_OPTION_MAP, true ) ) {
				$already = true;
			}

			if ( isset( $field['type'] ) && 'sectionend' === $field['type'] && 'account_endpoint_options' === $field['id'] ) {
				$index = $i;
			}
		}

		if ( ! $has_accounts || $already || null === $index ) {
			return $settings;
		}

		$rows = array();

		foreach ( self::keys() as $key ) {
			$slug = self::slug( $key );

			$rows[] = array(
				'title'    => self::title( $key ),
				'desc'     => 'tickets' === $key
					? 'نشانی بخش «تیکت پشتیبانی» در حساب کاربری؛ همگام با پیشخوان » BazzarMc » تأیید و حساب کاربری.'
					: 'نشانی بخش «اتصال ماینکرافت» در حساب کاربری؛ همگام با پیشخوان » BazzarMc » تأیید و حساب کاربری.',
				'id'       => self::wc_option_key( $key ),
				'type'     => 'text',
				'default'  => self::default_slug( $key ),
				'desc_tip' => 'tickets' === $key
					? 'BazzarMc — example.com/my-account/' . $slug . '/ . اگر نامک رزروشده یا تکراری باشد، به مقدار پیش‌فرض (' . self::default_slug( $key ) . ') بازمی‌گردد و پیوندهای یکتا خودکار بازنشانی می‌شود.'
					: 'BazzarMc — example.com/my-account/' . $slug . '/ . اگر نامک رزروشده یا تکراری باشد، به مقدار پیش‌فرض (' . self::default_slug( $key ) . ') بازمی‌گردد و پیوندهای یکتا خودکار بازنشانی می‌شود.',
			);
		}

		array_splice( $settings, $index, 0, $rows );

		return $settings;
	}

	public static function mirror_to_wc() {
		if ( self::$syncing ) {
			return;
		}

		self::$syncing = true;

		foreach ( self::keys() as $key ) {
			$option = self::wc_option_key( $key );
			$slug   = self::slug( $key );

			if ( (string) get_option( $option, '' ) !== $slug ) {
				update_option( $option, $slug );
			}
		}

		self::$syncing = false;
	}

	public static function adopt_from_wc( $old = null, $new = null, $option = '' ) {
		if ( is_array( $new ) && ! is_array( $old ) ) {
			$option = (string) $old;
			$new    = null;
		}

		if ( self::$syncing || '' === (string) $option ) {
			return;
		}

		$key = array_search( (string) $option, self::WC_OPTION_MAP, true );

		if ( false === $key ) {
			return;
		}

		$value = null === $new ? (string) get_option( (string) $option, '' ) : (string) $new;
		$value = self::sanitize_slug( $value );

		if ( '' === $value || in_array( $value, self::reserved(), true ) ) {
			return;
		}

		$prefix = self::setting_prefix( $key );

		if ( (string) BMC_Settings::get( $prefix . 'slug', '' ) === $value ) {
			return;
		}

		self::$syncing = true;

		BMC_Settings::save( array( $prefix . 'slug' => $value ) );
		self::$snapshot = null;
		self::queue_flush_if_changed();

		self::$syncing = false;
	}

	public static function current_endpoint() {
		$current = '';

		if ( function_exists( 'WC' ) && WC() && isset( WC()->query ) && method_exists( WC()->query, 'get_current_endpoint' ) ) {
			$current = (string) WC()->query->get_current_endpoint();
		}

		if ( '' === $current ) {
			global $wp;

			$requested = isset( $wp->query_vars ) && is_array( $wp->query_vars ) ? $wp->query_vars : array();

			foreach ( self::endpoint_candidates() as $candidate ) {
				if ( array_key_exists( $candidate, $requested ) ) {
					$current = (string) $candidate;
					break;
				}
			}
		}

		if ( '' === $current ) {
			$all_candidates = self::endpoint_candidates();

			foreach ( $all_candidates as $cand ) {
				if ( '' !== $cand && '' !== (string) ( function_exists( 'get_query_var' ) ? get_query_var( $cand, '' ) : '' ) ) {
					$current = $cand;
					break;
				}
			}
		}

		if ( '' === $current && function_exists( 'is_wc_endpoint_url' ) ) {
			foreach ( self::endpoint_candidates() as $candidate ) {
				if ( '' !== (string) $candidate && is_wc_endpoint_url( (string) $candidate ) ) {
					$current = (string) $candidate;
					break;
				}
			}
		}

		if ( '' === $current && ! empty( $_SERVER['REQUEST_URI'] ) ) {
			$req_path = trim( (string) self::parse_path( $_SERVER['REQUEST_URI'] ), '/' );

			foreach ( self::endpoint_candidates() as $candidate ) {
				if ( '' !== (string) $candidate && ( false !== stripos( $req_path, '/' . $candidate ) || $req_path === $candidate ) ) {
					$current = (string) $candidate;
					break;
				}
			}
		}

		return $current;
	}

	public static function rescue_request( $query ) {
		if ( is_admin() || ! ( $query instanceof \WP_Query ) || ! $query->is_main_query() ) {
			return;
		}

		if ( ! function_exists( 'wc_get_page_permalink' ) || ! function_exists( 'wc_get_page_id' ) ) {
			return;
		}

		$page_id = (int) wc_get_page_id( 'myaccount' );

		if ( $page_id < 1 ) {
			return;
		}

		$base = trim( (string) self::parse_path( wc_get_page_permalink( 'myaccount' ) ), '/' );

		if ( '' === $base ) {
			return;
		}

		$request = isset( $_SERVER['REQUEST_URI'] ) ? (string) wp_unslash( $_SERVER['REQUEST_URI'] ) : '';
		$path    = trim( (string) urldecode( (string) self::parse_path( $request ) ), '/' );

		if ( '' === $path || 0 !== stripos( $path . '/', $base . '/' ) ) {
			return;
		}

		$rest = trim( substr( $path, strlen( $base ) ), '/' );

		if ( '' === $rest ) {
			return;
		}

		$segments = explode( '/', $rest );
		$endpoint = (string) $segments[0];
		$value    = isset( $segments[1] ) ? (string) $segments[1] : '';

		if ( ! in_array( $endpoint, self::endpoint_candidates(), true ) ) {
			return;
		}

		$view_slug = (string) get_option( 'woocommerce_myaccount_view_order_endpoint', 'view-order' );
		if ( '' === $view_slug ) {
			$view_slug = 'view-order';
		}

		$orders_slug = (string) get_option( 'woocommerce_myaccount_orders_endpoint', 'orders' );
		if ( '' === $orders_slug ) {
			$orders_slug = 'orders';
		}

		if ( in_array( $endpoint, array( 'orders', $orders_slug ), true ) && '' !== $value && is_numeric( $value ) ) {
			$endpoint = $view_slug;
		}

		$vars = (array) $query->get_query_vars();

		if ( array_key_exists( $endpoint, $vars ) ) {
			return;
		}

		$query->set( 'pagename', $base );
		$query->set( 'name', '' );
		$query->set( 'error', '' );
		$query->set( 'page', '' );
		$query->set( 'page_id', $page_id );
		$query->set( $endpoint, $value );

		if ( in_array( $endpoint, self::connect_aliases(), true ) ) {
			$query->set( self::slug( 'connect' ), $value );
		}

		if ( in_array( $endpoint, self::tickets_aliases(), true ) ) {
			$query->set( self::slug( 'tickets' ), $value );
		}

		global $wp;

		if ( isset( $wp ) && isset( $wp->query_vars ) && is_array( $wp->query_vars ) ) {
			$wp->query_vars['pagename']   = $base;
			$wp->query_vars['page_id']    = $page_id;
			$wp->query_vars[ $endpoint ]  = $value;

			if ( in_array( $endpoint, self::connect_aliases(), true ) ) {
				$wp->query_vars[ self::slug( 'connect' ) ] = $value;
			}

			if ( in_array( $endpoint, self::tickets_aliases(), true ) ) {
				$wp->query_vars[ self::slug( 'tickets' ) ] = $value;
			}

			unset( $wp->query_vars['name'], $wp->query_vars['error'] );
		}

		self::queue_flush();
	}

	public static function endpoint_candidates() {
		$candidates = array();

		foreach ( self::keys() as $key ) {
			$candidates[] = self::slug( $key );
			$candidates[] = self::default_slug( $key );
		}

		$candidates = array_merge( $candidates, self::connect_aliases(), self::tickets_aliases() );
		$candidates[] = BMC_Tickets::ENDPOINT_VIEW;

		$wc_keys = array(
			'orders'                     => 'woocommerce_myaccount_orders_endpoint',
			'view-order'                 => 'woocommerce_myaccount_view_order_endpoint',
			'downloads'                  => 'woocommerce_myaccount_downloads_endpoint',
			'edit-address'               => 'woocommerce_myaccount_edit_address_endpoint',
			'payment-methods'            => 'woocommerce_myaccount_payment_methods_endpoint',
			'edit-account'               => 'woocommerce_myaccount_edit_account_endpoint',
			'lost-password'              => 'woocommerce_myaccount_lost_password_endpoint',
			'customer-logout'            => 'woocommerce_myaccount_customer_logout_endpoint',
			'add-payment-method'         => 'woocommerce_myaccount_add_payment_method_endpoint',
			'delete-payment-method'      => 'woocommerce_myaccount_delete_payment_method_endpoint',
			'set-default-payment-method' => 'woocommerce_myaccount_set_default_payment_method_endpoint',
		);

		foreach ( $wc_keys as $default_slug => $option_name ) {
			$candidates[] = $default_slug;
			$custom       = (string) get_option( $option_name, '' );
			if ( '' !== $custom ) {
				$candidates[] = self::sanitize_slug( $custom );
			}
		}

		if ( function_exists( 'WC' ) && WC() && isset( WC()->query ) && method_exists( WC()->query, 'get_query_vars' ) ) {
			$wc_vars = (array) WC()->query->get_query_vars();
			foreach ( $wc_vars as $qvar => $slug ) {
				$candidates[] = (string) $qvar;
				$candidates[] = (string) $slug;
			}
		}

		return array_values( array_unique( array_filter( array_map( 'strval', $candidates ) ) ) );
	}

	public static function context( $endpoint = null ) {
		if ( null === $endpoint ) {
			$endpoint = self::current_endpoint();
		}

		$endpoint = self::sanitize_key_fallback( (string) $endpoint );

		if ( '' === $endpoint ) {
			return 'dashboard';
		}

		if ( in_array( $endpoint, self::connect_aliases(), true ) ) {
			return 'minecraft';
		}

		if ( in_array( $endpoint, self::tickets_aliases(), true ) || BMC_Tickets::ENDPOINT_VIEW === $endpoint ) {
			return 'tickets';
		}

		$view_slug = (string) get_option( 'woocommerce_myaccount_view_order_endpoint', 'view-order' );
		if ( in_array( $endpoint, array( 'orders', 'view-order', $view_slug ), true ) ) {
			return 'orders';
		}

		if ( 'downloads' === $endpoint ) {
			return 'downloads';
		}

		if ( in_array( $endpoint, array( 'edit-account', 'edit-address', 'payment-methods' ), true ) ) {
			return 'profile';
		}

		return 'other';
	}

	public static function keys() {
		return array( 'connect', 'tickets' );
	}

	public static function default_slug( $key ) {
		return 'tickets' === $key ? 'bmc-tickets' : 'minecraft';
	}

	public static function default_title( $key ) {
		return 'tickets' === $key ? 'تیکت پشتیبانی' : 'اتصال ماینکرافت';
	}

	public static function setting_prefix( $key ) {
		return 'tickets' === $key ? 'ma_tickets_' : 'ma_connect_';
	}

	public static function slug( $key ) {
		$default = self::default_slug( $key );
		$value   = self::sanitize_slug( (string) BMC_Settings::get( self::setting_prefix( $key ) . 'slug', $default ) );

		if ( '' === $value || in_array( $value, self::reserved(), true ) ) {
			$value = $default;
		}

		foreach ( self::keys() as $other ) {
			if ( $other === $key ) {
				continue;
			}

			if ( $value === self::sanitize_slug( (string) BMC_Settings::get( self::setting_prefix( $other ) . 'slug', self::default_slug( $other ) ) ) ) {
				$value = $default;
			}
		}

		return $value;
	}

	public static function slugs() {
		$out = array();

		foreach ( self::keys() as $key ) {
			$out[ $key ] = self::slug( $key );
		}

		return $out;
	}

	public static function reserved() {
		return array(
			'dashboard',
			'orders',
			'view-order',
			'downloads',
			'edit-address',
			'payment-methods',
			'edit-account',
			'customer-logout',
			'lost-password',
			'add-payment-method',
			'delete-payment-method',
			'set-default-payment-method',
			BMC_Tickets::ENDPOINT_VIEW,
		);
	}

	public static function title( $key ) {
		$title = trim( (string) BMC_Settings::get( self::setting_prefix( $key ) . 'title', self::default_title( $key ) ) );

		return '' === $title ? self::default_title( $key ) : $title;
	}

	public static function icon( $key ) {
		$prefix = self::setting_prefix( $key );
		$icon   = self::sanitize_text_fallback( (string) BMC_Settings::get( $prefix . 'icon', '' ) );

		if ( '' === $icon || ! class_exists( 'BMC_Icons' ) || ! BMC_Icons::has( $icon ) ) {
			$icon = 'tickets' === $key ? 'support_agent' : 'sports_esports';
		}

		return $icon;
	}

	public static function position( $key ) {
		$allowed = array_keys( BMC_Settings::endpoint_positions() );
		$value   = self::sanitize_key_fallback( (string) BMC_Settings::get( self::setting_prefix( $key ) . 'position', '' ) );

		if ( ! in_array( $value, $allowed, true ) ) {
			$value = 'tickets' === $key ? 'before_logout' : 'after_orders';
		}

		return $value;
	}

	public static function in_menu( $key ) {
		if ( 'tickets' === $key ) {
			return BMC_Tickets::enabled() && BMC_Settings::bool( 'ma_tickets_enabled', true );
		}

		return BMC_Settings::bool( 'ma_connect_enabled', true );
	}

	public static function show_badge( $key ) {
		if ( 'tickets' === $key ) {
			return BMC_Settings::bool( 'ma_tickets_badge', true );
		}

		return BMC_Settings::bool( 'ma_connect_badge', true );
	}

	public static function definition( $key ) {
		return array(
			'key'      => $key,
			'slug'     => self::slug( $key ),
			'default'  => self::default_slug( $key ),
			'title'    => self::title( $key ),
			'icon'     => self::icon( $key ),
			'position' => self::position( $key ),
			'in_menu'  => self::in_menu( $key ),
			'badge'    => self::show_badge( $key ),
			'url'      => self::url( $key ),
		);
	}

	public static function definitions() {
		$out = array();

		foreach ( self::keys() as $key ) {
			$out[ $key ] = self::definition( $key );
		}

		return $out;
	}

	public static function url( $key ) {
		if ( function_exists( 'wc_get_account_endpoint_url' ) ) {
			$url = (string) wc_get_account_endpoint_url( self::slug( $key ) );

			if ( '' !== $url && false === strpos( $url, 'wc_get_account_endpoint_url' ) ) {
				return $url;
			}
		}

		return function_exists( 'wc_get_page_permalink' ) ? (string) wc_get_page_permalink( 'myaccount' ) : home_url( '/' );
	}

	public static function view_url( $ticket_id = 0 ) {
		$ticket_id = absint( $ticket_id );

		if ( ! $ticket_id ) {
			return self::url( 'tickets' );
		}

		if ( function_exists( 'wc_get_endpoint_url' ) && function_exists( 'wc_get_page_permalink' ) ) {
			$base = wc_get_page_permalink( 'myaccount' );
			if ( $base ) {
				$slug = self::slug( 'tickets' );
				if ( get_option( 'permalink_structure' ) ) {
					return trailingslashit( $base ) . $slug . '/' . $ticket_id . '/';
				}
				return add_query_arg( array( $slug => $ticket_id, 'ticket' => $ticket_id ), $base );
			}
		}

		return add_query_arg( 'ticket', $ticket_id, self::url( 'tickets' ) );
	}

	public static function is_current( $key ) {
		if ( 'connect' === $key ) {
			$aliases = self::connect_aliases();

			foreach ( $aliases as $alias ) {
				if ( function_exists( 'is_wc_endpoint_url' ) && is_wc_endpoint_url( $alias ) ) {
					return true;
				}

				if ( '' !== (string) ( function_exists( 'get_query_var' ) ? get_query_var( $alias, '' ) : '' ) ) {
					return true;
				}
			}

			if ( ! empty( $_SERVER['REQUEST_URI'] ) ) {
				$req = trim( (string) self::parse_path( $_SERVER['REQUEST_URI'] ), '/' );

				foreach ( $aliases as $alias ) {
					if ( false !== stripos( $req, '/' . $alias ) || $req === $alias ) {
						return true;
					}
				}
			}

			return false;
		}

		if ( 'tickets' === $key ) {
			$aliases = self::tickets_aliases();

			foreach ( $aliases as $alias ) {
				if ( function_exists( 'is_wc_endpoint_url' ) && ( is_wc_endpoint_url( $alias ) || is_wc_endpoint_url( BMC_Tickets::ENDPOINT_VIEW ) ) ) {
					return true;
				}

				if ( '' !== (string) ( function_exists( 'get_query_var' ) ? get_query_var( $alias, '' ) : '' ) || '' !== (string) ( function_exists( 'get_query_var' ) ? get_query_var( BMC_Tickets::ENDPOINT_VIEW, '' ) : '' ) ) {
					return true;
				}
			}

			if ( ! empty( $_SERVER['REQUEST_URI'] ) ) {
				$req = trim( (string) self::parse_path( $_SERVER['REQUEST_URI'] ), '/' );

				foreach ( $aliases as $alias ) {
					if ( false !== stripos( $req, '/' . $alias ) || $req === $alias ) {
						return true;
					}
				}
			}

			return false;
		}

		if ( ! function_exists( 'is_wc_endpoint_url' ) ) {
			return false;
		}

		return (bool) is_wc_endpoint_url( self::slug( $key ) );
	}

	public static function register_endpoints() {
		$connect_aliases = self::connect_aliases();

		foreach ( $connect_aliases as $alias ) {
			add_rewrite_endpoint( $alias, EP_ROOT | EP_PAGES );
		}

		if ( BMC_Tickets::enabled() ) {
			$tickets_aliases = self::tickets_aliases();

			foreach ( $tickets_aliases as $alias ) {
				add_rewrite_endpoint( $alias, EP_ROOT | EP_PAGES );
			}

			add_rewrite_endpoint( BMC_Tickets::ENDPOINT_VIEW, EP_ROOT | EP_PAGES );
		}
	}

	public static function wc_query_vars( $vars ) {
		if ( ! is_array( $vars ) ) {
			return $vars;
		}

		$connect_aliases = self::connect_aliases();

		foreach ( $connect_aliases as $alias ) {
			$vars[ $alias ] = $alias;
		}

		if ( BMC_Tickets::enabled() ) {
			$tickets_aliases = self::tickets_aliases();

			foreach ( $tickets_aliases as $alias ) {
				$vars[ $alias ] = $alias;
			}

			$vars[ BMC_Tickets::ENDPOINT_VIEW ] = BMC_Tickets::ENDPOINT_VIEW;
		}

		return $vars;
	}

	public static function query_vars( $vars ) {
		$connect_aliases = self::connect_aliases();

		foreach ( $connect_aliases as $alias ) {
			$vars[] = $alias;
		}

		$tickets_aliases = self::tickets_aliases();

		foreach ( $tickets_aliases as $alias ) {
			$vars[] = $alias;
		}

		$vars[] = BMC_Tickets::ENDPOINT_VIEW;

		return array_values( array_unique( $vars ) );
	}

	public static function menu_items( $items ) {
		if ( ! is_array( $items ) ) {
			return $items;
		}

		$defs = self::definitions();

		foreach ( $defs as $def ) {
			unset( $items[ $def['slug'] ], $items[ $def['default'] ] );
		}

		unset( $items[ BMC_Tickets::ENDPOINT_VIEW ] );

		foreach ( $defs as $key => $def ) {
			if ( ! $def['in_menu'] ) {
				continue;
			}

			$items = self::insert( $items, $def['slug'], $def['title'], $def['position'] );
		}

		return $items;
	}

	public static function insert( array $items, $slug, $title, $position ) {
		$out = array();

		switch ( $position ) {
			case 'first':
				$out[ $slug ] = $title;
				foreach ( $items as $key => $label ) {
					$out[ $key ] = $label;
				}
				return $out;

			case 'last':
				foreach ( $items as $key => $label ) {
					$out[ $key ] = $label;
				}
				$out[ $slug ] = $title;
				return $out;

			case 'after_dashboard':
				return self::insert_after( $items, $slug, $title, 'dashboard' );

			case 'before_logout':
				return self::insert_before( $items, $slug, $title, 'customer-logout' );

			case 'after_orders':
			default:
				return self::insert_after( $items, $slug, $title, 'orders' );
		}
	}

	private static function insert_after( array $items, $slug, $title, $anchor ) {
		$out    = array();
		$placed = false;

		foreach ( $items as $key => $label ) {
			$out[ $key ] = $label;

			if ( $key === $anchor ) {
				$out[ $slug ] = $title;
				$placed       = true;
			}
		}

		if ( ! $placed ) {
			$out[ $slug ] = $title;
		}

		return $out;
	}

	private static function insert_before( array $items, $slug, $title, $anchor ) {
		$out    = array();
		$placed = false;

		foreach ( $items as $key => $label ) {
			if ( $key === $anchor && ! $placed ) {
				$out[ $slug ] = $title;
				$placed       = true;
			}

			$out[ $key ] = $label;
		}

		if ( ! $placed ) {
			$out[ $slug ] = $title;
		}

		return $out;
	}

	public static function nav_icon( $endpoint ) {
		foreach ( self::keys() as $key ) {
			$def = self::definition( $key );

			if ( $def['slug'] === $endpoint || $def['default'] === $endpoint ) {
				return $def['icon'];
			}
		}

		return '';
	}

	public static function nav_meta( $endpoint ) {
		$meta = array(
			'count' => 0,
			'dot'   => false,
			'note'  => '',
		);

		if ( ! is_user_logged_in() ) {
			return $meta;
		}

		try {
			return self::nav_meta_rows( $endpoint, $meta );
		} catch ( \Throwable $error ) {
			if ( class_exists( 'BMC_Safe' ) ) {
				BMC_Safe::collect( 'nav:meta', $error );
			}

			return $meta;
		}
	}

	private static function nav_meta_rows( $endpoint, $meta ) {
		foreach ( self::keys() as $key ) {
			$def = self::definition( $key );

			$matches = ( $key === $endpoint || $def['slug'] === $endpoint || $def['default'] === $endpoint );
			if ( ! $matches ) {
				if ( 'connect' === $key && in_array( $endpoint, self::connect_aliases(), true ) ) {
					$matches = true;
				} elseif ( 'tickets' === $key && in_array( $endpoint, self::tickets_aliases(), true ) ) {
					$matches = true;
				}
			}

			if ( ! $matches ) {
				continue;
			}

			if ( ! $def['badge'] ) {
				return $meta;
			}

			if ( 'tickets' === $key ) {
				$meta['count'] = (int) BMC_Tickets::open_tickets_note( get_current_user_id() );
				$meta['dot']   = BMC_Settings::bool( 'ma_tickets_dot', true ) && (int) BMC_Tickets::unread_for_user( get_current_user_id() ) > 0;

				return $meta;
			}

			$linked = class_exists( 'BMC_Link' ) && BMC_Link::is_linked( get_current_user_id() );

			$meta['dot']  = ! $linked;
			$meta['note'] = $linked ? 'متصل' : 'نیاز به اتصال';

			return $meta;
		}

		return $meta;
	}

	public static function nav_url( $endpoint ) {
		foreach ( self::keys() as $key ) {
			$def = self::definition( $key );

			if ( $def['slug'] === $endpoint ) {
				return (string) $def['url'];
			}
		}

		return '';
	}

	public static function snapshot() {
		if ( null === self::$snapshot ) {
			self::$snapshot = self::slugs();
		}

		return self::$snapshot;
	}

	public static function queue_flush_if_changed() {
		$before = (array) get_option( self::FLUSH_OPTION . '_slugs', array() );
		$now    = self::slugs();

		if ( ! $before ) {
			update_option( self::FLUSH_OPTION . '_slugs', $now, false );

			return false;
		}

		if ( $before === $now ) {
			return false;
		}

		update_option( self::FLUSH_OPTION . '_slugs', $now, false );
		self::queue_flush();

		return true;
	}

	public static function queue_flush() {
		update_option( self::FLUSH_OPTION, 1, false );
	}

	public static function maybe_flush() {
		if ( ! get_option( self::FLUSH_OPTION, 0 ) ) {
			return;
		}

		delete_option( self::FLUSH_OPTION );

		flush_rewrite_rules();

		set_transient( self::FLUSH_NOTICE, 1, 60 );
	}

	public static function flush_notice() {
		if ( ! get_transient( self::FLUSH_NOTICE ) ) {
			return;
		}

		delete_transient( self::FLUSH_NOTICE );

		echo '<div class="notice notice-success is-dismissible"><p><strong>BazzarMc:</strong> پیوندهای یکتا بازسازی شد تا آدرس تازهٔ بخش‌های حساب کاربری فعال شود.</p></div>';
	}

	public static function status_rows() {
		$rows = array();

		foreach ( self::keys() as $key ) {
			$def    = self::definition( $key );
			$meta   = self::nav_meta( $def['slug'] );
			$rows[] = array(
				'key'      => $key,
				'label'    => 'tickets' === $key ? 'تیکت‌ها' : 'اتصال حساب ماینکرافت',
				'title'    => $def['title'],
				'slug'     => $def['slug'],
				'url'      => $def['url'],
				'in_menu'  => $def['in_menu'],
				'icon'     => $def['icon'],
				'position' => $def['position'],
				'count'    => $meta['count'],
				'note'     => $meta['note'],
			);
		}

		return $rows;
	}
}
