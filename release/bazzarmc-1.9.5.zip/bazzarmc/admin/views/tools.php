<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$tables = BMC_DB::table_status();
$report = BMC_Migrate::migration_report();
$logs   = BMC_Logger::recent( 30 );

$bmc_safe_on     = class_exists( 'BMC_Safe' ) && BMC_Safe::safe_mode();
$bmc_safe_reason = class_exists( 'BMC_Safe' ) ? BMC_Safe::safe_mode_reason() : '';
$bmc_safe_state  = class_exists( 'BMC_Safe' ) ? BMC_Safe::state() : array();
$bmc_safe_errors = class_exists( 'BMC_Safe' ) ? BMC_Safe::errors() : array();
$bmc_boot_errors = get_option( 'bmc_bootstrap_errors', array() );
$bmc_boot_errors = is_array( $bmc_boot_errors ) ? $bmc_boot_errors : array();
?>
<?php $bmc_update = class_exists( 'BMC_Updater' ) ? BMC_Updater::status() : array(); ?>
<section class="bmc-box">
	<div class="bmc-box__head">
		<h2><?php bmc_icon( 'update', array( 'size' => 18 ) ); ?> به‌روزرسانی افزونه</h2>
		<?php
		if ( empty( $bmc_update['enabled'] ) ) {
			echo '<span class="bmc-pill is-expired">بررسی خودکار خاموش است</span>';
		} elseif ( ! empty( $bmc_update['has_update'] ) ) {
			echo '<span class="bmc-pill is-pending">نسخهٔ جدید در دسترس است</span>';
		} elseif ( ! empty( $bmc_update['error'] ) ) {
			echo '<span class="bmc-pill is-cancelled">بررسی ناموفق</span>';
		} else {
			echo '<span class="bmc-pill is-done">به‌روز</span>';
		}
		?>
	</div>
	<div class="bmc-box__body">
		<p class="bmc-hint">
			افزونه خودش نسخهٔ جدید را از ریلیزهای گیت‌هاب بررسی می‌کند و آن را در <strong>پیشخوان ← افزونه‌ها</strong> اعلام می‌کند؛
			همان‌جا با یک کلیک به‌روزرسانی می‌شود (مانند افزونه‌های مخزن وردپرس). یادداشت‌های نسخه هم در پنجرهٔ «جزئیات نسخهٔ جدید» دیده می‌شود.
			تنظیمات، جدول‌ها و داده‌های شما هنگام به‌روزرسانی حفظ می‌مانند.
		</p>

		<table class="bmc-table bmc-table--full bmc-update__table">
			<tbody>
				<tr>
					<th>نسخهٔ نصب‌شده</th>
					<td><strong dir="ltr"><?php echo esc_html( BMC_VERSION ); ?></strong></td>
					<th>آخرین نسخهٔ منتشرشده</th>
					<td>
						<?php if ( ! empty( $bmc_update['latest'] ) ) : ?>
							<strong dir="ltr"><?php echo esc_html( $bmc_update['latest'] ); ?></strong>
							<?php if ( ! empty( $bmc_update['has_update'] ) ) : ?>
								<span class="bmc-pill is-pending">قابل به‌روزرسانی</span>
							<?php else : ?>
								<span class="bmc-pill is-done">به‌روز هستید</span>
							<?php endif; ?>
						<?php else : ?>
							<span class="bmc-dim">هنوز بررسی نشده است</span>
						<?php endif; ?>
					</td>
				</tr>
				<tr>
					<th>کانال انتشار</th>
					<td><?php echo 'prerelease' === ( isset( $bmc_update['channel'] ) ? $bmc_update['channel'] : '' ) ? 'پیش‌انتشار (شامل نسخهٔ آزمایشی)' : 'پایدار'; ?></td>
					<th>مخزن انتشار</th>
					<td><code dir="ltr"><?php echo esc_html( isset( $bmc_update['repo'] ) ? $bmc_update['repo'] : '' ); ?></code></td>
				</tr>
				<tr>
					<th>آخرین بررسی</th>
					<td>
						<?php if ( ! empty( $bmc_update['checked_at'] ) ) : ?>
							<?php echo esc_html( BMC_Jalali::format( (int) $bmc_update['checked_at'] ) ); ?>
							<small class="bmc-dim">(<?php echo esc_html( $bmc_update['checked_ago'] ); ?>)</small>
						<?php else : ?>
							<span class="bmc-dim">—</span>
						<?php endif; ?>
					</td>
					<th>پلاگین ماینکرافت همراه نسخه</th>
					<td>
						<?php if ( ! empty( $bmc_update['mc_jar'] ) && BMC_Settings::bool( 'update_show_jar', true ) ) : ?>
							<a href="<?php echo esc_url( $bmc_update['mc_jar_url'] ); ?>" target="_blank" rel="noopener"><code dir="ltr"><?php echo esc_html( $bmc_update['mc_jar'] ); ?></code></a>
						<?php else : ?>
							<span class="bmc-dim">در این ریلیز فایلی برای پلاگین ماینکرافت نیست</span>
						<?php endif; ?>
					</td>
				</tr>
				<?php if ( ! empty( $bmc_update['error'] ) ) : ?>
					<tr>
						<th>خطای بررسی</th>
						<td colspan="3"><span class="bmc-report is-warn"><?php echo esc_html( $bmc_update['error'] ); ?></span></td>
					</tr>
				<?php endif; ?>
			</tbody>
		</table>

		<div class="bmc-inline" style="margin-top:12px">
			<button type="button" class="button button-primary bmc-update-check"><?php bmc_icon( 'sync', array( 'size' => 15 ) ); ?> بررسی اکنون</button>
			<a class="button" href="<?php echo esc_url( admin_url( 'plugins.php' ) ); ?>">صفحهٔ افزونه‌ها</a>
			<a class="button" href="<?php echo esc_url( isset( $bmc_update['url'] ) ? $bmc_update['url'] : '' ); ?>" target="_blank" rel="noopener">ریلیزها در گیت‌هاب</a>
		</div>

		<?php BMC_Admin::form_open( 'tools' ); ?>
			<?php
			BMC_Admin::row(
				'بررسی خودکار به‌روزرسانی',
				BMC_Admin::toggle( 'update_enabled', BMC_Settings::get( 'update_enabled', 'yes' ), 'نسخهٔ جدید در صفحهٔ افزونه‌ها اعلام شود' ),
				'هر ' . esc_html( BMC_Helpers::to_persian_digits( max( 1, (int) BMC_Settings::get( 'update_ttl', 6 ) ) ) ) . ' ساعت یک‌بار و همچنین همراه بررسی‌های خودِ وردپرس.'
			);

			BMC_Admin::row(
				'کانال انتشار',
				BMC_Admin::select(
					'update_channel',
					BMC_Settings::get( 'update_channel', 'stable' ),
					array(
						'stable'     => 'پایدار (فقط ریلیزهای نهایی)',
						'prerelease' => 'پیش‌انتشار (شامل نسخهٔ آزمایشی)',
					)
				),
				'کانال پیش‌انتشار برای تست نسخهٔ بعدی پیش از انتشار عمومی است.'
			);

			BMC_Admin::row(
				'مخزن انتشار',
				BMC_Admin::input( 'update_repo', BMC_Settings::get( 'update_repo', 'iobsifox/BazzarMc' ), array( 'dir' => 'ltr', 'class' => 'bmc-mono' ) ),
				'به‌صورت <code>owner/repo</code> — اگر افزونه را از فورک خودتان منتشر می‌کنید، آدرس فورک را بگذارید.'
			);

			BMC_Admin::row(
				'توکن دسترسی (اختیاری)',
				BMC_Admin::input( 'update_token', BMC_Settings::get( 'update_token', '' ), array( 'type' => 'password', 'dir' => 'ltr', 'class' => 'bmc-mono', 'placeholder' => 'github_pat_…' ) ),
				'فقط وقتی لازم است که مخزن انتشار <strong>خصوصی</strong> باشد؛ برای مخزن عمومی خالی بگذارید.'
			);

			BMC_Admin::row(
				'فاصلهٔ بررسی (ساعت)',
				BMC_Admin::input( 'update_ttl', BMC_Settings::get( 'update_ttl', 6 ), array( 'type' => 'number', 'min' => 1, 'max' => 168, 'class' => 'bmc-input--sm' ) ),
				'۱ تا ۱۶۸ ساعت.'
			);

			BMC_Admin::row(
				'به‌روزرسانی خودکار',
				BMC_Admin::toggle( 'update_auto', BMC_Settings::get( 'update_auto', 'no' ), 'نسخهٔ جدید بدون تأیید من نصب شود' ),
				'معادل فعال‌کردن «به‌روزرسانی خودکار» در صفحهٔ افزونه‌ها؛ اگر سایت حساس است خاموش بگذارید.'
			);

			BMC_Admin::row(
				'به‌روزرسانی در صفحهٔ افزونه‌ها',
				BMC_Admin::toggle( 'update_check_plugins_page', BMC_Settings::get( 'update_check_plugins_page', 'yes' ), 'با باز کردن صفحهٔ افزونه‌ها، وجود نسخهٔ جدید همان لحظه بررسی شود' ),
				'بدون این گزینه فقط بر اساس فاصلهٔ بررسی (بالا) نسخهٔ جدید دیده می‌شود.'
			);

			BMC_Admin::row(
				'میان‌بر ردیف افزونه',
				BMC_Admin::toggle( 'update_row_link', BMC_Settings::get( 'update_row_link', 'yes' ), 'زیر نام BazzarMc در صفحهٔ افزونه‌ها پیوند «بررسی به‌روزرسانی» و اعلام نسخهٔ آماده نمایش داده شود' ),
				'با یک کلیک، کش پاک می‌شود، آخرین ریلیز بررسی می‌شود و اگر نسخهٔ جدید بود همان‌جا دکمهٔ «اکنون به‌روزرسانی کن» ظاهر می‌شود.'
			);

			BMC_Admin::row(
				'یادآوری در پیشخوان',
				BMC_Admin::toggle( 'update_notice', BMC_Settings::get( 'update_notice', 'yes' ), 'نوار اطلاع‌رسانی نسخهٔ جدید نمایش داده شود' )
			);

			BMC_Admin::row(
				'نمایش فایل پلاگین ماینکرافت',
				BMC_Admin::toggle( 'update_show_jar', BMC_Settings::get( 'update_show_jar', 'yes' ), 'فایل jar همراه هر ریلیز در همین جدول نشان داده شود' )
			);

			BMC_Admin::row(
				'ایمیل اطلاع‌رسانی (اختیاری)',
				BMC_Admin::input( 'update_notify_email', BMC_Settings::get( 'update_notify_email', '' ), array( 'dir' => 'ltr', 'placeholder' => 'admin@example.com' ) ),
				'چند آدرس با ویرگول جدا کنید؛ هنگام انتشار نسخهٔ جدید ایمیل می‌گیرند.'
			);
			?>
		<?php BMC_Admin::form_close( 'ذخیرهٔ تنظیمات به‌روزرسانی' ); ?>
	</div>
</section>

<section class="bmc-box bmc-mode-adv">
	<div class="bmc-box__head">
		<h2><?php bmc_icon( 'shield', array( 'size' => 18 ) ); ?> محافظ پایداری (حالت ایمن خودکار)</h2>
		<span class="bmc-pill <?php echo $bmc_safe_on ? 'is-cancelled' : 'is-done'; ?>"><?php echo $bmc_safe_on ? 'حالت ایمن فعال است' : 'محافظ فعال و سایت در وضعیت عادی'; ?></span>
	</div>
	<div class="bmc-box__body">
		<p class="bmc-hint">
			این محافظ، هر خطای مهلک مربوط به BazzarMc را می‌شمارد. اگر در بازهٔ ۱۰ دقیقه چند خطای مهلک پشت‌سرهم رخ دهد، افزونه خودش به «حالت ایمن» می‌رود: ویجت‌های المنتور، چک‌اوت و سبد اختصاصی و کارت داشبورد خاموش می‌شوند و سایت با هستهٔ ووکامرس به کارش ادامه می‌دهد تا هیچ‌وقت صفحهٔ سفید یا از دسترس خارج شدن کل سایت پیش نیاید. یک ایمیل هم به مدیر ارسال می‌شود.
		</p>

		<?php if ( $bmc_safe_on ) : ?>
			<p class="bmc-note bmc-note--warn">
				دلیل فعال‌شدن حالت ایمن: <strong><?php echo esc_html( $bmc_safe_reason ? $bmc_safe_reason : 'دستی یا خودکار' ); ?></strong>
				<?php if ( ! empty( $bmc_safe_state['message'] ) ) : ?>
					<br /><span dir="ltr" class="bmc-mono"><?php echo esc_html( $bmc_safe_state['message'] ); ?></span>
				<?php endif; ?>
			</p>
		<?php endif; ?>

		<p>
			خطای مهلک ثبت‌شده در بازهٔ فعلی:
			<strong><?php echo esc_html( BMC_Helpers::to_persian_digits( isset( $bmc_safe_state['count'] ) ? (int) $bmc_safe_state['count'] : 0 ) ); ?></strong>
			&nbsp;|&nbsp; آخرین خطا:
			<strong><?php echo ! empty( $bmc_safe_state['last'] ) ? esc_html( BMC_Jalali::format( (int) $bmc_safe_state['last'] ) ) : '—'; ?></strong>
			&nbsp;|&nbsp; خطاهای مهارشده در همین درخواست:
			<strong><?php echo esc_html( BMC_Helpers::to_persian_digits( count( $bmc_safe_errors ) ) ); ?></strong>
		</p>

		<?php BMC_Admin::form_open( 'tools' ); ?>

		<?php BMC_Admin::row( 'محافظ پایداری', BMC_Admin::toggle( 'safe_guard', $settings['safe_guard'], 'خطاهای مهلک شناسایی و شمارش شوند' ), 'خاموش‌کردن این گزینه فقط شمارش و بازیابی خودکار را متوقف می‌کند.' ); ?>
		<?php BMC_Admin::row( 'بازیابی خودکار', BMC_Admin::toggle( 'safe_autorecover', $settings['safe_autorecover'], 'پس از چند خطای مهلک، افزونه خودش حالت ایمن را فعال کند' ) ); ?>
		<?php BMC_Admin::row( 'آستانهٔ خطای مهلک', '<input type="number" class="bmc-input bmc-input--sm" name="safe_crash_limit" min="1" max="10" value="' . esc_attr( (int) $settings['safe_crash_limit'] ) . '" />', 'تعداد خطای مهلک در ۱۰ دقیقه که حالت ایمن را فعال می‌کند.' ); ?>
		<?php BMC_Admin::row( 'ایمیل اطلاع‌رسانی', BMC_Admin::input( 'safe_notify_email', $settings['safe_notify_email'] ), 'خالی = ایمیل مدیر سایت.' ); ?>
		<?php BMC_Admin::row( 'نمایش جزئیات خطا', BMC_Admin::toggle( 'safe_debug_display', $settings['safe_debug_display'], 'جزئیات خطاهای مهارشده فقط به مدیر دارای دسترسی ووکامرس نشان داده شود' ) ); ?>

		<?php BMC_Admin::form_close( 'ذخیرهٔ تنظیمات محافظ' ); ?>

		<div class="bmc-inline" style="margin-top:12px">
			<button type="button" class="button button-primary bmc-action" data-do="run_health">بررسی سلامت سایت</button>
			<button type="button" class="button bmc-action" data-do="safe_on" data-confirm="1">فعال‌سازی دستی حالت ایمن</button>
			<button type="button" class="button bmc-action" data-do="safe_off">خروج از حالت ایمن</button>
			<button type="button" class="button bmc-action" data-do="safe_recover" data-confirm="1">بازیابی تنظیمات به حالت سازگار</button>
			<button type="button" class="button button-link-delete bmc-action" data-do="clear_crash">صفرکردن شمارندهٔ خطا</button>
		</div>

		<div id="bmcHealthResult" class="bmc-health-result"></div>

		<?php if ( $bmc_safe_errors ) : ?>
			<h3 class="bmc-subhead">خطاهای مهارشدهٔ اخیر</h3>
			<ul class="bmc-loglist">
				<?php foreach ( array_slice( array_reverse( $bmc_safe_errors ), 0, 12 ) as $bmc_err ) : ?>
					<li class="bmc-log bmc-log--error">
						<span class="bmc-log__time"><?php echo esc_html( BMC_Jalali::format( (int) $bmc_err['time'] ) ); ?></span>
						<span class="bmc-log__channel"><?php echo esc_html( $bmc_err['label'] ); ?></span>
						<span class="bmc-log__msg"><?php echo esc_html( $bmc_err['message'] ); ?><?php echo ! empty( $bmc_err['file'] ) ? ' <small dir="ltr">' . esc_html( $bmc_err['file'] . ':' . (int) $bmc_err['line'] ) . '</small>' : ''; ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>

		<?php if ( $bmc_boot_errors ) : ?>
			<h3 class="bmc-subhead">ماژول‌هایی که هنگام بارگذاری افزونه خطا دادند</h3>
			<ul class="bmc-loglist">
				<?php foreach ( $bmc_boot_errors as $bmc_where => $bmc_info ) : ?>
					<li class="bmc-log bmc-log--error">
						<span class="bmc-log__channel" dir="ltr"><?php echo esc_html( (string) $bmc_where ); ?></span>
						<span class="bmc-log__msg"><?php echo esc_html( isset( $bmc_info['message'] ) ? $bmc_info['message'] : '' ); ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
</section>

<section class="bmc-box">
	<div class="bmc-box__head"><h2>وضعیت جدول‌های دیتابیس</h2></div>
	<div class="bmc-box__body">
		<table class="bmc-table bmc-table--full">
			<thead><tr><th>جدول</th><th>نام کامل</th><th>ردیف‌ها</th><th>وضعیت</th></tr></thead>
			<tbody>
				<?php foreach ( $tables as $name => $info ) : ?>
					<tr>
						<td><?php echo esc_html( $name ); ?></td>
						<td class="bmc-mono" dir="ltr"><?php echo esc_html( $info['table'] ); ?></td>
						<td><?php echo esc_html( BMC_Helpers::to_persian_digits( $info['rows'] ) ); ?></td>
						<td><span class="bmc-pill <?php echo $info['exists'] ? 'is-done' : 'is-cancelled'; ?>"><?php echo $info['exists'] ? 'سالم' : 'موجود نیست'; ?></span></td>
					</tr>
				<?php endforeach; ?>
			</tbody>
		</table>

		<div class="bmc-inline" style="margin-top:12px">
			<button type="button" class="button bmc-action" data-do="rebuild_tables">بازسازی/به‌روزرسانی جدول‌ها</button>
			<button type="button" class="button bmc-action" data-do="run_cron">اجرای دستی نگهداری</button>
			<button type="button" class="button bmc-action" data-do="create_pages">ساخت صفحه‌های افزونه</button>
			<button type="button" class="button bmc-action" data-do="clear_old_logs">پاک‌کردن لاگ‌های قدیمی (بیش از ۳۰ روز)</button>
			<button type="button" class="button button-link-delete bmc-action" data-do="clear_logs" data-confirm="1">پاک‌سازی همهٔ لاگ‌ها</button>
		</div>
	</div>
</section>

<section class="bmc-box bmc-mode-adv">
	<div class="bmc-box__head"><h2>کش و بهینه‌سازی <span class="bmc-badge-adv">پیشرفته</span></h2></div>
	<div class="bmc-box__body">
		<?php
		$bmc_cache_status = class_exists( 'BMC_Cache' ) ? BMC_Cache::status() : array();
		?>
		<p>
			استثنای خودکار از کش:
			<span class="bmc-pill <?php echo empty( $bmc_cache_status['enabled'] ) ? 'is-cancelled' : 'is-done'; ?>"><?php echo empty( $bmc_cache_status['enabled'] ) ? 'خاموش' : 'روشن'; ?></span>
			&nbsp;|&nbsp; افزونه‌های شناسایی‌شده:
			<strong><?php echo $bmc_cache_status['detected'] ? esc_html( implode( '، ', (array) $bmc_cache_status['detected'] ) ) : '—'; ?></strong>
			&nbsp;|&nbsp; کلادفلر:
			<span class="bmc-pill <?php echo empty( $bmc_cache_status['cloudflare'] ) ? 'is-cancelled' : 'is-done'; ?>"><?php echo empty( $bmc_cache_status['cloudflare'] ) ? 'تنظیم نشده' : 'آماده'; ?></span>
		</p>
		<div class="bmc-inline" style="margin-top:12px">
			<button type="button" class="button bmc-action" data-do="purge_cache">پاک‌سازی کش (سایت + افزونه‌ها + کلادفلر)</button>
			<button type="button" class="button bmc-action" data-do="cf_cache_rule">ساخت قاعدهٔ «کش نشود» در کلادفلر</button>
		</div>
		<p class="bmc-hint" style="margin-top:10px">صفحه‌های سبد، خرید، اتصال اکانت و ورود همیشه از کش مستثنی می‌شوند تا کد یکبارمصرف یک کاربر به کاربر دیگر نمایش داده نشود.</p>
	</div>
</section>

<section class="bmc-box bmc-mode-adv">
	<div class="bmc-box__head"><h2>یکپارچه‌سازی المنتور <span class="bmc-badge-adv">پیشرفته</span></h2></div>
	<div class="bmc-box__body">
		<?php
		$bmc_el_active    = class_exists( 'BMC_Elementor' ) && BMC_Elementor::is_active();
		$bmc_el_version   = class_exists( 'BMC_Elementor' ) ? BMC_Elementor::version() : '';
		$bmc_el_supported = class_exists( 'BMC_Elementor' ) && BMC_Elementor::is_supported();
		$bmc_el_booted    = class_exists( 'BMC_Elementor' ) && BMC_Elementor::booted();
		$bmc_el_files     = class_exists( 'BMC_Elementor' ) && BMC_Elementor::files_loaded();
		$bmc_el_count     = class_exists( 'BMC_Elementor' ) ? count( BMC_Elementor::widget_names() ) : 0;

		if ( $bmc_el_booted && $bmc_el_files ) {
			$bmc_el_state = 'ثبت شده (' . esc_html( BMC_Helpers::to_persian_digits( $bmc_el_count ) ) . ' ویجت)';
			$bmc_el_class = 'is-done';
		} elseif ( $bmc_el_booted ) {
			$bmc_el_state = 'در انتظار آماده‌شدن کلاس‌های المنتور';
			$bmc_el_class = 'is-pending';
		} else {
			$bmc_el_state = 'ثبت نشده';
			$bmc_el_class = 'is-cancelled';
		}
		?>
		<p>
			وضعیت المنتور:
			<span class="bmc-pill <?php echo $bmc_el_active ? 'is-done' : 'is-cancelled'; ?>"><?php echo $bmc_el_active ? 'فعال' : 'نصب یا فعال نیست'; ?></span>
			<?php if ( $bmc_el_version ) : ?>
				&nbsp;|&nbsp; نسخهٔ المنتور: <strong dir="ltr"><?php echo esc_html( $bmc_el_version ); ?></strong>
			<?php endif; ?>
			&nbsp;|&nbsp; ویجت‌های BazzarMc:
			<span class="bmc-pill <?php echo esc_attr( $bmc_el_class ); ?>"><?php echo esc_html( $bmc_el_state ); ?></span>
		</p>

		<p class="bmc-hint">
			ویجت‌ها در پنل المنتور زیر دستهٔ <strong>«BazzarMc — فروشگاه ماینکرافت»</strong> قرار می‌گیرند:
			کارت حساب کاربری، اتصال اکانت ماینکرافت، وضعیت اتصال، منوی حساب کاربری، محتوای حساب کاربری، تحویل‌های من و رنک‌های کاربر.
		</p>

		<?php if ( $bmc_el_active && $bmc_el_booted && ! $bmc_el_files ) : ?>
			<p class="bmc-hint">کلاس‌های ویجت هنگام آماده‌شدن autoload المنتور بارگذاری و ثبت می‌شوند؛ این وضعیت خطا نیست و چیزی را از کار نمی‌اندازد.</p>
		<?php endif; ?>

		<?php if ( $bmc_el_active && ! $bmc_el_supported ) : ?>
			<p class="bmc-hint">نسخهٔ المنتور شما قدیمی است؛ برای ثبت ویجت‌ها به المنتور ۳.۱ یا جدیدتر نیاز دارید. افزونه بدون المنتور هم کامل کار می‌کند.</p>
		<?php endif; ?>

		<p class="bmc-hint">
			اگر صفحهٔ «حساب کاربری» را با المنتور می‌سازید و ویجت «کارت حساب کاربری» را در آن گذاشته‌اید، گزینهٔ «نمایش کارت در داشبورد حساب کاربری» را در بخش <strong>تأیید و حساب کاربری</strong> خاموش کنید تا کارت دوبار نمایش داده نشود.
		</p>

		<?php BMC_Admin::form_open( 'tools' ); ?>
		<label class="bmc-check">
			<input type="checkbox" name="elementor_enabled" value="yes" <?php checked( BMC_Settings::bool( 'elementor_enabled', true ) ); ?> />
			<span>ثبت ویجت‌های BazzarMc در المنتور</span>
		</label>
		<p class="bmc-hint">اگر المنتور نصب یا فعال نباشد، افزونه هیچ خطایی نمی‌دهد و همهٔ بخش‌ها با شورت‌کدها و قالب‌های ووکامرس کار می‌کنند.</p>
		<?php BMC_Admin::form_close( 'ذخیرهٔ تنظیمات المنتور' ); ?>
	</div>
</section>

<section class="bmc-box bmc-mode-adv">
	<div class="bmc-box__head"><h2>مهاجرت از BazzarMc for MC (نسخهٔ قدیمی) <span class="bmc-badge-adv">پیشرفته</span></h2></div>
	<div class="bmc-box__body">
		<p>
			وضعیت شناسایی:
			<strong><?php echo $report['legacy_plugin'] ? 'افزونهٔ قدیمی نصب است' : 'افزونهٔ قدیمی نصب نیست'; ?></strong> —
			<?php echo esc_html( BMC_Helpers::to_persian_digits( $report['users'] ) ); ?> کاربر دارای متای <code>minecraft_player</code> —
			<?php echo esc_html( BMC_Helpers::to_persian_digits( $report['deliveries'] ) ); ?> رکورد در جدول قدیمی.
		</p>

		<p>با اجرای مهاجرت، موارد زیر منتقل می‌شوند:</p>
		<ul class="bmc-list">
			<li>اکانت‌های متصل (متای <code>minecraft_player</code> → <code>bmc_mc_player</code>) به‌همراه نقش کاربری</li>
			<li>تحویل‌های در انتظار و تحویل‌شده از جدول <code>pending_deliveries</code></li>
			<li>تنظیمات محصولات همگام‌شده، نقش‌ها و سیاست نام کاربری</li>
		</ul>

		<button type="button" class="button button-primary bmc-action" data-do="run_migration" data-confirm="1">اجرای مهاجرت</button>
	</div>
</section>

<section class="bmc-box">
	<div class="bmc-box__head"><h2>نصب پلاگین سمت سرور ماینکرافت</h2></div>
	<div class="bmc-box__body">
		<ol class="bmc-list bmc-list--ordered">
			<li>فایل <code>BazzarMC.jar</code> را در پوشهٔ <code>plugins</code> سرور (Spigot/Paper) قرار دهید.</li>
			<li>سرور را یک‌بار ری‌استارت کنید تا <code>plugins/BazzarMC/config.yml</code> ساخته شود.</li>
			<li>مقدار <code>api.base-url</code> را روی <code dir="ltr"><?php echo esc_html( home_url( '/' ) ); ?></code> و <code>api.token</code> را روی توکن بالا تنظیم کنید.</li>
			<li>در بخش <code>products</code> کلید هر محصول را دقیقاً برابر «نام محصول با حروف کوچک»، «شناسهٔ تحویل» پنل، شناسهٔ محصول یا نامک آن قرار دهید.</li>
			<li>برای هر محصول پاداش دلخواه بگذارید: <code>material</code> (آیتم)، <code>commands</code> (دستور کنسول مثل رنک)، <code>player-commands</code>، <code>rank</code>، <code>points</code> (امتیاز)، <code>money</code> (پول)، <code>broadcast</code> و <code>message</code>. نمونهٔ آماده در تب <strong>محصولات و نقش‌ها ← «پیکربندی پاداش در ماینکرافت»</strong> تولید می‌شود.</li>
			<li>دستور <code>/bmc reload</code> را با کنسول یا OP اجرا کنید.</li>
		</ol>

		<p class="bmc-note">
			دستورهای بازی: <code dir="ltr">/mclink &lt;code&gt;</code>، <code dir="ltr">/mclink phone &lt;mobile&gt;</code>، <code dir="ltr">/mclink status</code>، <code dir="ltr">/mclink claim</code>
		</p>
		<p class="bmc-note">
			دستورهای مدیر برای پاداش‌ها: <code dir="ltr">/bmc rewards</code> (فهرست پاداش‌های تعریف‌شده و تنظیم دستورهای رنک/امتیاز/پول)،
			<code dir="ltr">/bmc reward &lt;بازیکن&gt; &lt;کلید&gt; [تعداد]</code> (اجرای آزمایشی بدون ثبت در سایت)،
			<code dir="ltr">/bmc deliveries &lt;بازیکن&gt;</code> (صف تحویل)
		</p>
		<p class="bmc-note bmc-note--warn">
			اگر محصولی در <code>products</code> تعریف نشده باشد ولی کلید/نام/سطح آن با یکی از رنک‌های <code>ranks.list</code> مطابقت کند،
			<strong>رنک به‌صورت خودکار با دستور <code>rewards.rank-command</code> اعطا می‌شود</strong> و ردیف تحویل هم «تحویل‌شده» علامت می‌خورد
			(کلید <code>delivery.mark-granted-as-delivered</code>). دلیل تحویل‌نشدن هر خرید هم به سایت گزارش می‌شود و در تب <strong>تحویل‌ها ← ستون «گزارش»</strong> دیده می‌شود.
		</p>
	</div>
</section>

<section class="bmc-box bmc-mode-adv">
	<div class="bmc-box__head"><h2>لاگ‌های اخیر <span class="bmc-badge-adv">پیشرفته</span></h2></div>
	<div class="bmc-box__body">
		<?php if ( empty( $logs ) ) : ?>
			<p class="bmc-empty">لاگی ثبت نشده است.</p>
		<?php else : ?>
			<ul class="bmc-loglist">
				<?php foreach ( $logs as $log ) : ?>
					<li class="bmc-log bmc-log--<?php echo esc_attr( $log->level ); ?>">
						<span class="bmc-log__time"><?php echo esc_html( BMC_Jalali::format( $log->created_at ) ); ?></span>
						<span class="bmc-log__channel"><?php echo esc_html( $log->channel ); ?></span>
						<span class="bmc-log__msg"><?php echo esc_html( $log->message ); ?><?php echo $log->context ? ' <small dir="ltr">' . esc_html( $log->context ) . '</small>' : ''; ?></span>
					</li>
				<?php endforeach; ?>
			</ul>
		<?php endif; ?>
	</div>
</section>

<section class="bmc-box bmc-mode-adv">
	<div class="bmc-box__head"><h2>پاک‌سازی کامل هنگام حذف افزونه <span class="bmc-badge-adv">پیشرفته</span></h2></div>
	<div class="bmc-box__body">
		<form method="post" class="bmc-form">
			<?php wp_nonce_field( 'bmc_save_settings', 'bmc_settings_nonce' ); ?>
			<input type="hidden" name="bmc_tab" value="purge" />

			<div class="bmc-row">
				<div class="bmc-row__label">
					<label>حذف داده‌ها هنگام Uninstall</label>
					<span class="bmc-row__hint">اگر روشن باشد، با حذف افزونه جدول‌ها، تنظیمات و متای اتصال کاربران پاک می‌شود.</span>
				</div>
				<div class="bmc-row__field">
					<?php echo BMC_Admin::toggle( 'purge_on_uninstall', $settings['purge_on_uninstall'], 'جدول‌ها و تنظیمات حذف شوند' ); ?>
				</div>
			</div>

			<div class="bmc-inline" style="margin-top:12px">
				<button type="submit" class="button button-primary">ذخیره</button>
			</div>
		</form>

		<p class="bmc-note bmc-note--warn" style="margin-top:14px">حذف جدول‌ها بازگشت‌پذیر نیست. اگر ممکن است افزونه را دوباره نصب کنید، این گزینه را خاموش بگذارید.</p>
	</div>
</section>
