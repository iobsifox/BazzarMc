<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

BMC_Admin::form_open( 'login' );

BMC_Admin::section_open(
	'روش‌های تأیید برای اتصال اکانت',
	'این کدها فقط برای <strong>اتصال حساب سایت به اکانت ماینکرافت</strong> استفاده می‌شوند.'
);

$bmc_verify_methods = (array) $settings['verify_methods'];
?>
<div class="bmc-checklist bmc-checklist--inline">
	<label class="bmc-check"><input type="checkbox" name="verify_methods[]" value="dashboard" <?php checked( in_array( 'dashboard', $bmc_verify_methods, true ) ); ?> /> <span><?php echo bmc_get_icon( 'desktop_windows', array( 'size' => 15 ) ); ?> داشبورد / پنل کاربری (رایگان)</span></label>
	<label class="bmc-check"><input type="checkbox" name="verify_methods[]" value="email" <?php checked( in_array( 'email', $bmc_verify_methods, true ) ); ?> /> <span><?php echo bmc_get_icon( 'mail', array( 'size' => 15 ) ); ?> ایمیل</span></label>
</div>
<p class="bmc-hint">حداقل یک روش باید فعال باشد. روش «داشبورد» همیشه رایگان است و کد در همان صفحهٔ اتصال (و برای مدیر در ویجت پیشخوان) نمایش داده می‌شود.</p>
<?php

BMC_Admin::row(
	'روش پیش‌فرض',
	BMC_Admin::select(
		'verify_default',
		$settings['verify_default'],
		array(
			'dashboard' => 'داشبورد سایت',
			'email'     => 'ایمیل',
		)
	),
	'اگر روش پیش‌فرض فعال نباشد، افزونه به اولین روش فعال برمی‌گردد.'
);

BMC_Admin::row( 'ویجت پیشخوان مدیر', BMC_Admin::toggle( 'otp_dashboard_widget', $settings['otp_dashboard_widget'], 'کدهای فعال در پیشخوان مدیر نمایش داده شود' ), 'برای پشتیبانی سریع کاربران بدون هیچ هزینهٔ ارسال.' );
BMC_Admin::row( 'جعبهٔ کد در پنل کاربری', BMC_Admin::toggle( 'otp_dashboard_box', $settings['otp_dashboard_box'], 'کد در کارت حساب کاربری هم نمایش داده شود' ), 'خودِ کاربر کد را در همان صفحه می‌بیند و نیازی به ایمیل نیست.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'تنظیمات کد تأیید', 'این مقدارها برای کد تأیید اتصال اکانت (روش داشبورد و ایمیل) استفاده می‌شوند.', 'advanced' );

BMC_Admin::row( 'طول کد', '<input type="number" class="bmc-input bmc-input--sm" name="otp_length" min="4" max="8" value="' . esc_attr( (int) $settings['otp_length'] ) . '" />', 'بین ۴ تا ۸ رقم.' );
BMC_Admin::row( 'اعتبار کد (ثانیه)', '<input type="number" class="bmc-input bmc-input--sm" name="otp_ttl" min="30" max="900" value="' . esc_attr( (int) $settings['otp_ttl'] ) . '" />', 'پیش‌فرض ۱۲۰ ثانیه (۲ دقیقه).' );
BMC_Admin::row( 'فاصلهٔ حداقلی بین دو درخواست (ثانیه)', '<input type="number" class="bmc-input bmc-input--sm" name="otp_rate_limit" min="10" max="3600" value="' . esc_attr( (int) $settings['otp_rate_limit'] ) . '" />', 'محدودیت نرخ برای جلوگیری از درخواست پشت‌سرهم.' );
BMC_Admin::row( 'حداکثر تلاش ناموفق', '<input type="number" class="bmc-input bmc-input--sm" name="otp_max_attempts" min="1" max="20" value="' . esc_attr( (int) $settings['otp_max_attempts'] ) . '" />', 'پس از این تعداد تلاش ناموفق، کد باطل می‌شود.' );
BMC_Admin::row( 'حداکثر ارسال مجدد', '<input type="number" class="bmc-input bmc-input--sm" name="otp_resend_limit" min="1" max="20" value="' . esc_attr( (int) $settings['otp_resend_limit'] ) . '" />', 'تعداد مجاز ارسال مجدد برای هر کد.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'کانال ایمیل', 'کد تأیید و اطلاع‌رسانی‌ها با تابع <code>wp_mail()</code> وردپرس ارسال می‌شوند.' );

BMC_Admin::row( 'ارسال ایمیل', BMC_Admin::toggle( 'email_enabled', $settings['email_enabled'], 'کانال ایمیل فعال باشد' ), 'اگر خاموش باشد، فقط روش «داشبورد» در دسترس است.' );
BMC_Admin::row( 'موضوع ایمیل کد', '<input class="bmc-input" type="text" name="email_tpl_subject" value="' . esc_attr( (string) $settings['email_tpl_subject'] ) . '" />', 'متغیرها: <code>{site}</code> <code>{code}</code> <code>{player}</code> <code>{minutes}</code>' );
BMC_Admin::row( 'متن ایمیل کد', BMC_Admin::textarea( 'email_tpl_body', (string) $settings['email_tpl_body'], 6 ), 'متغیرها: <code>{site}</code> <code>{code}</code> <code>{player}</code> <code>{minutes}</code> — HTML مجاز است.' );

BMC_Admin::row(
	'تست ارسال ایمیل',
	'<div class="bmc-inline">'
		. '<input class="bmc-input" type="email" id="bmcTestEmail" dir="ltr" placeholder="you@example.com" style="max-width:240px" />'
		. '<button type="button" class="button button-secondary bmc-action" data-do="test_email" data-extra="to:#bmcTestEmail">'
		. bmc_get_icon( 'mark_email_unread', array( 'size' => 16 ) )
		. '<span>ارسال ایمیل تست</span></button>'
		. '</div>',
	'یک کد نمونه به این ایمیل ارسال می‌شود تا مسیر ارسال بررسی شود.'
);

BMC_Admin::section_close();

BMC_Admin::section_open( 'پنل حساب کاربری (حساب من)', 'کارت اختصاصی BazzarMc فقط در داشبورد حساب کاربری نمایش داده می‌شود و زیرصفحه‌ها بدون کارت می‌مانند.' );

BMC_Admin::row(
	'کارت حساب کاربری',
	BMC_Admin::toggle( 'myaccount_card', $settings['myaccount_card'], 'نمایش کارت BazzarMc در داشبورد حساب کاربری ووکامرس' ),
	'این کارت مشخصات کاربر، وضعیت اتصال ماینکرافت و رنک فعال را نشان می‌دهد.'
);

BMC_Admin::section_close();

BMC_Admin::section_open(
	'منوی حساب کاربری و طراحی موبایل',
	'منوی اختصاصی BazzarMc جای منوی پیش‌فرض ووکامرس را در صفحه‌های حساب کاربری می‌گیرد و برای موبایل چیدمان بهینه دارد.',
	'advanced'
);

BMC_Admin::row(
	'جایگزینی منوی ووکامرس',
	BMC_Admin::toggle( 'nav_override', $settings['nav_override'], 'منوی BazzarMc جای <code>myaccount/navigation.php</code> ووکامرس را بگیرد' )
);

BMC_Admin::row(
	'چیدمان موبایل',
	BMC_Admin::select(
		'nav_mobile_layout',
		$settings['nav_mobile_layout'],
		array(
			'scroll'   => 'افقی لغزان — یک ردیف قابل کشیدن با انگشت (پیشنهادی)',
			'grid'     => 'شبکهٔ سه‌ستونی — آیتم‌ها در سه ستون',
			'icons'    => 'آیکونی فشرده — آیکون بزرگ با برچسب کوچک',
			'dropdown' => 'فهرست کشویی — یک select برای انتخاب بخش',
			'collapse' => 'جمع‌شونده — با لمس باز می‌شود',
			'vertical' => 'عمودی — مثل دسکتاپ',
		)
	)
);

BMC_Admin::row( 'برچسب آیتم‌ها در موبایل', BMC_Admin::toggle( 'nav_mobile_labels', $settings['nav_mobile_labels'], 'نام بخش‌ها کنار آیکون‌ها در موبایل نمایش داده شود' ) );
BMC_Admin::row( 'منوی چسبان در موبایل', BMC_Admin::toggle( 'nav_mobile_sticky', $settings['nav_mobile_sticky'], 'منو هنگام اسکرول صفحه در بالای نمایشگر بماند' ) );
BMC_Admin::row(
	'عرض شکست موبایل',
	'<input type="number" class="bmc-input bmc-input--sm" name="nav_mobile_breakpoint" min="320" max="1600" value="' . esc_attr( (int) $settings['nav_mobile_breakpoint'] ) . '" />',
	'تا این عرض (پیکسل) چیدمان موبایل اعمال می‌شود.'
);

BMC_Admin::section_close();

$bmc_positions = BMC_Settings::endpoint_positions();
$bmc_ep_icons  = BMC_Settings::endpoint_icon_options();
$bmc_ep_rows   = class_exists( 'BMC_Account_Endpoints' ) ? BMC_Account_Endpoints::status_rows() : array();

BMC_Admin::section_open(
	'نقطهٔ فرود اتصال ماینکرافت',
	'افزودن بخش اتصال اکانت به منوی حساب کاربری ووکامرس.',
	'advanced'
);

if ( $bmc_ep_rows ) {
	echo '<div class="bmc-table-wrap"><table class="bmc-table"><thead><tr><th>بخش</th><th>عنوان در منو</th><th>آدرس</th><th>وضعیت</th></tr></thead><tbody>';

	foreach ( $bmc_ep_rows as $bmc_ep ) {
		printf(
			'<tr><td><span class="bmc-inline">%1$s<strong>%2$s</strong></span></td><td>%3$s</td><td><code class="bmc-token bmc-token--sm">%4$s</code></td><td>%5$s</td></tr>',
			bmc_get_icon( $bmc_ep['icon'], array( 'size' => 16 ) ),
			esc_html( $bmc_ep['label'] ),
			esc_html( $bmc_ep['title'] ),
			esc_html( $bmc_ep['url'] ),
			$bmc_ep['in_menu'] ? '<span class="bmc-pill is-done">در منو فعال</span>' : '<span class="bmc-pill is-cancelled">پنهان از منو</span>'
		);
	}

	echo '</tbody></table></div>';
}

BMC_Admin::row( 'نمایش در منو', BMC_Admin::toggle( 'ma_connect_enabled', $settings['ma_connect_enabled'], '«اتصال حساب» در منوی حساب کاربری باشد' ) );
BMC_Admin::row( 'عنوان در منو', BMC_Admin::input( 'ma_connect_title', $settings['ma_connect_title'] ) );
BMC_Admin::row( 'آدرس (نامک)', BMC_Admin::input( 'ma_connect_slug', $settings['ma_connect_slug'], array( 'dir' => 'ltr', 'placeholder' => 'minecraft' ) ) );
BMC_Admin::row( 'آیکون', BMC_Admin::select( 'ma_connect_icon', $settings['ma_connect_icon'], $bmc_ep_icons ) );
BMC_Admin::row( 'جایگاه در منو', BMC_Admin::select( 'ma_connect_position', $settings['ma_connect_position'], $bmc_positions ) );
BMC_Admin::row( 'نشان وضعیت اتصال', BMC_Admin::toggle( 'ma_connect_badge', $settings['ma_connect_badge'], 'کنار این گزینه وضعیت متصل بودن نمایش داده شود' ) );

echo '<div class="bmc-inline" style="margin-top:10px"><button type="button" class="button bmc-action" data-do="flush_permalinks">' . bmc_get_icon( 'refresh', array( 'size' => 16 ) ) . '<span>بازسازی پیوندهای یکتا</span></button></div>';

BMC_Admin::section_close();

BMC_Admin::section_open( 'فرم اتصال اکانت', 'ظاهر و متن‌های جعبهٔ اتصال اکانت ماینکرافت.', 'advanced' );

BMC_Admin::row( 'پهنای جعبه', BMC_Admin::select( 'link_width', $settings['link_width'], array( 'narrow' => 'باریک (پیشنهادی)', 'wide' => 'پهن' ) ) );
BMC_Admin::row( 'اندازهٔ آواتار', '<input type="number" class="bmc-input bmc-input--sm" name="link_avatar_size" min="32" max="192" value="' . esc_attr( (int) $settings['link_avatar_size'] ) . '" />', 'بین ۳۲ تا ۱۹۲ پیکسل.' );
BMC_Admin::row( 'راهنمای سه‌مرحله‌ای', BMC_Admin::toggle( 'link_show_steps', $settings['link_show_steps'], 'نمایش سه گام بالای فرم' ) );
BMC_Admin::row( 'متن مرحلهٔ ۱', BMC_Admin::textarea( 'link_step_1', (string) $settings['link_step_1'], 2 ) );
BMC_Admin::row( 'متن مرحلهٔ ۲', BMC_Admin::textarea( 'link_step_2', (string) $settings['link_step_2'], 2 ) );
BMC_Admin::row( 'متن مرحلهٔ ۳', BMC_Admin::textarea( 'link_step_3', (string) $settings['link_step_3'], 2 ) );
BMC_Admin::row( 'برچسب فیلد نام کاربری', BMC_Admin::input( 'link_player_label', $settings['link_player_label'] ) );
BMC_Admin::row( 'placeholder نام کاربری', BMC_Admin::input( 'link_player_placeholder', $settings['link_player_placeholder'] ) );
BMC_Admin::row( 'متن دکمهٔ ساخت کد', BMC_Admin::input( 'link_submit_text', $settings['link_submit_text'] ) );
BMC_Admin::row( 'متن بالای کد', BMC_Admin::textarea( 'link_code_hint', (string) $settings['link_code_hint'], 2 ) );
BMC_Admin::row( 'متن دکمهٔ کپی', BMC_Admin::input( 'link_copy_text', $settings['link_copy_text'] ) );
BMC_Admin::row( 'متن دکمهٔ کد جدید', BMC_Admin::input( 'link_regen_text', $settings['link_regen_text'] ) );
BMC_Admin::row( 'کارت کد تأیید', BMC_Admin::toggle( 'link_show_otp_card', $settings['link_show_otp_card'], 'کارت روش جایگزین: کد تأیید نمایش داده شود' ) );
BMC_Admin::row( 'عنوان کارت کد تأیید', BMC_Admin::input( 'link_otp_title', $settings['link_otp_title'] ) );
BMC_Admin::row( 'نمایش UUID', BMC_Admin::toggle( 'link_show_uuid', $settings['link_show_uuid'], 'در وضعیت متصل UUID اکانت نمایش داده شود' ) );
BMC_Admin::row( 'نمایش تاریخ اتصال', BMC_Admin::toggle( 'link_show_linked_at', $settings['link_show_linked_at'], 'تاریخ شمسی اتصال نمایش داده شود' ) );
BMC_Admin::row( 'دکمهٔ فروشگاه', BMC_Admin::toggle( 'link_show_shop_button', $settings['link_show_shop_button'], 'در وضعیت متصل دکمهٔ رفتن به فروشگاه نمایش داده شود' ) );
BMC_Admin::row( 'دکمهٔ قطع اتصال', BMC_Admin::toggle( 'link_show_unlink', $settings['link_show_unlink'], 'کاربر بتواند اتصال را قطع کند' ) );
BMC_Admin::row( 'عنوان کارت ورود', BMC_Admin::input( 'link_login_title', $settings['link_login_title'] ), 'برای کاربری که وارد سایت نشده است.' );
BMC_Admin::row( 'متن کارت ورود', BMC_Admin::textarea( 'link_login_body', (string) $settings['link_login_body'], 3 ) );
BMC_Admin::row( 'متن دکمهٔ ورود', BMC_Admin::input( 'link_login_button', $settings['link_login_button'] ) );

BMC_Admin::section_close();

BMC_Admin::section_open( 'صفحهٔ اتصال اکانت' );

BMC_Admin::row( 'صفحهٔ اتصال اکانت', BMC_Admin::page_select( 'page_link', (int) $settings['page_link'] ), 'شورت‌کد: <code>[bazzarmc]</code>' );

echo '<div class="bmc-inline" style="margin-top:10px"><button type="button" class="button bmc-action" data-do="create_pages">ساخت خودکار صفحه</button></div>';

BMC_Admin::section_close();

BMC_Admin::form_close();
