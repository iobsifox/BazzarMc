<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_ticket_id = isset( $_GET['ticket'] ) ? absint( wp_unslash( $_GET['ticket'] ) ) : 0; // phpcs:ignore WordPress.Security.NonceVerification
$bmc_ticket    = $bmc_ticket_id ? BMC_Tickets::get( $bmc_ticket_id ) : null;
$bmc_base_url  = admin_url( 'admin.php?page=bazzarmc&tab=tickets' );

$bmc_tone_map = array(
	'open'     => 'is-info',
	'answered' => 'is-done',
	'pending'  => 'is-pending',
	'closed'   => 'is-cancelled',
	'low'      => 'is-cancelled',
	'normal'   => 'is-info',
	'high'     => 'is-pending',
	'urgent'   => 'is-expired',
);

if ( isset( $_GET['bmc_msg'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
	$bmc_msg_key = sanitize_key( wp_unslash( $_GET['bmc_msg'] ) );
	$bmc_msg_map = array(
		'replied'          => 'پاسخ شما با موفقیت ارسال شد.',
		'note_added'       => 'یادداشت داخلی با موفقیت ذخیره شد.',
		'status_updated'   => 'وضعیت تیکت با موفقیت به‌روزرسانی شد.',
		'priority_updated' => 'اولویت تیکت با موفقیت به‌روزرسانی شد.',
		'deleted'          => 'تیکت با موفقیت حذف شد.',
	);
	if ( isset( $bmc_msg_map[ $bmc_msg_key ] ) ) {
		echo '<div class="bmc-notice bmc-notice--ok">' . bmc_get_icon( 'check_circle', array( 'size' => 17 ) )
			. '<span>' . esc_html( $bmc_msg_map[ $bmc_msg_key ] ) . '</span></div>';
	}
}

if ( isset( $_GET['bmc_ticket_note'] ) ) { // phpcs:ignore WordPress.Security.NonceVerification
	echo '<div class="bmc-notice bmc-notice--ok">' . bmc_get_icon( 'check_circle', array( 'size' => 17 ) )
		. '<span>' . esc_html( sanitize_text_field( rawurldecode( wp_unslash( $_GET['bmc_ticket_note'] ) ) ) ) . '</span></div>'; // phpcs:ignore WordPress.Security.NonceVerification
}

if ( $bmc_ticket ) :
	$bmc_owner    = get_userdata( (int) $bmc_ticket->user_id );
	$bmc_messages = BMC_Tickets::messages( (int) $bmc_ticket->id, true );
	$bmc_product  = BMC_Tickets::ticket_product_name( $bmc_ticket );
	$bmc_player   = BMC_Link::get_linked_player( (int) $bmc_ticket->user_id );
	$bmc_grants   = BMC_Roles::active_grants( (int) $bmc_ticket->user_id );
	$bmc_status   = BMC_Tickets::status_meta( $bmc_ticket->status );
	?>
	<section class="bmc-box">
		<div class="bmc-box__head">
			<h2>
				<?php echo bmc_get_icon( $bmc_status['icon'], array( 'size' => 18 ) ); ?>
				تیکت <?php echo esc_html( BMC_Tickets::reference( $bmc_ticket->id ) ); ?>
			</h2>
			<div class="bmc-inline">
				<a class="button" href="<?php echo esc_url( $bmc_base_url ); ?>"><?php echo bmc_get_icon( 'keyboard_arrow_right', array( 'size' => 16 ) ); ?> بازگشت به فهرست</a>
				<a class="button" href="<?php echo esc_url( BMC_Tickets::url( (int) $bmc_ticket->id ) ); ?>" target="_blank" rel="noopener"><?php echo bmc_get_icon( 'open_in_new', array( 'size' => 15 ) ); ?> نمای کاربر</a>
			</div>
		</div>

		<div class="bmc-box__body">
			<div class="bmc-ticket-head">
				<h3><?php echo esc_html( $bmc_ticket->subject ); ?></h3>
				<div class="bmc-ticket-meta">
					<span class="bmc-pill <?php echo esc_attr( isset( $bmc_tone_map[ $bmc_ticket->status ] ) ? $bmc_tone_map[ $bmc_ticket->status ] : '' ); ?>"><?php echo esc_html( $bmc_status['label'] ); ?></span>
					<span class="bmc-pill <?php echo esc_attr( isset( $bmc_tone_map[ $bmc_ticket->priority ] ) ? $bmc_tone_map[ $bmc_ticket->priority ] : '' ); ?>">اولویت: <?php echo esc_html( BMC_Tickets::priority_label( $bmc_ticket->priority ) ); ?></span>
					<span class="bmc-pill is-cancelled"><?php echo esc_html( BMC_Tickets::category_label( $bmc_ticket->category ) ); ?></span>
					<span class="bmc-dim">ثبت: <?php echo esc_html( BMC_Jalali::format( $bmc_ticket->created_at ) ); ?></span>
					<span class="bmc-dim">آخرین بروزرسانی: <?php echo esc_html( BMC_Jalali::format( $bmc_ticket->updated_at ) ); ?></span>
					<span class="bmc-dim">پاسخ‌ها: <?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_ticket->replies ) ); ?></span>
				</div>
			</div>

			<div class="bmc-ticket-layout">
				<div class="bmc-ticket-main">
					<div class="bmc-thread">
						<?php if ( empty( $bmc_messages ) ) : ?>
							<p class="bmc-empty">پیامی ثبت نشده است.</p>
						<?php else : ?>
							<?php foreach ( $bmc_messages as $bmc_message ) : ?>
								<div class="bmc-msg <?php echo ! empty( $bmc_message->is_staff ) ? 'bmc-msg--staff' : 'bmc-msg--user'; ?><?php echo ! empty( $bmc_message->is_note ) ? ' bmc-msg--note' : ''; ?>">
									<div class="bmc-msg__head">
										<strong><?php echo esc_html( '' !== $bmc_message->author ? $bmc_message->author : 'کاربر' ); ?></strong>
										<?php if ( ! empty( $bmc_message->is_note ) ) : ?>
											<span class="bmc-pill is-pending"><?php echo bmc_get_icon( 'visibility', array( 'size' => 13 ) ); ?> یادداشت داخلی</span>
										<?php elseif ( ! empty( $bmc_message->is_staff ) ) : ?>
											<span class="bmc-pill is-done"><?php echo bmc_get_icon( 'support_agent', array( 'size' => 13 ) ); ?> پشتیبانی</span>
										<?php else : ?>
											<span class="bmc-pill is-info"><?php echo bmc_get_icon( 'person', array( 'size' => 13 ) ); ?> کاربر</span>
										<?php endif; ?>
										<span class="bmc-dim"><?php echo esc_html( BMC_Jalali::format( $bmc_message->created_at ) ); ?></span>
									</div>
									<div class="bmc-msg__body"><?php echo wp_kses_post( nl2br( esc_html( (string) $bmc_message->body ) ) ); ?></div>
								</div>
							<?php endforeach; ?>
						<?php endif; ?>
					</div>

					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="bmc-reply">
						<input type="hidden" name="action" value="bmc_ticket" />
						<input type="hidden" name="ticket_action" value="reply" />
						<input type="hidden" name="ticket_id" value="<?php echo esc_attr( (int) $bmc_ticket->id ); ?>" />
						<?php wp_nonce_field( BMC_Tickets::NONCE, 'bmc_ticket_nonce' ); ?>

						<label for="bmc-reply-body">پاسخ پشتیبانی</label>
						<textarea id="bmc-reply-body" class="bmc-input bmc-textarea" name="ticket_body" rows="5" placeholder="پاسخ خود را بنویسید…"></textarea>

						<div class="bmc-reply__foot">
							<label class="bmc-check">
								<input type="checkbox" name="is_note" value="1" />
								<span>یادداشت داخلی باشد (برای کاربر ارسال و نمایش داده نمی‌شود)</span>
							</label>
							<button type="submit" class="button button-primary"><?php echo bmc_get_icon( 'send', array( 'size' => 16 ) ); ?> ارسال پاسخ</button>
						</div>
					</form>

					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="bmc-ticket-actions">
						<input type="hidden" name="action" value="bmc_ticket" />
						<input type="hidden" name="ticket_action" value="status" />
						<input type="hidden" name="ticket_id" value="<?php echo esc_attr( (int) $bmc_ticket->id ); ?>" />
						<?php wp_nonce_field( BMC_Tickets::NONCE, 'bmc_ticket_nonce' ); ?>

						<div>
							<label>وضعیت</label>
							<?php
							$bmc_status_options = array();
							foreach ( BMC_Tickets::statuses() as $bmc_key => $bmc_meta ) {
								$bmc_status_options[ $bmc_key ] = $bmc_meta['label'];
							}
							echo BMC_Admin::select( 'status', $bmc_ticket->status, $bmc_status_options ); // phpcs:ignore WordPress.Security.EscapeOutput
							?>
						</div>

						<div>
							<label>اولویت</label>
							<?php
							$bmc_priority_options = array();
							foreach ( BMC_Tickets::priorities() as $bmc_key => $bmc_meta ) {
								$bmc_priority_options[ $bmc_key ] = $bmc_meta['label'];
							}
							echo BMC_Admin::select( 'priority', $bmc_ticket->priority, $bmc_priority_options ); // phpcs:ignore WordPress.Security.EscapeOutput
							?>
						</div>

						<button type="submit" class="button"><?php echo bmc_get_icon( 'task_alt', array( 'size' => 16 ) ); ?> ذخیرهٔ وضعیت</button>
					</form>
				</div>

				<aside class="bmc-ticket-side">
					<div class="bmc-side-card">
						<h4><?php echo bmc_get_icon( 'person', array( 'size' => 15 ) ); ?> کاربر</h4>
						<ul>
							<li><span>نام</span><strong><?php echo esc_html( $bmc_owner ? $bmc_owner->display_name : '—' ); ?></strong></li>
							<li><span>ایمیل</span><strong dir="ltr"><?php echo esc_html( $bmc_owner ? $bmc_owner->user_email : '—' ); ?></strong></li>
							<li><span>موبایل</span><strong dir="ltr"><?php echo esc_html( BMC_Auth::get_user_mobile( (int) $bmc_ticket->user_id ) ? BMC_Auth::mask_mobile( BMC_Auth::get_user_mobile( (int) $bmc_ticket->user_id ) ) : '—' ); ?></strong></li>
							<li><span>ماینکرافت</span><strong><?php echo $bmc_player ? esc_html( $bmc_player ) : '<em class="bmc-dim">متصل نیست</em>'; ?></strong></li>
							<li><span>تیکت‌های کاربر</span><strong><?php echo esc_html( BMC_Helpers::to_persian_digits( (int) BMC_Tickets::counts( (int) $bmc_ticket->user_id )['total'] ) ); ?></strong></li>
						</ul>
						<?php if ( $bmc_owner ) : ?>
							<a class="button button-small" href="<?php echo esc_url( admin_url( 'user-edit.php?user_id=' . (int) $bmc_owner->ID ) ); ?>">ویرایش کاربر</a>
						<?php endif; ?>
					</div>

					<div class="bmc-side-card">
						<h4><?php echo bmc_get_icon( 'inventory_2', array( 'size' => 15 ) ); ?> محصول و سفارش</h4>
						<ul>
							<li><span>محصول</span><strong><?php echo $bmc_product ? esc_html( $bmc_product ) : '<em class="bmc-dim">بدون محصول</em>'; ?></strong></li>
							<li><span>شناسهٔ محصول</span><strong><?php echo $bmc_ticket->product_id ? esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_ticket->product_id ) ) : '—'; ?></strong></li>
							<li>
								<span>سفارش</span>
								<strong>
									<?php if ( $bmc_ticket->order_id ) : ?>
										<a href="<?php echo esc_url( admin_url( 'post.php?post=' . (int) $bmc_ticket->order_id . '&action=edit' ) ); ?>">#<?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_ticket->order_id ) ); ?></a>
									<?php else : ?>—<?php endif; ?>
								</strong>
							</li>
						</ul>
					</div>

					<?php if ( $bmc_grants ) : ?>
						<div class="bmc-side-card">
							<h4><?php echo bmc_get_icon( 'military_tech', array( 'size' => 15 ) ); ?> رنک‌های فعال</h4>
							<ul>
								<?php foreach ( $bmc_grants as $bmc_grant ) : ?>
									<li>
										<span><?php echo esc_html( isset( $bmc_grant['label'] ) ? $bmc_grant['label'] : '' ); ?></span>
										<strong><?php echo esc_html( isset( $bmc_grant['remaining_human'] ) ? $bmc_grant['remaining_human'] : '—' ); ?></strong>
									</li>
								<?php endforeach; ?>
							</ul>
						</div>
					<?php endif; ?>

					<form method="post" action="<?php echo esc_url( admin_url( 'admin-post.php' ) ); ?>" class="bmc-side-card bmc-danger"
						onsubmit="return window.confirm('این تیکت به‌همراه همهٔ پیام‌ها حذف شود؟');">
						<input type="hidden" name="action" value="bmc_ticket" />
						<input type="hidden" name="ticket_action" value="delete" />
						<input type="hidden" name="ticket_id" value="<?php echo esc_attr( (int) $bmc_ticket->id ); ?>" />
						<?php wp_nonce_field( BMC_Tickets::NONCE, 'bmc_ticket_nonce' ); ?>
						<h4><?php echo bmc_get_icon( 'delete', array( 'size' => 15 ) ); ?> حذف تیکت</h4>
						<p class="bmc-hint">با حذف، همهٔ پیام‌ها نیز پاک می‌شوند و قابل بازگردانی نیست.</p>
						<button type="submit" class="button button-link-delete">حذف کامل تیکت</button>
					</form>
				</aside>
			</div>
		</div>
	</section>
<?php else : ?>
	<?php
	$bmc_filter_status   = isset( $_GET['status'] ) ? sanitize_key( wp_unslash( $_GET['status'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$bmc_filter_category = isset( $_GET['category'] ) ? sanitize_key( wp_unslash( $_GET['category'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$bmc_filter_search   = isset( $_GET['s'] ) ? sanitize_text_field( wp_unslash( $_GET['s'] ) ) : ''; // phpcs:ignore WordPress.Security.NonceVerification
	$bmc_paged           = isset( $_GET['paged'] ) ? max( 1, (int) $_GET['paged'] ) : 1; // phpcs:ignore WordPress.Security.NonceVerification

	$bmc_result = BMC_Tickets::query(
		array(
			'status'   => $bmc_filter_status,
			'category' => $bmc_filter_category,
			'search'   => $bmc_filter_search,
			'page'     => $bmc_paged,
			'per_page' => BMC_Tickets::per_page(),
		)
	);

	$bmc_counts    = BMC_Tickets::counts();
	$bmc_attention = (int) BMC_Tickets::needs_attention();

	$bmc_status_tabs = array( '' => 'همه' );

	foreach ( BMC_Tickets::statuses() as $bmc_key => $bmc_meta ) {
		$bmc_status_tabs[ $bmc_key ] = $bmc_meta['label'];
	}
	?>
	<section class="bmc-box">
		<div class="bmc-box__head">
			<h2><?php echo bmc_get_icon( 'support_agent', array( 'size' => 18 ) ); ?> تیکت‌های پشتیبانی</h2>
			<div class="bmc-inline">
				<span class="bmc-status-pill <?php echo $bmc_attention > 0 ? 'is-off' : 'is-on'; ?>">
					<?php echo bmc_get_icon( 'inbox', array( 'size' => 15 ) ); ?>
					نیازمند پاسخ: <strong><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_attention ) ); ?></strong>
				</span>
			</div>
		</div>

		<div class="bmc-box__body">
			<ul class="bmc-filters">
				<?php foreach ( $bmc_status_tabs as $bmc_key => $bmc_label ) : ?>
					<li>
						<a class="<?php echo $bmc_filter_status === $bmc_key ? 'is-active' : ''; ?>"
							href="<?php echo esc_url( add_query_arg( array( 'status' => $bmc_key, 'paged' => false ), $bmc_base_url ) ); ?>">
							<?php echo esc_html( $bmc_label ); ?>
							<?php if ( '' !== $bmc_key ) : ?>
								<small>(<?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_counts[ $bmc_key ] ) ); ?>)</small>
							<?php endif; ?>
						</a>
					</li>
				<?php endforeach; ?>
			</ul>

			<form method="get" class="bmc-toolbar">
				<input type="hidden" name="page" value="bazzarmc" />
				<input type="hidden" name="tab" value="tickets" />
				<input type="hidden" name="status" value="<?php echo esc_attr( $bmc_filter_status ); ?>" />
				<input type="search" class="bmc-input" name="s" value="<?php echo esc_attr( $bmc_filter_search ); ?>" placeholder="جست‌وجو در موضوع یا کد تیکت…" />
				<?php
				$bmc_category_options = array( '' => 'همهٔ دسته‌ها' );

				foreach ( BMC_Tickets::categories() as $bmc_key => $bmc_meta ) {
					$bmc_category_options[ $bmc_key ] = $bmc_meta['label'];
				}

				echo BMC_Admin::select( 'category', $bmc_filter_category, $bmc_category_options ); // phpcs:ignore WordPress.Security.EscapeOutput
				?>
				<button type="submit" class="button button-primary"><?php echo bmc_get_icon( 'manage_search', array( 'size' => 16 ) ); ?> اعمال فیلتر</button>
				<?php if ( $bmc_filter_search || $bmc_filter_category || $bmc_filter_status ) : ?>
					<a class="button" href="<?php echo esc_url( $bmc_base_url ); ?>">پاک‌کردن فیلترها</a>
				<?php endif; ?>
			</form>

			<?php if ( empty( $bmc_result['items'] ) ) : ?>
				<div class="bmc-empty-state">
					<?php echo bmc_get_icon( 'inbox', array( 'size' => 34 ) ); ?>
					<p>تیکتی با این فیلترها یافت نشد.</p>
				</div>
			<?php else : ?>
				<table class="bmc-table bmc-table--full">
					<thead>
						<tr>
							<th>کد</th>
							<th>موضوع</th>
							<th>کاربر</th>
							<th>محصول</th>
							<th>دسته</th>
							<th>وضعیت</th>
							<th>اولویت</th>
							<th>آخرین بروزرسانی</th>
							<th>عملیات</th>
						</tr>
					</thead>
					<tbody>
						<?php foreach ( $bmc_result['items'] as $bmc_row ) : ?>
							<?php $bmc_row_status = BMC_Tickets::status_meta( $bmc_row->status ); ?>
							<tr>
								<td class="bmc-mono"><?php echo esc_html( BMC_Tickets::reference( $bmc_row->id ) ); ?></td>
								<td>
									<a class="bmc-rowlink" href="<?php echo esc_url( add_query_arg( 'ticket', (int) $bmc_row->id, $bmc_base_url ) ); ?>">
										<?php echo esc_html( $bmc_row->subject ); ?>
									</a>
									<?php if ( 'user' === $bmc_row->last_reply_by && 'closed' !== $bmc_row->status ) : ?>
										<span class="bmc-dot" title="در انتظار پاسخ شما"></span>
									<?php endif; ?>
								</td>
								<td><?php echo esc_html( BMC_Tickets::display_name( (int) $bmc_row->user_id ) ); ?></td>
								<td><?php echo esc_html( BMC_Tickets::ticket_product_name( $bmc_row ) ? BMC_Tickets::ticket_product_name( $bmc_row ) : '—' ); ?></td>
								<td class="bmc-dim"><?php echo esc_html( BMC_Tickets::category_label( $bmc_row->category ) ); ?></td>
								<td>
									<span class="bmc-pill <?php echo esc_attr( isset( $bmc_tone_map[ $bmc_row->status ] ) ? $bmc_tone_map[ $bmc_row->status ] : '' ); ?>">
										<?php echo esc_html( $bmc_row_status['label'] ); ?>
									</span>
								</td>
								<td>
									<span class="bmc-pill <?php echo esc_attr( isset( $bmc_tone_map[ $bmc_row->priority ] ) ? $bmc_tone_map[ $bmc_row->priority ] : '' ); ?>">
										<?php echo esc_html( BMC_Tickets::priority_label( $bmc_row->priority ) ); ?>
									</span>
								</td>
								<td class="bmc-dim"><?php echo esc_html( BMC_Jalali::format( $bmc_row->updated_at ) ); ?></td>
								<td>
									<div class="bmc-row-actions">
										<a class="button button-small" href="<?php echo esc_url( add_query_arg( 'ticket', (int) $bmc_row->id, $bmc_base_url ) ); ?>">مشاهده و پاسخ</a>
									</div>
								</td>
							</tr>
						<?php endforeach; ?>
					</tbody>
				</table>

				<?php if ( $bmc_result['pages'] > 1 ) : ?>
					<div class="bmc-pagination">
						<?php
						echo wp_kses_post(
							paginate_links(
								array(
									'base'      => add_query_arg( 'paged', '%#%' ),
									'format'    => '',
									'current'   => $bmc_result['page'],
									'total'     => $bmc_result['pages'],
									'prev_text' => '→',
									'next_text' => '←',
								)
							)
						);
						?>
					</div>
				<?php endif; ?>
			<?php endif; ?>
		</div>
	</section>

	<div class="bmc-stats">
		<div class="bmc-stat"><span class="bmc-stat__value"><?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_counts['total'] ) ); ?></span><span class="bmc-stat__label">کل تیکت‌ها</span></div>
		<div class="bmc-stat"><span class="bmc-stat__value"><?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_counts['open'] ) ); ?></span><span class="bmc-stat__label">باز</span></div>
		<div class="bmc-stat"><span class="bmc-stat__value"><?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_counts['answered'] ) ); ?></span><span class="bmc-stat__label">پاسخ داده‌شده</span></div>
		<div class="bmc-stat"><span class="bmc-stat__value"><?php echo esc_html( BMC_Helpers::to_persian_digits( (int) $bmc_counts['closed'] ) ); ?></span><span class="bmc-stat__label">بسته‌شده</span></div>
		<div class="bmc-stat"><span class="bmc-stat__value"><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_attention ) ); ?></span><span class="bmc-stat__label">نیازمند پاسخ</span></div>
	</div>
<?php endif; ?>

<?php
BMC_Admin::form_open( 'tickets' );

BMC_Admin::section_open(
	'تنظیمات سامانهٔ تیکت',
	'تیکت‌ها بخش مستقلی از افزونه هستند: یک تب اختصاصی در پیشخوان و یک بخش در «حساب کاربری» ووکامرس. کاربران دربارهٔ محصولات خریداری‌شده تیکت می‌زنند و شما از همین‌جا پاسخ می‌دهید.'
);

BMC_Admin::row(
	'فعال‌سازی تیکت‌ها',
	BMC_Admin::toggle( 'tickets_enabled', $settings['tickets_enabled'], 'سامانهٔ تیکت پشتیبانی فعال باشد' ),
	'در صورت غیرفعال‌کردن، منوی «تیکت پشتیبانی» از حساب کاربری حذف می‌شود.'
);

BMC_Admin::row(
	'تعداد تیکت در هر صفحه',
	BMC_Admin::input( 'tickets_per_page', (int) $settings['tickets_per_page'], array( 'type' => 'number', 'min' => 5, 'max' => 50 ) ),
	'هم در فهرست پیشخوان و هم در حساب کاربری اعمال می‌شود.'
);

BMC_Admin::row(
	'حداکثر تیکت باز هر کاربر',
	BMC_Admin::input( 'tickets_max_open', (int) $settings['tickets_max_open'], array( 'type' => 'number', 'min' => 0, 'max' => 50, 'placeholder' => 'بدون محدودیت' ) ),
	'عدد ۰ یعنی بدون محدودیت.'
);

BMC_Admin::row(
	'الزام انتخاب محصول',
	BMC_Admin::toggle( 'tickets_require_product', $settings['tickets_require_product'], 'برای تیکت با دستهٔ «محصول خریداری‌شده» انتخاب محصول اجباری باشد' )
);

BMC_Admin::row(
	'بستن تیکت توسط کاربر',
	BMC_Admin::toggle( 'tickets_user_close', $settings['tickets_user_close'], 'کاربر بتواند تیکت خود را ببندد' )
);

BMC_Admin::row(
	'بازکردن دوبارهٔ تیکت',
	BMC_Admin::toggle( 'tickets_user_reopen', $settings['tickets_user_reopen'], 'با پاسخ کاربر، تیکت بسته‌شده دوباره باز شود' )
);

BMC_Admin::row(
	'ایمیل به مدیر',
	BMC_Admin::toggle( 'tickets_email_admin', $settings['tickets_email_admin'], 'برای تیکت جدید و پاسخ کاربر، ایمیل ارسال شود' )
);

BMC_Admin::row(
	'ایمیل به کاربر',
	BMC_Admin::toggle( 'tickets_email_user', $settings['tickets_email_user'], 'برای پاسخ پشتیبانی و بسته‌شدن تیکت، ایمیل ارسال شود' )
);

BMC_Admin::row(
	'گیرندهٔ ایمیل‌های تیکت',
	BMC_Admin::input( 'tickets_admin_email', $settings['tickets_admin_email'], array( 'dir' => 'ltr', 'placeholder' => get_option( 'admin_email' ) ) ),
	'خالی = ایمیل مدیر کل سایت. برای چند گیرنده، آدرس‌ها را با کاما جدا کنید.'
);

BMC_Admin::row(
	'صفحهٔ تیکت‌ها',
	BMC_Admin::page_select( 'page_tickets', $settings['page_tickets'] ),
	'صفحه‌ای با شورت‌کد <code>[bazzarmc_tickets]</code>. اگر ووکامرس فعال باشد، منوی «تیکت پشتیبانی» در حساب کاربری به‌صورت خودکار ساخته می‌شود.'
);

BMC_Admin::section_close();

BMC_Admin::form_close();
