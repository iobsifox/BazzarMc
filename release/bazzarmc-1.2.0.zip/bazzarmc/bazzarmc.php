<?php
/**
 * Plugin Name:       BazzarMc
 * Plugin URI:        https://github.com/iobsifox/BazzarMc
 * Description:       اتصال فروشگاه ووکامرس به سرور ماینکرافت — کد اتصال ۵ دقیقه‌ای، تأیید با پیامک/ایمیل/داشبورد برای لینک‌کردن اکانت، سبد خرید و پرداخت اختصاصی فارسی، تحویل خودکار آیتم‌ها و رنک‌های زمان‌دار، سلسله‌مراتب رنک‌ها با همگام‌سازی از ماینکرافت و سامانهٔ تیکت پشتیبانی.
 * Version:           1.2.0
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Obsifox Studio
 * Author URI:        https://github.com/iobsifox
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       bazzarmc
 * Domain Path:       /languages
 * WC requires at least: 5.0
 * WC tested up to:      9.6
 *
 * @package BazzarMC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( defined( 'BMC_VERSION' ) ) {
	return;
}

define( 'BMC_VERSION', '1.2.0' );
define( 'BMC_DB_VERSION', '1.2.0' );
define( 'BMC_FILE', __FILE__ );
define( 'BMC_PATH', plugin_dir_path( __FILE__ ) );
define( 'BMC_URL', plugin_dir_url( __FILE__ ) );
define( 'BMC_BASENAME', plugin_basename( __FILE__ ) );
define( 'BMC_REST_NS', 'bazzarmc/v1' );
define( 'BMC_LEGACY_REST_NS', 'storelinkformc/v1' );

$bmc_includes = array(
	'includes/class-bmc-icons.php',
	'includes/class-bmc-roles.php',
	'includes/class-bmc-ranks.php',
	'includes/class-bmc-tickets.php',
	'includes/class-bmc-helpers.php',
	'includes/class-bmc-jalali.php',
	'includes/class-bmc-logger.php',
	'includes/class-bmc-settings.php',
	'includes/class-bmc-db.php',
	'includes/class-bmc-link.php',
	'includes/sms/class-bmc-sms-driver.php',
	'includes/sms/class-bmc-sms-email.php',
	'includes/integrations/class-bmc-ezlogin.php',
	'includes/sms/class-bmc-sms-ezlogin.php',
	'includes/class-bmc-sms.php',
	'includes/class-bmc-verify.php',
	'includes/class-bmc-fields.php',
	'includes/class-bmc-cache.php',
	'includes/class-bmc-api.php',
	'includes/class-bmc-deliveries.php',
	'includes/class-bmc-auth.php',
	'includes/class-bmc-checkout.php',
	'includes/class-bmc-cron.php',
	'includes/class-bmc-public.php',
	'includes/class-bmc-admin.php',
	'includes/class-bmc-migrate.php',
);

foreach ( $bmc_includes as $bmc_file ) {
	$bmc_path = BMC_PATH . $bmc_file;
	if ( file_exists( $bmc_path ) ) {
		require_once $bmc_path;
	}
}

register_activation_hook( __FILE__, 'bmc_activate_plugin' );
function bmc_activate_plugin() {
	BMC_DB::install();

	if ( ! BMC_Settings::get( 'api_token' ) ) {
		BMC_Settings::set( 'api_token', BMC_Helpers::random_token( 40 ) );
	}

	BMC_Cron::schedule();

	BMC_Migrate::maybe_create_pages();

	update_option( 'bmc_activated_at', time() );
	update_option( 'bmc_needs_setup', 1 );

	flush_rewrite_rules();
}

register_deactivation_hook( __FILE__, 'bmc_deactivate_plugin' );
function bmc_deactivate_plugin() {
	BMC_Cron::unschedule();
	flush_rewrite_rules();
}

add_action( 'plugins_loaded', 'bmc_bootstrap', 5 );
function bmc_bootstrap() {
	load_plugin_textdomain( 'bazzarmc', false, dirname( BMC_BASENAME ) . '/languages' );

	BMC_DB::maybe_upgrade();
	BMC_Cron::schedule();

	BMC_API::init();
	BMC_EZLogin::init();
	BMC_Link::init();
	BMC_Roles::init();
	BMC_Ranks::init();
	BMC_Tickets::init();
	BMC_Deliveries::init();
	BMC_Auth::init();
	BMC_Verify::init();
	BMC_Fields::init();
	BMC_Cache::init();
	BMC_Checkout::init();
	BMC_Public::init();
	BMC_Migrate::init();

	if ( is_admin() ) {
		BMC_Admin::init();
	}

	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', 'bmc_missing_woocommerce_notice' );
	}
}

function bmc_missing_woocommerce_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	echo '<div class="notice notice-error"><p><strong>BazzarMc:</strong> برای کارکرد کامل، افزونهٔ ووکامرس باید فعال باشد.</p></div>';
}

add_action( 'before_woocommerce_init', 'bmc_declare_hpos_compat' );
function bmc_declare_hpos_compat() {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, false );
	}
}

add_filter( 'plugin_action_links_' . BMC_BASENAME, 'bmc_plugin_action_links' );
function bmc_plugin_action_links( $links ) {
	$url   = admin_url( 'admin.php?page=bazzarmc' );
	$links = array_merge(
		array( '<a href="' . esc_url( $url ) . '">تنظیمات</a>' ),
		(array) $links
	);
	return $links;
}

if ( ! function_exists( 'bmc_get_option' ) ) {

	function bmc_get_option( $key, $default = null ) {
		return BMC_Settings::get( $key, $default );
	}
}

if ( ! function_exists( 'bmc_user_is_linked' ) ) {

	function bmc_user_is_linked( $user_id ) {
		return (bool) BMC_Link::get_linked_player( $user_id );
	}
}

if ( ! function_exists( 'bmc_get_linked_player' ) ) {

	function bmc_get_linked_player( $user_id ) {
		return BMC_Link::get_linked_player( $user_id );
	}
}

if ( ! function_exists( 'bmc_force_link_enabled' ) ) {

	function bmc_force_link_enabled() {
		return BMC_Settings::bool( 'force_link', true );
	}
}

if ( ! function_exists( 'bmc_cart_needs_link' ) ) {

	function bmc_cart_needs_link() {
		return BMC_Checkout::cart_needs_link();
	}
}
