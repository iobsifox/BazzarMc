<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$integrations = BMC_Auth::detected_integrations();

BMC_Admin::form_open( 'login' );

BMC_Admin::section_open(
	'روش‌های تأیید برای اتصال اکانت',
	'این کدها فقط برای <strong>اتصال حساب سایت به ماینکرافت</strong> استفاده می‌شوند (ورود به سایت با موبایل در این افزونه وجود ندارد). هر روش مستقل قابل فعال/غیرفعال‌کردن است.'
);

$bmc_verify_methods = (array) $settings['verify_methods'];
?>
<div class="bmc-checklist bmc-checklist--inline">
	<label class="bmc-check"><input type="checkbox" name="verify_methods[]" value="dashboard" <?php checked( in_array( 'dashboard', $bmc_verify_methods, true ) ); ?> /> <span><?php bmc_icon( 'desktop_windows', array( 'size' => 16 ) ); ?> داشبورد وردپرس و پنل کاربری (بدون هزینه)</span></label>
	<label class="bmc-check"><input type="checkbox" name="verify_methods[]" value="email" <?php checked( in_array( 'email', $bmc_verify_methods, true ) ); ?> /> <span><?php bmc_icon( 'mail', array( 'size' => 16 ) ); ?> ایمیل</span></label>
	<label class="bmc-check"><input type="checkbox" name="verify_methods[]" value="sms" <?php checked( in_array( 'sms', $bmc_verify_methods, true ) ); ?> /> <span><?php bmc_icon( 'smartphone', array( 'size' => 16 ) ); ?> پیامک (نیاز به کانال ارسال در تب پیامک)</span></label>
</div>
<p class="bmc-hint">حداقل یک روش باید فعال باشد. روش «داشبورد» همیشه رایگان است و کد در همان صفحه به کاربر نشان داده می‌شود.</p>
<?php

BMC_Admin::row(
	'روش پیش‌فرض',
	BMC_Admin::select(
		'verify_default',
		$settings['verify_default'],
		array(
			'dashboard' => 'داشبورد سایت',
			'email'     => 'ایمیل',
			'sms'       => 'پیامک',
		)
	),
	'اگر روش پیش‌فرض فعال نباشد، افزونه به اولین روش فعال برمی‌گردد.'
);

BMC_Admin::row( 'ویجت پیشخوان مدیر', BMC_Admin::toggle( 'otp_dashboard_widget', $settings['otp_dashboard_widget'], 'کدهای فعال در پیشخوان وردپرس نمایش داده شود' ), 'برای پشتیبانی سریع کاربران؛ فقط مدیران و مدیران فروشگاه می‌بینند.' );
BMC_Admin::row( 'جعبهٔ کد در پنل کاربری', BMC_Admin::toggle( 'otp_dashboard_box', $settings['otp_dashboard_box'], 'کد در کارت حساب کاربری و پنل اتصال نمایش داده شود' ), 'وقتی کاربر وارد شده باشد، کد به‌جای پیامک در همان صفحه نشان داده می‌شود و خودکار پر می‌شود.' );

BMC_Admin::section_close();

BMC_Admin::section_open( 'شمارهٔ موبایل کاربران', 'فقط برای فرستادن کد اتصال با پیامک استفاده می‌شود. اگر افزونهٔ دیگری مثل ایزی‌لاگین یا دیجیتس نصب دارید، شماره از همان افزونه خوانده می‌شود.' );

if ( $integrations ) {
	echo '<div class="bmc-note bmc-note--ok">' . bmc_get_icon( 'check_circle', array( 'size' => 16 ) ) . ' افزونه‌های شناسایی‌شده: <strong>' . esc_html( implode( '، ', array_keys( $integrations ) ) ) . '</strong></div>';
} else {
	echo '<div class="bmc-note">' . bmc_get_icon( 'info', array( 'size' => 16 ) ) . ' افزونهٔ پیامکی دیگری شناسایی نشد؛ شماره از فیلد تلفن ووکامرس و کلیدهای زیر خوانده می‌شود.</div>';
}

BMC_Admin::row(
	'کلیدهای متای شمارهٔ موبایل',
	'<input class="bmc-input" type="text" name="mobile_meta_keys" value="' . esc_attr( implode( ',', (array) $settings['mobile_meta_keys'] ) ) . '" dir="ltr" />'
		. '<div class="bmc-inline" style="margin-top:8px">'
		. '<button type="button" class="button bmc-action" data-do="detect_mobile_keys" data-target="#bmcDetectedKeys">شناسایی خودکار کلیدها</button>'
		. '<button type="button" class="button bmc-action" data-do="sync_mobiles">یکسان‌سازی شمارهٔ همهٔ کاربران</button>'
		. '</div>'
		. '<div id="bmcDetectedKeys" class="bmc-detect"></div>',
	'با کاما جدا کنید. کلیدهای شناخته‌شده به‌صورت خودکار هم بررسی می‌شوند: <code>digits_number</code>، <code>digcell</code>، <code>easylogin_mobile</code>، <code>billing_phone</code> و…'
);

BMC_Admin::section_close();

BMC_Admin::section_open( 'پنل حساب کاربری (حساب من)', 'کارت اختصاصی BazzarMc جای متن پیش‌فرض ووکامرس در صفحهٔ «حساب کاربری» می‌نشیند.' );

BMC_Admin::row(
	'کارت حساب کاربری',
	BMC_Admin::toggle( 'myaccount_card', $settings['myaccount_card'], 'نمایش کارت BazzarMc در داشبورد حساب کاربری ووکامرس' ),
	'این کارت نام واقعی کاربر، جعبهٔ اکانت ماینکرافت (با دکمهٔ اتصال در صورت متصل نبودن) و رنک‌های خریداری‌شده همراه با زمان باقی‌مانده را نشان می‌دهد.'
);

BMC_Admin::section_close();

BMC_Admin::section_open( 'صفحه‌های افزونه' );

BMC_Admin::row( 'صفحهٔ اتصال اکانت', BMC_Admin::page_select( 'page_link', (int) $settings['page_link'] ), 'شورت‌کد: <code>[bazzarmc]</code> — در حساب کاربری ووکامرس هم به‌صورت تب «اتصال ماینکرافت» اضافه می‌شود.' );
BMC_Admin::row( 'صفحهٔ سبد خرید', BMC_Admin::page_select( 'page_cart', (int) $settings['page_cart'] ), 'شورت‌کد: <code>[bazzarmc_cart]</code> — سبد کامل فارسی + پرداخت در همان صفحه.' );
BMC_Admin::row( 'صفحهٔ پرداخت', BMC_Admin::page_select( 'page_checkout', (int) $settings['page_checkout'] ), 'شورت‌کد: <code>[bazzarmc_checkout]</code>' );

echo '<div class="bmc-inline" style="margin-top:10px"><button type="button" class="button bmc-action" data-do="create_pages">ساخت خودکار صفحه‌ها</button></div>';

BMC_Admin::section_close();

BMC_Admin::form_close();
