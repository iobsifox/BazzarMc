<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

BMC_Admin::form_open( 'messages' );

BMC_Admin::section_open( 'متن‌های رابط کاربری', 'همهٔ متن‌ها فارسی هستند و می‌توانید آن‌ها را تغییر دهید.' );

BMC_Admin::row( 'عنوان بخش اتصال', BMC_Admin::input( 'txt_link_title', $settings['txt_link_title'] ) );
BMC_Admin::row( 'عنوان پیام «متصل نیستید»', BMC_Admin::input( 'txt_not_linked_title', $settings['txt_not_linked_title'] ) );
BMC_Admin::row( 'متن پیام «متصل نیستید»', BMC_Admin::textarea( 'txt_not_linked_body', $settings['txt_not_linked_body'], 3 ), 'در صفحهٔ خرید وقتی اکانت متصل نباشد نمایش داده می‌شود.' );

BMC_Admin::section_close();

BMC_Admin::row( 'عنوان حالت متصل', BMC_Admin::input( 'txt_linked_title', $settings['txt_linked_title'] ), 'وقتی کاربر اکانتش متصل است.' );
BMC_Admin::row(
	'متن مسدودسازی سبد',
	BMC_Admin::textarea( 'txt_cart_blocked', $settings['txt_cart_blocked'], 3 ),
	'وقتی اکانت متصل نیست، به‌جای دکمهٔ پرداخت در سبد خرید نمایش داده می‌شود. متغیر: <code>{connect_url}</code>'
);
BMC_Admin::row(
	'متن صفحهٔ تشکر',
	BMC_Admin::textarea( 'txt_thankyou', $settings['txt_thankyou'], 4 ),
	'متغیرها: <code>{player}</code> <code>{server}</code> <code>{order}</code> <code>{site}</code>'
);

BMC_Admin::section_close();

BMC_Admin::section_open( 'شورت‌کدها', 'این شورت‌کدها را در برگه‌ها یا قالب خود قرار دهید.' );

$shortcodes = array(
	'[bazzarmc]'         => 'پنل اتصال اکانت ماینکرافت (ساخت کد ۵ دقیقه‌ای، اتصال با پیامک، وضعیت اتصال و قطع اتصال)',
	'[bazzarmc_cart]'     => 'سبد خرید اختصاصی با پرداخت در همان صفحه',
	'[bazzarmc_tickets]'  => 'سیستم تیکت پشتیبانی',
	'[bazzarmc_status]'  => 'نمایش کوچک وضعیت اتصال کاربر',
	'[bazzarmc_checkout]' => 'چک‌اوت اختصاصی (به‌صورت دستی در هر صفحه)',
);

echo '<table class="bmc-table bmc-table--full"><tbody>';
foreach ( $shortcodes as $code => $desc ) {
	printf(
		'<tr><td style="width:230px"><code class="bmc-token bmc-token--sm" dir="ltr">%1$s</code></td><td>%2$s</td></tr>',
		esc_html( $code ),
		esc_html( $desc )
	);
}
echo '</tbody></table>';

BMC_Admin::section_close();

BMC_Admin::form_close();
