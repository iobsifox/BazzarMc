<?php

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

$bmc_user = wp_get_current_user();
$bmc_uid  = (int) $bmc_user->ID;

$bmc_first = trim( (string) get_user_meta( $bmc_uid, 'first_name', true ) );
$bmc_last  = trim( (string) get_user_meta( $bmc_uid, 'last_name', true ) );

if ( '' === $bmc_first && '' === $bmc_last ) {
	$bmc_first = trim( (string) get_user_meta( $bmc_uid, 'billing_first_name', true ) );
	$bmc_last  = trim( (string) get_user_meta( $bmc_uid, 'billing_last_name', true ) );
}

$bmc_realname = trim( $bmc_first . ' ' . $bmc_last );

if ( '' === $bmc_realname ) {
	$bmc_realname = (string) $bmc_user->display_name;
}

$bmc_email   = (string) $bmc_user->user_email;
$bmc_mobile  = (string) BMC_Auth::get_user_mobile( $bmc_uid );
$bmc_player  = (string) BMC_Link::get_linked_player( $bmc_uid );
$bmc_linked  = BMC_Link::is_linked( $bmc_uid );
$bmc_uuid    = (string) BMC_Link::get_linked_uuid( $bmc_uid );
$bmc_link_at = (int) get_user_meta( $bmc_uid, BMC_Link::META_LINKED_AT, true );
$bmc_grants  = BMC_Roles::active_grants( $bmc_uid );
$bmc_connect = BMC_Checkout::connect_url();
$bmc_manage  = function_exists( 'wc_get_account_endpoint_url' ) ? wc_get_account_endpoint_url( BMC_Public::ENDPOINT ) : $bmc_connect;
$bmc_initial = function_exists( 'mb_substr' ) ? mb_substr( $bmc_realname, 0, 1 ) : substr( $bmc_realname, 0, 1 );

$bmc_orders_count = 0;
$bmc_orders_url   = function_exists( 'wc_get_account_endpoint_url' ) ? wc_get_account_endpoint_url( 'orders' ) : '#';

if ( function_exists( 'wc_get_orders' ) ) {
	$bmc_orders_count = count(
		wc_get_orders(
			array(
				'customer' => $bmc_uid,
				'limit'    => -1,
				'return'   => 'ids',
			)
		)
	);
}

$bmc_role_labels = array();

foreach ( (array) $bmc_user->roles as $bmc_role_slug ) {
	if ( in_array( $bmc_role_slug, array( 'customer', 'subscriber' ), true ) ) {
		continue;
	}

	$bmc_role_labels[] = BMC_Roles::role_label( $bmc_role_slug );
}

$bmc_addresses_url = function_exists( 'wc_get_account_endpoint_url' ) ? wc_get_account_endpoint_url( 'edit-address' ) : '#';

$bmc_tickets_enabled = BMC_Tickets::enabled();
$bmc_tickets_url     = $bmc_tickets_enabled ? BMC_Tickets::url() : '#';
$bmc_tickets_open    = $bmc_tickets_enabled ? (int) BMC_Tickets::open_tickets_note( $bmc_uid ) : 0;
$bmc_tickets_new     = $bmc_tickets_enabled ? (int) BMC_Tickets::unread_for_user( $bmc_uid ) : 0;
$bmc_details_url   = function_exists( 'wc_get_account_endpoint_url' ) ? wc_get_account_endpoint_url( 'edit-account' ) : '#';
$bmc_logout_url    = wp_logout_url( home_url( '/' ) );

$bmc_allowed_html = array(
	'a' => array(
		'href' => array(),
	),
);
?>

<p>
	<?php
	printf(
		wp_kses( __( 'Hello %1$s (not %1$s? <a href="%2$s">Log out</a>)', 'woocommerce' ), $bmc_allowed_html ),
		'<strong>' . esc_html( $bmc_user->display_name ) . '</strong>',
		esc_url( $bmc_logout_url )
	);
	?>
</p>

<div class="bmc-acard">
	<div class="bmc-acard__head">
		<div class="bmc-acard__avatar">
			<?php if ( $bmc_linked && $bmc_player ) : ?>
				<img src="<?php echo esc_url( BMC_Helpers::mc_head( $bmc_player, 96 ) ); ?>" alt="" width="64" height="64" />
			<?php else : ?>
				<span><?php echo esc_html( $bmc_initial ); ?></span>
			<?php endif; ?>
		</div>

		<div class="bmc-acard__id">
			<span class="bmc-acard__kicker"><?php bmc_icon( 'waving_hand', array( 'size' => 15 ) ); ?> <?php echo esc_html( BMC_Helpers::to_persian_digits( (int) gmdate( 'G', BMC_Helpers::now_timestamp() ) ) < 12 ? 'صبح بخیر' : 'وقت بخیر' ); ?></span>
			<h2 class="bmc-acard__name"><?php echo esc_html( $bmc_realname ); ?></h2>
			<div class="bmc-acard__meta">
				<?php if ( $bmc_email ) : ?>
					<span><?php bmc_icon( 'mail', array( 'size' => 14 ) ); ?> <?php echo esc_html( $bmc_email ); ?></span>
				<?php endif; ?>
				<?php if ( $bmc_mobile ) : ?>
					<span dir="ltr"><?php bmc_icon( 'smartphone', array( 'size' => 14 ) ); ?> <?php echo esc_html( $bmc_mobile ); ?></span>
				<?php endif; ?>
				<span><?php bmc_icon( 'receipt_long', array( 'size' => 14 ) ); ?> <?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_orders_count ) ); ?> سفارش</span>
				<?php if ( $bmc_role_labels ) : ?>
					<span class="bmc-acard__role"><?php bmc_icon( 'workspace_premium', array( 'size' => 14 ) ); ?> <?php echo esc_html( implode( '، ', $bmc_role_labels ) ); ?></span>
				<?php endif; ?>
			</div>
		</div>
	</div>

	<div class="bmc-acard__grid">
		<section class="bmc-acard__box<?php echo $bmc_linked ? ' is-on' : ' is-off'; ?>">
			<header class="bmc-acard__boxlabel">
				<?php bmc_icon( 'sports_esports', array( 'size' => 16 ) ); ?>
				اکانت ماینکرافت
				<?php if ( $bmc_linked ) : ?>
					<span class="bmc-chip bmc-chip--ok"><?php bmc_icon( 'verified', array( 'size' => 13 ) ); ?> متصل</span>
				<?php else : ?>
					<span class="bmc-chip bmc-chip--off"><?php bmc_icon( 'link_off', array( 'size' => 13 ) ); ?> متصل نیست</span>
				<?php endif; ?>
			</header>

			<?php if ( $bmc_linked && $bmc_player ) : ?>
				<div class="bmc-mc">
					<img class="bmc-mc__head" src="<?php echo esc_url( BMC_Helpers::mc_head( $bmc_player, 64 ) ); ?>" alt="" width="44" height="44" />
					<div class="bmc-mc__body">
						<strong dir="ltr"><?php echo esc_html( $bmc_player ); ?></strong>
						<?php if ( $bmc_uuid ) : ?>
							<small dir="ltr"><?php echo esc_html( $bmc_uuid ); ?></small>
						<?php endif; ?>
					</div>
				</div>

				<ul class="bmc-acard__facts">
					<?php if ( $bmc_link_at ) : ?>
						<li><?php bmc_icon( 'calendar_month', array( 'size' => 14 ) ); ?> تاریخ اتصال: <?php echo esc_html( BMC_Jalali::format( $bmc_link_at, false ) ); ?></li>
					<?php endif; ?>
					<li><?php bmc_icon( 'inventory', array( 'size' => 14 ) ); ?> آیتم‌های خریداری‌شده در اولین ورود به سرور تحویل می‌شود.</li>
				</ul>

				<a class="bmc-btn bmc-btn-o bmc-btn-sm" href="<?php echo esc_url( $bmc_manage ); ?>"><?php bmc_icon( 'settings', array( 'size' => 15 ) ); ?> مدیریت اتصال</a>
			<?php else : ?>
				<p class="bmc-acard__hint">
					حساب شما هنوز به اکانت ماینکرافت متصل نیست. برای دریافت آیتم‌های خریداری‌شده در بازی، اکانت خود را متصل کنید.
				</p>
				<a class="bmc-btn bmc-btn-p bmc-btn-sm" href="<?php echo esc_url( $bmc_connect ); ?>"><?php bmc_icon( 'link', array( 'size' => 15 ) ); ?> اتصال اکانت ماینکرافت</a>
			<?php endif; ?>
		</section>

		<section class="bmc-acard__box bmc-acard__box--rank">
			<header class="bmc-acard__boxlabel">
				<?php bmc_icon( 'workspace_premium', array( 'size' => 16 ) ); ?>
				رنک‌های شما
				<span class="bmc-chip"><?php bmc_icon( 'category', array( 'size' => 13 ) ); ?> <?php echo esc_html( BMC_Helpers::to_persian_digits( count( $bmc_grants ) ) ); ?> مورد</span>
			</header>

			<?php if ( $bmc_grants ) : ?>
				<div class="bmc-ranks">
					<?php foreach ( $bmc_grants as $bmc_grant ) : ?>
						<?php
						$bmc_days   = max( 1, (int) ( isset( $bmc_grant['days'] ) ? $bmc_grant['days'] : 0 ) );
						$bmc_pct    = empty( $bmc_grant['permanent'] ) ? max( 2, min( 100, (int) round( ( (int) $bmc_grant['remaining'] / ( $bmc_days * DAY_IN_SECONDS ) ) * 100 ) ) ) : 100;
						$bmc_urgent = ! empty( $bmc_grant['permanent'] ) ? false : (int) $bmc_grant['remaining'] < ( 3 * DAY_IN_SECONDS );
						?>
						<article class="bmc-rank<?php echo $bmc_urgent ? ' is-urgent' : ''; ?>">
							<span class="bmc-rank__icon"><?php bmc_icon( $bmc_urgent ? 'hourglass_bottom' : 'trophy', array( 'size' => 18 ) ); ?></span>
							<div class="bmc-rank__body">
								<strong><?php echo esc_html( $bmc_grant['label'] ? $bmc_grant['label'] : $bmc_grant['role_label'] ); ?></strong>
								<small><?php bmc_icon( 'badge', array( 'size' => 12 ) ); ?> نقش: <?php echo esc_html( $bmc_grant['role_label'] ); ?><?php echo empty( $bmc_grant['still_has_role'] ) ? ' — در انتظار اعمال' : ''; ?></small>
							</div>
							<div class="bmc-rank__time">
								<span class="bmc-pill<?php echo $bmc_urgent ? ' bmc-pill--warn' : ''; ?>">
									<?php bmc_icon( empty( $bmc_grant['permanent'] ) ? 'all_inclusive' : 'timer', array( 'size' => 13 ) ); ?>
									<?php echo esc_html( $bmc_grant['remaining_human'] ); ?>
									<?php echo empty( $bmc_grant['permanent'] ) ? ' باقی مانده' : ''; ?>
								</span>
								<?php if ( empty( $bmc_grant['permanent'] ) && ! empty( $bmc_grant['expires_jalali'] ) ) : ?>
									<small><?php bmc_icon( 'calendar_month', array( 'size' => 12 ) ); ?> تا <?php echo esc_html( $bmc_grant['expires_jalali'] ); ?></small>
									<span class="bmc-bar"><i style="width:<?php echo esc_attr( $bmc_pct ); ?>%"></i></span>
								<?php endif; ?>
							</div>
						</article>
					<?php endforeach; ?>
				</div>
			<?php else : ?>
				<p class="bmc-acard__hint">هنوز رنکی خریداری نکرده‌اید. با خرید رنک، نقش مربوطه به‌صورت خودکار به حساب شما اضافه می‌شود.</p>
				<a class="bmc-btn bmc-btn-o bmc-btn-sm" href="<?php echo esc_url( function_exists( 'wc_get_page_permalink' ) ? wc_get_page_permalink( 'shop' ) : home_url( '/' ) ); ?>"><?php bmc_icon( 'storefront', array( 'size' => 15 ) ); ?> مشاهدهٔ فروشگاه</a>
			<?php endif; ?>
		</section>
	</div>

	<nav class="bmc-acard__links">
		<a href="<?php echo esc_url( $bmc_orders_url ); ?>"><?php bmc_icon( 'receipt_long', array( 'size' => 15 ) ); ?> سفارش‌ها</a>
		<a href="<?php echo esc_url( $bmc_addresses_url ); ?>"><?php bmc_icon( 'location_on', array( 'size' => 15 ) ); ?> آدرس‌ها</a>
		<a href="<?php echo esc_url( $bmc_details_url ); ?>"><?php bmc_icon( 'person', array( 'size' => 15 ) ); ?> جزئیات حساب</a>
		<a href="<?php echo esc_url( function_exists( 'wc_get_cart_url' ) ? wc_get_cart_url() : home_url( '/' ) ); ?>"><?php bmc_icon( 'shopping_cart', array( 'size' => 15 ) ); ?> سبد خرید</a>
		<?php if ( $bmc_tickets_enabled ) : ?>
			<a href="<?php echo esc_url( $bmc_tickets_url ); ?>">
				<?php bmc_icon( 'support_agent', array( 'size' => 15 ) ); ?> پشتیبانی
				<?php if ( $bmc_tickets_open > 0 ) : ?>
					<span class="bmc-acard__count"><?php echo esc_html( BMC_Helpers::to_persian_digits( $bmc_tickets_open ) ); ?></span>
				<?php endif; ?>
				<?php if ( $bmc_tickets_new > 0 ) : ?>
					<span class="bmc-acard__new">پاسخ جدید</span>
				<?php endif; ?>
			</a>
		<?php endif; ?>
		<a class="bmc-acard__logout" href="<?php echo esc_url( $bmc_logout_url ); ?>"><?php bmc_icon( 'logout', array( 'size' => 15 ) ); ?> خروج</a>
	</nav>
</div>

<?php
do_action( 'woocommerce_account_dashboard' );
do_action( 'woocommerce_before_my_account' );
do_action( 'woocommerce_after_my_account' );
