<?php
/**
 * Plugin Name:       BazzarMc
 * Plugin URI:        https://github.com/iobsifox/BazzarMc
 * Description:       اتصال فروشگاه ووکامرس به سرور ماینکرافت — کد اتصال ۵ دقیقه‌ای، تأیید با ایمیل/داشبورد برای لینک‌کردن اکانت، سبد خرید و صفحهٔ پرداخت جدا از هم، ویترین محصولات با نوار فیلتر دسته‌بندی، کارت محصول و پنجرهٔ مشاهدهٔ سریع، فرم‌ساز پرداخت و فرم‌ساز دلخواه، سامانهٔ تیکت پشتیبانی، کارت حساب کاربری وابسته به بخش، نقطه‌های فرود حساب کاربری تنظیم‌شدنی و همگام با ووکامرس، به‌روزرسانی خودکار از صفحهٔ افزونه‌ها، گزارش دلیل تحویل‌نشدن خریدها، محافظ پایداری (حالت ایمن خودکار) و ویجت‌های المنتور برای طراحی کامل فروشگاه و صفحهٔ حساب کاربری.
 * Version:           1.8.2
 * Requires at least: 6.0
 * Requires PHP:      7.4
 * Author:            Obsifox Studio
 * Author URI:        https://github.com/iobsifox
 * License:           GPL-2.0-or-later
 * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
 * Text Domain:       bazzarmc
 * Domain Path:       /languages
 * WC requires at least: 5.0
 * WC tested up to:      9.6
 *
 * @package BazzarMC
 */

if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

if ( defined( 'BMC_VERSION' ) ) {
	return;
}

define( 'BMC_VERSION', '1.8.2' );
define( 'BMC_DB_VERSION', '1.8.1' );
define( 'BMC_FILE', __FILE__ );
define( 'BMC_PATH', plugin_dir_path( __FILE__ ) );
define( 'BMC_URL', plugin_dir_url( __FILE__ ) );
define( 'BMC_BASENAME', plugin_basename( __FILE__ ) );
define( 'BMC_REST_NS', 'bazzarmc/v1' );
define( 'BMC_LEGACY_REST_NS', 'storelinkformc/v1' );

$bmc_includes = array(
	'includes/class-bmc-safe.php',
	'includes/class-bmc-icons.php',
	'includes/class-bmc-roles.php',
	'includes/class-bmc-ranks.php',
	'includes/class-bmc-tickets.php',
	'includes/class-bmc-helpers.php',
	'includes/class-bmc-jalali.php',
	'includes/class-bmc-logger.php',
	'includes/class-bmc-settings.php',
	'includes/class-bmc-db.php',
	'includes/class-bmc-link.php',
	'includes/integrations/class-bmc-ezlogin.php',
	'includes/integrations/class-bmc-elementor.php',
	'includes/class-bmc-verify.php',
	'includes/class-bmc-fields.php',
	'includes/class-bmc-cache.php',
	'includes/class-bmc-forms.php',
	'includes/class-bmc-checkout-fields.php',
	'includes/class-bmc-api.php',
	'includes/class-bmc-deliveries.php',
	'includes/class-bmc-auth.php',
	'includes/class-bmc-checkout.php',
	'includes/class-bmc-catalog.php',
	'includes/class-bmc-account-endpoints.php',
	'includes/class-bmc-account-card.php',
	'includes/class-bmc-updater.php',
	'includes/class-bmc-cron.php',
	'includes/class-bmc-public.php',
	'includes/class-bmc-admin.php',
	'includes/class-bmc-migrate.php',
);

function bmc_log_bootstrap_error( $where, $error ) {
	$message = ( $error instanceof Throwable ) ? $error->getMessage() : (string) $error;
	$line    = ( $error instanceof Throwable ) ? (int) $error->getLine() : 0;

	error_log( 'BazzarMc bootstrap: ' . $where . ' - ' . $message . ' (line ' . $line . ')' ); // phpcs:ignore WordPress.PHP.DevelopmentFunctions.error_log_error_log

	$failed = get_option( 'bmc_bootstrap_errors', array() );

	if ( ! is_array( $failed ) ) {
		$failed = array();
	}

	$failed[ (string) $where ] = array(
		'message' => $message,
		'line'    => $line,
		'time'    => time(),
	);

	if ( count( $failed ) > 20 ) {
		$failed = array_slice( $failed, -20, null, true );
	}

	update_option( 'bmc_bootstrap_errors', $failed, false );

	if ( class_exists( 'BMC_Safe' ) ) {
		BMC_Safe::collect( 'bootstrap:' . $where, $error );
	}
}

foreach ( $bmc_includes as $bmc_file ) {
	$bmc_path = BMC_PATH . $bmc_file;

	if ( ! file_exists( $bmc_path ) ) {
		continue;
	}

	try {
		require_once $bmc_path;
	} catch ( Throwable $bmc_error ) {
		bmc_log_bootstrap_error( $bmc_file, $bmc_error );
	}
}

if ( class_exists( 'BMC_Safe' ) ) {
	BMC_Safe::boot();
}

register_activation_hook( __FILE__, 'bmc_activate_plugin' );
function bmc_activate_plugin() {
	if ( class_exists( 'BMC_DB' ) ) {
		BMC_DB::install();
	}

	if ( class_exists( 'BMC_Safe' ) ) {
		BMC_Safe::reset();
		BMC_Safe::deactivate();
	}

	if ( class_exists( 'BMC_Settings' ) && ! BMC_Settings::get( 'api_token' ) ) {
		BMC_Settings::set( 'api_token', BMC_Helpers::random_token( 40 ) );
	}

	if ( class_exists( 'BMC_Cron' ) ) {
		BMC_Cron::schedule();
	}

	if ( class_exists( 'BMC_Migrate' ) ) {
		BMC_Migrate::maybe_create_pages();
	}

	update_option( 'bmc_activated_at', time() );
	update_option( 'bmc_needs_setup', 1 );

	flush_rewrite_rules();
}

register_deactivation_hook( __FILE__, 'bmc_deactivate_plugin' );
function bmc_deactivate_plugin() {
	if ( class_exists( 'BMC_Cron' ) ) {
		BMC_Cron::unschedule();
	}

	flush_rewrite_rules();
}

add_action( 'plugins_loaded', 'bmc_bootstrap', 5 );
function bmc_bootstrap() {
	load_plugin_textdomain( 'bazzarmc', false, dirname( BMC_BASENAME ) . '/languages' );

	bmc_run_module( 'BMC_Migrate', 'maybe_upgrade' );

	$bmc_safe_mode = class_exists( 'BMC_Safe' ) && BMC_Safe::safe_mode();

	bmc_run_module( 'BMC_DB', 'maybe_upgrade' );
	bmc_run_module( 'BMC_Cron', 'schedule' );

	bmc_run_module( 'BMC_API', 'init' );
	bmc_run_module( 'BMC_EZLogin', 'init' );

	if ( ! $bmc_safe_mode ) {
		bmc_run_module( 'BMC_Elementor', 'init' );
	}

	bmc_run_module( 'BMC_Link', 'init' );
	bmc_run_module( 'BMC_Roles', 'init' );
	bmc_run_module( 'BMC_Ranks', 'init' );
	bmc_run_module( 'BMC_Tickets', 'init' );
	bmc_run_module( 'BMC_Deliveries', 'init' );
	bmc_run_module( 'BMC_Auth', 'init' );
	bmc_run_module( 'BMC_Verify', 'init' );
	bmc_run_module( 'BMC_Fields', 'init' );
	bmc_run_module( 'BMC_Cache', 'init' );
	bmc_run_module( 'BMC_Forms', 'init' );
	bmc_run_module( 'BMC_Checkout', 'init' );
	bmc_run_module( 'BMC_Checkout_Fields', 'init' );
	bmc_run_module( 'BMC_Public', 'init' );
	bmc_run_module( 'BMC_Account_Card', 'init' );
	bmc_run_module( 'BMC_Catalog', 'init' );
	bmc_run_module( 'BMC_Account_Endpoints', 'init' );
	bmc_run_module( 'BMC_Updater', 'init' );
	bmc_run_module( 'BMC_Migrate', 'init' );

	if ( is_admin() ) {
		bmc_run_module( 'BMC_Admin', 'init' );
	}

	if ( ! class_exists( 'WooCommerce' ) ) {
		add_action( 'admin_notices', 'bmc_missing_woocommerce_notice' );
	}
}

function bmc_run_module( $class, $method = 'init' ) {
	if ( ! class_exists( $class ) ) {
		bmc_log_bootstrap_error( $class . ' (missing)', 'کلاس پیدا نشد' );
		return;
	}

	if ( ! method_exists( $class, $method ) ) {
		return;
	}

	try {
		call_user_func( array( $class, $method ) );
	} catch ( Throwable $bmc_error ) {
		bmc_log_bootstrap_error( $class . '::' . $method, $bmc_error );

		if ( class_exists( 'BMC_Safe' ) && 'BMC_Safe' !== $class ) {
			BMC_Safe::record_fatal(
				array(
					'message' => $class . '::' . $method . ' - ' . $bmc_error->getMessage(),
					'file'    => $bmc_error->getFile(),
					'line'    => $bmc_error->getLine(),
				)
			);
		}
	}
}

function bmc_missing_woocommerce_notice() {
	if ( ! current_user_can( 'activate_plugins' ) ) {
		return;
	}
	echo '<div class="notice notice-error"><p><strong>BazzarMc:</strong> برای کارکرد کامل، افزونهٔ ووکامرس باید فعال باشد.</p></div>';
}

add_action( 'before_woocommerce_init', 'bmc_declare_hpos_compat' );
function bmc_declare_hpos_compat() {
	if ( class_exists( '\Automattic\WooCommerce\Utilities\FeaturesUtil' ) ) {
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'custom_order_tables', __FILE__, true );
		\Automattic\WooCommerce\Utilities\FeaturesUtil::declare_compatibility( 'cart_checkout_blocks', __FILE__, false );
	}
}

add_filter( 'plugin_action_links_' . BMC_BASENAME, 'bmc_plugin_action_links' );
function bmc_plugin_action_links( $links ) {
	$url   = admin_url( 'admin.php?page=bazzarmc' );
	$links = array_merge(
		array( '<a href="' . esc_url( $url ) . '">تنظیمات</a>' ),
		(array) $links
	);
	return $links;
}

if ( ! function_exists( 'bmc_get_option' ) ) {

	function bmc_get_option( $key, $default = null ) {
		return BMC_Settings::get( $key, $default );
	}
}

if ( ! function_exists( 'bmc_user_is_linked' ) ) {

	function bmc_user_is_linked( $user_id ) {
		return (bool) BMC_Link::get_linked_player( $user_id );
	}
}

if ( ! function_exists( 'bmc_get_linked_player' ) ) {

	function bmc_get_linked_player( $user_id ) {
		return BMC_Link::get_linked_player( $user_id );
	}
}

if ( ! function_exists( 'bmc_force_link_enabled' ) ) {

	function bmc_force_link_enabled() {
		return BMC_Settings::bool( 'force_link', true );
	}
}

if ( ! function_exists( 'bmc_cart_needs_link' ) ) {

	function bmc_cart_needs_link() {
		return BMC_Checkout::cart_needs_link();
	}
}
